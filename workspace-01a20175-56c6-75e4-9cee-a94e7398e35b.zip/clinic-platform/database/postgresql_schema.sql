-- ============================================================================
-- Dr. Aparna Mishra Digital Clinic — Production PostgreSQL Schema (v16+)
-- Compliant with India DPDP Act 2023 & Telemedicine Practice Guidelines
-- ============================================================================

CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- 1. USERS (Unified identity with strict RBAC)
CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email VARCHAR(255) UNIQUE NOT NULL,
  phone VARCHAR(20) UNIQUE,
  password_hash TEXT,
  full_name VARCHAR(160) NOT NULL,
  role VARCHAR(20) NOT NULL CHECK (role IN ('PATIENT', 'DOCTOR', 'STAFF', 'ADMIN')),
  auth_provider VARCHAR(30) NOT NULL DEFAULT 'EMAIL' CHECK (auth_provider IN ('EMAIL', 'MOBILE_OTP', 'GOOGLE', 'APPLE')),
  email_verified BOOLEAN NOT NULL DEFAULT FALSE,
  phone_verified BOOLEAN NOT NULL DEFAULT FALSE,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  is_demo BOOLEAN NOT NULL DEFAULT FALSE,
  last_login_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_users_role ON users(role);
CREATE INDEX idx_users_phone ON users(phone);

-- 2. PATIENT PROFILES (Includes Minor / Legal Guardian support)
CREATE TABLE patient_profiles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID UNIQUE NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  patient_code VARCHAR(24) UNIQUE NOT NULL,
  date_of_birth DATE,
  gender VARCHAR(24),
  blood_group VARCHAR(10),
  city VARCHAR(100),
  state VARCHAR(100),
  address TEXT,
  allergies TEXT,
  chronic_conditions TEXT,
  current_medications TEXT,
  emergency_contact_name VARCHAR(160),
  emergency_contact_phone VARCHAR(20),
  is_minor_account BOOLEAN NOT NULL DEFAULT FALSE,
  guardian_name VARCHAR(160),
  guardian_relation VARCHAR(60),
  minor_patient_name VARCHAR(160),
  minor_date_of_birth DATE,
  deletion_requested_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_patient_profiles_user ON patient_profiles(user_id);

-- 3. DOCTOR PROFILES
CREATE TABLE doctor_profiles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID UNIQUE NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  display_name VARCHAR(160) NOT NULL,
  qualification VARCHAR(160) NOT NULL,
  specialisation VARCHAR(200) NOT NULL,
  experience_years INTEGER NOT NULL DEFAULT 7,
  registration_number VARCHAR(120) NOT NULL,
  registration_council VARCHAR(200) NOT NULL,
  tagline VARCHAR(255) NOT NULL,
  bio TEXT NOT NULL,
  consultation_mode VARCHAR(120) NOT NULL DEFAULT 'Online (Video & Audio)',
  timings_summary VARCHAR(200) NOT NULL DEFAULT 'Monday to Saturday, 3:00 PM – 8:00 PM IST',
  languages VARCHAR(200) NOT NULL DEFAULT 'English, Hindi',
  clinic_name VARCHAR(200) NOT NULL,
  clinic_address TEXT NOT NULL,
  clinic_city VARCHAR(100) NOT NULL,
  map_embed_url TEXT,
  phone VARCHAR(24) NOT NULL,
  whatsapp_number VARCHAR(24) NOT NULL,
  email VARCHAR(255) NOT NULL,
  photo_url TEXT NOT NULL,
  upi_id VARCHAR(120),
  upi_payee_name VARCHAR(160),
  upi_qr_url TEXT,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 4. STAFF PROFILES & PERMISSIONS
CREATE TABLE staff (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID UNIQUE NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  staff_code VARCHAR(24) UNIQUE NOT NULL,
  designation VARCHAR(120) NOT NULL,
  department VARCHAR(120) NOT NULL DEFAULT 'Clinic Operations',
  permissions JSONB NOT NULL DEFAULT '["appointments:manage","patients:read","payments:verify","whatsapp:send","support:manage"]'::jsonb,
  joined_at DATE NOT NULL DEFAULT CURRENT_DATE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 5. CONSULTATION TYPES & DOCTOR AVAILABILITY
CREATE TABLE consultation_types (
  id VARCHAR(40) PRIMARY KEY,
  name VARCHAR(160) NOT NULL,
  description TEXT NOT NULL,
  mode VARCHAR(20) NOT NULL CHECK (mode IN ('VIDEO', 'AUDIO', 'FOLLOW_UP')),
  duration_minutes INTEGER NOT NULL CHECK (duration_minutes BETWEEN 10 AND 90),
  fee_inr INTEGER NOT NULL CHECK (fee_inr >= 0),
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  sort_order INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE doctor_availability (
  day_of_week SMALLINT PRIMARY KEY CHECK (day_of_week BETWEEN 0 AND 6),
  day_name VARCHAR(16) NOT NULL,
  is_enabled BOOLEAN NOT NULL DEFAULT TRUE,
  start_time TIME NOT NULL DEFAULT '15:00',
  end_time TIME NOT NULL DEFAULT '20:00',
  slot_interval_minutes INTEGER NOT NULL DEFAULT 30,
  buffer_minutes INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE blocked_dates (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  blocked_date DATE UNIQUE NOT NULL,
  reason VARCHAR(255),
  created_by UUID REFERENCES users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 6. APPOINTMENTS (Overlap & Double-Booking Protected)
CREATE TABLE appointments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  reference_no VARCHAR(32) UNIQUE NOT NULL,
  patient_id UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  doctor_id UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  consultation_type_id VARCHAR(40) NOT NULL REFERENCES consultation_types(id),
  concern_category VARCHAR(80) NOT NULL,
  appointment_date DATE NOT NULL,
  start_time VARCHAR(5) NOT NULL,
  end_time VARCHAR(5) NOT NULL,
  duration_minutes INTEGER NOT NULL,
  status VARCHAR(24) NOT NULL CHECK (status IN ('PENDING', 'CONFIRMED', 'RESCHEDULED', 'COMPLETED', 'CANCELLED', 'REJECTED')),
  for_minor BOOLEAN NOT NULL DEFAULT FALSE,
  patient_display_name VARCHAR(160) NOT NULL,
  chief_complaint TEXT NOT NULL,
  symptom_duration VARCHAR(120),
  notes_for_doctor TEXT,
  rejection_or_cancel_reason TEXT,
  fee_inr INTEGER NOT NULL,
  payment_status VARCHAR(28) NOT NULL DEFAULT 'UNPAID' CHECK (payment_status IN ('UNPAID', 'PENDING_VERIFICATION', 'PAID', 'FAILED', 'REFUNDED')),
  followup_date DATE,
  followup_notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_appointments_date_status ON appointments(appointment_date, status);
CREATE INDEX idx_appointments_patient ON appointments(patient_id, appointment_date DESC);
CREATE UNIQUE INDEX idx_appointments_active_slot
  ON appointments(doctor_id, appointment_date, start_time)
  WHERE status NOT IN ('CANCELLED', 'REJECTED');

-- 7. CONSULTATIONS (Video/Audio Session + Clinical Case Notes, Recording Disabled)
CREATE TABLE consultations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  appointment_id UUID UNIQUE NOT NULL REFERENCES appointments(id) ON DELETE CASCADE,
  patient_id UUID NOT NULL REFERENCES users(id),
  doctor_id UUID NOT NULL REFERENCES users(id),
  provider VARCHAR(30) NOT NULL DEFAULT 'JITSI_SECURE',
  room_code VARCHAR(120) UNIQUE NOT NULL,
  access_token_hash TEXT NOT NULL,
  meeting_url TEXT NOT NULL,
  status VARCHAR(24) NOT NULL DEFAULT 'SCHEDULED' CHECK (status IN ('SCHEDULED', 'READY', 'IN_PROGRESS', 'COMPLETED', 'NO_SHOW')),
  auto_recording BOOLEAN NOT NULL DEFAULT FALSE CHECK (auto_recording = FALSE),
  started_at TIMESTAMPTZ,
  ended_at TIMESTAMPTZ,
  clinical_notes TEXT,
  homoeopathic_case_summary TEXT,
  provisional_impression TEXT,
  advice TEXT,
  referral_advised BOOLEAN NOT NULL DEFAULT FALSE,
  referral_details TEXT,
  followup_date DATE,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 8. PRESCRIPTIONS (Doctor-Only Authorisation)
CREATE TABLE prescriptions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  prescription_no VARCHAR(32) UNIQUE NOT NULL,
  appointment_id UUID REFERENCES appointments(id),
  consultation_id UUID REFERENCES consultations(id),
  patient_id UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  doctor_id UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  clinical_impression TEXT NOT NULL,
  symptoms_summary TEXT,
  medicines_json JSONB NOT NULL,
  general_instructions TEXT,
  dietary_advice TEXT,
  followup_date DATE,
  referral_note TEXT,
  status VARCHAR(20) NOT NULL DEFAULT 'DRAFT' CHECK (status IN ('DRAFT', 'AUTHORISED', 'REVOKED')),
  authorised_at TIMESTAMPTZ,
  digital_signature_hash TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_prescriptions_patient ON prescriptions(patient_id, created_at DESC);

-- 9. MEDICAL REPORTS (Private AES-256-GCM Encrypted Storage)
CREATE TABLE medical_reports (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  appointment_id UUID REFERENCES appointments(id),
  uploaded_by UUID NOT NULL REFERENCES users(id),
  title VARCHAR(200) NOT NULL,
  category VARCHAR(80) NOT NULL,
  report_date DATE,
  original_filename VARCHAR(255) NOT NULL,
  storage_key VARCHAR(255) UNIQUE NOT NULL,
  mime_type VARCHAR(100) NOT NULL,
  file_size_bytes INTEGER NOT NULL,
  is_encrypted BOOLEAN NOT NULL DEFAULT TRUE,
  review_status VARCHAR(24) NOT NULL DEFAULT 'PENDING_REVIEW' CHECK (review_status IN ('PENDING_REVIEW', 'REVIEWED')),
  doctor_remarks TEXT,
  reviewed_by UUID REFERENCES users(id),
  reviewed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_reports_patient ON medical_reports(patient_id, created_at DESC);

-- 10. PAYMENTS (Server-Verified Razorpay + Direct PhonePe/UPI QR + Cards/NetBanking/Wallets)
CREATE TABLE payments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  receipt_no VARCHAR(32) UNIQUE NOT NULL,
  appointment_id UUID NOT NULL REFERENCES appointments(id) ON DELETE RESTRICT,
  patient_id UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  amount_inr INTEGER NOT NULL CHECK (amount_inr >= 0),
  currency VARCHAR(3) NOT NULL DEFAULT 'INR',
  gateway VARCHAR(30) NOT NULL CHECK (gateway IN ('RAZORPAY', 'RAZORPAY_TEST', 'PHONEPE_UPI_QR', 'CLINIC_MANUAL')),
  payment_method VARCHAR(40) NOT NULL CHECK (payment_method IN ('PHONEPE_QR', 'UPI', 'CARD', 'NETBANKING', 'WALLET', 'PAY_LATER')),
  gateway_order_id VARCHAR(120),
  gateway_payment_id VARCHAR(120),
  gateway_signature TEXT,
  upi_utr VARCHAR(64),
  payer_vpa_or_last4 VARCHAR(120),
  status VARCHAR(28) NOT NULL CHECK (status IN ('INITIATED', 'PENDING_VERIFICATION', 'PAID', 'FAILED', 'REFUNDED')),
  server_verified BOOLEAN NOT NULL DEFAULT FALSE,
  verified_by UUID REFERENCES users(id),
  verified_at TIMESTAMPTZ,
  refund_amount_inr INTEGER,
  refund_reason TEXT,
  refunded_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_payments_patient ON payments(patient_id, created_at DESC);
CREATE INDEX idx_payments_appointment ON payments(appointment_id);

-- 11. NOTIFICATIONS (In-App, Official WhatsApp Business Templates, Email)
CREATE TABLE notifications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  appointment_id UUID REFERENCES appointments(id) ON DELETE SET NULL,
  channel VARCHAR(20) NOT NULL CHECK (channel IN ('IN_APP', 'WHATSAPP', 'EMAIL')),
  template_name VARCHAR(80),
  title VARCHAR(200) NOT NULL,
  message TEXT NOT NULL,
  delivery_status VARCHAR(28) NOT NULL DEFAULT 'SENT' CHECK (delivery_status IN ('SENT', 'DELIVERED', 'QUEUED_SANDBOX', 'FAILED')),
  is_read BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_notifications_user ON notifications(user_id, is_read, created_at DESC);

-- 12. CONSENT RECORDS (DPDP Act 2023 & NMC/NCH Telemedicine Consent)
CREATE TABLE consent_records (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  consent_type VARCHAR(60) NOT NULL CHECK (consent_type IN ('DPDP_DATA_PROCESSING', 'TELEMEDICINE_CONSULTATION', 'MINOR_GUARDIAN_AUTHORISATION', 'WHATSAPP_COMMUNICATION')),
  consent_version VARCHAR(20) NOT NULL DEFAULT 'v1.0-2026',
  granted BOOLEAN NOT NULL DEFAULT TRUE,
  guardian_declaration TEXT,
  ip_address VARCHAR(64),
  user_agent TEXT,
  granted_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  revoked_at TIMESTAMPTZ
);
CREATE INDEX idx_consent_user ON consent_records(user_id);

-- 13. IMMUTABLE AUDIT LOGS
CREATE TABLE audit_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  actor_id UUID REFERENCES users(id) ON DELETE SET NULL,
  actor_role VARCHAR(20),
  actor_name VARCHAR(160),
  action VARCHAR(100) NOT NULL,
  entity_type VARCHAR(60) NOT NULL,
  entity_id VARCHAR(80),
  details TEXT,
  ip_address VARCHAR(64),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_audit_logs_created ON audit_logs(created_at DESC);
CREATE INDEX idx_audit_logs_actor ON audit_logs(actor_id);

-- Row-Level Security Example for Patient Isolation in Production PostgreSQL
ALTER TABLE prescriptions ENABLE ROW LEVEL SECURITY;
ALTER TABLE medical_reports ENABLE ROW LEVEL SECURITY;
ALTER TABLE payments ENABLE ROW LEVEL SECURITY;

-- ============================================================
-- Live Two-Way Doctor <-> Patient Messaging & Audio/Video Calls
-- Official Clinic Calling & WhatsApp Line: +91 8123108149
-- ============================================================
ALTER TABLE appointments
  ADD COLUMN IF NOT EXISTS call_channel VARCHAR(40) NOT NULL DEFAULT 'WHATSAPP_VIDEO';

ALTER TABLE users
  ADD COLUMN IF NOT EXISTS google_sub VARCHAR(120);
CREATE UNIQUE INDEX IF NOT EXISTS idx_users_google_sub ON users(google_sub) WHERE google_sub IS NOT NULL;

CREATE TABLE IF NOT EXISTS clinic_messages (
  id VARCHAR(40) PRIMARY KEY,
  patient_id VARCHAR(40) NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  sender_id VARCHAR(40) NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  sender_role VARCHAR(16) NOT NULL CHECK (sender_role IN ('PATIENT', 'DOCTOR', 'STAFF', 'ADMIN')),
  sender_name VARCHAR(140) NOT NULL,
  appointment_id VARCHAR(40) REFERENCES appointments(id) ON DELETE SET NULL,
  message_type VARCHAR(20) NOT NULL DEFAULT 'TEXT' CHECK (message_type IN ('TEXT', 'AUDIO_CALL', 'VIDEO_CALL')),
  content TEXT NOT NULL,
  call_url TEXT,
  call_phone VARCHAR(24) DEFAULT '+918123108149',
  is_read BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_clinic_messages_patient ON clinic_messages(patient_id, created_at ASC);
CREATE INDEX IF NOT EXISTS idx_clinic_messages_unread ON clinic_messages(patient_id, is_read);

ALTER TABLE clinic_messages ENABLE ROW LEVEL SECURITY;
CREATE POLICY clinic_messages_patient_isolation ON clinic_messages
  USING (
    patient_id = current_setting('app.current_user_id', TRUE)
    OR current_setting('app.current_user_role', TRUE) IN ('DOCTOR', 'STAFF', 'ADMIN')
  );

-- Native Peer-to-Peer WebRTC Audio & Video Call Signaling (Auto-Recording Strictly Disabled)
CREATE TABLE IF NOT EXISTS rtc_calls (
  id VARCHAR(40) PRIMARY KEY,
  patient_id VARCHAR(40) NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  patient_name VARCHAR(140) NOT NULL,
  initiator_id VARCHAR(40) NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  initiator_role VARCHAR(16) NOT NULL,
  initiator_name VARCHAR(140) NOT NULL,
  call_type VARCHAR(10) NOT NULL CHECK (call_type IN ('AUDIO', 'VIDEO')),
  status VARCHAR(16) NOT NULL DEFAULT 'RINGING' CHECK (status IN ('RINGING', 'CONNECTED', 'ENDED', 'DECLINED', 'MISSED')),
  offer_sdp       TEXT,
  answer_sdp      TEXT,
  caller_key      TEXT,
  peer_key        TEXT,
  auto_recording  BOOLEAN NOT NULL DEFAULT FALSE CHECK (auto_recording = FALSE),
  connected_at TIMESTAMPTZ,
  ended_at TIMESTAMPTZ,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS rtc_ice_candidates (
  id BIGSERIAL PRIMARY KEY,
  call_id VARCHAR(40) NOT NULL REFERENCES rtc_calls(id) ON DELETE CASCADE,
  sender_side VARCHAR(10) NOT NULL CHECK (sender_side IN ('CALLER', 'CALLEE')),
  candidate_json TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

ALTER TABLE rtc_calls ENABLE ROW LEVEL SECURITY;

