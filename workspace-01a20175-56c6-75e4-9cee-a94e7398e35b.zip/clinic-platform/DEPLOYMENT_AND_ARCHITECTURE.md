# Dr. Aparna Mishra Digital Clinic — Architecture & Production Deployment Guide

## 1. Practice Summary Configured
- **Physician:** Dr. Aparna Mishra, BHMS (Homoeopathic Physician · 7 Years Experience)
- **Tagline:** *Compassionate Care, Individualized Healing.*
- **Consultation Schedule:** Monday – Saturday, **3:00 PM – 8:00 PM IST** (Online · By Prior Booking; Sunday Closed)
- **Contact / WhatsApp:** `+91 8123108149`
- **Email:** `aparnabhms@gmail.com`
- **Official PhonePe / UPI QR:** Embedded (`/images/phonepe-qr.jpeg`, VPA `a72549567212@axl`, Payee `APARNA MISHRA`) + Razorpay Online Checkout (UPI ID, RuPay/Visa/Mastercard Cards, NetBanking, Wallets & Pay Later)
- **Council Registration Placeholder:** Editable live inside **Doctor Dashboard → Website CMS**

## 2. System Architecture
- **Frontend:** Next.js 14 (App Router), React 18, TypeScript, Tailwind CSS (Navy `#153B5B`, Medical Teal `#168B83`, Light Aqua `#EAF4F5`, White `#FFFFFF`, Light Grey `#F5F7FA`; Manrope + Inter typography).
- **Backend API:** Next.js Route Handlers with Zod schema validation, sliding-window rate limiting, and Edge middleware RBAC.
- **Database:**
  - Production PostgreSQL 16 DDL with indexes, conflict constraints & RLS: `database/postgresql_schema.sql`
  - Zero-config live persistent relational database in sandbox: `data/clinic.db` (SQLite WAL mode + Foreign Keys + atomic booking transactions).
- **Security & Compliance (India DPDP Act 2023 & Telemedicine Guidelines):**
  - `bcryptjs` password & OTP hashing + `jose` HS256 signed `HttpOnly` JWT session cookies.
  - Strict server-side RBAC (`DOCTOR`, `ADMIN`, `STAFF`, `PATIENT`) and patient-record ownership enforcement.
  - Only `DOCTOR` can issue/authorise prescriptions or access private clinical case notes.
  - Uploaded patient lab reports are encrypted at rest with **AES-256-GCM** in `private_storage/reports/` (outside `public/`) and decrypted only through RBAC-audited download routes.
  - Parent / Legal Guardian accounts & explicit consent tracking (`consent_records`), DPDP JSON data export, deletion request workflow, immutable `audit_logs`, and recovery backup download.
  - Video consultations use unique authenticated rooms with automatic recording strictly disabled.
  - AI Patient-Support Chatbot enforces hard emergency triage (`112 / 108`) and strictly blocks medical diagnosis, prescriptions, and drug dosage advice.

## 3. Going Live in Production (Checklist)
1. Copy `.env.example` to `.env.local` and set strong random values for `JWT_SECRET` (64+ hex chars) and `FILE_ENCRYPTION_KEY`, and set `NEXT_PUBLIC_DEMO_MODE=false` (removes demo seed switcher).
2. Provision managed PostgreSQL in India (`ap-south-1` Mumbai — AWS RDS / Supabase / Neon) and apply `database/postgresql_schema.sql`.
3. Add external service credentials in `.env.local`:
   - **Razorpay:** `RAZORPAY_KEY_ID`, `RAZORPAY_KEY_SECRET`, `RAZORPAY_WEBHOOK_SECRET` (start with `rzp_test_*`, switch to `rzp_live_*` after verification).
   - **Meta WhatsApp Business Cloud API:** `WHATSAPP_PHONE_NUMBER_ID`, `WHATSAPP_BUSINESS_ACCOUNT_ID`, `WHATSAPP_ACCESS_TOKEN`.
   - **OAuth & DLT SMS OTP:** `GOOGLE_CLIENT_ID`, `GOOGLE_CLIENT_SECRET`, `APPLE_CLIENT_ID`, `SMS_PROVIDER_API_KEY`.
   - **Video (optional enterprise upgrade):** `DAILY_API_KEY` (keep `enable_recording: false`).
   - **Email:** `SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`, `SMTP_PASS`.
   - **Cloud Storage & Backups:** AWS S3 `ap-south-1` with SSE-KMS and automated daily encrypted backups.
4. Change the default doctor password immediately after first login and update the official State Homoeopathic Council Registration Number in **Admin → Website CMS**.
5. Deploy behind HTTPS (TLS 1.3) using `npm ci && npm run build && npm run start`.
