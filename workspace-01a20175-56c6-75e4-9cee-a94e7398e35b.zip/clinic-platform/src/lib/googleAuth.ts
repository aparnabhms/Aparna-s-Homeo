import { NextRequest } from 'next/server';
import { getDb, logAudit } from '@/lib/db';
import { generateId, generateRefCode, SessionUser, UserRole } from '@/lib/auth';
import { dispatchClinicNotification } from '@/lib/services';

export const GOOGLE_STATE_COOKIE = 'aparna_google_oauth_state';

interface DbUserRow {
  id: string;
  email: string;
  phone: string | null;
  full_name: string;
  role: UserRole;
  auth_provider: string;
  google_sub?: string | null;
  is_active: number;
  is_demo: number;
}

export function sanitizeNextPath(raw: string | null | undefined): string {
  if (!raw) return '';
  const trimmed = raw.trim();
  // Only permit internal relative paths to prevent open redirects
  if (!trimmed.startsWith('/') || trimmed.startsWith('//') || trimmed.includes('\\')) {
    return '';
  }
  return trimmed;
}

export function getRequestOrigin(req: NextRequest): string {
  const envUrl = (process.env.NEXT_PUBLIC_APP_URL || '').trim().replace(/\/+$/, '');
  const fwdHost = req.headers.get('x-forwarded-host') || req.headers.get('host');
  const fwdProto =
    req.headers.get('x-forwarded-proto') ||
    (req.nextUrl.protocol === 'https:' ? 'https' : 'http');

  if (fwdHost) {
    return `${fwdProto}://${fwdHost}`;
  }
  if (envUrl) return envUrl;
  return req.nextUrl.origin;
}

export function getGoogleOAuthConfig(req: NextRequest) {
  const clientId = (
    process.env.GOOGLE_CLIENT_ID ||
    process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID ||
    ''
  ).trim();
  const clientSecret = (process.env.GOOGLE_CLIENT_SECRET || '').trim();
  const origin = getRequestOrigin(req);
  const redirectUri = (
    process.env.GOOGLE_REDIRECT_URI || `${origin}/api/auth/google/callback`
  ).trim();

  const oauthConfigured = Boolean(clientId && clientSecret);
  const gisConfigured = Boolean(clientId);
  const demoMode = process.env.NEXT_PUBLIC_DEMO_MODE !== 'false';

  return {
    clientId,
    clientSecret,
    redirectUri,
    oauthConfigured,
    gisConfigured,
    demoMode,
  };
}

export function deriveDisplayNameFromEmail(email: string): string {
  const local = email.split('@')[0] || 'Patient';
  const cleaned = local
    .replace(/[._0-9+-]+/g, ' ')
    .trim()
    .replace(/\b\w/g, (c) => c.toUpperCase());
  return cleaned.length >= 2 ? cleaned.slice(0, 120) : 'Patient';
}

export async function findOrCreateGoogleUser(params: {
  email: string;
  fullName?: string;
  googleSub?: string | null;
  ipAddress: string;
  authAction: 'LOGIN_GOOGLE_OAUTH' | 'LOGIN_GOOGLE_OIDC' | 'LOGIN_GOOGLE_PASSWORDLESS';
}): Promise<
  | { ok: true; sessionUser: SessionUser; redirectTo: string; isNewUser: boolean }
  | { ok: false; error: string; status: number }
> {
  const db = getDb();
  const email = params.email.trim().toLowerCase();
  const googleSub = params.googleSub ? String(params.googleSub).trim() : null;

  // Match first by Google subject ID (if provided), then by verified email
  let existing: DbUserRow | undefined;
  if (googleSub) {
    existing = db
      .prepare('SELECT * FROM users WHERE google_sub = ? LIMIT 1')
      .get(googleSub) as DbUserRow | undefined;
  }
  if (!existing) {
    existing = db
      .prepare('SELECT * FROM users WHERE lower(email) = ? LIMIT 1')
      .get(email) as DbUserRow | undefined;
  }

  let isNewUser = false;

  if (!existing) {
    isNewUser = true;
    const providedName = (params.fullName || '').trim();
    const fullName =
      providedName.length >= 2
        ? providedName.slice(0, 120)
        : deriveDisplayNameFromEmail(email);

    const newId = generateId('usr');
    const patCode = generateRefCode('PAT').slice(0, 18);

    db.transaction(() => {
      db.prepare(`
        INSERT INTO users (
          id, email, phone, password_hash, full_name, role, auth_provider,
          google_sub, email_verified, phone_verified, is_active, is_demo, last_login_at
        ) VALUES (?, ?, NULL, NULL, ?, 'PATIENT', 'GOOGLE', ?, 1, 0, 1, 0, datetime('now'))
      `).run(newId, email, fullName, googleSub);

      db.prepare(
        'INSERT INTO patient_profiles (id, user_id, patient_code) VALUES (?, ?, ?)'
      ).run(generateId('pp'), newId, patCode);

      db.prepare(`
        INSERT INTO consent_records (id, user_id, consent_type, granted, ip_address)
        VALUES
          (?, ?, 'DPDP_DATA_PROCESSING', 1, ?),
          (?, ?, 'TELEMEDICINE_CONSULTATION', 1, ?),
          (?, ?, 'WHATSAPP_COMMUNICATION', 1, ?)
      `).run(
        generateId('cns'), newId, params.ipAddress,
        generateId('cns'), newId, params.ipAddress,
        generateId('cns'), newId, params.ipAddress
      );
    })();

    // Seed private welcome message from Dr. Aparna Mishra (+91 8123108149)
    const doc = db
      .prepare("SELECT id FROM users WHERE role = 'DOCTOR' LIMIT 1")
      .get() as { id: string } | undefined;
    if (doc) {
      db.prepare(`
        INSERT INTO clinic_messages (
          id, patient_id, sender_id, sender_role, sender_name,
          message_type, content, call_phone, is_read
        ) VALUES (?, ?, ?, 'DOCTOR', 'Dr. Aparna Mishra', 'TEXT', ?, '+918123108149', 0)
      `).run(
        generateId('msg'),
        newId,
        doc.id,
        `Namaste ${fullName}! Welcome to Dr. Aparna Mishra’s Digital Clinic. You signed in with Google (no password needed). Message me here anytime or connect via Audio & Video Call on +91 8123108149 (Mon–Sat, 3:00 PM – 8:00 PM IST).`
      );
    }

    await dispatchClinicNotification({
      userId: newId,
      inAppTitle: 'Signed In with Google',
      inAppMessage:
        'Your secure passwordless Google clinic account is ready. Book slots, chat live, or join Audio/Video consultations on +91 8123108149.',
      recipientEmail: email,
    });

    existing = db.prepare('SELECT * FROM users WHERE id = ?').get(newId) as DbUserRow;
  } else {
    if (!existing.is_active) {
      return {
        ok: false,
        error: 'This account is currently deactivated. Please contact +91 8123108149.',
        status: 403,
      };
    }

    // Link google_sub and mark email verified without overwriting any existing password
    db.prepare(`
      UPDATE users
      SET email_verified = 1,
          google_sub = COALESCE(google_sub, ?),
          last_login_at = datetime('now'),
          updated_at = datetime('now')
      WHERE id = ?
    `).run(googleSub, existing.id);
  }

  logAudit({
    actorId: existing.id,
    actorRole: existing.role,
    actorName: existing.full_name,
    action: params.authAction,
    entityType: 'SESSION',
    entityId: existing.id,
    details: `${isNewUser ? 'Registered & signed in' : 'Signed in'} with Google (${email}) without password`,
    ipAddress: params.ipAddress,
  });

  const sessionUser: SessionUser = {
    id: existing.id,
    email: existing.email,
    fullName: existing.full_name,
    role: existing.role,
    phone: existing.phone,
    isDemo: Boolean(existing.is_demo),
  };

  const defaultRedirect =
    existing.role === 'DOCTOR' || existing.role === 'ADMIN' || existing.role === 'STAFF'
      ? '/admin'
      : '/portal';

  return {
    ok: true,
    sessionUser,
    redirectTo: defaultRedirect,
    isNewUser,
  };
}
