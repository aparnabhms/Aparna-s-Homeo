import crypto from 'crypto';
import { formatTime12h, getDb, getDoctorPublicProfile } from './db';
import { generateId } from './auth';

/* ==========================================================================
   1. RAZORPAY & PHONEPE / UPI PAYMENT INTEGRATION (Server-Verified)
   ========================================================================== */

const SANDBOX_HMAC_SECRET =
  process.env.RAZORPAY_KEY_SECRET || 'rzp_test_sandbox_server_only_hmac_secret_2026';

export function isRazorpayLiveConfigured(): boolean {
  return Boolean(process.env.RAZORPAY_KEY_ID && process.env.RAZORPAY_KEY_SECRET);
}

export async function createRazorpayOrder(params: {
  amountInr: number;
  receiptNo: string;
  appointmentRef: string;
}): Promise<{
  orderId: string;
  amountPaise: number;
  currency: 'INR';
  keyId: string;
  mode: 'LIVE_OR_TEST_API' | 'TEST_SANDBOX';
  sandboxChallenge?: string;
}> {
  const amountPaise = Math.round(params.amountInr * 100);

  if (isRazorpayLiveConfigured()) {
    const keyId = process.env.RAZORPAY_KEY_ID!;
    const keySecret = process.env.RAZORPAY_KEY_SECRET!;
    const auth = Buffer.from(`${keyId}:${keySecret}`).toString('base64');

    const resp = await fetch('https://api.razorpay.com/v1/orders', {
      method: 'POST',
      headers: {
        Authorization: `Basic ${auth}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        amount: amountPaise,
        currency: 'INR',
        receipt: params.receiptNo,
        notes: { appointment_ref: params.appointmentRef },
      }),
    });

    if (!resp.ok) {
      const errText = await resp.text();
      throw new Error(`Razorpay order creation failed: ${errText}`);
    }
    const data = (await resp.json()) as { id: string; amount: number };
    return {
      orderId: data.id,
      amountPaise: data.amount,
      currency: 'INR',
      keyId,
      mode: 'LIVE_OR_TEST_API',
    };
  }

  // Test/Sandbox mode when RAZORPAY_KEY_ID is not yet set in environment
  const orderId = `order_test_${crypto.randomBytes(8).toString('hex')}`;
  return {
    orderId,
    amountPaise,
    currency: 'INR',
    keyId: 'rzp_test_sandbox_mode',
    mode: 'TEST_SANDBOX',
  };
}

export function generateSandboxPaymentSignature(orderId: string, paymentId: string): string {
  return crypto
    .createHmac('sha256', SANDBOX_HMAC_SECRET)
    .update(`${orderId}|${paymentId}`)
    .digest('hex');
}

export function verifyRazorpaySignature(
  orderId: string,
  paymentId: string,
  signature: string
): boolean {
  const expected = crypto
    .createHmac('sha256', SANDBOX_HMAC_SECRET)
    .update(`${orderId}|${paymentId}`)
    .digest('hex');
  try {
    return crypto.timingSafeEqual(
      Buffer.from(expected, 'hex'),
      Buffer.from(signature, 'hex')
    );
  } catch {
    return false;
  }
}

export function buildClinicUpiIntent(params: {
  amountInr: number;
  appointmentRef: string;
}): {
  upiUri: string;
  phonePeUri: string;
  gpayUri: string;
  paytmUri: string;
  upiId: string;
  payeeName: string;
  qrUrl: string;
} {
  const doc = getDoctorPublicProfile();
  const pa = encodeURIComponent(doc.upi_id || 'a72549567212@axl');
  const pn = encodeURIComponent(doc.upi_payee_name || 'APARNA MISHRA');
  const am = params.amountInr.toFixed(2);
  const tn = encodeURIComponent(`Consultation ${params.appointmentRef}`);
  const query = `pa=${pa}&pn=${pn}&am=${am}&cu=INR&tn=${tn}&mc=0000&mode=02`;

  return {
    upiUri: `upi://pay?${query}`,
    phonePeUri: `phonepe://pay?${query}`,
    gpayUri: `tez://upi/pay?${query}`,
    paytmUri: `paytmmp://pay?${query}`,
    upiId: doc.upi_id,
    payeeName: doc.upi_payee_name,
    qrUrl: doc.upi_qr_url,
  };
}

/**
 * Computes valid NPCI ISO-8583 4-digit `YDDD` Julian day prefixes for recent IST days.
 * Every genuine Indian UPI transaction RRN/UTR (PhonePe, Google Pay, Paytm, BHIM, bank apps)
 * is 12 numeric digits starting with `Y` (year % 10) + `DDD` (day-of-year 001..366).
 */
function getRecentIstYdddPrefixes(windowDays = 3): Set<string> {
  const prefixes = new Set<string>();
  const nowMs = Date.now();
  const istOffsetMs = 5.5 * 60 * 60 * 1000;

  for (let back = 0; back < windowDays; back++) {
    const istDate = new Date(nowMs + istOffsetMs - back * 86400 * 1000);
    const year = istDate.getUTCFullYear();
    const startOfYear = Date.UTC(year, 0, 1);
    const curDayUtc = Date.UTC(year, istDate.getUTCMonth(), istDate.getUTCDate());
    const dayOfYear = Math.floor((curDayUtc - startOfYear) / 86400000) + 1;
    const yDigit = String(year % 10);
    const ddd = String(dayOfYear).padStart(3, '0');
    prefixes.add(`${yDigit}${ddd}`);
  }
  return prefixes;
}

/**
 * Strict multi-layer validator for Indian UPI 12-digit UTR / RRN numbers.
 * Rejects letters/UPI IDs, wrong lengths, clinic/user phone numbers, sequential/repeating
 * patterns, low-entropy fake strings, and invalid NPCI YDDD transaction date headers.
 */
export function validateIndianUpiUtr(
  rawUtr: string,
  userPhone?: string | null
): { valid: boolean; cleanUtr: string; error?: string } {
  const clean = String(rawUtr || '')
    .trim()
    .replace(/[\s-]/g, '');

  if (!clean) {
    return {
      valid: false,
      cleanUtr: '',
      error: 'Please enter the 12-digit UPI UTR / Transaction Reference ID from your payment app.',
    };
  }

  if (/[A-Za-z@]/.test(clean)) {
    return {
      valid: false,
      cleanUtr: clean,
      error:
        'UPI UTR contains only 12 digits (0–9) — do not enter a UPI ID or letters. Copy the 12-digit UTR / UPI transaction ID from your payment success screen.',
    };
  }

  if (!/^\d{12}$/.test(clean)) {
    return {
      valid: false,
      cleanUtr: clean,
      error: `UPI UTR must be exactly 12 digits (you entered ${clean.length} digit${clean.length === 1 ? '' : 's'}).`,
    };
  }

  // Block clinic UPI digits, clinic phone, or patient phone pasted as UTR
  const blockedSubstrings = ['8123108149', '72549567212'];
  const cleanUserPhone = (userPhone || '').replace(/\D/g, '').slice(-10);
  if (cleanUserPhone.length === 10) blockedSubstrings.push(cleanUserPhone);
  if (blockedSubstrings.some((b) => clean.includes(b))) {
    return {
      valid: false,
      cleanUtr: clean,
      error:
        'That looks like a phone number or clinic UPI number, not a payment UTR. Enter the 12-digit UTR shown after completing your UPI transfer.',
    };
  }

  // Block repeated digits (e.g. 111111111111, 632200000000), repeated chunks, or low entropy
  if (
    /^(\d)\1{11}$/.test(clean) ||
    /(\d)\1{4,}/.test(clean) ||
    /^(\d{2})\1{5}$/.test(clean) ||
    /^(\d{3})\1{3}$/.test(clean) ||
    /^(\d{4})\1{2}$/.test(clean) ||
    /^(\d{6})\1$/.test(clean) ||
    /00000$/.test(clean)
  ) {
    return {
      valid: false,
      cleanUtr: clean,
      error:
        'Invalid or dummy UTR number detected. Please complete the actual UPI payment and enter the genuine 12-digit UTR from your receipt.',
    };
  }

  const uniqueDigits = new Set(clean.split('')).size;
  if (uniqueDigits < 4) {
    return {
      valid: false,
      cleanUtr: clean,
      error:
        'Invalid UTR number detected. Please enter the genuine 12-digit UTR from your UPI payment app.',
    };
  }

  // Block ascending/descending sequential runs of 5+ digits (e.g. 123456789123, 987654321098)
  const asc = '0123456789012345';
  const desc = '9876543210987654';
  for (let i = 0; i <= clean.length - 5; i++) {
    const seg = clean.slice(i, i + 5);
    if (asc.includes(seg) || desc.includes(seg)) {
      return {
        valid: false,
        cleanUtr: clean,
        error:
          'Sequential/random numbers cannot be used as a UPI UTR. Please complete the ₹ payment first and enter the real 12-digit UTR.',
      };
    }
  }

  // Verify genuine NPCI ISO-8583 YDDD Julian transaction date header (recent 3 IST days)
  const yddd = clean.slice(0, 4);
  const validPrefixes = getRecentIstYdddPrefixes(3);
  if (!validPrefixes.has(yddd)) {
    return {
      valid: false,
      cleanUtr: clean,
      error:
        'Invalid UPI UTR / Reference No. — this number does not match a genuine recent NPCI UPI transaction. Please scan the QR code, complete the payment first, and copy the exact 12-digit UTR / UPI Transaction ID from your PhonePe, Google Pay, or Paytm receipt.',
    };
  }

  return { valid: true, cleanUtr: clean };
}

/**
 * Verifies real binary magic bytes for uploaded UPI payment screenshots (JPEG, PNG, WebP, PDF).
 */
export function validatePaymentProofBuffer(buf: Buffer): {
  valid: boolean;
  detectedMime?: string;
  error?: string;
} {
  if (!buf || buf.length < 1024) {
    return {
      valid: false,
      error: 'Payment screenshot file is empty or too small. Please upload the actual screenshot from your UPI app.',
    };
  }
  if (buf.length > 6 * 1024 * 1024) {
    return {
      valid: false,
      error: 'Payment screenshot must be under 6 MB (JPG, PNG, WebP, or PDF).',
    };
  }

  const isJpeg = buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff;
  const isPng =
    buf[0] === 0x89 && buf[1] === 0x50 && buf[2] === 0x4e && buf[3] === 0x47;
  const isWebp =
    buf.length > 12 &&
    buf.subarray(0, 4).toString('ascii') === 'RIFF' &&
    buf.subarray(8, 12).toString('ascii') === 'WEBP';
  const isPdf = buf.subarray(0, 5).toString('ascii') === '%PDF-';

  if (isJpeg) return { valid: true, detectedMime: 'image/jpeg' };
  if (isPng) return { valid: true, detectedMime: 'image/png' };
  if (isWebp) return { valid: true, detectedMime: 'image/webp' };
  if (isPdf) return { valid: true, detectedMime: 'application/pdf' };

  return {
    valid: false,
    error: 'Please upload a valid payment screenshot image (JPG, PNG, WebP) or UPI receipt PDF.',
  };
}

/* ==========================================================================
   2. OFFICIAL WHATSAPP BUSINESS PLATFORM & EMAIL NOTIFICATIONS
      (Privacy-safe: never exposes clinical symptoms/diagnosis/medicines)
   ========================================================================== */

export function isWhatsAppConfigured(): boolean {
  return Boolean(process.env.WHATSAPP_PHONE_NUMBER_ID && process.env.WHATSAPP_ACCESS_TOKEN);
}

export async function dispatchClinicNotification(params: {
  userId: string;
  appointmentId?: string | null;
  inAppTitle: string;
  inAppMessage: string;
  whatsappTemplate?: string;
  whatsappParams?: string[];
  recipientPhone?: string | null;
  recipientEmail?: string | null;
  emailSubject?: string;
}) {
  const db = getDb();
  const insert = db.prepare(`
    INSERT INTO notifications (
      id, user_id, appointment_id, channel, template_name, recipient_address, title, message, delivery_status, is_read
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 0)
  `);

  // 1. Always deliver in-app portal notification immediately
  insert.run(
    generateId('ntf'),
    params.userId,
    params.appointmentId || null,
    'IN_APP',
    null,
    null,
    params.inAppTitle,
    params.inAppMessage,
    'DELIVERED'
  );

  // 2. Official Meta WhatsApp Business Cloud API template message
  if (params.whatsappTemplate && params.recipientPhone) {
    const tpl = db
      .prepare('SELECT * FROM whatsapp_templates WHERE template_name = ? AND is_active = 1')
      .get(params.whatsappTemplate) as
      | { template_name: string; body_template: string }
      | undefined;

    if (tpl) {
      let rendered = tpl.body_template;
      (params.whatsappParams || []).forEach((val, idx) => {
        rendered = rendered.replace(`{{${idx + 1}}}`, val);
      });

      const cleanPhone = params.recipientPhone.replace(/\D/g, '');
      const e164 = cleanPhone.length === 10 ? `91${cleanPhone}` : cleanPhone;
      let waStatus = 'QUEUED_SANDBOX';

      if (isWhatsAppConfigured()) {
        try {
          const ver = process.env.WHATSAPP_API_VERSION || 'v20.0';
          const phoneId = process.env.WHATSAPP_PHONE_NUMBER_ID!;
          const resp = await fetch(
            `https://graph.facebook.com/${ver}/${phoneId}/messages`,
            {
              method: 'POST',
              headers: {
                Authorization: `Bearer ${process.env.WHATSAPP_ACCESS_TOKEN}`,
                'Content-Type': 'application/json',
              },
              body: JSON.stringify({
                messaging_product: 'whatsapp',
                to: e164,
                type: 'template',
                template: {
                  name: tpl.template_name,
                  language: { code: 'en' },
                  components: [
                    {
                      type: 'body',
                      parameters: (params.whatsappParams || []).map((t) => ({
                        type: 'text',
                        text: t,
                      })),
                    },
                  ],
                },
              }),
            }
          );
          waStatus = resp.ok ? 'SENT' : 'FAILED';
        } catch {
          waStatus = 'FAILED';
        }
      }

      insert.run(
        generateId('ntf'),
        params.userId,
        params.appointmentId || null,
        'WHATSAPP',
        tpl.template_name,
        `+${e164}`,
        `WhatsApp · ${tpl.template_name}`,
        rendered,
        waStatus
      );
    }
  }

  // 3. Email Notification Record (dispatches via SMTP when configured)
  if (params.recipientEmail) {
    const emailStatus = process.env.SMTP_HOST ? 'SENT' : 'QUEUED_SANDBOX';
    insert.run(
      generateId('ntf'),
      params.userId,
      params.appointmentId || null,
      'EMAIL',
      null,
      params.recipientEmail,
      params.emailSubject || params.inAppTitle,
      params.inAppMessage,
      emailStatus
    );
  }
}

/* ==========================================================================
   3. SECURE VIDEO CONSULTATION SESSION GENERATOR (Auto-Recording Disabled)
   ========================================================================== */

export async function provisionVideoConsultation(params: {
  appointmentId: string;
  patientId: string;
  doctorId: string;
}): Promise<{
  id: string;
  roomCode: string;
  accessToken: string;
  meetingUrl: string;
  provider: string;
}> {
  const db = getDb();
  const existing = db
    .prepare('SELECT * FROM consultations WHERE appointment_id = ?')
    .get(params.appointmentId) as
    | { id: string; room_code: string; access_token: string; meeting_url: string; provider: string }
    | undefined;

  if (existing) {
    return {
      id: existing.id,
      roomCode: existing.room_code,
      accessToken: existing.access_token,
      meetingUrl: existing.meeting_url,
      provider: existing.provider,
    };
  }

  const entropy = crypto.randomBytes(9).toString('hex');
  const roomCode = `aparna-clinic-vc-${entropy}`;
  const accessToken = `tok_${crypto.randomBytes(16).toString('hex')}`;
  let provider = 'CLINIC_WEBRTC_DIRECT';
  // First-party authenticated WebRTC room (zero third-party Jitsi login wall, auto-recording OFF)
  let meetingUrl = `/portal?tab=video&start=VIDEO&room=${roomCode}`;

  // If Daily.co enterprise key is configured, provision a private non-recorded Daily room
  if (process.env.DAILY_API_KEY) {
    try {
      const resp = await fetch('https://api.daily.co/v1/rooms', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${process.env.DAILY_API_KEY}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          name: roomCode,
          privacy: 'private',
          properties: {
            enable_recording: false,
            enable_prejoin_ui: true,
            enable_chat: true,
            enable_screenshare: true,
          },
        }),
      });
      if (resp.ok) {
        const room = (await resp.json()) as { url: string };
        meetingUrl = room.url;
        provider = 'DAILY_PRIVATE';
      }
    } catch {
      // Fallback to Jitsi secure configuration
    }
  }

  const id = generateId('cons');
  db.prepare(`
    INSERT INTO consultations (
      id, appointment_id, patient_id, doctor_id, provider, room_code, access_token, meeting_url, status, auto_recording
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'READY', 0)
  `).run(id, params.appointmentId, params.patientId, params.doctorId, provider, roomCode, accessToken, meetingUrl);

  return { id, roomCode, accessToken, meetingUrl, provider };
}

/* ==========================================================================
   4. SAFETY-GUARDED AI HEALTHCARE PATIENT-SUPPORT CHATBOT
   ========================================================================== */

const EMERGENCY_PATTERNS = [
  /chest\s*pain/i,
  /heart\s*attack/i,
  /can'?t\s*breathe|cannot\s*breathe|shortness\s*of\s*breath|severe\s*breathless|breathing\s*difficulty/i,
  /unconscious|fainted|fainting|passed\s*out|seizure|fits|convulsion/i,
  /stroke|slurred\s*speech|face\s*droop|paralys/i,
  /heavy\s*bleeding|uncontrolled\s*bleeding|vomiting\s*blood|blood\s*in\s*vomit/i,
  /suicid|self[\s-]*harm|end\s*my\s*life|overdose|poison/i,
  /severe\s*burn|head\s*injury|snake\s*bite|anaphylax|swollen\s*(tongue|throat|lips)/i,
  /high\s*fever\s*(103|104|105)|emergency/i,
];

const MEDICAL_ADVICE_PATTERNS = [
  /what\s*medicine\s*(should|can)\s*i\s*take/i,
  /suggest\s*(a\s*)?(medicine|remedy|tablet|drug|pill|syrup|potency|antibiotic|painkiller)/i,
  /prescribe|prescription\s*for\s*my/i,
  /how\s*many\s*(mg|ml|pills|tablets|drops|globules)|what\s*dosage|what\s*dose|30c\s*or\s*200/i,
  /do\s*i\s*have\s*(pcos|thyroid|diabetes|cancer|infection|arthritis|asthma|ulcer|eczema)/i,
  /diagnose\s*me|what\s*disease\s*do\s*i\s*have|treat\s*my|cure\s*for\s*my/i,
  /can\s*i\s*stop\s*(taking\s*)?my\s*(thyroid|bp|sugar|medicine|tablet)/i,
  /i\s*have\s*(pain|fever|rash|cough|acidity|vomiting|headache|irregular\s*period|hair\s*fall).*what\s*(should|to)\s*(i\s*)?(take|do)/i,
];

export interface ChatbotReply {
  reply: string;
  category: string;
  safetyTriggered: 'EMERGENCY' | 'MEDICAL_ADVICE_BLOCKED' | null;
  suggestedActions: Array<{ label: string; href: string }>;
}

export function generateSafeChatbotReply(rawMessage: string, sessionKey: string): ChatbotReply {
  const db = getDb();
  const msg = rawMessage.trim();
  const lower = msg.toLowerCase();
  const doc = getDoctorPublicProfile();

  const recordLog = (res: ChatbotReply) => {
    db.prepare(`
      INSERT INTO chatbot_logs (id, session_key, category, user_query, bot_response, safety_triggered, escalated)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `).run(
      generateId('chat'),
      sessionKey,
      res.category,
      msg.slice(0, 500),
      res.reply.slice(0, 1000),
      res.safetyTriggered,
      res.category === 'ESCALATION' ? 1 : 0
    );
    return res;
  };

  // LAYER 1: Hard Emergency Triage (Never delay emergency medical care)
  if (EMERGENCY_PATTERNS.some((re) => re.test(msg))) {
    return recordLog({
      reply:
        'URGENT MEDICAL SAFETY NOTICE: Your message mentions symptoms that could indicate a medical emergency. This online clinic and chatbot cannot handle emergencies. Please go to the nearest hospital emergency department immediately or call India Emergency Services at 112 or Ambulance at 108 / 102 without delay. (For mental health crisis support in India, call Tele-MANAS at 14416.) Do not wait for an online consultation.',
      category: 'EMERGENCY_TRIAGE',
      safetyTriggered: 'EMERGENCY',
      suggestedActions: [
        { label: 'Call 112 Emergency', href: 'tel:112' },
        { label: 'Call 108 Ambulance', href: 'tel:108' },
      ],
    });
  }

  // LAYER 2: Strict Refusal to Diagnose, Prescribe, or Recommend Drug Dosages
  if (MEDICAL_ADVICE_PATTERNS.some((re) => re.test(msg))) {
    return recordLog({
      reply:
        `For your safety, I cannot diagnose health conditions, recommend or prescribe medicines/remedies, suggest drug dosages, or advise stopping any ongoing treatment. Every patient requires a proper clinical evaluation. You can book a private Online Consultation with ${doc.display_name} (${doc.qualification}) available Monday to Saturday, 3:00 PM – 8:00 PM IST, or reach our clinic desk for guidance. If symptoms are severe or worsening, please visit a nearby hospital promptly.`,
      category: 'MEDICAL_BOUNDARY',
      safetyTriggered: 'MEDICAL_ADVICE_BLOCKED',
      suggestedActions: [
        { label: 'Book Consultation with Doctor', href: '/book' },
        { label: 'Contact Clinic Support', href: '/contact' },
      ],
    });
  }

  // LAYER 3: Human Escalation
  if (/human|staff|reception|talk\s*to\s*(someone|person)|support|complaint|whatsapp|call\s*clinic/i.test(lower)) {
    return recordLog({
      reply:
        `You can connect directly with our clinic support team:\n• Phone / WhatsApp: ${doc.phone}\n• Email: ${doc.email}\n• Support Hours: ${doc.timings_summary}\nLogged-in patients can also raise a tracked ticket under Patient Portal → Support.`,
      category: 'ESCALATION',
      safetyTriggered: null,
      suggestedActions: [
        { label: 'Chat on WhatsApp', href: `https://wa.me/${doc.whatsapp_number}` },
        { label: 'Open Contact / Support', href: '/contact' },
      ],
    });
  }

  // LAYER 4: Grounded Clinic Knowledge Responses
  if (/timing|hour|open|close|schedule|monday|saturday|sunday|when\s*is\s*(the\s*)?doctor/i.test(lower)) {
    return recordLog({
      reply:
        `${doc.display_name} is available for online consultations ${doc.timings_summary}, strictly by prior appointment booking. The clinic is closed on Sundays.`,
      category: 'TIMINGS',
      safetyTriggered: null,
      suggestedActions: [
        { label: 'Check Available Slots', href: '/book' },
        { label: 'Clinic Information', href: '/clinic-info' },
      ],
    });
  }

  if (/fee|cost|price|charge|payment|upi|phonepe|gpay|paytm|card|netbanking|razorpay|qr|refund/i.test(lower)) {
    const types = db
      .prepare('SELECT name, duration_minutes, fee_inr FROM consultation_types WHERE is_active = 1 ORDER BY sort_order')
      .all() as Array<{ name: string; duration_minutes: number; fee_inr: number }>;
    const feeLines = types.map((t) => `• ${t.name} (${t.duration_minutes} mins): ₹${t.fee_inr}`).join('\n');
    return recordLog({
      reply:
        `Current online consultation fees:\n${feeLines}\n\nAccepted payment methods: PhonePe / GPay / Paytm / BHIM UPI QR scan (${doc.upi_id}), UPI ID, Credit/Debit Cards (RuPay, Visa, Mastercard), NetBanking, Wallets, and Pay Later. Official PDF receipts are available in your Patient Portal.`,
      category: 'FEES_AND_PAYMENTS',
      safetyTriggered: null,
      suggestedActions: [
        { label: 'Book & Pay Online', href: '/book' },
        { label: 'View Payment History', href: '/portal?tab=payments' },
      ],
    });
  }

  if (/qualif|degree|bhms|experience|about\s*(the\s*)?doctor|aparna|who\s*is|registration/i.test(lower)) {
    return recordLog({
      reply:
        `${doc.display_name} holds a ${doc.qualification} with ${doc.experience_years} years of clinical experience as a ${doc.specialisation}. Tagline: "${doc.tagline}" Consultations are conducted online in ${doc.languages} from 3:00 PM to 8:00 PM (Mon–Sat).`,
      category: 'DOCTOR_PROFILE',
      safetyTriggered: null,
      suggestedActions: [
        { label: 'About Dr. Aparna Mishra', href: '/about' },
        { label: 'Book Appointment', href: '/book' },
      ],
    });
  }

  if (/service|special|area|women|pcos|thyroid|skin|hair|digest|joint|respirat|allerg/i.test(lower)) {
    return recordLog({
      reply:
        `${doc.display_name} provides individualized online homoeopathic and wellness consultations across:\n• Women’s Health (menstrual health, PCOS & related concerns)\n• Thyroid Health\n• Skin & Hair (skin complaints, allergies, hair fall)\n• Digestive Health\n• Joint Health & musculoskeletal discomfort\n• Respiratory Health & seasonal allergies\n• General non-emergency wellness\n\n(Note: For personal symptom assessment, please book an appointment directly with the doctor.)`,
      category: 'SERVICES',
      safetyTriggered: null,
      suggestedActions: [
        { label: 'Explore Services', href: '/services' },
        { label: 'Book Consultation', href: '/book' },
      ],
    });
  }

  if (/prescription|download|pdf|report|upload|lab|test\s*result/i.test(lower)) {
    return recordLog({
      reply:
        'To access prescriptions or reports:\n1. Sign in to your secure Patient Portal.\n2. Open "My Prescriptions" to view and download doctor-authorised PDF prescriptions.\n3. Open "Medical Reports" to privately upload PDF/JPG/PNG lab reports before your consultation or view Dr. Aparna’s review notes.',
      category: 'PRESCRIPTIONS_REPORTS',
      safetyTriggered: null,
      suggestedActions: [
        { label: 'My Prescriptions', href: '/portal?tab=prescriptions' },
        { label: 'Medical Reports', href: '/portal?tab=reports' },
      ],
    });
  }

  if (/video|join|online\s*consult|link|call|record/i.test(lower)) {
    return recordLog({
      reply:
        'After your booking is confirmed, sign in to Patient Portal → Video Consultation 5–10 minutes before your scheduled slot (3:00 PM – 8:00 PM, Mon–Sat) and tap "Join Secure Video Room". Ensure good lighting, stable internet, and upload prior lab reports beforehand. Consultations are never automatically recorded.',
      category: 'VIDEO_CONSULTATION',
      safetyTriggered: null,
      suggestedActions: [
        { label: 'How Online Consultation Works', href: '/online-consultation' },
        { label: 'Open Video Room', href: '/portal?tab=video' },
      ],
    });
  }

  if (/location|address|where|map|city|contact|email|phone|number/i.test(lower)) {
    return recordLog({
      reply:
        `${doc.clinic_name} provides pan-India online consultations from the comfort of your home.\n• Consultation Mode: ${doc.consultation_mode}\n• Timings: ${doc.timings_summary}\n• Phone / WhatsApp: ${doc.phone}\n• Email: ${doc.email}`,
      category: 'LOCATION_CONTACT',
      safetyTriggered: null,
      suggestedActions: [
        { label: 'Clinic Info & Map', href: '/clinic-info' },
        { label: 'Contact Us', href: '/contact' },
      ],
    });
  }

  if (/book|appointment|slot|reschedul|cancel|login|sign\s*in|register|minor|child/i.test(lower)) {
    return recordLog({
      reply:
        'Booking an appointment takes under 2 minutes:\n1. Go to Book Appointment and pick Video, Detailed Review, Audio, or Follow-Up.\n2. Choose a date (Mon–Sat) and open slot between 3:00 PM and 8:00 PM.\n3. Sign in (via Email, Mobile OTP, Google, or Apple—Parent/Guardian accounts supported for minors).\n4. Complete payment via PhonePe QR, UPI, Card, NetBanking, or Wallet to get your reference number.\nYou can reschedule or cancel anytime from Patient Portal → My Appointments.',
      category: 'BOOKING_HELP',
      safetyTriggered: null,
      suggestedActions: [
        { label: 'Book Appointment Now', href: '/book' },
        { label: 'Patient Login', href: '/login' },
      ],
    });
  }

  // Check Admin custom KB entries
  const settings = db
    .prepare('SELECT custom_kb_json, escalation_note FROM chatbot_settings WHERE id = ?')
    .get('default') as { custom_kb_json: string; escalation_note: string } | undefined;

  if (settings) {
    try {
      const kb = JSON.parse(settings.custom_kb_json) as Array<{ topic: string; answer: string }>;
      const hit = kb.find((k) =>
        k.topic
          .toLowerCase()
          .split(/\s+/)
          .some((w) => w.length > 3 && lower.includes(w))
      );
      if (hit) {
        return recordLog({
          reply: hit.answer,
          category: 'CUSTOM_KB',
          safetyTriggered: null,
          suggestedActions: [
            { label: 'Book Appointment', href: '/book' },
            { label: 'Speak to Clinic Team', href: '/contact' },
          ],
        });
      }
    } catch {
      // ignore invalid json
    }
  }

  return recordLog({
    reply:
      `I can assist you with:\n• Consultation timings (${doc.timings_summary})\n• Booking, rescheduling, or joining online video/audio consultations\n• Dr. Aparna Mishra’s qualifications (BHMS, 7 yrs experience) & consultation areas\n• Consultation fees & payment methods (PhonePe UPI QR, Cards, NetBanking, Wallets)\n• Downloading prescriptions & uploading lab reports\n\nPlease note: I cannot diagnose conditions or suggest medicines. How may I assist you today?`,
    category: 'GENERAL_HELP',
    safetyTriggered: null,
    suggestedActions: [
      { label: 'Book Appointment', href: '/book' },
      { label: 'View Services', href: '/services' },
      { label: 'Human Support', href: '/contact' },
    ],
  });
}

export function getIntegrationStatuses() {
  const doc = getDoctorPublicProfile();
  return [
    {
      key: 'phonepe_qr',
      name: 'PhonePe / BHIM UPI Direct QR',
      status: 'ACTIVE',
      detail: `Active with verified clinic QR & VPA (${doc.upi_id}) + server UTR verification workflow.`,
      envVars: ['CLINIC_UPI_ID', 'CLINIC_UPI_PAYEE_NAME'],
    },
    {
      key: 'razorpay',
      name: 'Razorpay Gateway (UPI, Cards, NetBanking, Wallets)',
      status: isRazorpayLiveConfigured() ? 'CONFIGURED' : 'TEST_SANDBOX',
      detail: isRazorpayLiveConfigured()
        ? 'Connected to Razorpay Orders API with server-side HMAC-SHA256 verification.'
        : 'Running in server-verified Test Sandbox mode. Supply RAZORPAY_KEY_ID & RAZORPAY_KEY_SECRET for live capture.',
      envVars: ['RAZORPAY_KEY_ID', 'RAZORPAY_KEY_SECRET', 'RAZORPAY_WEBHOOK_SECRET'],
    },
    {
      key: 'whatsapp',
      name: 'Official Meta WhatsApp Business Platform',
      status: isWhatsAppConfigured() ? 'CONFIGURED' : 'SANDBOX_QUEUE',
      detail: isWhatsAppConfigured()
        ? 'Connected to Meta Graph API with approved privacy-safe templates.'
        : 'Approved templates & trigger hooks active (logged in queue); add Meta Cloud API credentials for live delivery. Direct WhatsApp clinic connect (+91 8123108149) active.',
      envVars: ['WHATSAPP_PHONE_NUMBER_ID', 'WHATSAPP_ACCESS_TOKEN', 'WHATSAPP_BUSINESS_ACCOUNT_ID'],
    },
    {
      key: 'video',
      name: 'Encrypted Video Consultation (No Auto-Recording)',
      status: process.env.DAILY_API_KEY ? 'DAILY_ENTERPRISE' : 'JITSI_ACTIVE',
      detail: process.env.DAILY_API_KEY
        ? 'Private Daily.co WebRTC rooms with recording strictly disabled.'
        : 'Authenticated unique Jitsi WebRTC rooms active with recording & livestreaming disabled; optional DAILY_API_KEY supported.',
      envVars: ['DAILY_API_KEY', 'JITSI_DOMAIN'],
    },
    {
      key: 'oauth',
      name: 'Authentication (Email, Mobile OTP, Google & Apple)',
      status: process.env.GOOGLE_CLIENT_ID ? 'FULL_OAUTH' : 'EMAIL_OTP_ACTIVE',
      detail: process.env.GOOGLE_CLIENT_ID
        ? 'Email/Password (bcrypt), OTP, and OAuth providers active.'
        : 'Email/Password (bcrypt + HttpOnly JWT) & Mobile OTP active; supply GOOGLE_CLIENT_ID / APPLE_CLIENT_ID / SMS_PROVIDER_API_KEY for live OAuth & DLT SMS delivery.',
      envVars: ['GOOGLE_CLIENT_ID', 'GOOGLE_CLIENT_SECRET', 'APPLE_CLIENT_ID', 'SMS_PROVIDER_API_KEY'],
    },
    {
      key: 'storage',
      name: 'Private Medical Report Storage (AES-256-GCM)',
      status: 'ACTIVE',
      detail: 'Files stored outside public web root, encrypted at rest with AES-256-GCM, served only after RBAC verification.',
      envVars: ['FILE_ENCRYPTION_KEY', 'S3_BUCKET_NAME'],
    },
    {
      key: 'email',
      name: 'Transactional Email Service',
      status: process.env.SMTP_HOST ? 'CONFIGURED' : 'SANDBOX_QUEUE',
      detail: process.env.SMTP_HOST
        ? 'SMTP relay configured for clinic alerts & password resets.'
        : 'Notifications queued in DB; supply SMTP_HOST, SMTP_USER & SMTP_PASS for live outbound email from aparnabhms@gmail.com.',
      envVars: ['SMTP_HOST', 'SMTP_PORT', 'SMTP_USER', 'SMTP_PASS'],
    },
  ];
}

export { formatTime12h };
