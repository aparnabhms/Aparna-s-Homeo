import Database from 'better-sqlite3';
import bcrypt from 'bcryptjs';
import fs from 'fs';
import path from 'path';
import { encryptBuffer, generateId, signDigitalHash } from './auth';

const DB_DIR = path.join(process.cwd(), 'data');
const DB_PATH = process.env.SQLITE_DB_PATH
  ? path.resolve(process.cwd(), process.env.SQLITE_DB_PATH)
  : path.join(DB_DIR, 'clinic.db');
export const PRIVATE_REPORTS_DIR = path.join(process.cwd(), 'private_storage', 'reports');

let dbInstance: Database.Database | null = null;

export function getDb(): Database.Database {
  if (dbInstance) return dbInstance;

  fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });
  fs.mkdirSync(PRIVATE_REPORTS_DIR, { recursive: true });

  const db = new Database(DB_PATH);
  db.pragma('journal_mode = WAL');
  db.pragma('foreign_keys = ON');
  db.pragma('busy_timeout = 5000');

  initializeSchema(db);
  seedIfEmpty(db);

  dbInstance = db;
  return db;
}

function initializeSchema(db: Database.Database) {
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      email TEXT UNIQUE NOT NULL,
      phone TEXT,
      password_hash TEXT,
      full_name TEXT NOT NULL,
      role TEXT NOT NULL CHECK (role IN ('PATIENT', 'DOCTOR', 'STAFF', 'ADMIN')),
      auth_provider TEXT NOT NULL DEFAULT 'EMAIL',
      google_sub TEXT,
      email_verified INTEGER NOT NULL DEFAULT 0,
      phone_verified INTEGER NOT NULL DEFAULT 0,
      is_active INTEGER NOT NULL DEFAULT 1,
      is_demo INTEGER NOT NULL DEFAULT 0,
      last_login_at TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
    CREATE INDEX IF NOT EXISTS idx_users_role ON users(role);
    CREATE INDEX IF NOT EXISTS idx_users_phone ON users(phone);

    CREATE TABLE IF NOT EXISTS patient_profiles (
      id TEXT PRIMARY KEY,
      user_id TEXT UNIQUE NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      patient_code TEXT UNIQUE NOT NULL,
      date_of_birth TEXT,
      gender TEXT,
      blood_group TEXT,
      city TEXT,
      state TEXT,
      address TEXT,
      allergies TEXT,
      chronic_conditions TEXT,
      current_medications TEXT,
      emergency_contact_name TEXT,
      emergency_contact_phone TEXT,
      is_minor_account INTEGER NOT NULL DEFAULT 0,
      guardian_name TEXT,
      guardian_relation TEXT,
      minor_patient_name TEXT,
      minor_date_of_birth TEXT,
      deletion_requested_at TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS doctor_profiles (
      id TEXT PRIMARY KEY,
      user_id TEXT UNIQUE NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      display_name TEXT NOT NULL,
      qualification TEXT NOT NULL,
      specialisation TEXT NOT NULL,
      experience_years INTEGER NOT NULL DEFAULT 7,
      registration_number TEXT NOT NULL,
      registration_council TEXT NOT NULL,
      tagline TEXT NOT NULL,
      bio TEXT NOT NULL,
      approach_note TEXT NOT NULL,
      consultation_mode TEXT NOT NULL,
      timings_summary TEXT NOT NULL,
      languages TEXT NOT NULL,
      clinic_name TEXT NOT NULL,
      clinic_address TEXT NOT NULL,
      clinic_city TEXT NOT NULL,
      map_embed_url TEXT NOT NULL,
      phone TEXT NOT NULL,
      whatsapp_number TEXT NOT NULL,
      email TEXT NOT NULL,
      photo_url TEXT NOT NULL,
      upi_id TEXT NOT NULL,
      upi_payee_name TEXT NOT NULL,
      upi_qr_url TEXT NOT NULL,
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS staff (
      id TEXT PRIMARY KEY,
      user_id TEXT UNIQUE NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      staff_code TEXT UNIQUE NOT NULL,
      designation TEXT NOT NULL,
      department TEXT NOT NULL,
      permissions_json TEXT NOT NULL,
      joined_at TEXT NOT NULL,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS medical_services (
      id TEXT PRIMARY KEY,
      slug TEXT UNIQUE NOT NULL,
      title TEXT NOT NULL,
      short_description TEXT NOT NULL,
      full_description TEXT NOT NULL,
      conditions_json TEXT NOT NULL,
      icon_key TEXT NOT NULL,
      is_active INTEGER NOT NULL DEFAULT 1,
      sort_order INTEGER NOT NULL DEFAULT 0
    );

    CREATE TABLE IF NOT EXISTS consultation_types (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      description TEXT NOT NULL,
      mode TEXT NOT NULL CHECK (mode IN ('VIDEO', 'AUDIO', 'FOLLOW_UP')),
      duration_minutes INTEGER NOT NULL,
      fee_inr INTEGER NOT NULL,
      is_active INTEGER NOT NULL DEFAULT 1,
      sort_order INTEGER NOT NULL DEFAULT 0
    );

    CREATE TABLE IF NOT EXISTS doctor_availability (
      day_of_week INTEGER PRIMARY KEY CHECK (day_of_week BETWEEN 0 AND 6),
      day_name TEXT NOT NULL,
      is_enabled INTEGER NOT NULL DEFAULT 1,
      start_time TEXT NOT NULL DEFAULT '15:00',
      end_time TEXT NOT NULL DEFAULT '20:00',
      slot_interval_minutes INTEGER NOT NULL DEFAULT 30,
      buffer_minutes INTEGER NOT NULL DEFAULT 0
    );

    CREATE TABLE IF NOT EXISTS blocked_dates (
      id TEXT PRIMARY KEY,
      blocked_date TEXT UNIQUE NOT NULL,
      reason TEXT,
      created_by TEXT REFERENCES users(id),
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS appointments (
      id TEXT PRIMARY KEY,
      reference_no TEXT UNIQUE NOT NULL,
      patient_id TEXT NOT NULL REFERENCES users(id),
      doctor_id TEXT NOT NULL REFERENCES users(id),
      consultation_type_id TEXT NOT NULL REFERENCES consultation_types(id),
      concern_category TEXT NOT NULL,
      appointment_date TEXT NOT NULL,
      start_time TEXT NOT NULL,
      end_time TEXT NOT NULL,
      duration_minutes INTEGER NOT NULL,
      status TEXT NOT NULL CHECK (status IN ('PENDING', 'CONFIRMED', 'RESCHEDULED', 'COMPLETED', 'CANCELLED', 'REJECTED')),
      for_minor INTEGER NOT NULL DEFAULT 0,
      patient_display_name TEXT NOT NULL,
      chief_complaint TEXT NOT NULL,
      symptom_duration TEXT,
      notes_for_doctor TEXT,
      rejection_or_cancel_reason TEXT,
      fee_inr INTEGER NOT NULL,
      payment_status TEXT NOT NULL DEFAULT 'UNPAID' CHECK (payment_status IN ('UNPAID', 'PENDING_VERIFICATION', 'PAID', 'FAILED', 'REFUNDED')),
      followup_date TEXT,
      followup_notes TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
    CREATE INDEX IF NOT EXISTS idx_appt_date ON appointments(appointment_date, status);
    CREATE INDEX IF NOT EXISTS idx_appt_patient ON appointments(patient_id, appointment_date DESC);

    CREATE TABLE IF NOT EXISTS consultations (
      id TEXT PRIMARY KEY,
      appointment_id TEXT UNIQUE NOT NULL REFERENCES appointments(id) ON DELETE CASCADE,
      patient_id TEXT NOT NULL REFERENCES users(id),
      doctor_id TEXT NOT NULL REFERENCES users(id),
      provider TEXT NOT NULL DEFAULT 'JITSI_SECURE',
      room_code TEXT UNIQUE NOT NULL,
      access_token TEXT NOT NULL,
      meeting_url TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'SCHEDULED' CHECK (status IN ('SCHEDULED', 'READY', 'IN_PROGRESS', 'COMPLETED', 'NO_SHOW')),
      auto_recording INTEGER NOT NULL DEFAULT 0 CHECK (auto_recording = 0),
      started_at TEXT,
      ended_at TEXT,
      clinical_notes TEXT,
      homoeopathic_case_summary TEXT,
      provisional_impression TEXT,
      advice TEXT,
      referral_advised INTEGER NOT NULL DEFAULT 0,
      referral_details TEXT,
      followup_date TEXT,
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS prescriptions (
      id TEXT PRIMARY KEY,
      prescription_no TEXT UNIQUE NOT NULL,
      appointment_id TEXT REFERENCES appointments(id),
      consultation_id TEXT REFERENCES consultations(id),
      patient_id TEXT NOT NULL REFERENCES users(id),
      doctor_id TEXT NOT NULL REFERENCES users(id),
      clinical_impression TEXT NOT NULL,
      symptoms_summary TEXT,
      medicines_json TEXT NOT NULL,
      general_instructions TEXT,
      dietary_advice TEXT,
      followup_date TEXT,
      referral_note TEXT,
      status TEXT NOT NULL DEFAULT 'DRAFT' CHECK (status IN ('DRAFT', 'AUTHORISED', 'REVOKED')),
      authorised_at TEXT,
      digital_signature_hash TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
    CREATE INDEX IF NOT EXISTS idx_rx_patient ON prescriptions(patient_id, created_at DESC);

    CREATE TABLE IF NOT EXISTS medical_reports (
      id TEXT PRIMARY KEY,
      patient_id TEXT NOT NULL REFERENCES users(id),
      appointment_id TEXT REFERENCES appointments(id),
      uploaded_by TEXT NOT NULL REFERENCES users(id),
      title TEXT NOT NULL,
      category TEXT NOT NULL,
      report_date TEXT,
      original_filename TEXT NOT NULL,
      storage_key TEXT UNIQUE NOT NULL,
      mime_type TEXT NOT NULL,
      file_size_bytes INTEGER NOT NULL,
      is_encrypted INTEGER NOT NULL DEFAULT 1,
      review_status TEXT NOT NULL DEFAULT 'PENDING_REVIEW' CHECK (review_status IN ('PENDING_REVIEW', 'REVIEWED')),
      doctor_remarks TEXT,
      reviewed_by TEXT REFERENCES users(id),
      reviewed_at TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
    CREATE INDEX IF NOT EXISTS idx_reports_patient ON medical_reports(patient_id, created_at DESC);

    CREATE TABLE IF NOT EXISTS payments (
      id TEXT PRIMARY KEY,
      receipt_no TEXT UNIQUE NOT NULL,
      appointment_id TEXT NOT NULL REFERENCES appointments(id),
      patient_id TEXT NOT NULL REFERENCES users(id),
      amount_inr INTEGER NOT NULL,
      currency TEXT NOT NULL DEFAULT 'INR',
      gateway TEXT NOT NULL,
      payment_method TEXT NOT NULL,
      gateway_order_id TEXT,
      gateway_payment_id TEXT,
      gateway_signature TEXT,
      upi_utr TEXT,
      payer_upi_id TEXT,
      payer_detail TEXT,
      proof_storage_key TEXT,
      proof_filename TEXT,
      proof_mime TEXT,
      rejection_reason TEXT,
      status TEXT NOT NULL CHECK (status IN ('INITIATED', 'PENDING_VERIFICATION', 'PAID', 'FAILED', 'REFUNDED')),
      server_verified INTEGER NOT NULL DEFAULT 0,
      verified_by TEXT REFERENCES users(id),
      verified_at TEXT,
      refund_amount_inr INTEGER,
      refund_reason TEXT,
      refunded_at TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
    CREATE INDEX IF NOT EXISTS idx_pay_patient ON payments(patient_id, created_at DESC);

    CREATE TABLE IF NOT EXISTS notifications (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      appointment_id TEXT REFERENCES appointments(id) ON DELETE SET NULL,
      channel TEXT NOT NULL CHECK (channel IN ('IN_APP', 'WHATSAPP', 'EMAIL')),
      template_name TEXT,
      recipient_address TEXT,
      title TEXT NOT NULL,
      message TEXT NOT NULL,
      delivery_status TEXT NOT NULL DEFAULT 'SENT',
      is_read INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
    CREATE INDEX IF NOT EXISTS idx_notif_user ON notifications(user_id, is_read, created_at DESC);

    CREATE TABLE IF NOT EXISTS whatsapp_templates (
      id TEXT PRIMARY KEY,
      template_name TEXT UNIQUE NOT NULL,
      category TEXT NOT NULL,
      event_trigger TEXT NOT NULL,
      body_template TEXT NOT NULL,
      approval_status TEXT NOT NULL DEFAULT 'APPROVED',
      is_active INTEGER NOT NULL DEFAULT 1,
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS consent_records (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      consent_type TEXT NOT NULL,
      consent_version TEXT NOT NULL DEFAULT 'v1.0-DPDP-2026',
      granted INTEGER NOT NULL DEFAULT 1,
      guardian_declaration TEXT,
      ip_address TEXT,
      granted_at TEXT NOT NULL DEFAULT (datetime('now')),
      revoked_at TEXT
    );

    CREATE TABLE IF NOT EXISTS audit_logs (
      id TEXT PRIMARY KEY,
      actor_id TEXT,
      actor_role TEXT,
      actor_name TEXT,
      action TEXT NOT NULL,
      entity_type TEXT NOT NULL,
      entity_id TEXT,
      details TEXT,
      ip_address TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
    CREATE INDEX IF NOT EXISTS idx_audit_created ON audit_logs(created_at DESC);

    CREATE TABLE IF NOT EXISTS otp_verifications (
      id TEXT PRIMARY KEY,
      target TEXT NOT NULL,
      purpose TEXT NOT NULL,
      otp_hash TEXT NOT NULL,
      expires_at TEXT NOT NULL,
      consumed INTEGER NOT NULL DEFAULT 0,
      attempts INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS blog_articles (
      id TEXT PRIMARY KEY,
      slug TEXT UNIQUE NOT NULL,
      title TEXT NOT NULL,
      category TEXT NOT NULL,
      excerpt TEXT NOT NULL,
      content TEXT NOT NULL,
      read_time_minutes INTEGER NOT NULL DEFAULT 4,
      reviewed_by TEXT NOT NULL,
      is_published INTEGER NOT NULL DEFAULT 1,
      published_at TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS faqs (
      id TEXT PRIMARY KEY,
      category TEXT NOT NULL,
      question TEXT NOT NULL,
      answer TEXT NOT NULL,
      sort_order INTEGER NOT NULL DEFAULT 0,
      is_active INTEGER NOT NULL DEFAULT 1
    );

    CREATE TABLE IF NOT EXISTS announcements (
      id TEXT PRIMARY KEY,
      title TEXT NOT NULL,
      message TEXT NOT NULL,
      type TEXT NOT NULL DEFAULT 'INFO',
      is_active INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS support_tickets (
      id TEXT PRIMARY KEY,
      ticket_no TEXT UNIQUE NOT NULL,
      user_id TEXT REFERENCES users(id) ON DELETE SET NULL,
      sender_name TEXT NOT NULL,
      sender_email TEXT NOT NULL,
      sender_phone TEXT,
      subject TEXT NOT NULL,
      category TEXT NOT NULL DEFAULT 'GENERAL',
      message TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'OPEN' CHECK (status IN ('OPEN', 'IN_PROGRESS', 'RESOLVED')),
      staff_reply TEXT,
      replied_by TEXT,
      replied_at TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS feedback_reviews (
      id TEXT PRIMARY KEY,
      user_id TEXT REFERENCES users(id) ON DELETE SET NULL,
      patient_initials TEXT NOT NULL,
      city TEXT,
      rating INTEGER NOT NULL CHECK (rating BETWEEN 1 AND 5),
      concern_area TEXT,
      comment TEXT NOT NULL,
      is_approved INTEGER NOT NULL DEFAULT 0,
      is_demo INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS chatbot_settings (
      id TEXT PRIMARY KEY,
      bot_name TEXT NOT NULL,
      welcome_message TEXT NOT NULL,
      escalation_note TEXT NOT NULL,
      custom_kb_json TEXT NOT NULL,
      is_enabled INTEGER NOT NULL DEFAULT 1,
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS chatbot_logs (
      id TEXT PRIMARY KEY,
      session_key TEXT NOT NULL,
      category TEXT NOT NULL,
      user_query TEXT NOT NULL,
      bot_response TEXT NOT NULL,
      safety_triggered TEXT,
      escalated INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS clinic_messages (
      id TEXT PRIMARY KEY,
      patient_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      sender_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      sender_role TEXT NOT NULL CHECK (sender_role IN ('PATIENT', 'DOCTOR', 'STAFF', 'ADMIN')),
      sender_name TEXT NOT NULL,
      appointment_id TEXT REFERENCES appointments(id) ON DELETE SET NULL,
      message_type TEXT NOT NULL DEFAULT 'TEXT' CHECK (message_type IN ('TEXT', 'AUDIO_CALL', 'VIDEO_CALL')),
      content TEXT NOT NULL,
      call_url TEXT,
      call_phone TEXT,
      is_read INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
    CREATE INDEX IF NOT EXISTS idx_clinic_msg_patient ON clinic_messages(patient_id, created_at ASC);
    CREATE INDEX IF NOT EXISTS idx_clinic_msg_unread ON clinic_messages(patient_id, is_read);

    CREATE TABLE IF NOT EXISTS rtc_calls (
      id TEXT PRIMARY KEY,
      patient_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      patient_name TEXT NOT NULL,
      initiator_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      initiator_role TEXT NOT NULL,
      initiator_name TEXT NOT NULL,
      call_type TEXT NOT NULL CHECK (call_type IN ('AUDIO', 'VIDEO')),
      status TEXT NOT NULL DEFAULT 'RINGING' CHECK (status IN ('RINGING', 'CONNECTED', 'ENDED', 'DECLINED', 'MISSED')),
      offer_sdp TEXT,
      answer_sdp TEXT,
      caller_key TEXT,
      peer_key TEXT,
      auto_recording INTEGER NOT NULL DEFAULT 0 CHECK (auto_recording = 0),
      connected_at TEXT,
      ended_at TEXT,
      updated_at TEXT NOT NULL DEFAULT (datetime('now')),
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
    CREATE INDEX IF NOT EXISTS idx_rtc_calls_patient ON rtc_calls(patient_id, created_at DESC);
    CREATE INDEX IF NOT EXISTS idx_rtc_calls_status ON rtc_calls(status, created_at DESC);

    CREATE TABLE IF NOT EXISTS rtc_ice_candidates (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      call_id TEXT NOT NULL REFERENCES rtc_calls(id) ON DELETE CASCADE,
      sender_side TEXT NOT NULL CHECK (sender_side IN ('CALLER', 'CALLEE')),
      candidate_json TEXT NOT NULL,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
    CREATE INDEX IF NOT EXISTS idx_rtc_ice_call ON rtc_ice_candidates(call_id, id ASC);
  `);

  // Safe migration for existing DB: add users.google_sub, appointments.call_channel & seed initial demo chat
  const userCols = db.prepare("PRAGMA table_info(users)").all() as Array<{ name: string }>;
  if (!userCols.some((c) => c.name === 'google_sub')) {
    db.exec('ALTER TABLE users ADD COLUMN google_sub TEXT');
  }
  db.exec('CREATE INDEX IF NOT EXISTS idx_users_google_sub ON users(google_sub)');

  const apptCols = db.prepare("PRAGMA table_info(appointments)").all() as Array<{ name: string }>;
  if (!apptCols.some((c) => c.name === 'call_channel')) {
    db.exec("ALTER TABLE appointments ADD COLUMN call_channel TEXT NOT NULL DEFAULT 'WHATSAPP_VIDEO'");
  }

  const rtcCols = db.prepare("PRAGMA table_info(rtc_calls)").all() as Array<{ name: string }>;
  if (rtcCols.length > 0 && !rtcCols.some((c) => c.name === 'caller_key')) {
    db.exec('ALTER TABLE rtc_calls ADD COLUMN caller_key TEXT');
    db.exec('ALTER TABLE rtc_calls ADD COLUMN peer_key TEXT');
  }

  const payCols = db.prepare("PRAGMA table_info(payments)").all() as Array<{ name: string }>;
  if (payCols.length > 0 && !payCols.some((c) => c.name === 'proof_storage_key')) {
    db.exec('ALTER TABLE payments ADD COLUMN payer_upi_id TEXT');
    db.exec('ALTER TABLE payments ADD COLUMN proof_storage_key TEXT');
    db.exec('ALTER TABLE payments ADD COLUMN proof_filename TEXT');
    db.exec('ALTER TABLE payments ADD COLUMN proof_mime TEXT');
    db.exec('ALTER TABLE payments ADD COLUMN rejection_reason TEXT');
  }
  db.exec(
    "CREATE UNIQUE INDEX IF NOT EXISTS idx_pay_unique_utr ON payments(upi_utr) WHERE upi_utr IS NOT NULL AND status != 'FAILED'"
  );

  const userCount = (db.prepare('SELECT COUNT(*) as c FROM users').get() as { c: number }).c;
  const msgCount = (db.prepare('SELECT COUNT(*) as c FROM clinic_messages').get() as { c: number }).c;
  if (userCount > 0 && msgCount === 0) {
    seedInitialMessages(db);
  }
}

function seedInitialMessages(db: Database.Database) {
  const doc = db.prepare("SELECT id FROM users WHERE role = 'DOCTOR' LIMIT 1").get() as { id: string } | undefined;
  const p1 = db.prepare("SELECT id FROM users WHERE id = 'usr_pat_ananya_demo'").get() as { id: string } | undefined;
  const p2 = db.prepare("SELECT id FROM users WHERE id = 'usr_pat_rajesh_demo'").get() as { id: string } | undefined;
  if (!doc) return;
  const ins = db.prepare(`
    INSERT INTO clinic_messages (id, patient_id, sender_id, sender_role, sender_name, message_type, content, call_phone, is_read, created_at)
    VALUES (?, ?, ?, ?, ?, 'TEXT', ?, '+918123108149', ?, ?)
  `);
  if (p1) {
    ins.run('msg_demo_01', p1.id, doc.id, 'DOCTOR', 'Dr. Aparna Mishra',
      'Namaste Ananya! Welcome to your private clinic chat. You can message here before or after your online slot (Mon–Sat, 3:00 PM – 8:00 PM) or connect via Audio/Video Call on +91 8123108149 or In-App Call.',
      1, "2026-11-18 15:05:00");
    ins.run('msg_demo_02', p1.id, p1.id, 'PATIENT', 'Ananya Sharma',
      'Thank you Doctor! I have uploaded my latest Thyroid TSH report in Medical Reports ahead of tomorrow’s 4:30 PM follow-up call.',
      0, "2026-11-18 15:18:00");
  }
  if (p2) {
    ins.run('msg_demo_03', p2.id, p2.id, 'PATIENT', 'Rajesh Kumar',
      'Namaste Dr. Aparna, I am ready for my 5:00 PM consultation today. Shall I join on video call or +91 8123108149?',
      0, "2026-11-18 16:50:00");
    ins.run('msg_demo_04', p2.id, doc.id, 'DOCTOR', 'Dr. Aparna Mishra',
      'Namaste Rajesh ji, you may tap Video Call or Audio Call right at the top of this chat (either live in-portal or via WhatsApp/Phone on +91 8123108149) at 5:00 PM.',
      1, "2026-11-18 16:53:00");
  }
}

function isoDateOffset(daysFromToday: number): string {
  const base = new Date();
  base.setDate(base.getDate() + daysFromToday);
  // Skip Sunday (0) for scheduled clinic days when positive
  if (daysFromToday > 0 && base.getDay() === 0) {
    base.setDate(base.getDate() + 1);
  }
  return base.toISOString().slice(0, 10);
}

function seedIfEmpty(db: Database.Database) {
  const count = db.prepare('SELECT COUNT(*) as c FROM users').get() as { c: number };
  if (count.c > 0) return;

  const doctorPass = bcrypt.hashSync('Doctor@2026!', 10);
  const staffPass = bcrypt.hashSync('Staff@2026!', 10);
  const patientPass = bcrypt.hashSync('Patient@2026!', 10);

  const doctorId = 'usr_doctor_aparna';
  const staffId = 'usr_staff_meera';
  const pat1Id = 'usr_pat_ananya_demo';
  const pat2Id = 'usr_pat_rajesh_demo';
  const pat3Id = 'usr_pat_priya_demo';
  const pat4Id = 'usr_pat_kavita_demo';

  const seedTx = db.transaction(() => {
    // 1. Users
    const insertUser = db.prepare(`
      INSERT INTO users (id, email, phone, password_hash, full_name, role, auth_provider, email_verified, phone_verified, is_active, is_demo, last_login_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, 1, 1, 1, ?, datetime('now'))
    `);
    insertUser.run(doctorId, 'aparnabhms@gmail.com', '8123108149', doctorPass, 'Dr. Aparna Mishra', 'DOCTOR', 'EMAIL', 0);
    insertUser.run(staffId, 'staff.demo@aparnaclinic.in', '9000011122', staffPass, 'Meera Verma (Demo Staff)', 'STAFF', 'EMAIL', 1);
    insertUser.run(pat1Id, 'ananya.demo@example.com', '9800011101', patientPass, 'Ananya Sharma', 'PATIENT', 'EMAIL', 1);
    insertUser.run(pat2Id, 'rajesh.demo@example.com', '9800011102', patientPass, 'Rajesh Kumar', 'PATIENT', 'MOBILE_OTP', 1);
    insertUser.run(pat3Id, 'priya.demo@example.com', '9800011103', patientPass, 'Priya Sinha', 'PATIENT', 'GOOGLE', 1);
    insertUser.run(pat4Id, 'kavita.demo@example.com', '9800011104', patientPass, 'Kavita Nair', 'PATIENT', 'EMAIL', 1);

    // 2. Doctor Profile (Dr. Aparna Mishra's exact real details + editable registration placeholder)
    db.prepare(`
      INSERT INTO doctor_profiles (
        id, user_id, display_name, qualification, specialisation, experience_years,
        registration_number, registration_council, tagline, bio, approach_note,
        consultation_mode, timings_summary, languages, clinic_name, clinic_address,
        clinic_city, map_embed_url, phone, whatsapp_number, email, photo_url,
        upi_id, upi_payee_name, upi_qr_url
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      'doc_prof_aparna',
      doctorId,
      'Dr. Aparna Mishra',
      'BHMS (Bachelor of Homoeopathic Medicine & Surgery)',
      'Homoeopathic Physician · General & Constitutional Healthcare',
      7,
      '[State Council Reg. No. — Update in Admin CMS]',
      'State Board of Homoeopathic Medicine / NCH, India',
      'Compassionate Care, Individualized Healing.',
      'Dr. Aparna Mishra is a dedicated Homoeopathic Physician (BHMS) with 7 years of clinical experience in individualized, patient-centred healthcare and general consultation. She focuses on understanding each patient’s complete health profile, lifestyle, and symptom patterns across women’s health, thyroid care, skin and hair complaints, digestive wellness, joint discomfort, and respiratory allergies.',
      'Through structured online consultations, I aim to make professional homoeopathic and primary healthcare guidance accessible and convenient from the comfort of your home. Where in-person examination, diagnostic testing, specialist medical evaluation, or emergency care is clinically indicated, timely evaluation and referral are always advised.',
      'Online Consultation (Video & Audio — By Prior Booking)',
      'Monday to Saturday · 3:00 PM – 8:00 PM IST',
      'English, Hindi',
      'Dr. Aparna Mishra — Digital Homoeopathy & Wellness Clinic',
      'Online Tele-Consultation Practice (Pan-India) · [Clinic Chamber Address — Editable in Admin]',
      'India (Pan-India Online Practice)',
      'https://www.openstreetmap.org/export/embed.html?bbox=77.15%2C28.55%2C77.28%2C28.65&layer=mapnik',
      '+91 8123108149',
      '918123108149',
      'aparnabhms@gmail.com',
      '/images/dr-aparna-mishra.jpeg',
      'a72549567212@axl',
      'APARNA MISHRA',
      '/images/phonepe-qr.jpeg'
    );

    // 3. Staff Profile
    db.prepare(`
      INSERT INTO staff (id, user_id, staff_code, designation, department, permissions_json, joined_at)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `).run(
      'stf_01',
      staffId,
      'STF-2026-01',
      'Patient Care & Appointment Coordinator',
      'Online Clinic Desk',
      JSON.stringify(['appointments:manage', 'patients:read', 'payments:verify', 'whatsapp:send', 'support:manage', 'calendar:read']),
      '2025-04-01'
    );

    // 4. Demo Patient Profiles (clearly synthetic, including a minor/guardian account)
    const insertPat = db.prepare(`
      INSERT INTO patient_profiles (
        id, user_id, patient_code, date_of_birth, gender, blood_group, city, state, address,
        allergies, chronic_conditions, current_medications, emergency_contact_name, emergency_contact_phone,
        is_minor_account, guardian_name, guardian_relation, minor_patient_name, minor_date_of_birth
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    insertPat.run(
      'pp_01', pat1Id, 'PAT-DEMO-1001', '1997-04-14', 'Female', 'O+', 'Lucknow', 'Uttar Pradesh',
      'Gomti Nagar, Lucknow (Demo Record)', 'No known drug allergies', 'PCOS, Mild Subclinical Hypothyroidism',
      'Vitamin D3 weekly supplement', 'rohit Sharma (Spouse)', '9800099901', 0, null, null, null, null
    );
    insertPat.run(
      'pp_02', pat2Id, 'PAT-DEMO-1002', '1982-09-22', 'Male', 'B+', 'Patna', 'Bihar',
      'Boring Road, Patna (Demo Record)', 'Dust allergy', 'Chronic Acidity, Mild Knee Osteoarthritis',
      'Calcium + D3 daily', 'Sunita Kumar (Spouse)', '9800099902', 0, null, null, null, null
    );
    insertPat.run(
      'pp_03', pat3Id, 'PAT-DEMO-1003', '1990-06-10', 'Female', 'A+', 'Bengaluru', 'Karnataka',
      'Indiranagar, Bengaluru (Demo Record)', 'Pollen & cold air sensitivity (minor)', 'Seasonal Allergic Rhinitis (minor)',
      'Saline nasal drops PRN', 'Vikram Sinha (Father)', '9800099903', 1, 'Priya Sinha', 'Mother (Legal Guardian)', 'Aarav Sinha', '2017-08-19'
    );
    insertPat.run(
      'pp_04', pat4Id, 'PAT-DEMO-1004', '1991-12-03', 'Female', 'AB+', 'Pune', 'Maharashtra',
      'Kothrud, Pune (Demo Record)', 'Fragrance sensitivity', 'Recurrent Urticaria & Diffuse Hair Fall',
      'Iron + Folic acid', 'Arun Nair (Spouse)', '9800099904', 0, null, null, null, null
    );

    // 5. Medical Services (Exact 6 areas from screenshot + General Consultation)
    const insertSvc = db.prepare(`
      INSERT INTO medical_services (id, slug, title, short_description, full_description, conditions_json, icon_key, is_active, sort_order)
      VALUES (?, ?, ?, ?, ?, ?, ?, 1, ?)
    `);
    insertSvc.run(
      'svc_womens', 'womens-health', "Women's Health",
      'Menstrual health, PCOS and related concerns.',
      'Individualized homoeopathic case-taking and supportive lifestyle consultation for menstrual cycle irregularities, PCOS/PCOD symptoms, dysmenorrhoea, PMS, leucorrhoea, and perimenopausal wellbeing, coordinated with routine diagnostic monitoring where required.',
      JSON.stringify(['PCOS / PCOD Support', 'Irregular Menstrual Cycles', 'Painful Periods (Dysmenorrhoea)', 'PMS & Hormonal Imbalance', 'Perimenopausal Wellness']),
      'womens', 1
    );
    insertSvc.run(
      'svc_thyroid', 'thyroid-health', 'Thyroid Health',
      'Thyroid-related health concerns.',
      'Comprehensive constitutional homoeopathic care, periodic TSH/T3/T4 report review, fatigue and weight-management counselling, and supportive guidance for patients managing thyroid-related concerns alongside standard medical evaluation when advised.',
      JSON.stringify(['Hypothyroid Symptom Support', 'Thyroid Profile (TSH/FT4) Review', 'Fatigue, Weight & Metabolism', 'Postpartum Thyroid Follow-up', 'Nutritional & Lifestyle Guidance']),
      'thyroid', 2
    );
    insertSvc.run(
      'svc_skin', 'skin-and-hair', 'Skin & Hair',
      'Skin complaints, allergies and hair concerns.',
      'Gentle, root-cause oriented consultation for chronic and recurring dermatological and scalp complaints—evaluating triggers, stress, nutrition, sleep, and constitutional tendencies.',
      JSON.stringify(['Acne & Post-Acne Flare-ups', 'Eczema, Psoriasis & Dry Skin', 'Skin Allergies & Urticaria (Hives)', 'Diffuse Hair Fall & Alopecia Support', 'Dandruff & Seborrhoeic Scalp']),
      'skin', 3
    );
    insertSvc.run(
      'svc_digestive', 'digestive-health', 'Digestive Health',
      'Common digestive complaints.',
      'Structured consultation for recurring gastrointestinal discomfort, dietary habit optimisation, gut sensitivity, acidity, and bowel regularity—with red-flag screening and diagnostic referral whenever indicated.',
      JSON.stringify(['Hyperacidity, GERD & Heartburn', 'Gas, Bloating & Indigestion', 'Irritable Bowel (IBS) Support', 'Chronic Constipation', 'Food Sensitivity & Appetite Concerns']),
      'digestive', 4
    );
    insertSvc.run(
      'svc_joint', 'joint-health', 'Joint Health',
      'Joint discomfort and musculoskeletal complaints.',
      'Supportive homoeopathic management and ergonomic/postural care guidance for chronic joint stiffness, early degenerative joint discomfort, back and neck strain, and uric-acid-related joint complaints.',
      JSON.stringify(['Knee Pain & Osteoarthritis Support', 'Cervical & Lumbar Spondylosis', 'Joint Stiffness & Muscle Ache', 'Uric Acid / Gouty Discomfort', 'Sciatica & Postural Back Strain']),
      'joint', 5
    );
    insertSvc.run(
      'svc_respiratory', 'respiratory-health', 'Respiratory Health',
      'Allergies and common respiratory complaints.',
      'Constitutional care for recurring seasonal allergies, upper respiratory sensitivities, sinus congestion, and mild chronic cough—strictly advising immediate hospital care for acute breathlessness or high-risk respiratory distress.',
      JSON.stringify(['Allergic Rhinitis & Sneezing', 'Sinusitis & Nasal Congestion', 'Seasonal & Dust Allergies', 'Recurrent Cold, Cough & Tonsillitis', 'Mild Bronchial Sensitivity Follow-up']),
      'respiratory', 6
    );
    insertSvc.run(
      'svc_general', 'general-wellness', 'General Physician & Wellness Guidance',
      'Holistic online consultation for everyday non-emergency ailments and overall well-being.',
      'Complete primary wellness consultation for recurrent headaches/migraine, stress-related sleep disturbances, mild seasonal fevers, paediatric mild concerns (with parent/legal guardian), and preventive follow-up care.',
      JSON.stringify(['Migraine & Tension Headaches', 'Stress, Fatigue & Sleep Hygiene', 'Mild Seasonal Viral Complaints', 'Child Wellness (with Guardian)', 'Overall Constitutional Well-being']),
      'general', 7
    );

    // 6. Consultation Types
    const insertCt = db.prepare(`
      INSERT INTO consultation_types (id, name, description, mode, duration_minutes, fee_inr, is_active, sort_order)
      VALUES (?, ?, ?, ?, ?, ?, 1, ?)
    `);
    insertCt.run('ct_video_new', 'First Online Video Consultation', 'Comprehensive 30-minute video case-taking, report review, personalized homoeopathic prescription & lifestyle plan.', 'VIDEO', 30, 500, 1);
    insertCt.run('ct_chronic_video', 'Detailed Constitutional Case Review (Video)', 'In-depth 45-minute online consultation ideal for long-standing PCOS, Thyroid, Skin, Joint, or Allergic conditions.', 'VIDEO', 45, 700, 2);
    insertCt.run('ct_audio_new', 'Online Audio / Tele-Consultation', 'Convenient 20-minute private phone/audio consultation for low-bandwidth patients with digital prescription.', 'AUDIO', 20, 400, 3);
    insertCt.run('ct_followup', 'Follow-Up Online Consultation', '15-minute progress review, medicine potency adjustment, and continuation plan for existing patients.', 'FOLLOW_UP', 15, 300, 4);

    // 7. Doctor Availability: Monday (1) to Saturday (6), 15:00 (3:00 PM) to 20:00 (8:00 PM), Sunday (0) Off
    const days = [
      { d: 0, name: 'Sunday', enabled: 0 },
      { d: 1, name: 'Monday', enabled: 1 },
      { d: 2, name: 'Tuesday', enabled: 1 },
      { d: 3, name: 'Wednesday', enabled: 1 },
      { d: 4, name: 'Thursday', enabled: 1 },
      { d: 5, name: 'Friday', enabled: 1 },
      { d: 6, name: 'Saturday', enabled: 1 },
    ];
    const insertAvail = db.prepare(`
      INSERT INTO doctor_availability (day_of_week, day_name, is_enabled, start_time, end_time, slot_interval_minutes, buffer_minutes)
      VALUES (?, ?, ?, '15:00', '20:00', 30, 0)
    `);
    for (const day of days) {
      insertAvail.run(day.d, day.name, day.enabled);
    }

    // 8. Demo Appointments (Strictly within 3:00 PM – 8:00 PM Mon–Sat)
    const today = isoDateOffset(0);
    const tomorrow = isoDateOffset(1);
    const inTwoDays = isoDateOffset(2);
    const past1 = isoDateOffset(-7);
    const past2 = isoDateOffset(-14);

    const insertAppt = db.prepare(`
      INSERT INTO appointments (
        id, reference_no, patient_id, doctor_id, consultation_type_id, concern_category,
        appointment_date, start_time, end_time, duration_minutes, status, for_minor,
        patient_display_name, chief_complaint, symptom_duration, notes_for_doctor,
        fee_inr, payment_status, followup_date, followup_notes
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    // Past completed appointment for Ananya (with authorised Rx & report)
    insertAppt.run(
      'appt_demo_past1', 'APM-20261111-2104', pat1Id, doctorId, 'ct_chronic_video', "Women's Health",
      past1, '16:00', '16:45', 45, 'COMPLETED', 0, 'Ananya Sharma',
      'Irregular menstrual cycles (38–45 days) with PCOS and mild fatigue', '8 months',
      'Uploaded recent TSH & pelvic ultrasound summary for review.',
      700, 'PAID', isoDateOffset(7), 'Continue prescribed remedies for 14 days; track cycle dates and sleep schedule; book follow-up with repeat TSH if due.'
    );
    // Upcoming confirmed appointment for Ananya tomorrow at 4:30 PM
    insertAppt.run(
      'appt_demo_up1', 'APM-20261119-3418', pat1Id, doctorId, 'ct_followup', 'Thyroid Health',
      tomorrow, '16:30', '16:45', 15, 'CONFIRMED', 0, 'Ananya Sharma',
      'Scheduled follow-up for PCOS & thyroid wellness review, improved energy levels', '2 weeks follow-up',
      'Feeling better overall, mild evening bloating occasionally.',
      300, 'PAID', null, null
    );
    // Today confirmed appointment for Rajesh at 5:00 PM
    insertAppt.run(
      'appt_demo_today1', 'APM-20261118-5092', pat2Id, doctorId, 'ct_video_new', 'Digestive Health',
      today, '17:00', '17:30', 30, 'CONFIRMED', 0, 'Rajesh Kumar',
      'Post-meal acidity, bloating, and bilateral mild knee stiffness in mornings', '4 months',
      'Sedentary desk schedule, drinks 3 cups of tea daily.',
      500, 'PAID', null, null
    );
    // Today pending appointment for Minor Aarav (via Guardian Priya) at 6:00 PM (with PhonePe QR UTR pending verification)
    insertAppt.run(
      'appt_demo_today2', 'APM-20261118-6175', pat3Id, doctorId, 'ct_video_new', 'Respiratory Health',
      today, '18:00', '18:30', 30, 'PENDING', 1, 'Aarav Sinha (Minor · Guardian: Priya Sinha)',
      'Morning sneezing bouts and watery nasal discharge during weather change', '6 weeks',
      'No fever or breathlessness. Booked by mother/legal guardian.',
      500, 'PENDING_VERIFICATION', null, null
    );
    // Upcoming pending appointment for Kavita in 2 days at 3:30 PM
    insertAppt.run(
      'appt_demo_up2', 'APM-20261120-7820', pat4Id, doctorId, 'ct_video_new', 'Skin & Hair',
      inTwoDays, '15:30', '16:00', 30, 'CONFIRMED', 0, 'Kavita Nair',
      'Recurrent itchy wheals (urticaria) in evening and increased hair shedding', '3 months',
      'No lip swelling or breathing difficulty.',
      500, 'PAID', null, null
    );
    // Past completed appointment for Rajesh
    insertAppt.run(
      'appt_demo_past2', 'APM-20261104-1190', pat2Id, doctorId, 'ct_audio_new', 'Joint Health',
      past2, '19:00', '19:20', 20, 'COMPLETED', 0, 'Rajesh Kumar',
      'Mild right knee stiffness while climbing stairs', '3 months',
      'Requested audio consultation.',
      400, 'PAID', today, 'Gentle quadriceps strengthening exercises, warm compress, follow up in 2 weeks.'
    );

    // 9. Consultations (Authenticated private links, auto_recording = 0)
    const insertCons = db.prepare(`
      INSERT INTO consultations (
        id, appointment_id, patient_id, doctor_id, provider, room_code, access_token, meeting_url,
        status, auto_recording, started_at, ended_at, clinical_notes, homoeopathic_case_summary,
        provisional_impression, advice, referral_advised, followup_date
      ) VALUES (?, ?, ?, ?, 'JITSI_SECURE', ?, ?, ?, ?, 0, ?, ?, ?, ?, ?, ?, 0, ?)
    `);
    insertCons.run(
      'cons_01', 'appt_demo_past1', pat1Id, doctorId,
      'aparna-clinic-rx-9f3a2c1b8e', 'tok_demo_9f3a2c1b8e',
      'https://meet.jit.si/DrAparnaClinic-9f3a2c1b8e#config.prejoinPageEnabled=true&config.fileRecordingsEnabled=false&config.liveStreamingEnabled=false',
      'COMPLETED', `${past1}T10:30:00Z`, `${past1}T11:12:00Z`,
      'Patient alert, cooperative on video. Cycles delayed 38-45d, mild weight gain, chilly thermal reaction, thirstless, mild mood sensitivity.',
      'Constitutional totality points to gentle hormonal & metabolic support. Advised regular morning sunlight, 30-min brisk walk, protein-rich breakfast.',
      'Menstrual Irregularity associated with PCOS & Subclinical Hypothyroid tendency (Non-emergency online case)',
      'Maintain menstrual diary; avoid late-night heavy meals and refined sugar; repeat Serum TSH & Free T4 after 6 weeks.',
      isoDateOffset(7)
    );
    insertCons.run(
      'cons_02', 'appt_demo_up1', pat1Id, doctorId,
      'aparna-clinic-vc-4b8d1e7a2f', 'tok_demo_4b8d1e7a2f',
      'https://meet.jit.si/DrAparnaClinic-4b8d1e7a2f#config.prejoinPageEnabled=true&config.fileRecordingsEnabled=false&config.liveStreamingEnabled=false',
      'READY', null, null, null, null, null, null, 0
    );
    insertCons.run(
      'cons_03', 'appt_demo_today1', pat2Id, doctorId,
      'aparna-clinic-vc-7c2e9a5d10', 'tok_demo_7c2e9a5d10',
      'https://meet.jit.si/DrAparnaClinic-7c2e9a5d10#config.prejoinPageEnabled=true&config.fileRecordingsEnabled=false&config.liveStreamingEnabled=false',
      'READY', null, null, null, null, null, null, 0
    );
    insertCons.run(
      'cons_04', 'appt_demo_up2', pat4Id, doctorId,
      'aparna-clinic-vc-2a6f8c3e19', 'tok_demo_2a6f8c3e19',
      'https://meet.jit.si/DrAparnaClinic-2a6f8c3e19#config.prejoinPageEnabled=true&config.fileRecordingsEnabled=false&config.liveStreamingEnabled=false',
      'SCHEDULED', null, null, null, null, null, null, 0
    );

    // 10. Authorised Demo Prescriptions
    const rx1Meds = [
      {
        name: 'Pulsatilla Nigricans 30C (Demo Sample Entry)',
        dosage: '4 globules (size 30)',
        frequency: 'Twice daily (Morning & Evening)',
        duration: '14 days',
        instructions: 'Take on a clean tongue 20 minutes before meals; do not touch globules directly with hands.'
      },
      {
        name: 'Calcarea Phosphorica 6X Biochemic (Demo Sample Entry)',
        dosage: '4 tablets',
        frequency: 'Twice daily after meals',
        duration: '14 days',
        instructions: 'Dissolve slowly on tongue with lukewarm water.'
      }
    ];
    const rx1Sig = signDigitalHash(`RX-2026-1001|${pat1Id}|${doctorId}|${past1}`);
    db.prepare(`
      INSERT INTO prescriptions (
        id, prescription_no, appointment_id, consultation_id, patient_id, doctor_id,
        clinical_impression, symptoms_summary, medicines_json, general_instructions,
        dietary_advice, followup_date, referral_note, status, authorised_at, digital_signature_hash
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'AUTHORISED', ?, ?)
    `).run(
      'rx_demo_01', 'RX-2026-1001', 'appt_demo_past1', 'cons_01', pat1Id, doctorId,
      'PCOS-associated Oligomenorrhoea with Mild Subclinical Hypothyroid Support [DEMO RECORD]',
      'Delayed menstrual cycles (38–45 days), mild afternoon fatigue, occasional evening bloating.',
      JSON.stringify(rx1Meds),
      'Keep a 20–30 minute gap before and after taking homoeopathic medicines. Avoid strong-smelling substances (raw onion, strong coffee, camphor, mint) immediately around dose time. Store vials away from direct sunlight.',
      'Balanced home-cooked meals rich in fibre, leafy greens, sprouts, and adequate hydration (2.5 L/day). 30 minutes brisk walk 5 days/week. Consistent sleep before 11:00 PM.',
      isoDateOffset(7),
      'Continue periodic gynaecological/endocrinology laboratory monitoring (TSH, FT4). Seek immediate in-person medical evaluation in case of severe pelvic pain, heavy bleeding, or acute symptoms.',
      `${past1} 17:05:00`,
      rx1Sig
    );

    const rx2Meds = [
      {
        name: 'Rhus Toxicodendron 30C (Demo Sample Entry)',
        dosage: '4 globules (size 30)',
        frequency: 'Twice daily',
        duration: '10 days',
        instructions: 'Take 20 minutes before food on a clean tongue.'
      }
    ];
    const rx2Sig = signDigitalHash(`RX-2026-1000|${pat2Id}|${doctorId}|${past2}`);
    db.prepare(`
      INSERT INTO prescriptions (
        id, prescription_no, appointment_id, patient_id, doctor_id,
        clinical_impression, symptoms_summary, medicines_json, general_instructions,
        dietary_advice, followup_date, referral_note, status, authorised_at, digital_signature_hash
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'AUTHORISED', ?, ?)
    `).run(
      'rx_demo_02', 'RX-2026-1000', 'appt_demo_past2', pat2Id, doctorId,
      'Mild Early Knee Joint Stiffness — Supportive Care [DEMO RECORD]',
      'Morning stiffness in right knee improving after gentle movement.',
      JSON.stringify(rx2Meds),
      'Warm water fomentation for 10 minutes in the evening; avoid prolonged cross-legged sitting on floor.',
      'Adequate hydration, reduce excess tea/coffee, maintain healthy body weight.',
      today,
      'Orthopaedic in-person review and X-ray bilateral knees advised if swelling, locking, or persistent pain develops.',
      `${past2} 19:35:00`,
      rx2Sig
    );

    // 11. Demo Encrypted Medical Report in private_storage/reports/
    const demoReportText = [
      '================================================================',
      '  DEMO DIAGNOSTIC LABORATORY SUMMARY (SYNTHETIC TEST DATA ONLY) ',
      '================================================================',
      'Patient Name : Ananya Sharma [DEMO-1001]   Age/Sex: 29Y / Female',
      `Report Date  : ${past1}`,
      'Investigation: Thyroid Profile (Total T3, Total T4, Ultra-TSH)',
      '----------------------------------------------------------------',
      'Serum T3     : 1.18 ng/mL        (Ref: 0.80 - 2.00 ng/mL)',
      'Serum T4     : 7.90 ug/dL        (Ref: 5.10 - 14.10 ug/dL)',
      'Serum TSH    : 5.42 uIU/mL       (Ref: 0.27 - 4.20 uIU/mL) [Mildly Elevated]',
      '----------------------------------------------------------------',
      'Note: Synthetic sample file stored with AES-256-GCM encryption',
      'inside private server storage for RBAC demonstration.',
      '================================================================',
    ].join('\n');
    const storageKey = 'rep_demo_thyroid_ananya.txt.enc';
    const encrypted = encryptBuffer(Buffer.from(demoReportText, 'utf8'));
    fs.writeFileSync(path.join(PRIVATE_REPORTS_DIR, storageKey), encrypted);

    db.prepare(`
      INSERT INTO medical_reports (
        id, patient_id, appointment_id, uploaded_by, title, category, report_date,
        original_filename, storage_key, mime_type, file_size_bytes, is_encrypted,
        review_status, doctor_remarks, reviewed_by, reviewed_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, 'REVIEWED', ?, ?, ?)
    `).run(
      'rep_demo_01', pat1Id, 'appt_demo_past1', pat1Id,
      'Thyroid Function Profile (T3, T4, TSH) — Demo Lab Summary',
      'Thyroid Profile', past1,
      'ananya-demo-thyroid-profile.txt', storageKey, 'text/plain; charset=utf-8',
      Buffer.byteLength(demoReportText),
      'Reviewed during online consultation: Mildly elevated TSH (5.42 uIU/mL) with normal T3/T4. Correlated clinically; repeat fasting TSH & Free T4 in 6–8 weeks.',
      doctorId, `${past1} 16:50:00`
    );

    // 12. Demo Payments (All payment methods showcased)
    const insertPay = db.prepare(`
      INSERT INTO payments (
        id, receipt_no, appointment_id, patient_id, amount_inr, currency, gateway,
        payment_method, gateway_order_id, gateway_payment_id, upi_utr, payer_detail,
        status, server_verified, verified_by, verified_at, created_at
      ) VALUES (?, ?, ?, ?, ?, 'INR', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    insertPay.run(
      'pay_01', 'RCP-2026-8001', 'appt_demo_past1', pat1Id, 700,
      'PHONEPE_UPI_QR', 'PHONEPE_QR', null, null, '431518294011', 'PhonePe QR → a72549567212@axl',
      'PAID', 1, doctorId, `${past1} 15:20:00`, `${past1} 15:15:00`
    );
    insertPay.run(
      'pay_02', 'RCP-2026-8002', 'appt_demo_up1', pat1Id, 300,
      'RAZORPAY_TEST', 'UPI', 'order_demo_Upi901', 'pay_demo_Upi901', null, 'ananya@okhdfcbank (Test)',
      'PAID', 1, null, `${today} 10:05:00`, `${today} 10:05:00`
    );
    insertPay.run(
      'pay_03', 'RCP-2026-8003', 'appt_demo_today1', pat2Id, 500,
      'RAZORPAY_TEST', 'CARD', 'order_demo_Card442', 'pay_demo_Card442', null, 'RuPay Debit •••• 4821 (Test)',
      'PAID', 1, null, `${today} 09:30:00`, `${today} 09:30:00`
    );
    insertPay.run(
      'pay_04', 'RCP-2026-8004', 'appt_demo_today2', pat3Id, 500,
      'PHONEPE_UPI_QR', 'PHONEPE_QR', null, null, '432299104582', 'PhonePe QR UTR: 432299104582',
      'PENDING_VERIFICATION', 0, null, null, `${today} 11:40:00`
    );
    insertPay.run(
      'pay_05', 'RCP-2026-8005', 'appt_demo_up2', pat4Id, 500,
      'RAZORPAY_TEST', 'NETBANKING', 'order_demo_Nb715', 'pay_demo_Nb715', null, 'SBI NetBanking (Test)',
      'PAID', 1, null, `${today} 12:15:00`, `${today} 12:15:00`
    );
    insertPay.run(
      'pay_06', 'RCP-2026-8000', 'appt_demo_past2', pat2Id, 400,
      'RAZORPAY_TEST', 'WALLET', 'order_demo_Wal309', 'pay_demo_Wal309', null, 'Paytm Wallet (Test)',
      'PAID', 1, null, `${past2} 16:00:00`, `${past2} 16:00:00`
    );

    // 13. Approved WhatsApp Business Platform Templates (Zero sensitive medical info exposed)
    const insertTpl = db.prepare(`
      INSERT INTO whatsapp_templates (id, template_name, category, event_trigger, body_template, approval_status, is_active)
      VALUES (?, ?, 'UTILITY', ?, ?, 'APPROVED', 1)
    `);
    insertTpl.run('wa_01', 'appointment_confirmed_v1', 'APPOINTMENT_CONFIRMED',
      'Namaste {{1}}, your online consultation (Ref: {{2}}) with Dr. Aparna Mishra (BHMS) is confirmed for {{3}} at {{4}} IST. Log in to your secure Patient Portal 5 minutes before your slot. Help: +91 8123108149.');
    insertTpl.run('wa_02', 'appointment_reminder_24h', 'APPOINTMENT_REMINDER',
      'Reminder: Namaste {{1}}, your scheduled online appointment (Ref: {{2}}) with Dr. Aparna Mishra is on {{3}} at {{4}} IST. Please join securely via your Patient Portal.');
    insertTpl.run('wa_03', 'appointment_rescheduled_v1', 'APPOINTMENT_RESCHEDULED',
      'Update: Namaste {{1}}, your appointment (Ref: {{2}}) with Dr. Aparna Mishra has been rescheduled to {{3}} at {{4}} IST. For assistance call +91 8123108149.');
    insertTpl.run('wa_04', 'appointment_cancelled_v1', 'APPOINTMENT_CANCELLED',
      'Namaste {{1}}, your appointment (Ref: {{2}}) scheduled for {{3}} has been cancelled. Visit your Patient Portal to rebook (Mon–Sat, 3 PM – 8 PM) or contact +91 8123108149.');
    insertTpl.run('wa_05', 'payment_confirmation_v1', 'PAYMENT_CONFIRMED',
      'Namaste {{1}}, payment of INR {{2}} (Receipt: {{3}}) for appointment Ref {{4}} has been verified. Download your official receipt safely from your Patient Portal.');
    insertTpl.run('wa_06', 'followup_reminder_v1', 'FOLLOWUP_REMINDER',
      'Namaste {{1}}, your follow-up consultation with Dr. Aparna Mishra is due around {{2}}. You may book a convenient online slot (Mon–Sat, 3:00 PM – 8:00 PM) via your Patient Portal.');

    // 14. Sample Notifications
    const insertNotif = db.prepare(`
      INSERT INTO notifications (id, user_id, appointment_id, channel, template_name, recipient_address, title, message, delivery_status, is_read)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    insertNotif.run('ntf_01', pat1Id, 'appt_demo_up1', 'IN_APP', null, null,
      'Online Appointment Confirmed',
      `Your Follow-Up Online Consultation (Ref: APM-20261119-3418) with Dr. Aparna Mishra is confirmed for ${tomorrow} at 4:30 PM IST.`,
      'DELIVERED', 0);
    insertNotif.run('ntf_02', pat1Id, 'appt_demo_up1', 'WHATSAPP', 'appointment_confirmed_v1', '+919800011101',
      'WhatsApp Confirmation Queued',
      `Namaste Ananya Sharma, your online consultation (Ref: APM-20261119-3418) with Dr. Aparna Mishra (BHMS) is confirmed for ${tomorrow} at 4:30 PM IST.`,
      'QUEUED_SANDBOX', 1);
    insertNotif.run('ntf_03', pat1Id, 'appt_demo_past1', 'EMAIL', null, 'ananya.demo@example.com',
      'Authorised Digital Prescription Available',
      'Dr. Aparna Mishra has authorised prescription RX-2026-1001. Sign in to your secure Patient Portal to view and download the PDF.',
      'QUEUED_SANDBOX', 0);
    insertNotif.run('ntf_04', doctorId, 'appt_demo_today2', 'IN_APP', null, null,
      'New Booking & PhonePe UTR Verification Pending',
      'Priya Sinha (Guardian for Aarav Sinha) submitted booking APM-20261118-6175 for 6:00 PM today with PhonePe QR UTR 432299104582.',
      'DELIVERED', 0);

    // 15. DPDP & Telemedicine Consent Records
    const insertConsent = db.prepare(`
      INSERT INTO consent_records (id, user_id, consent_type, consent_version, granted, guardian_declaration, ip_address)
      VALUES (?, ?, ?, 'v1.0-DPDP-2026', 1, ?, '127.0.0.1')
    `);
    for (const pid of [pat1Id, pat2Id, pat3Id, pat4Id]) {
      insertConsent.run(generateId('cns'), pid, 'DPDP_DATA_PROCESSING', null);
      insertConsent.run(generateId('cns'), pid, 'TELEMEDICINE_CONSULTATION', null);
      insertConsent.run(generateId('cns'), pid, 'WHATSAPP_COMMUNICATION', null);
    }
    insertConsent.run(
      generateId('cns'), pat3Id, 'MINOR_GUARDIAN_AUTHORISATION',
      'Verified legal guardian (Mother: Priya Sinha) consenting for online consultation of minor child Aarav Sinha (DOB 2017-08-19).'
    );

    // 16. Doctor-Approved Health & Wellness Blog Articles
    const insertBlog = db.prepare(`
      INSERT INTO blog_articles (id, slug, title, category, excerpt, content, read_time_minutes, reviewed_by, is_published)
      VALUES (?, ?, ?, ?, ?, ?, ?, 'Dr. Aparna Mishra, BHMS', 1)
    `);
    insertBlog.run(
      'blg_01', 'understanding-pcos-and-cycle-wellness',
      'Understanding PCOS & Menstrual Health: Daily Habits Alongside Individualized Care',
      "Women's Health",
      'Practical, evidence-informed lifestyle rhythms—sleep timing, balanced Indian meals, stress regulation, and cycle tracking—that support women managing PCOS.',
      `Polycystic Ovary Syndrome (PCOS) affects a significant proportion of women of reproductive age in India and commonly presents with delayed or irregular menstrual cycles, acne, unwanted facial hair growth, weight fluctuations, and fatigue.\n\n### Why Individualized Assessment Matters\nNo two women experience PCOS identically. During a detailed online consultation, we review your complete menstrual timeline, sleep quality, stress patterns, appetite, thermal sensitivity, family history, and diagnostic reports (such as pelvic ultrasound, fasting insulin, lipid profile, and thyroid panel).\n\n### Foundational Lifestyle Pillars\n1. **Consistent Circadian Rhythm:** Aim for 7–8 hours of restorative sleep and consistent meal timings to support hormonal balance.\n2. **Balanced Indian Plate:** Pair complex carbohydrates (millets, hand-pounded rice, whole wheat rotis) with adequate protein (dal, paneer, curd, sprouts, eggs) and seasonal vegetables.\n3. **Regular Movement:** 30–40 minutes of brisk walking, yoga, or strength training five days a week improves insulin sensitivity.\n4. **Cycle Tracking:** Record period start dates, flow duration, pain intensity, and premenstrual mood changes before your follow-up.\n\n### When to Seek Immediate In-Person Care\nOnline consultation is suited for non-emergency chronic guidance. Always seek prompt in-person gynaecological evaluation for severe acute abdominal pain, heavy prolonged bleeding, fainting, or pregnancy-related concerns.\n\n*Educational note: This article is for general health awareness and does not substitute an individualized medical consultation.*`,
      5
    );
    insertBlog.run(
      'blg_02', 'thyroid-health-monitoring-and-lifestyle-guide',
      'Thyroid Wellness Guide: Making Sense of Routine Check-ups & Everyday Energy',
      'Thyroid Health',
      'Learn how regular TSH monitoring, nutrition, stress management, and supportive constitutional care work together for long-term thyroid wellness.',
      `The thyroid gland plays a vital role in regulating metabolism, body temperature, heart rate, menstrual regularity, skin texture, and emotional well-being.\n\n### Common Signs Worth Discussing with a Physician\nPersistent unexplained fatigue, unexpected weight gain or loss, dry skin, increased hair fall, sensitivity to cold or heat, constipation, or irregular periods merit a clinical review and a simple blood thyroid panel (TSH, Free T3, Free T4).\n\n### Preparing for Your Online Thyroid Consultation\n- Upload your latest and previous thyroid lab reports in the secure **Patient Portal** before your appointment.\n- Note down all current medicines and supplements—never abruptly stop any ongoing prescribed thyroid hormone medication without explicit medical supervision.\n- Keep a short note of your sleep hours, energy dips, and bowel patterns.\n\n### Everyday Supportive Practices\nPrioritize whole, minimally processed home-cooked meals, adequate selenium and Vitamin D status (guided by lab tests), gentle daily exercise, and structured stress relief. Timely referral to an endocrinologist is advised whenever thyroid nodules, pregnancy thyroid adjustments, or marked hormonal derangements are present.\n\n*Educational note: For general awareness only; always consult a qualified physician for personal medical advice.*`,
      4
    );
    insertBlog.run(
      'blg_03', 'managing-seasonal-respiratory-allergies-in-india',
      'Seasonal Allergies & Dust Sensitivity: Practical Home Prevention Tips',
      'Respiratory Health',
      'Weather transitions, indoor dust, and urban air quality frequently trigger sneezing and sinus congestion. Here is how to minimize everyday triggers safely.',
      `Recurrent morning sneezing, watery nasal discharge, itchy eyes, and post-nasal drip are common across changing Indian seasons—especially during monsoon transitions and winter smog.\n\n### Reducing Everyday Environmental Triggers\n- **Bedroom Hygiene:** Sun-dry pillows and blankets regularly and wash bed linens weekly in warm water to limit dust mites.\n- **Ventilation & Masks:** On high-AQI or dusty days, wear a well-fitted mask outdoors and rinse your face and nostrils gently after returning home.\n- **Hydration & Warm Fluids:** Sip lukewarm water through the day and avoid sudden exposure from hot outdoors directly into very cold air-conditioning.\n- **Identify Personal Triggers:** Keep a note of whether symptoms worsen with damp weather, cold wind, incense smoke, strong perfumes, or specific foods.\n\n### Important Safety Red Flags\nSeek urgent in-person emergency care (or call **112 / 108**) immediately if you experience breathlessness, wheezing at rest, chest tightness, bluish lips, drop in oxygen saturation, or high persistent fever.`,
      4
    );
    insertBlog.run(
      'blg_04', 'chronic-acidity-digestive-comfort-habits',
      'Digestive Comfort in a Busy Routine: Simple Habits for Acidity & Bloating',
      'Digestive Health',
      'Late dinners, rushed meals, and excess tea or coffee quietly disrupt digestion. Explore practical steps that restore daily gut comfort.',
      `Digestive complaints such as post-meal heaviness, sour eructations, bloating, and irregular bowel movements are closely linked to modern desk routines and irregular eating schedules.\n\n### Six Clinic-Recommended Daily Habits\n1. Maintain a 2.5 to 3-hour gap between dinner and lying down.\n2. Avoid drinking strong tea or coffee on an empty stomach first thing in the morning.\n3. Chew slowly without screen distractions and keep portion sizes moderate at night.\n4. Include natural probiotics such as fresh homemade curd or buttermilk during daytime meals if tolerated.\n5. Walk gently for 10–15 minutes after lunch and dinner.\n6. Take regular posture breaks if your work involves prolonged sitting.\n\n### Warning Signs Requiring Prompt Evaluation\nDifficulty swallowing, persistent vomiting, unexplained weight loss, black stools, blood in stool, or severe abdominal pain always require immediate in-person medical evaluation.`,
      4
    );
    insertBlog.run(
      'blg_05', 'skin-and-hair-care-from-within',
      'Healthy Skin & Hair from Within: Hydration, Nutrition & Gentle Care',
      'Skin & Hair',
      'Why recurring skin flare-ups and hair fall often reflect internal nutrition, stress, sleep, and gentle barrier care rather than harsh topical routines.',
      `Skin allergies, recurring acne, dry itchy patches, and diffuse hair fall are among the most common reasons patients seek online homoeopathic consultation.\n\n### Looking Beyond the Surface\nDuring consultation, we evaluate potential internal contributors—iron/ferritin levels, Vitamin B12 and Vitamin D status, thyroid balance, menstrual health, recent febrile illness, emotional stress, dandruff, and harsh cosmetic products.\n\n### Gentle Everyday Care\n- Use mild, fragrance-free cleansers and lukewarm (not hot) water.\n- Never self-medicate with over-the-counter steroid creams on facial skin or rashes.\n- Support hair health with adequate dietary protein, iron-rich greens, seeds, and gentle scalp hygiene.\n- Take clear, well-lit photographs or upload dermatology/blood reports securely to your Patient Portal prior to your video slot so the doctor can review them accurately.`,
      4
    );

    // 17. Frequently Asked Questions
    const insertFaq = db.prepare(`
      INSERT INTO faqs (id, category, question, answer, sort_order, is_active)
      VALUES (?, ?, ?, ?, ?, 1)
    `);
    const faqList = [
      ['Appointments & Timings', 'What are Dr. Aparna Mishra’s consultation timings?', 'Online consultations are available Monday to Saturday, from 3:00 PM to 8:00 PM IST, strictly by prior appointment booking. The clinic remains closed on Sundays.', 1],
      ['Appointments & Timings', 'How do I book an online consultation?', 'Click "Book Appointment", select your consultation type (Video, Detailed Case Review, Audio, or Follow-Up), choose an available date and time slot between 3:00 PM and 8:00 PM, complete sign-in, accept telemedicine consent, and pay securely. You will immediately receive an Appointment Reference Number.', 2],
      ['Online Consultation', 'How do I join my video consultation and is it recorded?', 'Log in to your Patient Portal and open "Video Consultation" 5–10 minutes before your scheduled slot. Click your authenticated session button to join from any smartphone, tablet, or laptop browser. For strict patient privacy, consultations are NEVER automatically recorded.', 3],
      ['Doctor & Services', 'What qualifications and areas of consultation does Dr. Aparna Mishra cover?', 'Dr. Aparna Mishra holds a BHMS (Bachelor of Homoeopathic Medicine & Surgery) degree with 7 years of clinical experience. Key areas of consultation include Women’s Health (menstrual health, PCOS), Thyroid Health, Skin & Hair, Digestive Health, Joint Health, Respiratory Health & Allergies, and General Non-Emergency Wellness.', 4],
      ['Payments & Receipts', 'Which payment methods are accepted?', 'We accept all major Indian payment options: direct PhonePe / Google Pay / Paytm / BHIM UPI QR scan (VPA: a72549567212@axl) with UTR submission, as well as online checkout supporting UPI ID, Credit/Debit Cards (RuPay, Visa, Mastercard), NetBanking, Wallets, and Pay Later. Downloadable PDF receipts are stored in your Patient Portal.', 5],
      ['Prescriptions & Reports', 'How will I receive my prescription and upload previous lab reports?', 'Before your consultation, upload PDF or image lab reports in Patient Portal → Medical Reports (stored with AES-256-GCM encryption). After your consultation, Dr. Aparna Mishra authorises your digital prescription, which becomes instantly available as a downloadable PDF under "My Prescriptions".', 6],
      ['Account & Family', 'Can I book an online consultation for my child (minor)?', 'Yes. Parents and legal guardians can register a Parent/Legal Guardian account during sign-up, provide explicit guardian consent, and book and attend online consultations together with their minor child.', 7],
      ['Account & Family', 'What sign-in options are available for patients?', 'You can sign in using Email & Password, Mobile Number with one-time OTP verification, Google Sign-In, or Apple Sign-In, and reset your password securely at any time.', 8],
      ['Safety & Privacy', 'How is my personal health information protected?', 'All health records follow strict role-based access control—patients can view only their own authorised documents. Uploaded reports are encrypted at rest, sessions use HttpOnly signed tokens, consent records are maintained in line with India’s DPDP Act 2023, and WhatsApp/email reminders never expose sensitive diagnosis details.', 9],
      ['Safety & Privacy', 'Can I use this platform for a medical emergency?', 'No. Online consultations are strictly for non-emergency healthcare. If you experience chest pain, severe breathlessness, stroke symptoms, heavy bleeding, high uncontrolled fever, severe injury, or any medical emergency, please visit the nearest hospital emergency department immediately or dial 112 / 108.', 10],
    ];
    faqList.forEach(([cat, q, a, ord], idx) => {
      insertFaq.run(`faq_${idx + 1}`, cat, q, a, ord);
    });

    // 18. Clinic Announcement
    db.prepare(`
      INSERT INTO announcements (id, title, message, type, is_active)
      VALUES (?, ?, ?, 'INFO', 1)
    `).run(
      'ann_01',
      'Online Consultations Open',
      'Mon–Sat · 3:00 PM to 8:00 PM IST · Online Homoeopathic & General Wellness Consultation by prior booking · Helpline/WhatsApp: +91 8123108149'
    );

    // 19. Chatbot Settings
    db.prepare(`
      INSERT INTO chatbot_settings (id, bot_name, welcome_message, escalation_note, custom_kb_json, is_enabled)
      VALUES ('default', ?, ?, ?, ?, 1)
    `).run(
      'Clinic Care Assistant',
      'Namaste! I am Dr. Aparna Mishra’s automated Clinic Assistant. I can help you with consultation timings (3 PM – 8 PM, Mon–Sat), services, fees, booking steps, payments, and prescription downloads. I do not provide medical diagnosis or prescriptions.',
      'For direct human assistance, message our clinic desk on WhatsApp at +91 8123108149, email aparnabhms@gmail.com, or submit a ticket in Support.',
      JSON.stringify([
        { topic: 'homoeopathic medicine instructions', answer: 'Please follow the exact instructions written on your authorised PDF prescription inside the Patient Portal. For any clarification about ongoing medicines, book a follow-up or message the clinic support desk—our chatbot never advises dosages.' },
        { topic: 'reschedule policy', answer: 'You can reschedule or cancel an upcoming appointment from Patient Portal → My Appointments at least 3 hours prior to your scheduled slot, or contact +91 8123108149.' }
      ])
    );

    // 20. Sample Support Ticket & Approved Demo Feedback
    db.prepare(`
      INSERT INTO support_tickets (id, ticket_no, user_id, sender_name, sender_email, sender_phone, subject, category, message, status)
      VALUES ('tkt_01', 'SUP-2026-401', ?, 'Rajesh Kumar', 'rajesh.demo@example.com', '9800011102',
      'Can I share older X-ray image before 5 PM call?', 'REPORTS',
      'Hello clinic team, I have a 6-month-old knee X-ray photo on my phone. Should I upload it in Medical Reports before today’s 5:00 PM consultation?', 'OPEN')
    `).run(pat2Id);

    const insertFb = db.prepare(`
      INSERT INTO feedback_reviews (id, user_id, patient_initials, city, rating, concern_area, comment, is_approved, is_demo)
      VALUES (?, ?, ?, ?, ?, ?, ?, 1, 1)
    `);
    insertFb.run('fb_01', pat1Id, 'A. S. (Demo)', 'Lucknow', 5, "Women's Health",
      'Very patient and attentive online consultation. Booking an evening slot after work and downloading the digital prescription from the portal was effortless.');
    insertFb.run('fb_02', pat2Id, 'R. K. (Demo)', 'Patna', 5, 'Digestive Health',
      'Dr. Aparna listened carefully to my full routine and dietary habits instead of rushing. Clear instructions and easy follow-up scheduling.');
    insertFb.run('fb_03', pat3Id, 'P. S. (Demo)', 'Bengaluru', 5, 'Respiratory Health',
      'Appreciated the dedicated parent/guardian booking option and clear guidance on home allergy precautions.');

    // 21. Initial Audit Log
    db.prepare(`
      INSERT INTO audit_logs (id, actor_id, actor_role, actor_name, action, entity_type, entity_id, details, ip_address)
      VALUES (?, ?, 'DOCTOR', 'Dr. Aparna Mishra', 'SYSTEM_INITIALIZED', 'CLINIC_PLATFORM', 'v1.0',
      'Database initialised with RBAC, AES-256-GCM report storage, DPDP consent ledger, and clearly labelled demo dataset.', '127.0.0.1')
    `).run(generateId('aud'), doctorId);

    seedInitialMessages(db);
  });

  seedTx();
}

export function logAudit(params: {
  actorId?: string | null;
  actorRole?: string | null;
  actorName?: string | null;
  action: string;
  entityType: string;
  entityId?: string | null;
  details?: string | null;
  ipAddress?: string | null;
}) {
  const db = getDb();
  db.prepare(`
    INSERT INTO audit_logs (id, actor_id, actor_role, actor_name, action, entity_type, entity_id, details, ip_address)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    generateId('aud'),
    params.actorId || null,
    params.actorRole || 'SYSTEM',
    params.actorName || 'System',
    params.action,
    params.entityType,
    params.entityId || null,
    params.details || null,
    params.ipAddress || '127.0.0.1'
  );
}

export function timeToMinutes(hhmm: string): number {
  const [h, m] = hhmm.split(':').map(Number);
  return (h || 0) * 60 + (m || 0);
}

export function minutesToTime(mins: number): string {
  const h = Math.floor(mins / 60);
  const m = mins % 60;
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
}

export function formatTime12h(hhmm: string): string {
  const [hStr, mStr] = hhmm.split(':');
  const h = Number(hStr);
  const suffix = h >= 12 ? 'PM' : 'AM';
  const h12 = h % 12 === 0 ? 12 : h % 12;
  return `${h12}:${mStr} ${suffix}`;
}

/**
 * Computes available appointment slots for a date & consultation duration,
 * strictly respecting Mon–Sat 3:00 PM – 8:00 PM schedule, blocked dates,
 * and preventing any overlapping appointments.
 */
export function computeAvailableSlots(
  dateStr: string,
  durationMinutes: number,
  excludeAppointmentId?: string
): {
  available: boolean;
  reason?: string;
  dayName: string;
  slots: Array<{ startTime: string; endTime: string; label: string; isBooked: boolean }>;
} {
  const db = getDb();
  if (!/^\d{4}-\d{2}-\d{2}$/.test(dateStr)) {
    return { available: false, reason: 'Invalid date format.', dayName: '', slots: [] };
  }

  const [y, m, d] = dateStr.split('-').map(Number);
  const dt = new Date(Date.UTC(y, m - 1, d));
  const dayOfWeek = dt.getUTCDay();

  const avail = db
    .prepare('SELECT * FROM doctor_availability WHERE day_of_week = ?')
    .get(dayOfWeek) as
    | {
        day_name: string;
        is_enabled: number;
        start_time: string;
        end_time: string;
        slot_interval_minutes: number;
        buffer_minutes: number;
      }
    | undefined;

  if (!avail || !avail.is_enabled) {
    return {
      available: false,
      reason: `Clinic is closed on ${avail?.day_name || 'this day'}. Online consultations run Monday to Saturday, 3:00 PM – 8:00 PM IST.`,
      dayName: avail?.day_name || '',
      slots: [],
    };
  }

  const blocked = db
    .prepare('SELECT reason FROM blocked_dates WHERE blocked_date = ?')
    .get(dateStr) as { reason?: string } | undefined;
  if (blocked) {
    return {
      available: false,
      reason: blocked.reason
        ? `Doctor unavailable on ${dateStr}: ${blocked.reason}`
        : `Doctor is unavailable on ${dateStr}. Please choose another date.`,
      dayName: avail.day_name,
      slots: [],
    };
  }

  // Auto-release abandoned UNPAID checkout holds older than 15 minutes so unpaid clicks never block slots
  db.prepare(`
    UPDATE appointments
    SET status = 'CANCELLED',
        rejection_or_cancel_reason = 'Checkout expired — payment was not completed within 15 minutes',
        updated_at = datetime('now')
    WHERE status = 'PENDING'
      AND payment_status = 'UNPAID'
      AND created_at < datetime('now', '-15 minutes')
  `).run();

  const existing = db
    .prepare(
      `SELECT id, start_time, end_time FROM appointments
       WHERE appointment_date = ? AND status NOT IN ('CANCELLED', 'REJECTED')`
    )
    .all(dateStr) as Array<{ id: string; start_time: string; end_time: string }>;

  const startMin = timeToMinutes(avail.start_time);
  const endMin = timeToMinutes(avail.end_time);
  const step = Math.max(15, avail.slot_interval_minutes || 30);
  const buffer = Math.max(0, avail.buffer_minutes || 0);

  const slots: Array<{ startTime: string; endTime: string; label: string; isBooked: boolean }> = [];
  for (let cur = startMin; cur + durationMinutes <= endMin; cur += step) {
    const slotEnd = cur + durationMinutes;
    const overlaps = existing.some((appt) => {
      if (excludeAppointmentId && appt.id === excludeAppointmentId) return false;
      const aStart = timeToMinutes(appt.start_time) - buffer;
      const aEnd = timeToMinutes(appt.end_time) + buffer;
      return cur < aEnd && slotEnd > aStart;
    });

    const st = minutesToTime(cur);
    const et = minutesToTime(slotEnd);
    slots.push({
      startTime: st,
      endTime: et,
      label: formatTime12h(st),
      isBooked: overlaps,
    });
  }

  return {
    available: true,
    dayName: avail.day_name,
    slots,
  };
}

export function getDoctorPublicProfile() {
  const db = getDb();
  return db.prepare('SELECT * FROM doctor_profiles LIMIT 1').get() as {
    id: string;
    user_id: string;
    display_name: string;
    qualification: string;
    specialisation: string;
    experience_years: number;
    registration_number: string;
    registration_council: string;
    tagline: string;
    bio: string;
    approach_note: string;
    consultation_mode: string;
    timings_summary: string;
    languages: string;
    clinic_name: string;
    clinic_address: string;
    clinic_city: string;
    map_embed_url: string;
    phone: string;
    whatsapp_number: string;
    email: string;
    photo_url: string;
    upi_id: string;
    upi_payee_name: string;
    upi_qr_url: string;
  };
}
