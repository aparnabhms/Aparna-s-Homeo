import { getDb, getDoctorPublicProfile } from './db';
import { getSessionWithToken } from './auth';

export async function getPublicShellContext(fallbackToken?: string | null) {
  const db = getDb();
  const doctor = getDoctorPublicProfile();
  const session = await getSessionWithToken(fallbackToken);
  const user = session?.user || null;
  const ann = db
    .prepare('SELECT message FROM announcements WHERE is_active = 1 ORDER BY created_at DESC LIMIT 1')
    .get() as { message: string } | undefined;
  const bot = db
    .prepare('SELECT welcome_message FROM chatbot_settings WHERE id = ?')
    .get('default') as { welcome_message: string } | undefined;

  return {
    doctor,
    user: user ? { fullName: user.fullName, role: user.role, email: user.email, phone: user.phone } : null,
    sessionToken: session?.token || undefined,
    announcement: ann?.message || null,
    chatbotWelcome: bot?.welcome_message,
  };
}
