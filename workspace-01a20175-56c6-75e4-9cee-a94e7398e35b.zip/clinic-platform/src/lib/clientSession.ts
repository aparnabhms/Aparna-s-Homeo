'use client';

export const CLIENT_TOKEN_KEY = 'aparna_clinic_session_token';
const WINDOW_NAME_PREFIX = '__APARNA_CLINIC_SESSION__:';

declare global {
  interface Window {
    __APARNA_SESSION_TOKEN__?: string | null;
    __aparnaFetchPatched?: boolean;
  }
}

function readWindowNameToken(): string | null {
  if (typeof window === 'undefined') return null;
  try {
    const wn = window.name || '';
    if (wn.startsWith(WINDOW_NAME_PREFIX)) {
      const tok = wn.slice(WINDOW_NAME_PREFIX.length).trim();
      return tok || null;
    }
  } catch {
    // ignore
  }
  return null;
}

function writeWindowNameToken(token: string | null): void {
  if (typeof window === 'undefined') return;
  try {
    if (token) {
      window.name = `${WINDOW_NAME_PREFIX}${token}`;
    } else if ((window.name || '').startsWith(WINDOW_NAME_PREFIX)) {
      window.name = '';
    }
  } catch {
    // ignore
  }
}

/**
 * Saves session JWT across all 4 browser layers (window global, window.name,
 * sessionStorage, localStorage) so sessions persist reliably even when a browser
 * blocks third-party cookies AND localStorage inside an embedded preview iframe.
 */
export function saveClientSession(token: string | null | undefined): void {
  if (typeof window === 'undefined' || !token) return;
  const clean = String(token).trim();
  if (!clean) return;

  window.__APARNA_SESSION_TOKEN__ = clean;
  writeWindowNameToken(clean);

  try {
    window.sessionStorage.setItem(CLIENT_TOKEN_KEY, clean);
  } catch {
    // storage blocked in strict iframe mode — window global & window.name still hold it
  }
  try {
    window.localStorage.setItem(CLIENT_TOKEN_KEY, clean);
  } catch {
    // storage blocked in strict iframe mode — window global & window.name still hold it
  }
}

export function getClientSessionToken(explicitToken?: string | null): string | null {
  if (explicitToken && String(explicitToken).trim()) {
    return String(explicitToken).trim();
  }
  if (typeof window === 'undefined') return null;

  // 1. Active URL handoff token (highest priority right after login / new-tab open)
  try {
    const urlTok = new URLSearchParams(window.location.search).get('_st');
    if (urlTok && urlTok.trim()) {
      const clean = urlTok.trim();
      window.__APARNA_SESSION_TOKEN__ = clean;
      writeWindowNameToken(clean);
      return clean;
    }
  } catch {
    // ignore
  }

  // 2. Shared window global (works across all Next.js chunks, even with zero storage)
  if (window.__APARNA_SESSION_TOKEN__) {
    return window.__APARNA_SESSION_TOKEN__;
  }

  // 3. sessionStorage -> localStorage
  try {
    const ss = window.sessionStorage.getItem(CLIENT_TOKEN_KEY);
    if (ss) {
      window.__APARNA_SESSION_TOKEN__ = ss;
      return ss;
    }
  } catch {
    // ignore
  }
  try {
    const ls = window.localStorage.getItem(CLIENT_TOKEN_KEY);
    if (ls) {
      window.__APARNA_SESSION_TOKEN__ = ls;
      return ls;
    }
  } catch {
    // ignore
  }

  // 4. window.name fallback (survives full-page navigations even when all cookies & storage are blocked)
  const wnTok = readWindowNameToken();
  if (wnTok) {
    window.__APARNA_SESSION_TOKEN__ = wnTok;
    return wnTok;
  }

  return null;
}

export function clearClientSession(): void {
  if (typeof window === 'undefined') return;
  window.__APARNA_SESSION_TOKEN__ = null;
  writeWindowNameToken(null);
  try {
    window.sessionStorage.removeItem(CLIENT_TOKEN_KEY);
  } catch {
    // ignore
  }
  try {
    window.localStorage.removeItem(CLIENT_TOKEN_KEY);
  } catch {
    // ignore
  }
}

export function buildAuthedUrl(path: string, explicitToken?: string | null): string {
  if (typeof window === 'undefined') return path;
  const token = getClientSessionToken(explicitToken);
  if (!token) return path;

  try {
    const url = new URL(path, window.location.origin);
    if (url.origin !== window.location.origin) return path;
    url.searchParams.set('_st', token);
    return `${url.pathname}${url.search}${url.hash}`;
  } catch {
    return path;
  }
}

/**
 * Guaranteed-authenticated fetch wrapper for clinic API endpoints.
 * Attaches Cookie + Authorization: Bearer + X-Clinic-Session + _st fallback
 * so no API call (chat, audio/video RTC, booking, prescriptions) ever drops auth.
 */
export async function authFetch(
  path: string,
  init?: RequestInit,
  explicitToken?: string | null
): Promise<Response> {
  const token = getClientSessionToken(explicitToken);
  const headers = new Headers(init?.headers || undefined);

  if (token) {
    if (!headers.has('Authorization')) {
      headers.set('Authorization', `Bearer ${token}`);
    }
    if (!headers.has('X-Clinic-Session')) {
      headers.set('X-Clinic-Session', token);
    }
  }

  let finalUrl = path;
  if (token && typeof window !== 'undefined' && path.startsWith('/api/')) {
    try {
      const u = new URL(path, window.location.origin);
      if (!u.searchParams.has('_st')) {
        u.searchParams.set('_st', token);
      }
      finalUrl = `${u.pathname}${u.search}`;
    } catch {
      finalUrl = path;
    }
  }

  const resp = await fetch(finalUrl, {
    ...init,
    headers,
    credentials: 'include',
    cache: 'no-store',
  });

  return resp;
}

export function navigateWithSession(path: string, token?: string | null): void {
  const resolved = getClientSessionToken(token);
  if (resolved) {
    saveClientSession(resolved);
  }
  const dest = buildAuthedUrl(path, resolved);
  window.location.assign(dest);
}
