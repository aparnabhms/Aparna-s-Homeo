import PDFDocument from 'pdfkit';

export interface MedicineItem {
  name: string;
  dosage: string;
  frequency: string;
  duration: string;
  instructions?: string;
}

export async function generatePrescriptionPdf(data: {
  prescriptionNo: string;
  authorisedAt: string;
  digitalSignatureHash: string;
  doctorName: string;
  qualification: string;
  specialisation: string;
  registrationNumber: string;
  clinicName: string;
  phone: string;
  email: string;
  timings: string;
  patientName: string;
  patientCode: string;
  patientGenderAge: string;
  appointmentRef?: string;
  clinicalImpression: string;
  symptomsSummary?: string;
  medicines: MedicineItem[];
  generalInstructions?: string;
  dietaryAdvice?: string;
  followupDate?: string;
  referralNote?: string;
}): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    const doc = new PDFDocument({ size: 'A4', margin: 46 });
    const chunks: Buffer[] = [];
    doc.on('data', (c) => chunks.push(Buffer.from(c)));
    doc.on('end', () => resolve(Buffer.concat(chunks)));
    doc.on('error', reject);

    const navy = '#153B5B';
    const teal = '#168B83';
    const slate = '#334155';
    const muted = '#64748B';

    // Top Accent Bar
    doc.rect(0, 0, doc.page.width, 8).fill(navy);
    doc.rect(0, 8, doc.page.width, 3).fill(teal);

    // Letterhead
    doc.fillColor(navy).font('Helvetica-Bold').fontSize(17).text(data.doctorName, 46, 28);
    doc.fillColor(teal).font('Helvetica-Bold').fontSize(9.5).text(data.qualification, 46, 49);
    doc.fillColor(slate).font('Helvetica').fontSize(9).text(data.specialisation, 46, 63);
    doc.fillColor(muted).fontSize(8.5).text(`Reg. No.: ${data.registrationNumber}`, 46, 76);

    // Right Contact Block
    doc
      .fillColor(navy)
      .font('Helvetica-Bold')
      .fontSize(9)
      .text('ONLINE CONSULTATION CLINIC', 320, 28, { width: 229, align: 'right' });
    doc
      .fillColor(slate)
      .font('Helvetica')
      .fontSize(8.5)
      .text(`Phone / WhatsApp: ${data.phone}`, 320, 43, { width: 229, align: 'right' })
      .text(`Email: ${data.email}`, 320, 55, { width: 229, align: 'right' })
      .text(`Timings: ${data.timings}`, 320, 67, { width: 229, align: 'right' });

    doc.moveTo(46, 96).lineTo(549, 96).lineWidth(1).strokeColor('#CBD5E1').stroke();

    // Patient Info Box
    doc.roundedRect(46, 106, 503, 56, 6).fill('#EAF4F5');
    doc.fillColor(navy).font('Helvetica-Bold').fontSize(9).text('PATIENT:', 58, 116);
    doc.fillColor(slate).font('Helvetica').fontSize(9).text(`${data.patientName} (${data.patientCode})`, 112, 116);
    doc.fillColor(navy).font('Helvetica-Bold').fontSize(9).text('AGE / SEX:', 58, 132);
    doc.fillColor(slate).font('Helvetica').fontSize(9).text(data.patientGenderAge || 'On Record', 115, 132);
    doc.fillColor(navy).font('Helvetica-Bold').fontSize(9).text('MODE:', 58, 147);
    doc.fillColor(slate).font('Helvetica').fontSize(8.5).text('Authenticated Online Tele-Consultation', 112, 147);

    doc.fillColor(navy).font('Helvetica-Bold').fontSize(9).text('Rx NO.:', 340, 116);
    doc.fillColor(slate).font('Helvetica').fontSize(9).text(data.prescriptionNo, 395, 116);
    doc.fillColor(navy).font('Helvetica-Bold').fontSize(9).text('DATE:', 340, 132);
    doc.fillColor(slate).font('Helvetica').fontSize(9).text(data.authorisedAt.slice(0, 16), 395, 132);
    if (data.appointmentRef) {
      doc.fillColor(navy).font('Helvetica-Bold').fontSize(9).text('APPT REF:', 340, 147);
      doc.fillColor(slate).font('Helvetica').fontSize(8.5).text(data.appointmentRef, 395, 147);
    }

    let y = 176;

    // Clinical Impression
    doc.fillColor(navy).font('Helvetica-Bold').fontSize(10).text('Clinical Impression / Consultation Summary', 46, y);
    y += 15;
    doc.fillColor(slate).font('Helvetica').fontSize(9.5).text(data.clinicalImpression, 46, y, { width: 503 });
    y = doc.y + 6;

    if (data.symptomsSummary) {
      doc.fillColor(muted).font('Helvetica').fontSize(8.8).text(`Presenting Complaints: ${data.symptomsSummary}`, 46, y, {
        width: 503,
      });
      y = doc.y + 10;
    } else {
      y += 6;
    }

    // Rx Header
    doc.fillColor(teal).font('Helvetica-Bold').fontSize(16).text('Rx', 46, y);
    doc.fillColor(navy).font('Helvetica-Bold').fontSize(10).text('Prescribed Medicines & Regimen', 74, y + 4);
    y += 24;

    // Table Header
    doc.rect(46, y, 503, 22).fill(navy);
    doc.fillColor('#FFFFFF').font('Helvetica-Bold').fontSize(8.5);
    doc.text('#', 54, y + 7, { width: 18 });
    doc.text('Medicine / Remedy & Potency', 74, y + 7, { width: 185 });
    doc.text('Dosage', 264, y + 7, { width: 90 });
    doc.text('Frequency', 358, y + 7, { width: 105 });
    doc.text('Duration', 468, y + 7, { width: 75 });
    y += 26;

    data.medicines.forEach((m, idx) => {
      if (y > 680) {
        doc.addPage();
        y = 50;
      }
      const rowStart = y;
      doc.fillColor(navy).font('Helvetica-Bold').fontSize(9).text(`${idx + 1}.`, 54, y, { width: 18 });
      doc.fillColor(navy).font('Helvetica-Bold').fontSize(9).text(m.name, 74, y, { width: 185 });
      const afterName = doc.y;
      doc.fillColor(slate).font('Helvetica').fontSize(8.8).text(m.dosage, 264, rowStart, { width: 90 });
      doc.text(m.frequency, 358, rowStart, { width: 105 });
      doc.text(m.duration, 468, rowStart, { width: 75 });
      y = Math.max(afterName, doc.y) + 2;
      if (m.instructions) {
        doc.fillColor(muted).font('Helvetica-Oblique').fontSize(8.2).text(`Directions: ${m.instructions}`, 74, y, {
          width: 468,
        });
        y = doc.y + 4;
      }
      doc.moveTo(46, y + 2).lineTo(549, y + 2).lineWidth(0.5).strokeColor('#E2E8F0').stroke();
      y += 8;
    });

    y += 6;
    if (data.generalInstructions) {
      doc.fillColor(navy).font('Helvetica-Bold').fontSize(9.5).text('General Instructions:', 46, y);
      y += 13;
      doc.fillColor(slate).font('Helvetica').fontSize(8.8).text(data.generalInstructions, 46, y, { width: 503 });
      y = doc.y + 10;
    }

    if (data.dietaryAdvice) {
      doc.fillColor(navy).font('Helvetica-Bold').fontSize(9.5).text('Dietary & Lifestyle Guidance:', 46, y);
      y += 13;
      doc.fillColor(slate).font('Helvetica').fontSize(8.8).text(data.dietaryAdvice, 46, y, { width: 503 });
      y = doc.y + 10;
    }

    if (data.followupDate) {
      doc
        .fillColor(teal)
        .font('Helvetica-Bold')
        .fontSize(9.5)
        .text(`Recommended Follow-Up Date: ${data.followupDate} (Book online: Mon–Sat, 3:00 PM – 8:00 PM)`, 46, y);
      y = doc.y + 10;
    }

    if (data.referralNote) {
      doc.fillColor(muted).font('Helvetica').fontSize(8.2).text(`Safety & Referral Note: ${data.referralNote}`, 46, y, {
        width: 503,
      });
      y = doc.y + 14;
    }

    // Digital Signature Block
    const sigY = Math.max(y + 10, 685);
    doc.moveTo(340, sigY).lineTo(549, sigY).lineWidth(0.8).strokeColor(navy).stroke();
    doc
      .fillColor(navy)
      .font('Helvetica-Bold')
      .fontSize(9.5)
      .text(`Digitally Authorised by ${data.doctorName}`, 320, sigY + 6, { width: 229, align: 'right' });
    doc
      .fillColor(slate)
      .font('Helvetica')
      .fontSize(8.2)
      .text(data.qualification, 320, sigY + 19, { width: 229, align: 'right' })
      .fillColor(muted)
      .fontSize(7.5)
      .text(`Auth Hash: ${data.digitalSignatureHash}`, 320, sigY + 31, { width: 229, align: 'right' });

    // Footer disclaimer
    doc
      .fillColor(muted)
      .font('Helvetica')
      .fontSize(7.5)
      .text(
        'Issued following an authenticated online consultation. Not valid for medico-legal purposes or emergency care. In case of acute emergency, call 112/108 or visit the nearest hospital immediately.',
        46,
        762,
        { width: 503, align: 'center' }
      );

    doc.end();
  });
}

export async function generateReceiptPdf(data: {
  receiptNo: string;
  paidAt: string;
  clinicName: string;
  doctorName: string;
  qualification: string;
  phone: string;
  email: string;
  patientName: string;
  patientEmail: string;
  appointmentRef: string;
  consultationType: string;
  appointmentSlot: string;
  amountInr: number;
  paymentMethod: string;
  gateway: string;
  transactionRef: string;
  status: string;
}): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    const doc = new PDFDocument({ size: 'A4', margin: 50 });
    const chunks: Buffer[] = [];
    doc.on('data', (c) => chunks.push(Buffer.from(c)));
    doc.on('end', () => resolve(Buffer.concat(chunks)));
    doc.on('error', reject);

    const navy = '#153B5B';
    const teal = '#168B83';
    const slate = '#334155';
    const muted = '#64748B';

    doc.rect(0, 0, doc.page.width, 8).fill(navy);
    doc.fillColor(navy).font('Helvetica-Bold').fontSize(16).text('PAYMENT RECEIPT', 50, 34);
    doc.fillColor(teal).font('Helvetica-Bold').fontSize(10).text(data.clinicName, 50, 56);
    doc
      .fillColor(muted)
      .font('Helvetica')
      .fontSize(8.8)
      .text(`${data.doctorName} · ${data.qualification}`, 50, 71)
      .text(`Contact: ${data.phone}  |  Email: ${data.email}`, 50, 84);

    doc.roundedRect(390, 34, 155, 48, 6).fill('#EAF4F5');
    doc.fillColor(navy).font('Helvetica-Bold').fontSize(8.5).text('RECEIPT NO.', 402, 43);
    doc.fillColor(slate).font('Helvetica-Bold').fontSize(10).text(data.receiptNo, 402, 56);
    doc.fillColor(teal).font('Helvetica-Bold').fontSize(8).text(`STATUS: ${data.status}`, 402, 70);

    doc.moveTo(50, 108).lineTo(545, 108).strokeColor('#CBD5E1').stroke();

    const rows: Array<[string, string]> = [
      ['Patient Name', data.patientName],
      ['Patient Email', data.patientEmail],
      ['Receipt Date', data.paidAt],
      ['Appointment Reference', data.appointmentRef],
      ['Consultation Service', data.consultationType],
      ['Scheduled Slot (IST)', data.appointmentSlot],
      ['Payment Method', `${data.paymentMethod} (${data.gateway})`],
      ['Transaction / UTR Ref', data.transactionRef || 'Recorded on Server'],
    ];

    let y = 126;
    rows.forEach(([label, val], idx) => {
      if (idx % 2 === 0) {
        doc.rect(50, y - 5, 495, 24).fill('#F5F7FA');
      }
      doc.fillColor(navy).font('Helvetica-Bold').fontSize(9.2).text(label, 62, y + 2);
      doc.fillColor(slate).font('Helvetica').fontSize(9.2).text(val, 230, y + 2, { width: 305 });
      y += 26;
    });

    y += 16;
    doc.roundedRect(50, y, 495, 48, 6).fill(navy);
    doc.fillColor('#FFFFFF').font('Helvetica-Bold').fontSize(11).text('Total Consultation Fee', 66, y + 17);
    doc
      .fillColor('#FFFFFF')
      .font('Helvetica-Bold')
      .fontSize(14)
      .text(`INR ${data.amountInr.toFixed(2)}`, 340, y + 15, { width: 189, align: 'right' });

    doc
      .fillColor(muted)
      .font('Helvetica')
      .fontSize(8.2)
      .text(
        'This is a computer-generated official receipt verified by Dr. Aparna Mishra Digital Clinic platform. For billing support, contact aparnabhms@gmail.com or +91 8123108149.',
        50,
        y + 74,
        { width: 495, align: 'center' }
      );

    doc.end();
  });
}
