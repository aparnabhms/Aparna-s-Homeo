import crypto from 'crypto';
import bcrypt from 'bcryptjs';
import { SignJWT, jwtVerify } from 'jose';
import { cookies, headers } from 'next/headers';
import { NextRequest, NextResponse } from 'next/server';

export type UserRole = 'PATIENT' | 'DOCTOR' | 'STAFF' | 'ADMIN';

export interface SessionUser {
  id: string;
  email: string;
  fullName: string;
  role: UserRole;
  phone?: string | null;
  isDemo?: boolean;
}

export const SESSION_COOKIE = 'aparna_clinic_session';

function getJwtSecret(): Uint8Array {
  const secret =
    process.env.JWT_SECRET ||
    'dr-aparna-mishra-clinic-dev-jwt-secret-change-in-production-2026-secure-key';
  return new TextEncoder().encode(secret);
}

function getFileEncryptionKey(): Buffer {
  const raw =
    process.env.FILE_ENCRYPTION_KEY ||
    'aparna-clinic-aes256gcm-private-medical-reports-key-2026';
  return crypto.createHash('sha256').update(raw).digest();
}

export async function hashPassword(plain: string): Promise<string> {
  return bcrypt.hash(plain, 10);
}

export async function verifyPassword(plain: string, hash: string): Promise<boolean> {
  return bcrypt.compare(plain, hash);
}

export async function signSessionToken(user: SessionUser): Promise<string> {
  return new SignJWT({
    email: user.email,
    fullName: user.fullName,
    role: user.role,
    phone: user.phone || null,
    isDemo: Boolean(user.isDemo),
  })
    .setProtectedHeader({ alg: 'HS256' })
    .setSubject(user.id)
    .setIssuedAt()
    .setIssuer('aparna-mishra-clinic')
    .setExpirationTime('7d')
    .sign(getJwtSecret());
}

export async function verifySessionToken(token: string): Promise<SessionUser | null> {
  try {
    const { payload } = await jwtVerify(token, getJwtSecret(), {
      issuer: 'aparna-mishra-clinic',
    });
    if (!payload.sub || !payload.role || !payload.email) return null;
    return {
      id: payload.sub,
      email: String(payload.email),
      fullName: String(payload.fullName || ''),
      role: payload.role as UserRole,
      phone: payload.phone ? String(payload.phone) : null,
      isDemo: Boolean(payload.isDemo),
    };
  } catch {
    return null;
  }
}

function isHttpsRequest(req?: NextRequest): boolean {
  if (!req) return process.env.NODE_ENV === 'production';
  const proto = (req.headers.get('x-forwarded-proto') || '').split(',')[0].trim().toLowerCase();
  if (proto === 'https') return true;
  if (req.nextUrl.protocol === 'https:') return true;
  const origin = (req.headers.get('origin') || '').toLowerCase();
  if (origin.startsWith('https://')) return true;
  const referer = (req.headers.get('referer') || '').toLowerCase();
  if (referer.startsWith('https://')) return true;
  const host = (req.headers.get('x-forwarded-host') || req.headers.get('host') || '').toLowerCase();
  if (host.endsWith('.e2b.app')) return true;
  return false;
}

export function attachSessionCookie(
  res: NextResponse,
  token: string,
  req?: NextRequest
): NextResponse {
  const isHttps = isHttpsRequest(req);
  const maxAge = 60 * 60 * 24 * 7; // 7 days

  if (isHttps) {
    // Include CHIPS `Partitioned` attribute + SameSite=None; Secure so cookies persist
    // reliably in both standalone tabs and embedded cross-origin preview iframes.
    res.headers.append(
      'Set-Cookie',
      `${SESSION_COOKIE}=${encodeURIComponent(
        token
      )}; Path=/; Max-Age=${maxAge}; HttpOnly; Secure; SameSite=None; Partitioned`
    );
  } else {
    res.cookies.set(SESSION_COOKIE, token, {
      httpOnly: true,
      secure: false,
      sameSite: 'lax',
      path: '/',
      maxAge,
    });
  }
  return res;
}

export function clearSessionCookie(res: NextResponse, req?: NextRequest): NextResponse {
  const isHttps = isHttpsRequest(req);

  if (isHttps) {
    res.headers.append(
      'Set-Cookie',
      `${SESSION_COOKIE}=; Path=/; Max-Age=0; HttpOnly; Secure; SameSite=None; Partitioned`
    );
  } else {
    res.cookies.set(SESSION_COOKIE, '', {
      httpOnly: true,
      secure: false,
      sameSite: 'lax',
      path: '/',
      maxAge: 0,
    });
  }
  return res;
}

function extractBearerToken(authHeader: string | null | undefined): string | null {
  if (!authHeader) return null;
  const match = authHeader.match(/^Bearer\s+(.+)$/i);
  return match ? match[1].trim() : null;
}

function cleanTokenValue(raw: string | null | undefined): string | null {
  if (!raw) return null;
  let val = raw.trim();
  if (!val) return null;
  try {
    if (val.includes('%')) val = decodeURIComponent(val);
  } catch {
    // keep raw
  }
  return val || null;
}

export async function getSessionWithToken(
  fallbackToken?: string | null
): Promise<{ user: SessionUser; token: string } | null> {
  const candidates: Array<string | null> = [];

  // Prioritize explicit fresh token (_st / middleware-verified header) over potentially stale cookie
  candidates.push(cleanTokenValue(fallbackToken));

  try {
    const h = headers();
    candidates.push(cleanTokenValue(h.get('x-clinic-session')));
    candidates.push(cleanTokenValue(extractBearerToken(h.get('authorization'))));
  } catch {
    // ignore outside request scope
  }

  try {
    const cookieStore = cookies();
    candidates.push(cleanTokenValue(cookieStore.get(SESSION_COOKIE)?.value));
  } catch {
    // ignore outside request scope
  }

  for (const tok of candidates) {
    if (!tok) continue;
    const u = await verifySessionToken(tok);
    if (u) return { user: u, token: tok };
  }
  return null;
}

export async function getSessionUser(fallbackToken?: string | null): Promise<SessionUser | null> {
  const result = await getSessionWithToken(fallbackToken);
  return result ? result.user : null;
}

export async function getRequestUser(req: NextRequest): Promise<SessionUser | null> {
  const candidates = [
    cleanTokenValue(extractBearerToken(req.headers.get('authorization'))),
    cleanTokenValue(req.headers.get('x-clinic-session')),
    cleanTokenValue(req.nextUrl.searchParams.get('_st')),
    cleanTokenValue(req.cookies.get(SESSION_COOKIE)?.value),
  ];

  for (const tok of candidates) {
    if (tok) {
      const user = await verifySessionToken(tok);
      if (user) return user;
    }
  }
  return null;
}

export function getClientIp(req?: NextRequest): string {
  if (req) {
    return (
      req.headers.get('x-forwarded-for')?.split(',')[0]?.trim() ||
      req.headers.get('x-real-ip') ||
      '127.0.0.1'
    );
  }
  try {
    const h = headers();
    return h.get('x-forwarded-for')?.split(',')[0]?.trim() || '127.0.0.1';
  } catch {
    return '127.0.0.1';
  }
}

/**
 * AES-256-GCM encryption at rest for patient medical reports stored privately.
 */
export function encryptBuffer(plain: Buffer): Buffer {
  const key = getFileEncryptionKey();
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
  const encrypted = Buffer.concat([cipher.update(plain), cipher.final()]);
  const authTag = cipher.getAuthTag();
  return Buffer.concat([iv, authTag, encrypted]);
}

export function decryptBuffer(packed: Buffer): Buffer {
  const key = getFileEncryptionKey();
  const iv = packed.subarray(0, 12);
  const authTag = packed.subarray(12, 28);
  const ciphertext = packed.subarray(28);
  const decipher = crypto.createDecipheriv('aes-256-gcm', key, iv);
  decipher.setAuthTag(authTag);
  return Buffer.concat([decipher.update(ciphertext), decipher.final()]);
}

/**
 * Sliding-window in-memory rate limiter to protect authentication, OTP, uploads & booking endpoints.
 */
const rateBuckets = new Map<string, number[]>();

export function checkRateLimit(
  key: string,
  maxRequests: number,
  windowMs: number
): { allowed: boolean; retryAfterSec: number } {
  const now = Date.now();
  const windowStart = now - windowMs;
  const existing = (rateBuckets.get(key) || []).filter((ts) => ts > windowStart);
  if (existing.length >= maxRequests) {
    const retryAfterSec = Math.max(1, Math.ceil((existing[0] + windowMs - now) / 1000));
    rateBuckets.set(key, existing);
    return { allowed: false, retryAfterSec };
  }
  existing.push(now);
  rateBuckets.set(key, existing);
  return { allowed: true, retryAfterSec: 0 };
}

export function generateId(prefix?: string): string {
  const uuid = crypto.randomUUID();
  return prefix ? `${prefix}_${uuid.replace(/-/g, '').slice(0, 16)}` : uuid;
}

export function generateRefCode(prefix: string): string {
  const d = new Date();
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  const rand = crypto.randomInt(1000, 9999);
  return `${prefix}-${y}${m}${day}-${rand}`;
}

export function signDigitalHash(payload: string): string {
  return crypto
    .createHmac('sha256', getFileEncryptionKey())
    .update(payload)
    .digest('hex')
    .slice(0, 32)
    .toUpperCase();
}
