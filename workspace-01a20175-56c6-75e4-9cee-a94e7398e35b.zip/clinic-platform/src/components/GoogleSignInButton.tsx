'use client';

import React, { useEffect, useState } from 'react';
import { ArrowRight, ShieldCheck, X } from 'lucide-react';
import { navigateWithSession, saveClientSession } from '@/lib/clientSession';

export interface GoogleAuthUser {
  id: string;
  email: string;
  fullName: string;
  role: string;
  phone?: string | null;
}

interface SavedGoogleAccount {
  email: string;
  fullName: string;
  badge?: string;
}

const RECENT_GOOGLE_KEY = 'aparna_clinic_recent_google_accounts';

const DEFAULT_DEMO_ACCOUNTS: SavedGoogleAccount[] = [
  {
    email: 'aparnabhms@gmail.com',
    fullName: 'Dr. Aparna Mishra',
    badge: 'Doctor Console',
  },
  {
    email: 'ananya.demo@example.com',
    fullName: 'Ananya Sharma',
    badge: 'Patient Portal',
  },
];

export function GoogleLogo({ className = 'h-5 w-5' }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" aria-hidden="true">
      <path
        fill="#4285F4"
        d="M23.49 12.27c0-.79-.07-1.54-.19-2.27H12v4.51h6.47c-.29 1.48-1.14 2.73-2.4 3.58v3h3.86c2.26-2.09 3.56-5.17 3.56-8.82z"
      />
      <path
        fill="#34A853"
        d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.86-3c-1.08.72-2.45 1.16-4.07 1.16-3.13 0-5.78-2.11-6.73-4.96H1.29v3.09C3.26 21.3 7.31 24 12 24z"
      />
      <path
        fill="#FBBC05"
        d="M5.27 14.29c-.25-.72-.38-1.49-.38-2.29s.14-1.57.38-2.29V6.62H1.29C.47 8.24 0 10.06 0 12s.47 3.76 1.29 5.38l3.98-3.09z"
      />
      <path
        fill="#EA4335"
        d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.31 0 3.26 2.7 1.29 6.62l3.98 3.09c.95-2.85 3.6-4.96 6.73-4.96z"
      />
    </svg>
  );
}

async function safeJson(res: Response): Promise<Record<string, unknown>> {
  const txt = await res.text();
  if (!txt) return {};
  try {
    return JSON.parse(txt) as Record<string, unknown>;
  } catch {
    return { error: `Server returned an unexpected response (HTTP ${res.status}). Please retry.` };
  }
}

export default function GoogleSignInButton({
  label = 'Sign in with Google',
  sublabel = 'Fast & secure · No password needed',
  nextPath = '',
  autoOpen = false,
  onSuccess,
  onError,
}: {
  label?: string;
  sublabel?: string;
  nextPath?: string;
  autoOpen?: boolean;
  onSuccess?: (user: GoogleAuthUser, redirectTo: string, sessionToken?: string) => void;
  onError?: (message: string) => void;
}) {
  const [status, setStatus] = useState<{
    loaded: boolean;
    oauthConfigured: boolean;
    gisClientId: string | null;
    demoMode: boolean;
  }>({
    loaded: false,
    oauthConfigured: false,
    gisClientId: null,
    demoMode: true,
  });

  const [chooserOpen, setChooserOpen] = useState(Boolean(autoOpen));
  const [googleEmail, setGoogleEmail] = useState('');
  const [googleName, setGoogleName] = useState('');
  const [savedAccounts, setSavedAccounts] = useState<SavedGoogleAccount[]>(DEFAULT_DEMO_ACCOUNTS);
  const [busy, setBusy] = useState(false);
  const [localErr, setLocalErr] = useState('');

  useEffect(() => {
    let active = true;
    fetch('/api/auth/google?mode=status', { cache: 'no-store' })
      .then((r) => safeJson(r))
      .then((data) => {
        if (!active) return;
        const oauthConfigured = Boolean(data.oauthConfigured);
        setStatus({
          loaded: true,
          oauthConfigured,
          gisClientId: typeof data.gisClientId === 'string' ? data.gisClientId : null,
          demoMode: data.demoMode === false ? false : true,
        });
        if (autoOpen && !oauthConfigured) {
          setChooserOpen(true);
        }
      })
      .catch(() => {
        if (active) setStatus((s) => ({ ...s, loaded: true }));
      });

    try {
      const raw = localStorage.getItem(RECENT_GOOGLE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw) as SavedGoogleAccount[];
        if (Array.isArray(parsed) && parsed.length > 0) {
          const merged = [...parsed];
          for (const d of DEFAULT_DEMO_ACCOUNTS) {
            if (!merged.some((m) => m.email.toLowerCase() === d.email.toLowerCase())) {
              merged.push(d);
            }
          }
          setSavedAccounts(merged.slice(0, 5));
        }
      }
    } catch {
      // storage restricted in iframe — default accounts still work
    }

    return () => {
      active = false;
    };
  }, [autoOpen]);

  useEffect(() => {
    function onMessage(ev: MessageEvent) {
      if (ev.origin !== window.location.origin || !ev.data) return;
      if (ev.data.type === 'CLINIC_GOOGLE_AUTH_SUCCESS') {
        setBusy(false);
        const user = ev.data.user as GoogleAuthUser;
        const redirectTo = String(ev.data.redirectTo || '/portal');
        const tok = typeof ev.data.sessionToken === 'string' ? ev.data.sessionToken : undefined;
        if (tok) saveClientSession(tok);
        if (onSuccess) {
          onSuccess(user, redirectTo, tok);
        } else {
          navigateWithSession(redirectTo, tok);
        }
      } else if (ev.data.type === 'CLINIC_GOOGLE_AUTH_ERROR') {
        setBusy(false);
        const msg = String(ev.data.error || 'Google sign-in was cancelled.');
        setLocalErr(msg);
        onError?.(msg);
      }
    }
    window.addEventListener('message', onMessage);
    return () => window.removeEventListener('message', onMessage);
  }, [onSuccess, onError]);

  function rememberAccount(email: string, fullName: string) {
    try {
      const entry: SavedGoogleAccount = { email: email.toLowerCase(), fullName };
      const existingRaw = localStorage.getItem(RECENT_GOOGLE_KEY);
      const existing: SavedGoogleAccount[] = existingRaw ? JSON.parse(existingRaw) : [];
      const next = [
        entry,
        ...existing.filter((a) => a.email.toLowerCase() !== entry.email),
      ].slice(0, 4);
      localStorage.setItem(RECENT_GOOGLE_KEY, JSON.stringify(next));
    } catch {
      // ignore
    }
  }

  function handleButtonClick() {
    setLocalErr('');

    if (status.oauthConfigured) {
      const params = new URLSearchParams();
      if (nextPath) params.set('next', nextPath);

      const inIframe = (() => {
        try {
          return window.self !== window.top;
        } catch {
          return true;
        }
      })();

      if (inIframe || Boolean(onSuccess)) {
        params.set('popup', '1');
        setBusy(true);
        const popup = window.open(
          `/api/auth/google?${params.toString()}`,
          'google_oauth_signin',
          'width=500,height=640,menubar=no,toolbar=no,status=no'
        );
        if (!popup) {
          params.delete('popup');
          window.location.href = `/api/auth/google?${params.toString()}`;
        } else {
          const timer = setInterval(() => {
            if (popup.closed) {
              clearInterval(timer);
              setBusy(false);
            }
          }, 700);
        }
      } else {
        setBusy(true);
        window.location.href = `/api/auth/google?${params.toString()}`;
      }
      return;
    }

    if (status.demoMode) {
      setChooserOpen(true);
      return;
    }

    const msg =
      'Google Sign-In requires GOOGLE_CLIENT_ID & GOOGLE_CLIENT_SECRET in server environment.';
    setLocalErr(msg);
    onError?.(msg);
  }

  async function completePasswordlessGoogleSignIn(email: string, fullName = '') {
    const cleanEmail = email.trim().toLowerCase();
    if (!/^[a-zA-Z0-9._%+-]{2,}@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/.test(cleanEmail)) {
      setLocalErr('Please enter a valid Google / Gmail address (e.g. yourname@gmail.com).');
      return;
    }

    setBusy(true);
    setLocalErr('');
    try {
      const res = await fetch('/api/auth/google', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        cache: 'no-store',
        body: JSON.stringify({
          email: cleanEmail,
          fullName: fullName.trim(),
          next: nextPath || undefined,
        }),
      });
      const data = await safeJson(res);
      const userObj = data.user as GoogleAuthUser | undefined;
      if (!res.ok || !userObj) {
        const msg = String(data.error || 'Google sign-in failed. Please try again.');
        setLocalErr(msg);
        onError?.(msg);
        setBusy(false);
        return;
      }

      const sessionTok = typeof data.sessionToken === 'string' ? data.sessionToken : undefined;
      if (sessionTok) saveClientSession(sessionTok);

      if (!DEFAULT_DEMO_ACCOUNTS.some((d) => d.email === cleanEmail)) {
        rememberAccount(userObj.email, userObj.fullName);
      }

      const redirectTo = typeof data.redirectTo === 'string' ? data.redirectTo : '/portal';
      if (onSuccess) {
        setChooserOpen(false);
        onSuccess(userObj, redirectTo, sessionTok);
      } else {
        navigateWithSession(redirectTo, sessionTok);
      }
    } catch {
      const msg = 'Could not reach clinic sign-in server. Please tap Continue with Google again.';
      setLocalErr(msg);
      onError?.(msg);
      setBusy(false);
    }
  }

  return (
    <>
      <div className="space-y-1.5">
        <button
          type="button"
          onClick={handleButtonClick}
          disabled={busy}
          className="w-full flex items-center justify-center gap-3 rounded-xl border-2 border-slate-200 bg-white px-4 py-3 text-sm font-semibold text-slate-800 shadow-sm hover:border-teal hover:bg-aqua/40 active:bg-aqua transition-all disabled:opacity-60 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-teal"
        >
          <GoogleLogo className="h-5 w-5 shrink-0" />
          <span>{busy ? 'Opening Your Clinic Portal…' : label}</span>
        </button>
        {sublabel && <p className="text-center text-[11px] text-slate-500">{sublabel}</p>}
      </div>

      {/* Instant 1-Step Passwordless Google Sign-In Dialog */}
      {chooserOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-navy/55 backdrop-blur-[2px] p-4"
          role="dialog"
          aria-modal="true"
          aria-label="Sign in with Google"
        >
          <div className="w-full max-w-md rounded-2xl border border-slate-200 bg-white shadow-elevated overflow-hidden">
            <div className="px-6 pt-4 pb-3 border-b border-slate-100 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <GoogleLogo className="h-5 w-5" />
                <span className="text-xs font-semibold text-slate-700">Sign in with Google</span>
              </div>
              <button
                type="button"
                onClick={() => {
                  setChooserOpen(false);
                  setBusy(false);
                  setLocalErr('');
                }}
                className="rounded-lg p-1 text-slate-400 hover:bg-slate-100 hover:text-slate-700"
                aria-label="Close Google Sign-In"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <div className="p-6 space-y-4">
              <div className="text-center space-y-1">
                <h2 className="font-heading text-lg font-bold text-navy">
                  Continue with Google
                </h2>
                <p className="text-xs text-slate-500">
                  Enter your Gmail address or tap a quick account below — no password required
                </p>
              </div>

              {/* Direct 1-Click Gmail Entry */}
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  completePasswordlessGoogleSignIn(googleEmail, googleName);
                }}
                className="space-y-2.5 rounded-xl bg-surface-muted border border-slate-200 p-3.5"
              >
                <label className="block text-[11px] font-semibold text-navy">
                  Your Gmail Address
                </label>
                <input
                  type="email"
                  required
                  autoFocus
                  value={googleEmail}
                  onChange={(e) => setGoogleEmail(e.target.value)}
                  placeholder="yourname@gmail.com"
                  className="input-field text-xs py-2.5 bg-white"
                />
                <input
                  type="text"
                  value={googleName}
                  onChange={(e) => setGoogleName(e.target.value)}
                  placeholder="Your full name (optional)"
                  className="input-field text-xs py-2 bg-white"
                />
                <button
                  type="submit"
                  disabled={busy}
                  className="btn-primary w-full py-2.5 text-xs"
                >
                  {busy ? 'Signing You In…' : 'Continue with Google'}
                  <ArrowRight className="h-3.5 w-3.5" />
                </button>
              </form>

              {/* Quick 1-Tap Accounts */}
              <div className="space-y-1.5">
                <p className="text-[10.5px] font-semibold text-slate-500 uppercase tracking-wider">
                  Or tap an account
                </p>
                <div className="divide-y divide-slate-100 rounded-xl border border-slate-200 overflow-hidden">
                  {savedAccounts.map((acc) => {
                    const initial = (acc.fullName || acc.email).charAt(0).toUpperCase();
                    return (
                      <button
                        key={acc.email}
                        type="button"
                        disabled={busy}
                        onClick={() => completePasswordlessGoogleSignIn(acc.email, acc.fullName)}
                        className="w-full flex items-center gap-3 px-4 py-2.5 text-left bg-white hover:bg-aqua/60 transition-colors disabled:opacity-60"
                      >
                        <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-navy text-xs font-bold text-white">
                          {initial}
                        </span>
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-2">
                            <p className="text-xs font-semibold text-navy truncate">{acc.fullName}</p>
                            {acc.badge && (
                              <span className="rounded-full bg-aqua px-2 py-0.5 text-[10px] font-semibold text-teal shrink-0">
                                {acc.badge}
                              </span>
                            )}
                          </div>
                          <p className="text-[11px] text-slate-500 truncate">{acc.email}</p>
                        </div>
                        <ArrowRight className="h-3.5 w-3.5 text-teal shrink-0" />
                      </button>
                    );
                  })}
                </div>
              </div>

              {localErr && (
                <p className="rounded-xl bg-rose-50 border border-rose-200 px-3 py-2 text-xs font-medium text-rose-700">
                  {localErr}
                </p>
              )}

              <div className="pt-1 flex items-center justify-center gap-1.5 text-[10.5px] text-slate-500">
                <ShieldCheck className="h-3.5 w-3.5 text-teal shrink-0" />
                <span>Encrypted Google Session · Dr. Aparna Mishra Clinic</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
