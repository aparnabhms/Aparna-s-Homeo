'use client';

import React, { useState, useMemo } from 'react';
import { ChevronDown, Search } from 'lucide-react';

export interface FaqItem {
  id: string;
  category: string;
  question: string;
  answer: string;
}

export default function FaqAccordion({
  faqs,
  searchable = false,
}: {
  faqs: FaqItem[];
  searchable?: boolean;
}) {
  const [openId, setOpenId] = useState<string | null>(faqs[0]?.id || null);
  const [query, setQuery] = useState('');
  const [category, setCategory] = useState('All');

  const categories = useMemo(
    () => ['All', ...Array.from(new Set(faqs.map((f) => f.category)))],
    [faqs]
  );

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return faqs.filter((f) => {
      const catOk = category === 'All' || f.category === category;
      const qOk =
        !q ||
        f.question.toLowerCase().includes(q) ||
        f.answer.toLowerCase().includes(q) ||
        f.category.toLowerCase().includes(q);
      return catOk && qOk;
    });
  }, [faqs, query, category]);

  return (
    <div>
      {searchable && (
        <div className="mb-8 space-y-4">
          <div className="relative">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
            <input
              type="search"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search timings, payments, prescriptions, privacy, minor accounts..."
              className="input-field pl-10 py-3"
            />
          </div>
          <div className="flex flex-wrap gap-2">
            {categories.map((cat) => (
              <button
                key={cat}
                type="button"
                onClick={() => setCategory(cat)}
                className={`rounded-full px-3.5 py-1.5 text-xs font-semibold transition-colors ${
                  category === cat
                    ? 'bg-navy text-white'
                    : 'bg-aqua text-navy hover:bg-teal hover:text-white'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>
      )}

      {filtered.length === 0 ? (
        <div className="card-surface p-8 text-center text-sm text-slate-500">
          No questions matched your search. Try another keyword or ask the Clinic Assistant at the bottom-right corner.
        </div>
      ) : (
        <div className="space-y-3">
          {filtered.map((faq) => {
            const isOpen = openId === faq.id;
            return (
              <div key={faq.id} className="card-surface overflow-hidden">
                <button
                  type="button"
                  onClick={() => setOpenId(isOpen ? null : faq.id)}
                  className="w-full px-5 sm:px-6 py-4 text-left flex items-center justify-between gap-4 hover:bg-surface-muted/70 transition-colors"
                  aria-expanded={isOpen}
                >
                  <div>
                    {searchable && (
                      <span className="block text-[11px] font-semibold uppercase tracking-wider text-teal mb-0.5">
                        {faq.category}
                      </span>
                    )}
                    <span className="font-heading text-sm sm:text-[15.5px] font-semibold text-navy">
                      {faq.question}
                    </span>
                  </div>
                  <ChevronDown
                    className={`h-4 w-4 shrink-0 text-teal transition-transform ${
                      isOpen ? 'rotate-180' : ''
                    }`}
                  />
                </button>
                {isOpen && (
                  <div className="px-5 sm:px-6 pb-5 pt-1 text-sm text-slate-600 leading-relaxed border-t border-slate-100">
                    {faq.answer}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
