'use client';

import { useEffect } from 'react';
import {
  buildAuthedUrl,
  clearClientSession,
  getClientSessionToken,
  saveClientSession,
} from '@/lib/clientSession';

function installFetchInterceptor() {
  if (typeof window === 'undefined') return;

  // Immediately absorb any `_st` token from current location into all storage layers
  try {
    const urlTok = new URLSearchParams(window.location.search).get('_st');
    if (urlTok) saveClientSession(urlTok);
  } catch {
    // ignore
  }

  if (window.__aparnaFetchPatched) return;
  window.__aparnaFetchPatched = true;

  const nativeFetch = window.fetch.bind(window);

  window.fetch = async (input: RequestInfo | URL, init?: RequestInit) => {
    try {
      const rawUrl =
        typeof input === 'string'
          ? input
          : input instanceof URL
          ? input.toString()
          : input.url;

      const resolved = new URL(rawUrl, window.location.origin);
      const isSameOriginApi =
        resolved.origin === window.location.origin &&
        resolved.pathname.startsWith('/api/');

      if (isSameOriginApi) {
        if (resolved.pathname === '/api/auth/logout') {
          clearClientSession();
          return nativeFetch(input, { ...init, credentials: 'include' });
        }

        const token = getClientSessionToken();
        const headers = new Headers(
          init?.headers || (input instanceof Request ? input.headers : undefined)
        );
        if (token) {
          if (!headers.has('Authorization')) {
            headers.set('Authorization', `Bearer ${token}`);
          }
          if (!headers.has('X-Clinic-Session')) {
            headers.set('X-Clinic-Session', token);
          }
          if (
            !resolved.searchParams.has('_st') &&
            !resolved.pathname.startsWith('/api/auth/login') &&
            !resolved.pathname.startsWith('/api/auth/register') &&
            !resolved.pathname.startsWith('/api/auth/google')
          ) {
            resolved.searchParams.set('_st', token);
          }
        }

        const targetInput =
          typeof input === 'string' || input instanceof URL
            ? `${resolved.pathname}${resolved.search}`
            : input;

        const resp = await nativeFetch(targetInput, {
          ...init,
          headers,
          credentials: 'include',
        });

        if (
          resp.ok &&
          (resolved.pathname === '/api/auth/login' ||
            resolved.pathname === '/api/auth/register' ||
            resolved.pathname === '/api/auth/google')
        ) {
          try {
            const data = await resp.clone().json();
            if (data && typeof data.sessionToken === 'string' && data.sessionToken) {
              saveClientSession(data.sessionToken);
            }
          } catch {
            // ignore
          }
        }
        return resp;
      }
    } catch {
      // fall through
    }
    return nativeFetch(input, init);
  };
}

if (typeof window !== 'undefined') {
  installFetchInterceptor();
}

export default function AuthBridge() {
  useEffect(() => {
    installFetchInterceptor();

    // Persist `_st` from URL, then strip it from visible bar after hydration settles
    const cleanTimer = setTimeout(() => {
      try {
        const url = new URL(window.location.href);
        const urlToken = url.searchParams.get('_st');
        if (urlToken) {
          saveClientSession(urlToken);
          url.searchParams.delete('_st');
          const cleanUrl = `${url.pathname}${url.search}${url.hash}`;
          window.history.replaceState(window.history.state, '', cleanUrl);
        }
      } catch {
        // ignore
      }
    }, 300);

    function handleAnchorClick(ev: MouseEvent) {
      if (
        ev.defaultPrevented ||
        ev.button !== 0 ||
        ev.metaKey ||
        ev.ctrlKey ||
        ev.shiftKey ||
        ev.altKey
      ) {
        return;
      }
      const target = ev.target as HTMLElement | null;
      const anchor = target?.closest?.('a') as HTMLAnchorElement | null;
      if (!anchor) return;
      const href = anchor.getAttribute('href');
      if (!href || !href.startsWith('/')) return;

      const token = getClientSessionToken();
      if (!token) return;

      const isProtectedNav =
        href === '/portal' ||
        href.startsWith('/portal?') ||
        href.startsWith('/portal/') ||
        href === '/admin' ||
        href.startsWith('/admin?') ||
        href.startsWith('/admin/') ||
        href.startsWith('/call/');

      const isProtectedDownload =
        href.startsWith('/api/payments/') ||
        href.startsWith('/api/prescriptions/') ||
        href.startsWith('/api/reports/') ||
        href.startsWith('/api/admin/backup');

      if (isProtectedDownload) {
        anchor.href = buildAuthedUrl(href, token);
      } else if (isProtectedNav) {
        ev.preventDefault();
        window.location.assign(buildAuthedUrl(href, token));
      }
    }

    document.addEventListener('click', handleAnchorClick, true);
    return () => {
      clearTimeout(cleanTimer);
      document.removeEventListener('click', handleAnchorClick, true);
    };
  }, []);

  return null;
}
