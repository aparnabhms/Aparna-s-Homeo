'use client';

import React, { useEffect, useState } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { getClientSessionToken } from '@/lib/clientSession';
import {
  Calendar,
  Clock,
  LayoutDashboard,
  LogIn,
  Mail,
  Menu,
  Phone,
  ShieldCheck,
  X,
} from 'lucide-react';
import { BrandMark } from './MedicalIcons';
import ChatbotWidget from './ChatbotWidget';

const NAV_LINKS = [
  { href: '/', label: 'Home' },
  { href: '/about', label: 'About' },
  { href: '/services', label: 'Services' },
  { href: '/online-consultation', label: 'Online Consultation' },
  { href: '/blog', label: 'Health Blog' },
  { href: '/clinic-info', label: 'Clinic Info' },
  { href: '/faq', label: 'FAQs' },
  { href: '/contact', label: 'Contact' },
];

export interface PublicShellProps {
  children: React.ReactNode;
  announcement?: string | null;
  user?: {
    fullName: string;
    role: string;
  } | null;
  doctor?: {
    display_name: string;
    qualification: string;
    tagline: string;
    timings_summary: string;
    phone: string;
    whatsapp_number: string;
    email: string;
    registration_number: string;
  };
  chatbotWelcome?: string;
}

export default function PublicShell({
  children,
  announcement,
  user,
  doctor,
  chatbotWelcome,
}: PublicShellProps) {
  const pathname = usePathname();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [activeUser, setActiveUser] = useState(user || null);

  useEffect(() => {
    if (user) {
      setActiveUser(user);
      return;
    }
    const tok = getClientSessionToken();
    if (!tok) return;
    let mounted = true;
    fetch('/api/auth/me', { headers: { Authorization: `Bearer ${tok}` } })
      .then((r) => (r.ok ? r.json() : null))
      .then((d) => {
        if (mounted && d?.user) setActiveUser(d.user);
      })
      .catch(() => {});
    return () => {
      mounted = false;
    };
  }, [user]);

  const phone = doctor?.phone || '+91 8123108149';
  const email = doctor?.email || 'aparnabhms@gmail.com';
  const wa = doctor?.whatsapp_number || '918123108149';
  const timings = doctor?.timings_summary || 'Monday to Saturday · 3:00 PM – 8:00 PM IST';
  const portalHref =
    activeUser && ['DOCTOR', 'ADMIN', 'STAFF'].includes(activeUser.role) ? '/admin' : '/portal';
  const portalLabel =
    activeUser && ['DOCTOR', 'ADMIN', 'STAFF'].includes(activeUser.role)
      ? 'Clinic Console'
      : 'Patient Portal';

  return (
    <div className="min-h-screen flex flex-col bg-white">
      {/* Subtle Top Announcement Strip */}
      {announcement && (
        <div className="bg-navy text-white/95 text-xs">
          <div className="clinic-container py-2 flex items-center justify-between gap-4">
            <p className="truncate sm:whitespace-normal flex items-center gap-2">
              <Clock className="h-3.5 w-3.5 text-teal-300 shrink-0" />
              <span>{announcement}</span>
            </p>
            <Link
              href="/login"
              className="hidden md:inline-flex shrink-0 text-teal-200 hover:text-white font-medium transition-colors"
            >
              Doctor / Staff Sign In
            </Link>
          </div>
        </div>
      )}

      {/* Primary Header */}
      <header className="sticky top-0 z-40 border-b border-slate-200/80 bg-white/95 backdrop-blur-md">
        <div className="clinic-container flex h-[72px] items-center justify-between gap-3">
          <Link href="/" className="flex items-center gap-3 shrink-0 group">
            <BrandMark className="h-10 w-10" />
            <div className="leading-tight">
              <span className="block font-heading text-base sm:text-[17px] font-bold text-navy group-hover:text-teal transition-colors">
                {doctor?.display_name || 'Dr. Aparna Mishra'}
              </span>
              <span className="block text-[11px] font-medium text-slate-500">
                BHMS · Online Homoeopathic Clinic
              </span>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden xl:flex items-center gap-1" aria-label="Primary">
            {NAV_LINKS.map((item) => {
              const active =
                item.href === '/'
                  ? pathname === '/'
                  : pathname.startsWith(item.href);
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className={`rounded-lg px-3 py-2 text-[13.5px] font-medium transition-colors ${
                    active
                      ? 'bg-aqua text-navy font-semibold'
                      : 'text-slate-600 hover:text-navy hover:bg-slate-50'
                  }`}
                >
                  {item.label}
                </Link>
              );
            })}
          </nav>

          {/* Desktop Right Actions */}
          <div className="hidden sm:flex items-center gap-2.5 shrink-0">
            {activeUser ? (
              <Link
                href={portalHref}
                className="inline-flex items-center gap-1.5 rounded-xl border border-slate-200 px-3.5 py-2.5 text-xs font-semibold text-navy hover:border-teal hover:bg-aqua/60 transition-colors"
              >
                <LayoutDashboard className="h-3.5 w-3.5 text-teal" />
                {portalLabel}
              </Link>
            ) : (
              <Link
                href="/login"
                className="inline-flex items-center gap-1.5 rounded-xl border border-slate-200 px-3.5 py-2.5 text-xs font-semibold text-navy hover:border-teal hover:bg-aqua/60 transition-colors"
              >
                <LogIn className="h-3.5 w-3.5 text-teal" />
                Sign In
              </Link>
            )}
            <Link
              href="/book"
              className="inline-flex items-center gap-1.5 rounded-xl bg-teal px-4 py-2.5 text-xs font-semibold text-white shadow-sm hover:bg-teal-600 transition-colors"
            >
              <Calendar className="h-3.5 w-3.5" />
              Book Appointment
            </Link>
          </div>

          {/* Mobile Hamburger */}
          <button
            type="button"
            onClick={() => setMobileOpen((o) => !o)}
            className="xl:hidden inline-flex h-10 w-10 items-center justify-center rounded-xl border border-slate-200 text-navy hover:bg-slate-50"
            aria-label="Toggle navigation menu"
            aria-expanded={mobileOpen}
          >
            {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>

        {/* Mobile / Tablet Drawer */}
        {mobileOpen && (
          <div className="xl:hidden border-t border-slate-200 bg-white px-4 pb-6 pt-3 shadow-lg">
            <nav className="grid grid-cols-1 sm:grid-cols-2 gap-1 mb-4" aria-label="Mobile">
              {NAV_LINKS.map((item) => {
                const active = item.href === '/' ? pathname === '/' : pathname.startsWith(item.href);
                return (
                  <Link
                    key={item.href}
                    href={item.href}
                    onClick={() => setMobileOpen(false)}
                    className={`rounded-xl px-3.5 py-2.5 text-sm font-medium ${
                      active ? 'bg-aqua text-navy font-semibold' : 'text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    {item.label}
                  </Link>
                );
              })}
            </nav>
            <div className="flex flex-col sm:flex-row gap-2.5 pt-3 border-t border-slate-100">
              <Link
                href="/book"
                onClick={() => setMobileOpen(false)}
                className="btn-primary flex-1"
              >
                <Calendar className="h-4 w-4" />
                Book Online Consultation
              </Link>
              {activeUser ? (
                <Link
                  href={portalHref}
                  onClick={() => setMobileOpen(false)}
                  className="btn-secondary flex-1"
                >
                  <LayoutDashboard className="h-4 w-4 text-teal" />
                  {portalLabel}
                </Link>
              ) : (
                <>
                  <Link
                    href="/login"
                    onClick={() => setMobileOpen(false)}
                    className="btn-secondary flex-1"
                  >
                    Sign In
                  </Link>
                  <Link
                    href="/register"
                    onClick={() => setMobileOpen(false)}
                    className="btn-secondary flex-1"
                  >
                    Patient Registration
                  </Link>
                </>
              )}
            </div>
          </div>
        )}
      </header>

      {/* Main Content */}
      <main className="flex-1">{children}</main>

      {/* Professional Medical Footer */}
      <footer className="bg-navy text-slate-200 mt-auto">
        <div className="clinic-container py-14">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
            {/* Practice Identity */}
            <div>
              <div className="flex items-center gap-3 mb-4">
                <div className="rounded-xl bg-white/10 p-1">
                  <BrandMark className="h-9 w-9" />
                </div>
                <div>
                  <p className="font-heading text-base font-bold text-white">
                    {doctor?.display_name || 'Dr. Aparna Mishra'}
                  </p>
                  <p className="text-xs text-teal-200">BHMS · Homoeopathic Physician</p>
                </div>
              </div>
              <p className="text-sm text-slate-300 leading-relaxed mb-4">
                “{doctor?.tagline || 'Compassionate Care, Individualized Healing.'}”
              </p>
              <p className="text-xs text-slate-400">
                7 Years Clinical Experience · Reg: {doctor?.registration_number || '[Update in Admin CMS]'}
              </p>
            </div>

            {/* Public Pages */}
            <div>
              <h3 className="font-heading text-sm font-semibold text-white uppercase tracking-wider mb-4">
                Clinic Navigation
              </h3>
              <ul className="space-y-2.5 text-sm text-slate-300">
                <li><Link href="/about" className="hover:text-white transition-colors">About the Doctor</Link></li>
                <li><Link href="/services" className="hover:text-white transition-colors">Areas of Consultation</Link></li>
                <li><Link href="/online-consultation" className="hover:text-white transition-colors">Online Video Consultation</Link></li>
                <li><Link href="/blog" className="hover:text-white transition-colors">Health & Wellness Blog</Link></li>
                <li><Link href="/clinic-info" className="hover:text-white transition-colors">Clinic Info & Privacy</Link></li>
                <li><Link href="/faq" className="hover:text-white transition-colors">Frequently Asked Questions</Link></li>
              </ul>
            </div>

            {/* Portals & Access */}
            <div>
              <h3 className="font-heading text-sm font-semibold text-white uppercase tracking-wider mb-4">
                Patient & Clinic Portals
              </h3>
              <ul className="space-y-2.5 text-sm text-slate-300">
                <li><Link href="/book" className="hover:text-white transition-colors">Book Online Appointment</Link></li>
                <li><Link href="/login" className="hover:text-white transition-colors">Sign In (Google / Email)</Link></li>
                <li><Link href="/portal?tab=chat" className="hover:text-white transition-colors">Live Doctor Chat &amp; Calls</Link></li>
                <li><Link href="/portal?tab=video" className="hover:text-white transition-colors">Audio &amp; Video Consultation</Link></li>
                <li><Link href="/portal?tab=prescriptions" className="hover:text-white transition-colors">Download Prescriptions</Link></li>
                <li><Link href="/admin" className="hover:text-teal-200 transition-colors">Doctor / Admin Dashboard</Link></li>
              </ul>
            </div>

            {/* Timings & Direct Contact */}
            <div>
              <h3 className="font-heading text-sm font-semibold text-white uppercase tracking-wider mb-4">
                Timings & Contact
              </h3>
              <div className="space-y-3 text-sm text-slate-300">
                <div className="flex items-start gap-2.5">
                  <Clock className="h-4 w-4 text-teal-300 mt-0.5 shrink-0" />
                  <div>
                    <p className="font-medium text-white">Monday – Saturday</p>
                    <p className="text-xs text-slate-300">3:00 PM – 8:00 PM IST (Online · Prior Booking)</p>
                    <p className="text-xs text-slate-400">Sunday: Closed</p>
                  </div>
                </div>
                <a href={`tel:${phone.replace(/\s+/g, '')}`} className="flex items-center gap-2.5 hover:text-white">
                  <Phone className="h-4 w-4 text-teal-300 shrink-0" />
                  <span className="tabular">{phone} (Audio / Video / Chat)</span>
                </a>
                <a
                  href={`https://wa.me/${wa}?text=${encodeURIComponent(
                    'Namaste Dr. Aparna Mishra, connecting for Online Video / Audio Consultation.'
                  )}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 rounded-lg bg-white/10 px-3 py-1.5 text-xs font-semibold text-teal-200 hover:bg-white/20 hover:text-white transition-colors"
                >
                  WhatsApp Call &amp; Chat · +91 8123108149
                </a>
                <a href={`mailto:${email}`} className="flex items-center gap-2.5 hover:text-white break-all">
                  <Mail className="h-4 w-4 text-teal-300 shrink-0" />
                  <span>{email}</span>
                </a>
                <div className="pt-2 flex items-center gap-2 text-xs text-teal-200">
                  <ShieldCheck className="h-4 w-4 shrink-0" />
                  <span>DPDP Act 2023 & Telemedicine Compliant</span>
                </div>
              </div>
            </div>
          </div>

          {/* Clinical Emergency & Privacy Disclaimer */}
          <div className="mt-10 pt-6 border-t border-white/10 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 text-xs text-slate-400">
            <p className="max-w-3xl leading-relaxed">
              <strong className="text-slate-300">Medical & Emergency Notice:</strong> This platform provides non-emergency online consultations ({timings}). For acute medical emergencies, visit your nearest hospital immediately or dial <strong className="text-white">112 / 108</strong>. In-person medical evaluation and specialist referral are advised whenever clinically required.
            </p>
            <p className="shrink-0">
              © {new Date().getFullYear()} {doctor?.display_name || 'Dr. Aparna Mishra'}. All rights reserved.
            </p>
          </div>
        </div>
      </footer>

      {/* Floating Safety-Guarded AI Healthcare Support Assistant */}
      <ChatbotWidget welcomeMessage={chatbotWelcome} whatsappNumber={wa} />
    </div>
  );
}
