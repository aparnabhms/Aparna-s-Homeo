'use client';

import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  AlertCircle,
  Check,
  Copy,
  ExternalLink,
  MessageCircle,
  Mic,
  MicOff,
  MonitorUp,
  Phone,
  PhoneOff,
  RefreshCw,
  ShieldCheck,
  Video,
  VideoOff,
  Volume2,
  VolumeX,
} from 'lucide-react';
import { authFetch, buildAuthedUrl } from '@/lib/clientSession';

export interface ActiveRtcSession {
  callId: string;
  callType: 'AUDIO' | 'VIDEO';
  role: 'CALLER' | 'CALLEE';
  peerName: string;
  peerPhone?: string | null;
  callerKey?: string | null;
  peerKey?: string | null;
  roomKey?: string | null;
}

function formatDuration(sec: number): string {
  const m = Math.floor(sec / 60);
  const s = sec % 60;
  return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
}

export default function NativeWebRTCCall({
  session,
  mode,
  currentUserName,
  sessionToken,
  fullScreen = false,
  onClose,
}: {
  session: ActiveRtcSession;
  mode: 'PATIENT' | 'CLINIC';
  currentUserName: string;
  sessionToken?: string;
  fullScreen?: boolean;
  onClose: () => void;
}) {
  const [callStatus, setCallStatus] = useState<
    'CONNECTING_MEDIA' | 'RINGING' | 'CONNECTING_PEER' | 'CONNECTED' | 'ENDED' | 'DECLINED' | 'MISSED'
  >('CONNECTING_MEDIA');
  const [mediaNotice, setMediaNotice] = useState<string>('');
  const [iframeBlocked, setIframeBlocked] = useState(false);
  const [micEnabled, setMicEnabled] = useState(true);
  const [camEnabled, setCamEnabled] = useState(session.callType === 'VIDEO');
  const [hasLocalVideo, setHasLocalVideo] = useState(false);
  const [hasLocalAudio, setHasLocalAudio] = useState(false);
  const [hasRemoteStream, setHasRemoteStream] = useState(false);
  const [screenSharing, setScreenSharing] = useState(false);
  const [ringToneOn, setRingToneOn] = useState(true);
  const [micLevel, setMicLevel] = useState(0);
  const [elapsedSec, setElapsedSec] = useState(0);
  const [copiedPhone, setCopiedPhone] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);
  const [callerKeyState, setCallerKeyState] = useState<string>(session.callerKey || '');
  const [peerKeyState, setPeerKeyState] = useState<string>(session.peerKey || '');

  const activeRoomKey =
    session.roomKey || (session.role === 'CALLER' ? callerKeyState || session.callerKey : '') || '';

  const rtcGet = useCallback(
    (extraParams = '') => {
      const qs = new URLSearchParams();
      qs.set('callId', session.callId);
      if (activeRoomKey) qs.set('rk', activeRoomKey);
      const url = `/api/rtc?${qs.toString()}${extraParams ? `&${extraParams}` : ''}`;
      return authFetch(
        url,
        activeRoomKey ? { headers: { 'X-Call-Key': activeRoomKey } } : undefined,
        sessionToken
      );
    },
    [session.callId, activeRoomKey, sessionToken]
  );

  const rtcPost = useCallback(
    (payload: Record<string, unknown>) => {
      const headers: Record<string, string> = { 'Content-Type': 'application/json' };
      if (activeRoomKey) headers['X-Call-Key'] = activeRoomKey;
      return authFetch(
        '/api/rtc',
        {
          method: 'POST',
          headers,
          body: JSON.stringify({
            ...payload,
            roomKey: activeRoomKey || undefined,
          }),
        },
        sessionToken
      );
    },
    [activeRoomKey, sessionToken]
  );

  const localVideoRef = useRef<HTMLVideoElement | null>(null);
  const remoteVideoRef = useRef<HTMLVideoElement | null>(null);
  const remoteAudioRef = useRef<HTMLAudioElement | null>(null);

  const pcRef = useRef<RTCPeerConnection | null>(null);
  const localStreamRef = useRef<MediaStream | null>(null);
  const remoteStreamRef = useRef<MediaStream | null>(null);
  const screenStreamRef = useRef<MediaStream | null>(null);
  const lastIceIdRef = useRef<number>(0);
  const answerAppliedRef = useRef<boolean>(false);
  const calleeAnsweredRef = useRef<boolean>(false);
  const pendingRemoteIceRef = useRef<RTCIceCandidateInit[]>([]);
  const audioCtxRef = useRef<AudioContext | null>(null);
  const endedRef = useRef<boolean>(false);

  const stopAllMedia = useCallback(() => {
    if (localStreamRef.current) {
      localStreamRef.current.getTracks().forEach((t) => t.stop());
      localStreamRef.current = null;
    }
    if (screenStreamRef.current) {
      screenStreamRef.current.getTracks().forEach((t) => t.stop());
      screenStreamRef.current = null;
    }
    if (pcRef.current) {
      try {
        pcRef.current.close();
      } catch {
        // ignore
      }
      pcRef.current = null;
    }
    if (audioCtxRef.current) {
      try {
        audioCtxRef.current.close();
      } catch {
        // ignore
      }
      audioCtxRef.current = null;
    }
  }, []);

  // Attach microphone audio level meter (visual confirmation that your mic is live!)
  const attachMicMeter = useCallback((stream: MediaStream) => {
    if (stream.getAudioTracks().length === 0) return;
    try {
      const Ctx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!Ctx) return;
      const ctx = new Ctx();
      audioCtxRef.current = ctx;
      const src = ctx.createMediaStreamSource(stream);
      const analyser = ctx.createAnalyser();
      analyser.fftSize = 256;
      src.connect(analyser);
      const data = new Uint8Array(analyser.frequencyBinCount);

      const tick = () => {
        if (endedRef.current || !localStreamRef.current) return;
        analyser.getByteFrequencyData(data);
        let sum = 0;
        for (let i = 0; i < 32; i++) sum += data[i];
        const avg = Math.min(100, Math.round((sum / 32 / 140) * 100));
        setMicLevel(avg);
        requestAnimationFrame(tick);
      };
      requestAnimationFrame(tick);
    } catch {
      // ignore if AudioContext blocked
    }
  }, []);

  // Request browser microphone + camera with intelligent fallbacks
  const acquireUserMedia = useCallback(
    async (wantVideo: boolean): Promise<MediaStream | null> => {
      if (typeof navigator === 'undefined' || !navigator.mediaDevices?.getUserMedia) {
        const inFrame = (() => {
          try {
            return window.self !== window.top;
          } catch {
            return true;
          }
        })();
        setIframeBlocked(inFrame);
        setMediaNotice(
          inFrame
            ? 'Camera & microphone are restricted inside this preview pane. Click "Open Call in Full Tab" below to enable full HD camera & microphone.'
            : 'Your browser blocked camera/microphone access. Allow permissions in your browser address bar and click Retry.'
        );
        return null;
      }

      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          audio: {
            echoCancellation: true,
            noiseSuppression: true,
            autoGainControl: true,
          },
          video: wantVideo
            ? {
                width: { ideal: 1280 },
                height: { ideal: 720 },
                facingMode: 'user',
              }
            : false,
        });
        setMediaNotice('');
        setIframeBlocked(false);
        setHasLocalAudio(stream.getAudioTracks().length > 0);
        setHasLocalVideo(stream.getVideoTracks().length > 0);
        setCamEnabled(stream.getVideoTracks().length > 0);
        setMicEnabled(stream.getAudioTracks().length > 0);
        localStreamRef.current = stream;
        if (localVideoRef.current && stream.getVideoTracks().length > 0) {
          localVideoRef.current.srcObject = stream;
        }
        attachMicMeter(stream);
        return stream;
      } catch (err: unknown) {
        const errName = err instanceof Error ? err.name : '';

        // If video failed (no webcam or camera busy), automatically fall back to audio-only!
        if (wantVideo) {
          try {
            const audioOnly = await navigator.mediaDevices.getUserMedia({
              audio: { echoCancellation: true, noiseSuppression: true },
              video: false,
            });
            setMediaNotice('No camera detected — connected with live microphone (Audio mode).');
            setHasLocalAudio(true);
            setHasLocalVideo(false);
            setCamEnabled(false);
            setMicEnabled(true);
            localStreamRef.current = audioOnly;
            attachMicMeter(audioOnly);
            return audioOnly;
          } catch {
            // fall through to permission notice
          }
        }

        const inFrame = (() => {
          try {
            return window.self !== window.top;
          } catch {
            return true;
          }
        })();
        setIframeBlocked(inFrame);
        if (inFrame) {
          setMediaNotice(
            'Embedded preview restricted camera/mic permissions. The call is ringing live — click "Open Call in Full Tab" to enable your camera & microphone immediately.'
          );
        } else if (errName === 'NotAllowedError' || errName === 'PermissionDeniedError') {
          setMediaNotice(
            'Camera/Microphone permission was blocked. Click the lock/camera icon in your browser address bar → Allow Camera & Microphone → then tap Retry Mic/Cam.'
          );
        } else {
          setMediaNotice(
            'No microphone or camera found on this device. Plug in earphones/mic and tap Retry, or call +91 8123108149 from your phone.'
          );
        }
        return null;
      }
    },
    [attachMicMeter]
  );

  // Initialize PeerConnection + WebRTC Signaling
  const startPeerEngine = useCallback(async () => {
    endedRef.current = false;
    answerAppliedRef.current = false;
    calleeAnsweredRef.current = false;
    lastIceIdRef.current = 0;
    pendingRemoteIceRef.current = [];

    // 1. Fetch call metadata & ICE servers
    const initResp = await rtcGet();
    if (!initResp.ok) {
      const errJson = await initResp.json().catch(() => ({}));
      setMediaNotice(
        errJson.error || 'Could not reach clinic call server. Please tap Retry Mic/Cam.'
      );
      setCallStatus('ENDED');
      return;
    }
    const initData = await initResp.json();
    if (initData.call?.callerKey) setCallerKeyState(initData.call.callerKey);
    if (initData.call?.peerKey) setPeerKeyState(initData.call.peerKey);
    const iceServers = initData.iceServers || [
      { urls: 'stun:stun.l.google.com:19302' },
    ];

    // 2. Capture local mic (+ camera if VIDEO)
    const stream = await acquireUserMedia(session.callType === 'VIDEO');
    if (endedRef.current) return;

    // 3. Create RTCPeerConnection (pure P2P, NEVER recorded)
    const pc = new RTCPeerConnection({ iceServers });
    pcRef.current = pc;

    const remoteStream = new MediaStream();
    remoteStreamRef.current = remoteStream;

    pc.ontrack = (ev) => {
      const tracks = ev.streams?.[0]?.getTracks() || [ev.track];
      tracks.forEach((t) => {
        if (!remoteStream.getTracks().some((rt) => rt.id === t.id)) {
          remoteStream.addTrack(t);
        }
      });
      setHasRemoteStream(true);
      if (remoteVideoRef.current) {
        remoteVideoRef.current.srcObject = remoteStream;
      }
      if (remoteAudioRef.current) {
        remoteAudioRef.current.srcObject = remoteStream;
      }
    };

    pc.onicecandidate = (ev) => {
      if (ev.candidate && !endedRef.current) {
        rtcPost({
          action: 'ICE',
          callId: session.callId,
          candidate: ev.candidate.toJSON(),
        }).catch(() => {});
      }
    };

    pc.onconnectionstatechange = () => {
      const st = pc.connectionState;
      if (st === 'connected') {
        setCallStatus('CONNECTED');
      } else if (st === 'connecting') {
        setCallStatus('CONNECTING_PEER');
      }
    };

    // Add local tracks (or recvonly transceivers so signaling works even before mic is unlocked)
    if (stream) {
      stream.getTracks().forEach((track) => pc.addTrack(track, stream));
    } else {
      pc.addTransceiver('audio', { direction: 'recvonly' });
      if (session.callType === 'VIDEO') {
        pc.addTransceiver('video', { direction: 'recvonly' });
      }
    }

    // 4. Caller generates & posts SDP Offer; Callee applies Offer & generates SDP Answer
    const mySide: 'CALLER' | 'CALLEE' = initData.mySide || session.role;

    if (mySide === 'CALLER') {
      const offer = await pc.createOffer();
      await pc.setLocalDescription(offer);
      await rtcPost({
        action: 'OFFER',
        callId: session.callId,
        offerSdp: pc.localDescription,
        resetIce: true,
      });
      setCallStatus('RINGING');
    } else {
      setCallStatus('CONNECTING_PEER');
      if (initData.call?.offerSdp) {
        calleeAnsweredRef.current = true;
        await pc.setRemoteDescription(new RTCSessionDescription(initData.call.offerSdp));
        const answer = await pc.createAnswer();
        await pc.setLocalDescription(answer);
        await rtcPost({
          action: 'ANSWER',
          callId: session.callId,
          answerSdp: pc.localDescription,
        });
        setCallStatus('CONNECTED');
      }
    }
  }, [session.callId, session.callType, session.role, acquireUserMedia, rtcGet, rtcPost]);

  useEffect(() => {
    startPeerEngine();
    return () => {
      endedRef.current = true;
      stopAllMedia();
    };
  }, [startPeerEngine, stopAllMedia]);

  // Re-attach local stream whenever localVideoRef renders
  useEffect(() => {
    if (localVideoRef.current && localStreamRef.current && hasLocalVideo) {
      localVideoRef.current.srcObject = localStreamRef.current;
    }
  }, [hasLocalVideo, camEnabled, callStatus]);

  // Re-attach remote stream whenever remote elements render
  useEffect(() => {
    if (hasRemoteStream && remoteStreamRef.current) {
      if (remoteVideoRef.current) remoteVideoRef.current.srcObject = remoteStreamRef.current;
      if (remoteAudioRef.current) remoteAudioRef.current.srcObject = remoteStreamRef.current;
    }
  }, [hasRemoteStream, callStatus]);

  // Fast signaling poll loop (exchanges SDP offer/answer + trickled ICE candidates)
  useEffect(() => {
    if (callStatus === 'ENDED' || callStatus === 'DECLINED' || callStatus === 'MISSED') return;

    const timer = setInterval(async () => {
      if (endedRef.current) return;
      try {
        const res = await rtcGet(`afterIce=${lastIceIdRef.current}`);
        if (!res.ok) return;
        const data = await res.json();
        const pc = pcRef.current;
        const call = data.call;
        if (!call) return;

        if (call.status === 'ENDED' || call.status === 'DECLINED' || call.status === 'MISSED') {
          setCallStatus(call.status);
          stopAllMedia();
          return;
        }

        // If callee was waiting for offer, answer now
        if (
          pc &&
          data.mySide === 'CALLEE' &&
          call.offerSdp &&
          !calleeAnsweredRef.current
        ) {
          calleeAnsweredRef.current = true;
          await pc.setRemoteDescription(new RTCSessionDescription(call.offerSdp));
          for (const c of pendingRemoteIceRef.current) {
            try {
              await pc.addIceCandidate(new RTCIceCandidate(c));
            } catch {}
          }
          pendingRemoteIceRef.current = [];
          const answer = await pc.createAnswer();
          await pc.setLocalDescription(answer);
          await rtcPost({
            action: 'ANSWER',
            callId: session.callId,
            answerSdp: pc.localDescription,
          });
          setCallStatus('CONNECTED');
        }

        // If caller receives callee's SDP Answer, complete P2P handshake!
        if (
          pc &&
          data.mySide === 'CALLER' &&
          call.answerSdp &&
          !answerAppliedRef.current
        ) {
          answerAppliedRef.current = true;
          await pc.setRemoteDescription(new RTCSessionDescription(call.answerSdp));
          for (const c of pendingRemoteIceRef.current) {
            try {
              await pc.addIceCandidate(new RTCIceCandidate(c));
            } catch {}
          }
          pendingRemoteIceRef.current = [];
          setCallStatus('CONNECTED');
        }

        // Add newly arrived remote ICE candidates
        if (pc && Array.isArray(data.remoteCandidates)) {
          for (const item of data.remoteCandidates) {
            if (item.id > lastIceIdRef.current) {
              lastIceIdRef.current = item.id;
            }
            if (pc.remoteDescription) {
              try {
                await pc.addIceCandidate(new RTCIceCandidate(item.candidate));
              } catch {
                // ignore duplicate/stale ICE
              }
            } else {
              pendingRemoteIceRef.current.push(item.candidate);
            }
          }
        }
      } catch {
        // transient network retry
      }
    }, 1200);

    return () => clearInterval(timer);
  }, [session.callId, callStatus, stopAllMedia]);

  // Gentle synthesized calling tone while RINGING (can be muted)
  useEffect(() => {
    if (callStatus !== 'RINGING' || !ringToneOn) return;
    let ringCtx: AudioContext | null = null;
    const playPulse = () => {
      try {
        const Ctx =
          window.AudioContext ||
          (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
        if (!Ctx) return;
        if (!ringCtx) ringCtx = new Ctx();
        if (ringCtx.state === 'suspended') ringCtx.resume().catch(() => {});
        const osc = ringCtx.createOscillator();
        const gain = ringCtx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(440, ringCtx.currentTime);
        gain.gain.setValueAtTime(0.035, ringCtx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.0001, ringCtx.currentTime + 0.9);
        osc.connect(gain);
        gain.connect(ringCtx.destination);
        osc.start();
        osc.stop(ringCtx.currentTime + 0.9);
      } catch {
        // ignore autoplay restriction
      }
    };
    playPulse();
    const id = setInterval(playPulse, 3200);
    return () => {
      clearInterval(id);
      if (ringCtx) ringCtx.close().catch(() => {});
    };
  }, [callStatus, ringToneOn]);

  // Call duration timer once CONNECTED
  useEffect(() => {
    if (callStatus !== 'CONNECTED') return;
    const t = setInterval(() => setElapsedSec((s) => s + 1), 1000);
    return () => clearInterval(t);
  }, [callStatus]);

  function toggleMic() {
    const stream = localStreamRef.current;
    if (!stream) return;
    const next = !micEnabled;
    stream.getAudioTracks().forEach((t) => {
      t.enabled = next;
    });
    setMicEnabled(next);
  }

  async function toggleCamera() {
    const stream = localStreamRef.current;
    if (stream && stream.getVideoTracks().length > 0) {
      const next = !camEnabled;
      stream.getVideoTracks().forEach((t) => {
        t.enabled = next;
      });
      setCamEnabled(next);
      return;
    }

    // Upgrade Audio call to turn on local camera
    try {
      const vidStream = await navigator.mediaDevices.getUserMedia({
        video: { width: { ideal: 1280 }, height: { ideal: 720 }, facingMode: 'user' },
      });
      const vTrack = vidStream.getVideoTracks()[0];
      if (vTrack) {
        if (localStreamRef.current) {
          localStreamRef.current.addTrack(vTrack);
        } else {
          localStreamRef.current = vidStream;
        }
        if (localVideoRef.current) {
          localVideoRef.current.srcObject = localStreamRef.current;
        }
        if (pcRef.current && localStreamRef.current) {
          pcRef.current.addTrack(vTrack, localStreamRef.current);
        }
        setHasLocalVideo(true);
        setCamEnabled(true);
        setMediaNotice('');
      }
    } catch {
      setMediaNotice('Could not access camera. Check camera permissions or open call in a full tab.');
    }
  }

  async function toggleScreenShare() {
    if (screenSharing && screenStreamRef.current) {
      screenStreamRef.current.getTracks().forEach((t) => t.stop());
      screenStreamRef.current = null;
      setScreenSharing(false);
      const camTrack = localStreamRef.current?.getVideoTracks()[0];
      const sender = pcRef.current?.getSenders().find((s) => s.track?.kind === 'video');
      if (sender && camTrack) await sender.replaceTrack(camTrack);
      if (localVideoRef.current && localStreamRef.current) {
        localVideoRef.current.srcObject = localStreamRef.current;
      }
      return;
    }

    if (!navigator.mediaDevices?.getDisplayMedia) {
      setMediaNotice('Screen sharing works in a full desktop browser tab — click "Open Call in Full Tab".');
      return;
    }
    try {
      const disp = await navigator.mediaDevices.getDisplayMedia({ video: true });
      const sTrack = disp.getVideoTracks()[0];
      if (!sTrack) return;
      screenStreamRef.current = disp;
      setScreenSharing(true);
      const sender = pcRef.current?.getSenders().find((s) => s.track?.kind === 'video');
      if (sender) {
        await sender.replaceTrack(sTrack);
      } else if (pcRef.current) {
        pcRef.current.addTrack(sTrack, disp);
      }
      if (localVideoRef.current) {
        localVideoRef.current.srcObject = disp;
      }
      sTrack.onended = () => {
        setScreenSharing(false);
        const camTrack = localStreamRef.current?.getVideoTracks()[0];
        if (sender && camTrack) sender.replaceTrack(camTrack);
        if (localVideoRef.current && localStreamRef.current) {
          localVideoRef.current.srcObject = localStreamRef.current;
        }
      };
    } catch {
      // user cancelled picker
    }
  }

  async function handleHangUp() {
    endedRef.current = true;
    stopAllMedia();
    try {
      await rtcPost({ action: 'END', callId: session.callId });
    } catch {
      // ignore
    }
    onClose();
  }

  async function handleRetryMedia() {
    stopAllMedia();
    setMediaNotice('');
    setCallStatus('CONNECTING_MEDIA');
    await startPeerEngine();
  }

  function openCallInFullTab() {
    const base = activeRoomKey
      ? `/call/${session.callId}?rk=${encodeURIComponent(activeRoomKey)}`
      : `/call/${session.callId}`;
    const fullUrl = buildAuthedUrl(base, sessionToken);
    window.open(fullUrl, '_blank', 'noopener');
  }

  function copyClinicNumber() {
    navigator.clipboard?.writeText('+91 8123108149').catch(() => {});
    setCopiedPhone(true);
    setTimeout(() => setCopiedPhone(false), 2000);
  }

  const origin = typeof window !== 'undefined' ? window.location.origin : '';
  const effectivePeerKey = peerKeyState || session.peerKey || '';
  const joinUrlForPeer = effectivePeerKey
    ? `${origin}/call/${session.callId}?rk=${encodeURIComponent(effectivePeerKey)}`
    : `${origin}/call/${session.callId}`;

  function copyJoinLink() {
    navigator.clipboard?.writeText(joinUrlForPeer).catch(() => {});
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2200);
  }

  const cleanPeerPhone = (session.peerPhone || '').replace(/\D/g, '');
  const peerWa =
    mode === 'PATIENT'
      ? '918123108149'
      : cleanPeerPhone.length === 10
      ? `91${cleanPeerPhone}`
      : cleanPeerPhone;

  const waInviteHref = peerWa
    ? `https://wa.me/${peerWa}?text=${encodeURIComponent(
        mode === 'PATIENT'
          ? `Namaste Dr. Aparna Mishra, I am ${currentUserName} waiting on our live ${
              session.callType === 'VIDEO' ? 'Video' : 'Audio'
            } Consultation Call. Join here: ${joinUrlForPeer}`
          : `Namaste ${session.peerName}, Dr. Aparna Mishra (+91 8123108149) is calling you for your Online ${
              session.callType === 'VIDEO' ? 'Video' : 'Audio'
            } Consultation. Tap to answer: ${joinUrlForPeer}`
      )}`
    : '';

  const remoteHasVideo =
    hasRemoteStream && (remoteStreamRef.current?.getVideoTracks().length || 0) > 0;

  return (
    <div
      className={`rounded-2xl border-2 border-teal bg-navy text-white overflow-hidden shadow-elevated flex flex-col ${
        fullScreen ? 'min-h-[calc(100vh-2rem)]' : ''
      }`}
    >
      {/* Hidden audio element ensures remote voice always plays clearly even in audio-only calls */}
      <audio ref={remoteAudioRef} autoPlay playsInline className="hidden" />

      {/* Top Status Bar */}
      <div className="px-4 sm:px-5 py-3 bg-navy-800 border-b border-white/10 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2.5 text-xs">
          <span
            className={`h-2.5 w-2.5 rounded-full ${
              callStatus === 'CONNECTED'
                ? 'bg-emerald-400'
                : callStatus === 'RINGING' || callStatus === 'CONNECTING_MEDIA' || callStatus === 'CONNECTING_PEER'
                ? 'bg-amber-400 animate-pulse'
                : 'bg-rose-400'
            }`}
          />
          <strong className="font-heading text-sm">
            {session.callType === 'VIDEO' ? 'Live HD Video Call' : 'Live Audio Call'}
          </strong>
          <span className="rounded-full bg-white/10 px-2.5 py-0.5 text-[11px] font-semibold text-teal-200 tabular">
            {callStatus === 'CONNECTED'
              ? `Connected · ${formatDuration(elapsedSec)}`
              : callStatus === 'RINGING'
              ? `Ringing ${session.peerName}…`
              : callStatus === 'CONNECTING_MEDIA'
              ? 'Starting Mic / Camera…'
              : callStatus === 'CONNECTING_PEER'
              ? 'Connecting Secure Stream…'
              : callStatus === 'DECLINED'
              ? 'Call Busy / Declined'
              : callStatus === 'MISSED'
              ? 'No Answer'
              : 'Call Ended'}
          </span>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <span className="hidden md:inline-flex items-center gap-1 text-[11px] text-teal-200">
            <ShieldCheck className="h-3.5 w-3.5" /> Encrypted P2P · Recording OFF
          </span>
          {!fullScreen && (
            <button
              type="button"
              onClick={openCallInFullTab}
              className="inline-flex items-center gap-1.5 rounded-lg bg-teal px-3 py-1.5 text-xs font-semibold text-white hover:bg-teal-600 transition-colors"
            >
              Open in Full Tab <ExternalLink className="h-3 w-3" />
            </button>
          )}
        </div>
      </div>

      {/* Camera / Mic Permission Helper Banner (when embedded preview restricts media) */}
      {mediaNotice && (
        <div className="px-4 py-2.5 bg-amber-500/15 border-b border-amber-400/30 flex flex-wrap items-center justify-between gap-2 text-xs text-amber-100">
          <div className="flex items-start gap-2 max-w-2xl">
            <AlertCircle className="h-4 w-4 text-amber-300 shrink-0 mt-0.5" />
            <span>{mediaNotice}</span>
          </div>
          <div className="flex items-center gap-2">
            {iframeBlocked && !fullScreen && (
              <button
                type="button"
                onClick={openCallInFullTab}
                className="rounded-lg bg-amber-400 px-3 py-1 text-[11px] font-bold text-navy hover:bg-amber-300"
              >
                Open Call in Full Tab →
              </button>
            )}
            <button
              type="button"
              onClick={handleRetryMedia}
              className="inline-flex items-center gap-1 rounded-lg bg-white/15 px-2.5 py-1 text-[11px] font-semibold text-white hover:bg-white/25"
            >
              <RefreshCw className="h-3 w-3" /> Retry Mic/Cam
            </button>
          </div>
        </div>
      )}

      {/* Main Video / Audio Stage */}
      <div
        className={`relative bg-slate-950 flex items-center justify-center overflow-hidden ${
          fullScreen ? 'flex-1 min-h-[420px]' : 'h-[360px] sm:h-[420px]'
        }`}
      >
        {/* Remote Video Stream (full stage when peer shares video) */}
        <video
          ref={remoteVideoRef}
          autoPlay
          playsInline
          className={`w-full h-full object-cover ${
            callStatus === 'CONNECTED' && remoteHasVideo ? 'block' : 'hidden'
          }`}
        />

        {/* Avatar / Ringing / Audio Call Center Stage */}
        {!(callStatus === 'CONNECTED' && remoteHasVideo) && (
          <div className="relative z-10 flex flex-col items-center text-center px-6 space-y-3">
            <div className="relative">
              {callStatus === 'RINGING' && (
                <span className="absolute -inset-2 rounded-full border-2 border-teal-300/50 animate-ping" />
              )}
              {mode === 'PATIENT' ? (
                <img
                  src="/images/dr-aparna-mishra.jpeg"
                  alt="Dr. Aparna Mishra"
                  className="relative h-24 w-24 rounded-full object-cover object-top border-2 border-teal shadow-lg"
                />
              ) : (
                <div className="relative h-24 w-24 rounded-full bg-teal/25 border-2 border-teal flex items-center justify-center font-heading text-3xl font-bold text-white">
                  {session.peerName.charAt(0).toUpperCase()}
                </div>
              )}
            </div>

            <div>
              <h3 className="font-heading text-lg font-bold text-white">{session.peerName}</h3>
              <p className="text-xs text-teal-200 tabular mt-0.5">
                {mode === 'PATIENT'
                  ? 'BHMS · Official Clinic Line: +91 8123108149'
                  : session.peerPhone
                  ? `Patient Mobile: +91 ${session.peerPhone}`
                  : 'Patient Online Consultation'}
              </p>
            </div>

            <p className="text-xs text-slate-300 max-w-md leading-relaxed">
              {callStatus === 'CONNECTED'
                ? `Connected on secure two-way audio (${formatDuration(elapsedSec)}).`
                : callStatus === 'RINGING'
                ? mode === 'PATIENT'
                  ? 'Ringing Dr. Aparna Mishra’s Clinic Console… You can also tap "Alert on WhatsApp +91 8123108149" below so she receives an instant join link on her phone.'
                  : `Ringing ${session.peerName}’s Patient Portal… They can answer directly in the portal or via the WhatsApp join link below.`
                : callStatus === 'DECLINED'
                ? 'The other side is currently busy. You can message in Live Chat or connect via WhatsApp +91 8123108149.'
                : callStatus === 'ENDED'
                ? 'This call has ended.'
                : 'Preparing your encrypted WebRTC consultation channel…'}
            </p>

            {/* Quick WhatsApp + Direct Instant Join Link while Ringing */}
            {callStatus === 'RINGING' && (
              <div className="flex flex-wrap items-center justify-center gap-2 pt-1">
                {waInviteHref && (
                  <a
                    href={waInviteHref}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 rounded-xl bg-emerald-600 px-4 py-2 text-xs font-semibold text-white hover:bg-emerald-500 transition-colors shadow-sm"
                  >
                    <MessageCircle className="h-3.5 w-3.5" />
                    {mode === 'PATIENT'
                      ? 'Alert Dr. Aparna on WhatsApp (+91 8123108149)'
                      : 'Send Call Link to Patient’s WhatsApp'}
                  </a>
                )}
                <button
                  type="button"
                  onClick={copyJoinLink}
                  className="inline-flex items-center gap-1.5 rounded-xl bg-white/15 border border-white/25 px-3.5 py-2 text-xs font-semibold text-white hover:bg-white/25 transition-colors"
                >
                  {copiedLink ? <Check className="h-3.5 w-3.5 text-emerald-300" /> : <Copy className="h-3.5 w-3.5" />}
                  {copiedLink ? 'Direct Call Link Copied!' : 'Copy Direct Call Link'}
                </button>
              </div>
            )}
          </div>
        )}

        {/* Live Local Camera Picture-in-Picture Preview */}
        {hasLocalVideo && camEnabled && (
          <div className="absolute bottom-3 right-3 z-20 w-32 sm:w-44 aspect-video rounded-xl overflow-hidden border-2 border-white/30 bg-slate-900 shadow-lg">
            <video
              ref={localVideoRef}
              autoPlay
              muted
              playsInline
              className={`w-full h-full object-cover ${screenSharing ? '' : '-scale-x-100'}`}
            />
            <span className="absolute bottom-1 left-1.5 rounded bg-black/60 px-1.5 py-0.5 text-[10px] font-medium text-white">
              {screenSharing ? 'Your Screen' : 'You (Live)'}
            </span>
          </div>
        )}

        {/* Live Microphone Activity Indicator (Bottom Left) */}
        <div className="absolute bottom-3 left-3 z-20 rounded-xl bg-black/60 backdrop-blur-sm border border-white/15 px-3 py-1.5 flex items-center gap-2 text-[11px]">
          {hasLocalAudio && micEnabled ? (
            <>
              <Mic className="h-3.5 w-3.5 text-emerald-400" />
              <span className="text-slate-200">Mic Live</span>
              <div className="flex items-end gap-0.5 h-3">
                {[12, 28, 46, 65, 82].map((thresh, idx) => (
                  <span
                    key={idx}
                    style={{ height: `${Math.max(3, (idx + 1) * 2.4)}px` }}
                    className={`w-1 rounded-full transition-colors ${
                      micLevel >= thresh ? 'bg-emerald-400' : 'bg-white/20'
                    }`}
                  />
                ))}
              </div>
            </>
          ) : (
            <>
              <MicOff className="h-3.5 w-3.5 text-rose-400" />
              <span className="text-slate-300">{hasLocalAudio ? 'Muted' : 'Mic Not Active'}</span>
            </>
          )}
        </div>
      </div>

      {/* Bottom Call Control Bar */}
      <div className="px-4 py-3.5 bg-navy-800 border-t border-white/10 flex flex-wrap items-center justify-between gap-3">
        {/* Media Controls */}
        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={hasLocalAudio ? toggleMic : handleRetryMedia}
            className={`inline-flex items-center gap-1.5 rounded-xl px-3.5 py-2 text-xs font-semibold transition-colors ${
              hasLocalAudio && micEnabled
                ? 'bg-white/15 text-white hover:bg-white/25'
                : 'bg-rose-500/80 text-white hover:bg-rose-500'
            }`}
          >
            {hasLocalAudio && micEnabled ? (
              <>
                <Mic className="h-4 w-4" /> Mute
              </>
            ) : (
              <>
                <MicOff className="h-4 w-4" /> {hasLocalAudio ? 'Unmute' : 'Enable Mic'}
              </>
            )}
          </button>

          <button
            type="button"
            onClick={toggleCamera}
            className={`inline-flex items-center gap-1.5 rounded-xl px-3.5 py-2 text-xs font-semibold transition-colors ${
              hasLocalVideo && camEnabled
                ? 'bg-white/15 text-white hover:bg-white/25'
                : 'bg-white/10 text-slate-200 hover:bg-white/20'
            }`}
          >
            {hasLocalVideo && camEnabled ? (
              <>
                <Video className="h-4 w-4" /> Camera On
              </>
            ) : (
              <>
                <VideoOff className="h-4 w-4" /> Turn On Video
              </>
            )}
          </button>

          <button
            type="button"
            onClick={toggleScreenShare}
            className={`hidden sm:inline-flex items-center gap-1.5 rounded-xl px-3 py-2 text-xs font-semibold transition-colors ${
              screenSharing
                ? 'bg-teal text-white'
                : 'bg-white/10 text-slate-200 hover:bg-white/20'
            }`}
          >
            <MonitorUp className="h-4 w-4" /> {screenSharing ? 'Stop Share' : 'Share Report'}
          </button>

          {callStatus === 'RINGING' && (
            <button
              type="button"
              onClick={() => setRingToneOn((r) => !r)}
              className="inline-flex items-center gap-1 rounded-xl bg-white/10 px-3 py-2 text-xs font-medium text-slate-200 hover:bg-white/20"
              title="Toggle dial tone"
            >
              {ringToneOn ? <Volume2 className="h-4 w-4" /> : <VolumeX className="h-4 w-4" />}
            </button>
          )}
        </div>

        {/* Direct Phone Line + End Call */}
        <div className="flex flex-wrap items-center gap-2">
          {mode === 'PATIENT' && (
            <>
              <a
                href="tel:+918123108149"
                target="_top"
                className="inline-flex items-center gap-1 rounded-xl bg-white/10 px-3 py-2 text-xs font-semibold text-teal-200 hover:bg-white/20 tabular"
              >
                <Phone className="h-3.5 w-3.5" /> +91 8123108149
              </a>
              <button
                type="button"
                onClick={copyClinicNumber}
                className="inline-flex items-center gap-1 rounded-xl bg-white/10 px-2.5 py-2 text-xs text-slate-200 hover:bg-white/20"
                title="Copy +91 8123108149"
              >
                {copiedPhone ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
              </button>
            </>
          )}
          <button
            type="button"
            onClick={handleHangUp}
            className="inline-flex items-center gap-1.5 rounded-xl bg-rose-600 px-4 py-2 text-xs font-bold text-white hover:bg-rose-700 transition-colors"
          >
            <PhoneOff className="h-4 w-4" /> End Call
          </button>
        </div>
      </div>
    </div>
  );
}
