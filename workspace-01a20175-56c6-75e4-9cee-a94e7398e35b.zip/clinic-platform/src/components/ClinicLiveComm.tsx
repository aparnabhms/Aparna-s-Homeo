'use client';

import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  Check,
  CheckCheck,
  Copy,
  ExternalLink,
  MessageCircle,
  MessageSquare,
  Phone,
  PhoneCall,
  Search,
  Send,
  ShieldCheck,
  Video,
} from 'lucide-react';
import NativeWebRTCCall, { ActiveRtcSession } from './NativeWebRTCCall';
import { authFetch, buildAuthedUrl, saveClientSession } from '@/lib/clientSession';

interface ChatMessage {
  id: string;
  patient_id: string;
  sender_id: string;
  sender_role: string;
  sender_name: string;
  message_type: 'TEXT' | 'AUDIO_CALL' | 'VIDEO_CALL';
  content: string;
  call_url: string | null;
  call_phone: string | null;
  is_read: number;
  created_at: string;
}

interface PatientThread {
  patient_id: string;
  full_name: string;
  email: string;
  phone: string | null;
  patient_code: string | null;
  last_message: string | null;
  last_message_at: string | null;
  unread_count: number;
}

const DOCTOR_QUICK_REPLIES = [
  'Namaste! I am online now — tap Live Video Call or Live Audio Call above to connect.',
  'Please upload your recent lab reports in Medical Reports before our call.',
  'Your authorised PDF prescription is now ready in My Prescriptions.',
];

export default function ClinicLiveComm({
  mode,
  currentUserName,
  sessionToken,
  initialCallMode,
  externalSession,
  onClearExternalSession,
  onActiveCallChange,
}: {
  mode: 'PATIENT' | 'CLINIC';
  currentUserName: string;
  sessionToken?: string;
  initialCallMode?: 'AUDIO' | 'VIDEO' | null;
  externalSession?: ActiveRtcSession | null;
  onClearExternalSession?: () => void;
  onActiveCallChange?: (callId: string | null) => void;
}) {
  if (typeof window !== 'undefined' && sessionToken) {
    saveClientSession(sessionToken);
  }
  const [threads, setThreads] = useState<PatientThread[]>([]);
  const [selectedPatientId, setSelectedPatientId] = useState<string>('');
  const [threadSearch, setThreadSearch] = useState('');
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [text, setText] = useState('');
  const [sending, setSending] = useState(false);
  const [callBusy, setCallBusy] = useState(false);
  const [callError, setCallError] = useState('');
  const [copied, setCopied] = useState(false);
  const [phoneHint, setPhoneHint] = useState(false);

  const [clinicInfo, setClinicInfo] = useState({
    display: '+91 8123108149',
    tel: '+918123108149',
    whatsapp: '918123108149',
    doctorName: 'Dr. Aparna Mishra',
    doctorPhoto: '/images/dr-aparna-mishra.jpeg',
    timings: 'Monday to Saturday · 3:00 PM – 8:00 PM IST',
  });

  // Real Native WebRTC P2P Call Session
  const [activeRtc, setActiveRtc] = useState<ActiveRtcSession | null>(externalSession || null);
  const autoStartedRef = useRef<string | null>(null);
  const bottomRef = useRef<HTMLDivElement | null>(null);
  const prevCountRef = useRef(0);

  // Sync incoming accepted call from parent banner
  useEffect(() => {
    if (externalSession) {
      setActiveRtc(externalSession);
      onActiveCallChange?.(externalSession.callId);
    }
  }, [externalSession, onActiveCallChange]);

  const fetchChat = useCallback(
    async (pid?: string, markRead = true) => {
      try {
        const params = new URLSearchParams();
        if (markRead) params.set('markRead', '1');
        const targetPid = pid ?? selectedPatientId;
        if (mode === 'CLINIC' && targetPid) {
          params.set('patientId', targetPid);
        }
        const res = await authFetch(`/api/messages?${params.toString()}`, undefined, sessionToken);
        if (!res.ok) return;
        const data = await res.json();
        if (data.clinicNumber) setClinicInfo(data.clinicNumber);
        if (mode === 'CLINIC') {
          setThreads(data.threads || []);
          if (!selectedPatientId && data.selectedPatientId) {
            setSelectedPatientId(data.selectedPatientId);
          }
        }
        setMessages(data.messages || []);
      } catch {
        // silent poll retry
      }
    },
    [mode, selectedPatientId, sessionToken]
  );

  useEffect(() => {
    fetchChat(selectedPatientId, true);
    const interval = setInterval(() => {
      fetchChat(selectedPatientId, true);
    }, 3000);
    return () => clearInterval(interval);
  }, [fetchChat, selectedPatientId]);

  useEffect(() => {
    if (messages.length !== prevCountRef.current) {
      prevCountRef.current = messages.length;
      bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages.length]);

  // Start a REAL Native Peer-to-Peer WebRTC Audio or Video Call
  const startLiveCall = useCallback(
    async (callType: 'AUDIO' | 'VIDEO', openNewTab = false) => {
      if (callBusy) return;
      if (mode === 'CLINIC' && !selectedPatientId) {
        setCallError('Please select a patient from the left list first.');
        return;
      }

      setCallBusy(true);
      setCallError('');
      try {
        const res = await authFetch(
          '/api/rtc',
          {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              action: 'START',
              callType,
              patientId: mode === 'CLINIC' ? selectedPatientId : undefined,
            }),
          },
          sessionToken
        );
        const data = await res.json();
        if (!res.ok || !data.callId) {
          setCallError(data.error || 'Could not start live call. Please try again.');
          return;
        }

        const sess: ActiveRtcSession = {
          callId: data.callId,
          callType,
          role: 'CALLER',
          peerName:
            mode === 'PATIENT' ? clinicInfo.doctorName : data.patientName || 'Patient',
          peerPhone: mode === 'PATIENT' ? '8123108149' : data.patientPhone || null,
          callerKey: data.callerKey || null,
          peerKey: data.peerKey || null,
          roomKey: data.callerKey || null,
        };

        if (openNewTab) {
          const tabPath = data.callerKey
            ? `/call/${data.callId}?rk=${encodeURIComponent(data.callerKey)}`
            : `/call/${data.callId}`;
          window.open(buildAuthedUrl(tabPath, sessionToken), '_blank', 'noopener');
        } else {
          setActiveRtc(sess);
          onActiveCallChange?.(data.callId);
        }
        await fetchChat(selectedPatientId, true);
      } catch {
        setCallError('Network error while starting call. Please tap Start Call again.');
      } finally {
        setCallBusy(false);
      }
    },
    [callBusy, mode, selectedPatientId, clinicInfo.doctorName, fetchChat, onActiveCallChange, sessionToken]
  );

  // Auto-launch Audio or Video call immediately when user clicked a quick call card on Dashboard
  useEffect(() => {
    if (
      initialCallMode &&
      autoStartedRef.current !== initialCallMode &&
      !activeRtc &&
      (mode === 'PATIENT' || Boolean(selectedPatientId))
    ) {
      autoStartedRef.current = initialCallMode;
      startLiveCall(initialCallMode, false);
    }
  }, [initialCallMode, activeRtc, mode, selectedPatientId, startLiveCall]);

  async function joinCallFromMessage(m: ChatMessage) {
    const type: 'AUDIO' | 'VIDEO' = m.message_type === 'AUDIO_CALL' ? 'AUDIO' : 'VIDEO';
    const match = (m.call_url || '').match(/\/call\/([a-zA-Z0-9_]+)/);
    if (match && match[1]) {
      // Check if that call is still RINGING/CONNECTED; otherwise start a fresh live call!
      try {
        const check = await authFetch(
          `/api/rtc?callId=${encodeURIComponent(match[1])}`,
          undefined,
          sessionToken
        );
        if (check.ok) {
          const d = await check.json();
          if (d.call && (d.call.status === 'RINGING' || d.call.status === 'CONNECTED')) {
            const sess: ActiveRtcSession = {
              callId: d.call.id,
              callType: d.call.callType,
              role: d.mySide,
              peerName:
                mode === 'PATIENT' ? clinicInfo.doctorName : d.call.patientName || 'Patient',
              callerKey: d.call.callerKey || null,
              peerKey: d.call.peerKey || null,
            };
            setActiveRtc(sess);
            onActiveCallChange?.(sess.callId);
            return;
          }
        }
      } catch {
        // fall through to starting a new call
      }
    }
    startLiveCall(type, false);
  }

  async function sendChatMessage(e?: React.FormEvent, customText?: string) {
    e?.preventDefault();
    const content = (customText ?? text).trim();
    if (!content || sending) return;
    setSending(true);
    try {
      const res = await authFetch(
        '/api/messages',
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            patientId: mode === 'CLINIC' ? selectedPatientId : undefined,
            messageType: 'TEXT',
            content,
          }),
        },
        sessionToken
      );
      if (res.ok) {
        if (!customText) setText('');
        await fetchChat(selectedPatientId, true);
      }
    } finally {
      setSending(false);
    }
  }

  function copyNumber() {
    navigator.clipboard?.writeText('+91 8123108149').catch(() => {});
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  }

  function handleSimDialClick() {
    copyNumber();
    setPhoneHint(true);
  }

  const activeThread = threads.find((t) => t.patient_id === selectedPatientId) || null;
  const cleanPatientPhone = (activeThread?.phone || '').replace(/\D/g, '');
  const patientWa =
    cleanPatientPhone.length === 10 ? `91${cleanPatientPhone}` : cleanPatientPhone;

  const waCallHref = `https://wa.me/${clinicInfo.whatsapp}?text=${encodeURIComponent(
    `Namaste Dr. Aparna Mishra, I am ${currentUserName}. Ready to connect for my Online Video / Audio Consultation on +91 8123108149.`
  )}`;
  const waChatHref = `https://wa.me/${clinicInfo.whatsapp}?text=${encodeURIComponent(
    `Namaste Dr. Aparna Mishra, I am ${currentUserName} messaging from your Digital Clinic Portal.`
  )}`;

  const filteredThreads = threads.filter((t) => {
    const q = threadSearch.trim().toLowerCase();
    if (!q) return true;
    return (
      t.full_name.toLowerCase().includes(q) ||
      (t.phone || '').includes(q) ||
      t.email.toLowerCase().includes(q)
    );
  });

  return (
    <div className="space-y-5">
      {/* OFFICIAL AUDIO / VIDEO / WHATSAPP CONTROL BAR (PATIENT VIEW) */}
      {mode === 'PATIENT' && (
        <div className="card-surface p-5 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center gap-3.5">
              <img
                src={clinicInfo.doctorPhoto}
                alt={clinicInfo.doctorName}
                className="h-12 w-12 rounded-2xl object-cover object-top border border-slate-200"
              />
              <div>
                <h2 className="font-heading text-base font-bold text-navy">
                  {clinicInfo.doctorName}{' '}
                  <span className="text-xs font-semibold text-teal">· BHMS</span>
                </h2>
                <div className="flex flex-wrap items-center gap-2 text-xs text-slate-600 mt-0.5">
                  <span className="font-semibold text-navy tabular">
                    Official Call / Video / Chat No: {clinicInfo.display}
                  </span>
                  <button
                    type="button"
                    onClick={copyNumber}
                    className="inline-flex items-center gap-1 rounded-md bg-aqua px-2 py-0.5 text-[11px] font-semibold text-teal hover:bg-teal hover:text-white transition-colors"
                  >
                    {copied ? <Check className="h-3 w-3" /> : <Copy className="h-3 w-3" />}
                    {copied ? 'Copied!' : 'Copy'}
                  </button>
                </div>
                <p className="text-[11px] text-slate-500 mt-0.5">{clinicInfo.timings}</p>
              </div>
            </div>

            <span className="inline-flex items-center gap-1.5 rounded-full bg-aqua px-3 py-1 text-[11px] font-semibold text-navy">
              <ShieldCheck className="h-3.5 w-3.5 text-teal" /> Live WebRTC · Never Recorded
            </span>
          </div>

          {/* Primary Audio Call, Video Call & WhatsApp Buttons */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5 pt-2 border-t border-slate-100">
            <button
              type="button"
              disabled={callBusy}
              onClick={() => startLiveCall('VIDEO', false)}
              className="flex items-center justify-center gap-2 rounded-xl bg-teal px-4 py-3 text-xs font-bold text-white hover:bg-teal-600 transition-colors shadow-sm disabled:opacity-60"
            >
              <Video className="h-4 w-4 shrink-0" />
              {callBusy ? 'Starting…' : 'Start Live Video Call'}
            </button>

            <button
              type="button"
              disabled={callBusy}
              onClick={() => startLiveCall('AUDIO', false)}
              className="flex items-center justify-center gap-2 rounded-xl bg-navy px-4 py-3 text-xs font-bold text-white hover:bg-navy-600 transition-colors shadow-sm disabled:opacity-60"
            >
              <PhoneCall className="h-4 w-4 shrink-0" />
              {callBusy ? 'Starting…' : 'Start Live Audio Call'}
            </button>

            <a
              href={waCallHref}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-2 rounded-xl border border-emerald-200 bg-emerald-50 px-3.5 py-3 text-xs font-semibold text-emerald-800 hover:bg-emerald-100 transition-colors"
            >
              <MessageCircle className="h-4 w-4 shrink-0" />
              WhatsApp Video / Audio
            </a>

            <a
              href="tel:+918123108149"
              onClick={handleSimDialClick}
              className="flex items-center justify-center gap-2 rounded-xl border border-slate-200 bg-white px-3.5 py-3 text-xs font-semibold text-navy hover:border-teal hover:bg-aqua transition-colors tabular"
            >
              <Phone className="h-4 w-4 text-teal shrink-0" />
              Phone: +91 8123108149
            </a>
          </div>

          {/* Helpful feedback when tapping SIM Phone dialer on desktop / embedded preview */}
          {phoneHint && (
            <div className="rounded-xl bg-aqua border border-teal/30 px-4 py-2.5 flex flex-wrap items-center justify-between gap-2 text-xs text-navy">
              <span>
                <strong>+91 8123108149</strong> copied! On a mobile phone this opens your phone dialer; on a computer or preview tab, click{' '}
                <strong>Start Live Audio Call</strong> to talk right inside your browser (or open in a full tab).
              </span>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setPhoneHint(false);
                    startLiveCall('AUDIO', false);
                  }}
                  className="rounded-lg bg-teal px-3 py-1 text-[11px] font-bold text-white hover:bg-teal-600"
                >
                  Start Browser Audio Call
                </button>
                <button
                  type="button"
                  onClick={() => startLiveCall('VIDEO', true)}
                  className="inline-flex items-center gap-1 rounded-lg bg-navy px-3 py-1 text-[11px] font-semibold text-white hover:bg-navy-600"
                >
                  Full-Tab Call <ExternalLink className="h-3 w-3" />
                </button>
              </div>
            </div>
          )}

          {callError && (
            <p className="rounded-xl bg-rose-50 border border-rose-200 px-3.5 py-2 text-xs font-medium text-rose-700">
              {callError}
            </p>
          )}
        </div>
      )}

      {/* REAL NATIVE WEBRTC PEER-TO-PEER AUDIO / VIDEO CALL STAGE */}
      {activeRtc && (
        <NativeWebRTCCall
          session={activeRtc}
          mode={mode}
          currentUserName={currentUserName}
          sessionToken={sessionToken}
          onClose={() => {
            setActiveRtc(null);
            onActiveCallChange?.(null);
            onClearExternalSession?.();
            fetchChat(selectedPatientId, true);
          }}
        />
      )}

      {/* REAL-TIME TWO-WAY DOCTOR ↔ PATIENT LIVE CHAT */}
      <div
        className={`card-surface overflow-hidden grid grid-cols-1 ${
          mode === 'CLINIC' ? 'lg:grid-cols-12' : ''
        }`}
      >
        {/* Clinic Left Column: Patient Directory */}
        {mode === 'CLINIC' && (
          <div className="lg:col-span-4 border-b lg:border-b-0 lg:border-r border-slate-200 flex flex-col max-h-[540px]">
            <div className="p-3.5 border-b border-slate-100 space-y-2">
              <p className="text-xs font-bold uppercase tracking-wider text-navy">
                Patient Conversations ({threads.length})
              </p>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-slate-400" />
                <input
                  type="search"
                  value={threadSearch}
                  onChange={(e) => setThreadSearch(e.target.value)}
                  placeholder="Search patient or mobile..."
                  className="input-field pl-8 py-1.5 text-xs"
                />
              </div>
            </div>
            <div className="flex-1 overflow-y-auto divide-y divide-slate-100">
              {filteredThreads.map((t) => {
                const selected = t.patient_id === selectedPatientId;
                return (
                  <button
                    key={t.patient_id}
                    type="button"
                    onClick={() => setSelectedPatientId(t.patient_id)}
                    className={`w-full text-left px-4 py-3 transition-colors ${
                      selected ? 'bg-aqua' : 'hover:bg-surface-muted'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-2">
                      <span className="font-heading text-xs font-bold text-navy truncate">
                        {t.full_name}
                      </span>
                      {t.unread_count > 0 && (
                        <span className="rounded-full bg-teal px-2 py-0.5 text-[10px] font-bold text-white tabular">
                          {t.unread_count}
                        </span>
                      )}
                    </div>
                    <p className="text-[11px] text-slate-500 tabular truncate">
                      {t.phone ? `+91 ${t.phone}` : t.email}
                    </p>
                    {t.last_message && (
                      <p className="text-[11px] text-slate-600 truncate mt-1">{t.last_message}</p>
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* Chat Thread Pane */}
        <div className={`${mode === 'CLINIC' ? 'lg:col-span-8' : ''} flex flex-col h-[500px]`}>
          <div className="px-4 sm:px-5 py-3 bg-surface-muted border-b border-slate-200 flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2.5 min-w-0">
              <MessageSquare className="h-4 w-4 text-teal shrink-0" />
              <div className="min-w-0">
                <p className="font-heading text-sm font-bold text-navy truncate">
                  {mode === 'PATIENT'
                    ? `Live Chat with ${clinicInfo.doctorName}`
                    : activeThread
                    ? `${activeThread.full_name} (${activeThread.patient_code || 'Patient'})`
                    : 'Select a patient'}
                </p>
                <p className="text-[11px] text-slate-500 truncate tabular">
                  {mode === 'PATIENT'
                    ? `Portal Messaging & WhatsApp (${clinicInfo.display})`
                    : activeThread?.phone
                    ? `Patient Mobile: +91 ${activeThread.phone} · Clinic Line: +91 8123108149`
                    : activeThread?.email || ''}
                </p>
              </div>
            </div>

            {mode === 'PATIENT' ? (
              <a
                href={waChatHref}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 rounded-xl border border-emerald-200 bg-white px-3 py-1.5 text-xs font-semibold text-emerald-700 hover:bg-emerald-50"
              >
                <MessageCircle className="h-3.5 w-3.5" /> WhatsApp Chat
              </a>
            ) : (
              activeThread && (
                <div className="flex flex-wrap items-center gap-1.5">
                  <button
                    type="button"
                    disabled={callBusy}
                    onClick={() => startLiveCall('VIDEO', false)}
                    className="inline-flex items-center gap-1 rounded-lg bg-teal px-3 py-1.5 text-[11px] font-bold text-white hover:bg-teal-600"
                  >
                    <Video className="h-3.5 w-3.5" /> Video Call
                  </button>
                  <button
                    type="button"
                    disabled={callBusy}
                    onClick={() => startLiveCall('AUDIO', false)}
                    className="inline-flex items-center gap-1 rounded-lg bg-navy px-3 py-1.5 text-[11px] font-bold text-white hover:bg-navy-600"
                  >
                    <PhoneCall className="h-3.5 w-3.5" /> Audio Call
                  </button>
                  {cleanPatientPhone && (
                    <>
                      <a
                        href={`tel:+${patientWa}`}
                        className="inline-flex items-center gap-1 rounded-lg border border-slate-200 bg-white px-2.5 py-1.5 text-[11px] font-semibold text-navy hover:bg-aqua"
                      >
                        <Phone className="h-3 w-3 text-teal" /> Dial
                      </a>
                      <a
                        href={`https://wa.me/${patientWa}?text=${encodeURIComponent(
                          `Namaste ${activeThread.full_name}, this is Dr. Aparna Mishra’s Clinic (+91 8123108149) regarding your online consultation.`
                        )}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1 rounded-lg border border-emerald-200 bg-emerald-50 px-2.5 py-1.5 text-[11px] font-semibold text-emerald-800 hover:bg-emerald-100"
                      >
                        WhatsApp
                      </a>
                    </>
                  )}
                </div>
              )
            )}
          </div>

          {/* Messages Stream */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-white">
            {messages.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center text-xs text-slate-400 space-y-1">
                <MessageSquare className="h-7 w-7 text-slate-200" />
                <p>No messages yet. Say Namaste or tap Start Live Video / Audio Call above.</p>
              </div>
            ) : (
              messages.map((m) => {
                const isMine =
                  mode === 'PATIENT'
                    ? m.sender_role === 'PATIENT'
                    : m.sender_role !== 'PATIENT';
                const isCall = m.message_type === 'AUDIO_CALL' || m.message_type === 'VIDEO_CALL';

                return (
                  <div
                    key={m.id}
                    className={`flex ${isMine ? 'justify-end' : 'justify-start'}`}
                  >
                    <div
                      className={`max-w-[84%] rounded-2xl px-4 py-2.5 text-xs leading-relaxed ${
                        isCall
                          ? 'bg-aqua border border-teal/40 text-navy'
                          : isMine
                          ? 'bg-navy text-white rounded-br-sm'
                          : 'bg-surface-muted text-slate-800 border border-slate-200/80 rounded-bl-sm'
                      }`}
                    >
                      <p
                        className={`text-[10px] font-semibold mb-0.5 ${
                          isCall ? 'text-teal' : isMine ? 'text-teal-200' : 'text-teal'
                        }`}
                      >
                        {m.sender_name}
                      </p>
                      <p className="whitespace-pre-line">{m.content}</p>

                      {isCall && (
                        <div className="mt-2.5 flex flex-wrap gap-2">
                          <button
                            type="button"
                            onClick={() => joinCallFromMessage(m)}
                            className="inline-flex items-center gap-1.5 rounded-lg bg-teal px-3 py-1.5 text-[11px] font-bold text-white hover:bg-teal-600"
                          >
                            {m.message_type === 'VIDEO_CALL' ? (
                              <Video className="h-3.5 w-3.5" />
                            ) : (
                              <PhoneCall className="h-3.5 w-3.5" />
                            )}
                            Answer / Join {m.message_type === 'VIDEO_CALL' ? 'Video' : 'Audio'} Call
                          </button>
                          {m.call_url && m.call_url.startsWith('/call/') && (
                            <button
                              type="button"
                              onClick={() =>
                                window.open(buildAuthedUrl(m.call_url!), '_blank', 'noopener')
                              }
                              className="inline-flex items-center gap-1 rounded-lg bg-white border border-slate-200 px-2.5 py-1.5 text-[11px] font-semibold text-navy hover:border-teal"
                            >
                              Full Tab <ExternalLink className="h-3 w-3 text-teal" />
                            </button>
                          )}
                        </div>
                      )}

                      <div
                        className={`mt-1 flex items-center justify-end gap-1 text-[10px] ${
                          isMine && !isCall ? 'text-slate-300' : 'text-slate-400'
                        }`}
                      >
                        <span className="tabular">{m.created_at.slice(11, 16)}</span>
                        {isMine &&
                          (m.is_read ? (
                            <CheckCheck className="h-3 w-3 text-teal-300" />
                          ) : (
                            <Check className="h-3 w-3" />
                          ))}
                      </div>
                    </div>
                  </div>
                );
              })
            )}
            <div ref={bottomRef} />
          </div>

          {/* Doctor Quick Reply Chips */}
          {mode === 'CLINIC' && activeThread && (
            <div className="px-3 py-1.5 bg-surface-muted border-t border-slate-100 flex gap-1.5 overflow-x-auto">
              {DOCTOR_QUICK_REPLIES.map((qr) => (
                <button
                  key={qr}
                  type="button"
                  onClick={() => sendChatMessage(undefined, qr)}
                  className="shrink-0 rounded-full bg-white border border-slate-200 px-2.5 py-1 text-[10.5px] font-medium text-navy hover:border-teal"
                >
                  {qr.slice(0, 48)}…
                </button>
              ))}
            </div>
          )}

          {/* Message Composer */}
          <form
            onSubmit={sendChatMessage}
            className="p-3 bg-surface-muted border-t border-slate-200 flex items-center gap-2"
          >
            <input
              type="text"
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder={
                mode === 'PATIENT'
                  ? 'Type a message to Dr. Aparna Mishra...'
                  : 'Reply to patient...'
              }
              className="input-field py-2.5 text-xs flex-1"
            />
            <button
              type="submit"
              disabled={sending || !text.trim()}
              className="btn-primary py-2.5 px-4 text-xs shrink-0"
            >
              <Send className="h-3.5 w-3.5" /> Send
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
