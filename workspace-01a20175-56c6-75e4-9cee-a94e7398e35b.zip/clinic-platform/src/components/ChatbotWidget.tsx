'use client';

import React, { useState, useRef, useEffect } from 'react';
import Link from 'next/link';
import {
  AlertTriangle,
  MessageCircle,
  Send,
  ShieldAlert,
  X,
  Headphones,
  ExternalLink,
} from 'lucide-react';

interface ChatMsg {
  id: string;
  sender: 'bot' | 'user';
  text: string;
  safetyTriggered?: 'EMERGENCY' | 'MEDICAL_ADVICE_BLOCKED' | null;
  actions?: Array<{ label: string; href: string }>;
}

const QUICK_PROMPTS = [
  'Consultation timings',
  'Fees & payment methods',
  'How to book online?',
  'Areas of consultation',
  'Download prescription',
  'Speak to clinic team',
];

export default function ChatbotWidget({
  welcomeMessage,
  botName = 'Clinic Care Assistant',
  whatsappNumber = '918123108149',
}: {
  welcomeMessage?: string;
  botName?: string;
  whatsappNumber?: string;
}) {
  const [open, setOpen] = useState(false);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [messages, setMessages] = useState<ChatMsg[]>([
    {
      id: 'welcome',
      sender: 'bot',
      text:
        welcomeMessage ||
        'Namaste! I am Dr. Aparna Mishra’s Clinic Assistant. Ask me about consultation timings (Mon–Sat, 3:00 PM – 8:00 PM), services, fees, booking, payments, or prescriptions. I do not provide medical diagnosis or prescriptions.',
      actions: [
        { label: 'Book Appointment', href: '/book' },
        { label: 'View Services', href: '/services' },
      ],
    },
  ]);

  const endRef = useRef<HTMLDivElement | null>(null);
  useEffect(() => {
    if (open) {
      endRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, open]);

  async function sendMessage(text: string) {
    const trimmed = text.trim();
    if (!trimmed || loading) return;
    setInput('');
    const userMsg: ChatMsg = { id: `u_${Date.now()}`, sender: 'user', text: trimmed };
    setMessages((prev) => [...prev, userMsg]);
    setLoading(true);

    try {
      const res = await fetch('/api/chatbot', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: trimmed }),
      });
      const data = await res.json();
      setMessages((prev) => [
        ...prev,
        {
          id: `b_${Date.now()}`,
          sender: 'bot',
          text: data.reply || data.error || 'Please reach our clinic desk at +91 8123108149.',
          safetyTriggered: data.safetyTriggered || null,
          actions: data.suggestedActions || [],
        },
      ]);
    } catch {
      setMessages((prev) => [
        ...prev,
        {
          id: `e_${Date.now()}`,
          sender: 'bot',
          text: 'Connection issue. Please call or WhatsApp our clinic desk at +91 8123108149.',
        },
      ]);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="fixed bottom-5 right-5 z-50">
      {open ? (
        <div
          role="dialog"
          aria-label={botName}
          className="w-[calc(100vw-2rem)] sm:w-[390px] max-h-[82vh] flex flex-col rounded-2xl border border-slate-200 bg-white shadow-elevated overflow-hidden"
        >
          {/* Header */}
          <div className="bg-navy px-4 py-3.5 text-white flex items-center justify-between gap-2">
            <div className="flex items-center gap-2.5 min-w-0">
              <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-teal text-white">
                <MessageCircle className="h-4 w-4" />
              </span>
              <div className="min-w-0">
                <p className="font-heading text-sm font-semibold truncate">{botName}</p>
                <p className="text-[11px] text-slate-200 truncate">
                  Clinic Guide · Non-diagnostic Support
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => setOpen(false)}
              className="rounded-lg p-1.5 text-slate-200 hover:bg-white/10 hover:text-white"
              aria-label="Close assistant"
            >
              <X className="h-4 w-4" />
            </button>
          </div>

          {/* Safety Banner */}
          <div className="bg-aqua px-3.5 py-2 border-b border-slate-200/70 flex items-center justify-between gap-2 text-[11px] text-navy">
            <span>No diagnosis or prescriptions. Emergency? Call 112 / 108.</span>
            <a
              href={`https://wa.me/${whatsappNumber}`}
              target="_blank"
              rel="noopener noreferrer"
              className="shrink-0 inline-flex items-center gap-1 font-semibold text-teal hover:underline"
            >
              <Headphones className="h-3 w-3" /> Human
            </a>
          </div>

          {/* Direct Live Audio Call, Live Video Call & Live Doctor Chat Bar */}
          <div className="bg-white px-3 py-1.5 border-b border-slate-100 flex items-center justify-between gap-1.5 text-[10.5px]">
            <Link
              href="/portal?tab=video&start=AUDIO"
              onClick={() => setOpen(false)}
              className="flex-1 text-center rounded-lg border border-slate-200 py-1 font-semibold text-navy hover:border-teal hover:bg-aqua"
            >
              Audio Call
            </Link>
            <Link
              href="/portal?tab=video&start=VIDEO"
              onClick={() => setOpen(false)}
              className="flex-1 text-center rounded-lg bg-teal py-1 font-semibold text-white hover:bg-teal-600"
            >
              Video Call
            </Link>
            <Link
              href="/portal?tab=chat"
              onClick={() => setOpen(false)}
              className="flex-1 text-center rounded-lg border border-emerald-200 bg-emerald-50 py-1 font-semibold text-emerald-800 hover:bg-emerald-100"
            >
              Live Chat
            </Link>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-3.5 space-y-3 bg-surface-muted max-h-[340px]">
            {messages.map((m) => (
              <div
                key={m.id}
                className={`flex ${m.sender === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`max-w-[88%] rounded-2xl px-3.5 py-2.5 text-[13px] leading-relaxed whitespace-pre-line ${
                    m.sender === 'user'
                      ? 'bg-navy text-white rounded-br-sm'
                      : m.safetyTriggered === 'EMERGENCY'
                      ? 'bg-rose-50 text-rose-900 border border-rose-300 rounded-bl-sm'
                      : m.safetyTriggered === 'MEDICAL_ADVICE_BLOCKED'
                      ? 'bg-amber-50 text-amber-950 border border-amber-300 rounded-bl-sm'
                      : 'bg-white text-slate-700 border border-slate-200/80 rounded-bl-sm shadow-sm'
                  }`}
                >
                  {m.safetyTriggered === 'EMERGENCY' && (
                    <div className="flex items-center gap-1.5 font-bold text-rose-700 text-xs mb-1">
                      <AlertTriangle className="h-4 w-4" /> Emergency Medical Guidance
                    </div>
                  )}
                  {m.safetyTriggered === 'MEDICAL_ADVICE_BLOCKED' && (
                    <div className="flex items-center gap-1.5 font-bold text-amber-800 text-xs mb-1">
                      <ShieldAlert className="h-4 w-4" /> Physician Consultation Required
                    </div>
                  )}
                  <p>{m.text}</p>
                  {m.actions && m.actions.length > 0 && (
                    <div className="mt-2.5 flex flex-wrap gap-1.5">
                      {m.actions.map((act) =>
                        act.href.startsWith('http') || act.href.startsWith('tel:') ? (
                          <a
                            key={act.label}
                            href={act.href}
                            target={act.href.startsWith('http') ? '_blank' : undefined}
                            rel="noopener noreferrer"
                            className="inline-flex items-center gap-1 rounded-lg bg-teal px-2.5 py-1 text-[11px] font-semibold text-white hover:bg-teal-600"
                          >
                            {act.label} <ExternalLink className="h-2.5 w-2.5" />
                          </a>
                        ) : (
                          <Link
                            key={act.label}
                            href={act.href}
                            onClick={() => setOpen(false)}
                            className="inline-flex items-center rounded-lg bg-aqua px-2.5 py-1 text-[11px] font-semibold text-navy hover:bg-teal hover:text-white transition-colors"
                          >
                            {act.label}
                          </Link>
                        )
                      )}
                    </div>
                  )}
                </div>
              </div>
            ))}
            {loading && (
              <div className="text-xs text-slate-400 px-2">Assistant is replying…</div>
            )}
            <div ref={endRef} />
          </div>

          {/* Quick Chips */}
          <div className="px-3 py-2 bg-white border-t border-slate-100 flex gap-1.5 overflow-x-auto">
            {QUICK_PROMPTS.map((q) => (
              <button
                key={q}
                type="button"
                onClick={() => sendMessage(q)}
                className="shrink-0 rounded-full border border-slate-200 bg-surface-muted px-2.5 py-1 text-[11px] font-medium text-navy hover:border-teal hover:bg-aqua transition-colors"
              >
                {q}
              </button>
            ))}
          </div>

          {/* Input */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              sendMessage(input);
            }}
            className="p-2.5 bg-white border-t border-slate-200 flex items-center gap-2"
          >
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask about timings, fees, booking..."
              className="flex-1 rounded-xl border border-slate-200 px-3 py-2 text-xs text-slate-800 focus:border-teal focus:outline-none"
            />
            <button
              type="submit"
              disabled={loading || !input.trim()}
              className="flex h-9 w-9 items-center justify-center rounded-xl bg-teal text-white hover:bg-teal-600 disabled:opacity-50"
              aria-label="Send message"
            >
              <Send className="h-4 w-4" />
            </button>
          </form>
        </div>
      ) : (
        <button
          type="button"
          onClick={() => setOpen(true)}
          className="group flex items-center gap-2.5 rounded-full bg-navy pl-4 pr-5 py-3 text-white shadow-elevated hover:bg-navy-600 transition-colors focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-teal"
          aria-label="Open Clinic Care Assistant"
        >
          <span className="flex h-7 w-7 items-center justify-center rounded-full bg-teal text-white">
            <MessageCircle className="h-4 w-4" />
          </span>
          <span className="text-xs font-semibold tracking-wide">Clinic Assistant</span>
        </button>
      )}
    </div>
  );
}
