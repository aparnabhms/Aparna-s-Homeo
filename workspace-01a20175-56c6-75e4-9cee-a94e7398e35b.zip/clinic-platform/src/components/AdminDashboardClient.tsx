'use client';

import React, { useState, useEffect, useCallback } from 'react';
import Link from 'next/link';
import {
  BarChart3,
  Bot,
  Calendar,
  CalendarDays,
  Check,
  ClipboardList,
  Clock,
  CreditCard,
  Download,
  ExternalLink,
  FileEdit,
  FolderHeart,
  Home,
  KeyRound,
  LayoutDashboard,
  LogOut,
  Menu,
  MessageCircle,
  MessageSquare,
  Phone,
  Plus,
  Search,
  Send,
  Shield,
  Trash2,
  UserCog,
  Users,
  Video,
  X,
} from 'lucide-react';
import { BrandMark, StatusBadge } from './MedicalIcons';
import ClinicLiveComm from './ClinicLiveComm';
import IncomingCallBanner from './IncomingCallBanner';
import { ActiveRtcSession } from './NativeWebRTCCall';
import { authFetch, clearClientSession, saveClientSession } from '@/lib/clientSession';

type AdminTab =
  | 'overview'
  | 'chat'
  | 'appointments'
  | 'patients'
  | 'consultations'
  | 'prescriptions'
  | 'reports'
  | 'payments'
  | 'calendar'
  | 'availability'
  | 'whatsapp'
  | 'chatbot'
  | 'cms'
  | 'analytics'
  | 'staff'
  | 'roles'
  | 'security';

const NAV_ITEMS: Array<{
  id: AdminTab;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  doctorOnly?: boolean;
}> = [
  { id: 'overview', label: 'Dashboard Overview', icon: LayoutDashboard },
  { id: 'chat', label: 'Live Chat, Audio & Video', icon: MessageCircle },
  { id: 'appointments', label: 'Appointments', icon: Calendar },
  { id: 'patients', label: 'Patients', icon: Users },
  { id: 'consultations', label: 'Consultations & Notes', icon: Video },
  { id: 'prescriptions', label: 'Prescriptions (Rx)', icon: ClipboardList, doctorOnly: true },
  { id: 'reports', label: 'Medical Reports', icon: FolderHeart, doctorOnly: true },
  { id: 'payments', label: 'Payments & Billing', icon: CreditCard },
  { id: 'calendar', label: 'Appointment Calendar', icon: CalendarDays },
  { id: 'availability', label: 'Doctor Availability', icon: Clock },
  { id: 'whatsapp', label: 'WhatsApp Notifications', icon: MessageSquare },
  { id: 'chatbot', label: 'AI Chatbot & Support', icon: Bot },
  { id: 'cms', label: 'Website CMS', icon: FileEdit, doctorOnly: true },
  { id: 'analytics', label: 'Analytics & Reports', icon: BarChart3 },
  { id: 'staff', label: 'Staff Management', icon: UserCog, doctorOnly: true },
  { id: 'roles', label: 'Roles & Permissions', icon: KeyRound },
  { id: 'security', label: 'Security & Settings', icon: Shield, doctorOnly: true },
];

function fmt12(hhmm?: string) {
  if (!hhmm) return '';
  const [hS, mS] = hhmm.split(':');
  const h = Number(hS);
  const suf = h >= 12 ? 'PM' : 'AM';
  const h12 = h % 12 === 0 ? 12 : h % 12;
  return `${h12}:${mS} ${suf}`;
}

const RBAC_MATRIX = [
  { capability: 'Approve, reschedule & cancel bookings', doctor: true, admin: true, staff: true, patient: 'Own only' },
  { capability: 'Issue & digitally authorise prescriptions (Rx)', doctor: true, admin: false, staff: false, patient: 'Read own PDF' },
  { capability: 'Clinical consultation notes & case totality', doctor: true, admin: false, staff: false, patient: false },
  { capability: 'Private AES-256 medical report access & review', doctor: true, admin: true, staff: false, patient: 'Own only' },
  { capability: 'Verify PhonePe/UPI QR UTR & view receipts', doctor: true, admin: true, staff: true, patient: 'Own only' },
  { capability: 'Process secure payment refunds', doctor: true, admin: true, staff: false, patient: false },
  { capability: 'Dispatch official WhatsApp template reminders', doctor: true, admin: true, staff: true, patient: false },
  { capability: 'Doctor availability, fees & Website CMS', doctor: true, admin: true, staff: false, patient: false },
  { capability: 'Staff accounts, DPDP consents, Audit logs & Backups', doctor: true, admin: true, staff: false, patient: 'Own consent' },
];

/* eslint-disable @typescript-eslint/no-explicit-any */
export default function AdminDashboardClient({
  initialTab,
  sessionToken,
  sessionUser,
}: {
  initialTab: string;
  sessionToken: string;
  sessionUser: { id: string; fullName: string; email: string; role: string };
}) {
  // Synchronously persist SSR session token BEFORE any child component or effect runs
  if (typeof window !== 'undefined' && sessionToken) {
    saveClientSession(sessionToken);
  }
  const apiFetch = useCallback(
    (path: string, init?: RequestInit) => authFetch(path, init, sessionToken),
    [sessionToken]
  );

  const isDoctor = sessionUser.role === 'DOCTOR';
  const isDoctorOrAdmin = sessionUser.role === 'DOCTOR' || sessionUser.role === 'ADMIN';

  const visibleNav = NAV_ITEMS.filter((n) => !n.doctorOnly || isDoctorOrAdmin);
  const startTab = visibleNav.some((n) => n.id === initialTab)
    ? (initialTab as AdminTab)
    : 'overview';

  const [tab, setTab] = useState<AdminTab>(startTab);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [loading, setLoading] = useState(true);
  const [toast, setToast] = useState('');

  // Server data
  const [adminData, setAdminData] = useState<any>(null);
  const [appointments, setAppointments] = useState<any[]>([]);
  const [consultations, setConsultations] = useState<any[]>([]);
  const [prescriptions, setPrescriptions] = useState<any[]>([]);
  const [reports, setReports] = useState<any[]>([]);
  const [payments, setPayments] = useState<any[]>([]);

  // Filters
  const [apptFilter, setApptFilter] = useState('ALL');
  const [searchQ, setSearchQ] = useState('');
  const [calSelectedDate, setCalSelectedDate] = useState(new Date().toISOString().slice(0, 10));

  // Consultation notes modal
  const [activeCons, setActiveCons] = useState<any | null>(null);

  // Prescription Builder state
  const [rxForm, setRxForm] = useState({
    patientId: '',
    appointmentId: '',
    clinicalImpression: '',
    symptomsSummary: '',
    generalInstructions:
      'Maintain a 20-minute gap before and after taking homoeopathic medicines. Avoid raw onion, strong coffee, and mint around dose timing.',
    dietaryAdvice: 'Warm balanced home-cooked meals, adequate water intake, and regular sleep schedule.',
    followupDate: '',
    publishNow: true,
  });
  const [rxMeds, setRxMeds] = useState([
    { name: '', dosage: '4 globules (size 30)', frequency: 'Twice daily', duration: '14 days', instructions: '20 mins before meals on clean tongue' },
  ]);

  // Report review remarks
  const [reportRemarks, setReportRemarks] = useState<Record<string, string>>({});

  // Availability editing
  const [availDraft, setAvailDraft] = useState<any[]>([]);
  const [blockDateInput, setBlockDateInput] = useState('');
  const [blockReasonInput, setBlockReasonInput] = useState('');

  // WhatsApp quick send
  const [waPatientId, setWaPatientId] = useState('');
  const [waTemplate, setWaTemplate] = useState('appointment_reminder_24h');

  // Chatbot tester & ticket reply
  const [testPrompt, setTestPrompt] = useState('');
  const [testResult, setTestResult] = useState<any | null>(null);
  const [ticketReplies, setTicketReplies] = useState<Record<string, string>>({});

  // CMS state
  const [docDraft, setDocDraft] = useState<any>({});
  const [newArticle, setNewArticle] = useState({ title: '', category: "Women's Health", excerpt: '', content: '' });
  const [newFaq, setNewFaq] = useState({ category: 'Appointments & Timings', question: '', answer: '' });
  const [annText, setAnnText] = useState('');

  // Staff create state
  const [newStaff, setNewStaff] = useState({
    fullName: '',
    email: '',
    phone: '',
    designation: 'Appointment & Care Coordinator',
    password: '',
  });

  // Reschedule state
  const [reschedTarget, setReschedTarget] = useState<any | null>(null);
  const [reschedDate, setReschedDate] = useState('');
  const [reschedTime, setReschedTime] = useState('16:00');

  // Native WebRTC Live Call state for Doctor/Staff Console
  const [acceptedCall, setAcceptedCall] = useState<ActiveRtcSession | null>(null);
  const [activeCallId, setActiveCallId] = useState<string | null>(null);

  async function startDoctorRtcCall(
    patientId: string,
    patientName: string,
    patientPhone: string | null,
    callType: 'AUDIO' | 'VIDEO',
    consultationId?: string
  ) {
    if (consultationId) {
      apiFetch('/api/consultations', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'JOIN_LOG', consultationId }),
      }).catch(() => {});
    }
    const res = await apiFetch('/api/rtc', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'START', callType, patientId }),
    });
    const data = await res.json();
    if (!res.ok || !data.callId) {
      flash(data.error || 'Could not initiate call.');
      return;
    }
    setAcceptedCall({
      callId: data.callId,
      callType,
      role: 'CALLER',
      peerName: patientName,
      peerPhone: patientPhone,
      callerKey: data.callerKey || null,
      peerKey: data.peerKey || null,
      roomKey: data.callerKey || null,
    });
    setActiveCallId(data.callId);
    setTab('chat');
  }

  function flash(msg: string) {
    setToast(msg);
    setTimeout(() => setToast(''), 4000);
  }

  const refreshAll = useCallback(async () => {
    setLoading(true);
    try {
      const reqs: Promise<Response>[] = [
        apiFetch('/api/admin'),
        apiFetch('/api/appointments'),
        apiFetch('/api/consultations'),
        apiFetch('/api/payments'),
      ];
      if (isDoctorOrAdmin) {
        reqs.push(apiFetch('/api/prescriptions'), apiFetch('/api/reports'));
      }
      const resps = await Promise.all(reqs);
      const jsons = await Promise.all(resps.map((r) => (r.ok ? r.json().catch(() => ({})) : Promise.resolve({}))));

      const adm = jsons[0];
      setAdminData(adm);
      setAvailDraft(adm.availability || []);
      if (adm.doctorProfile) setDocDraft(adm.doctorProfile);
      if (adm.cms?.announcements?.[0]) setAnnText(adm.cms.announcements[0].message);
      if (adm.patients?.[0] && !waPatientId) setWaPatientId(adm.patients[0].id);

      setAppointments(jsons[1]?.appointments || []);
      setConsultations(jsons[2]?.consultations || []);
      setPayments(jsons[3]?.payments || []);
      if (isDoctorOrAdmin) {
        setPrescriptions(jsons[4]?.prescriptions || []);
        setReports(jsons[5]?.reports || []);
      }
    } finally {
      setLoading(false);
    }
  }, [isDoctorOrAdmin, waPatientId]);

  useEffect(() => {
    refreshAll();
  }, [refreshAll]);

  async function postAdmin(payload: Record<string, unknown>, successMsg?: string) {
    const res = await apiFetch('/api/admin', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    const d = await res.json();
    if (!res.ok) {
      flash(d.error || 'Action failed.');
      return false;
    }
    flash(d.message || successMsg || 'Saved successfully.');
    refreshAll();
    return true;
  }

  async function updateAppointment(id: string, payload: Record<string, unknown>, msg: string) {
    const res = await apiFetch(`/api/appointments/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    const d = await res.json();
    flash(res.ok ? d.message || msg : d.error || 'Failed.');
    if (res.ok) refreshAll();
  }

  async function handlePaymentAction(
    paymentId: string,
    action: 'ADMIN_VERIFY' | 'ADMIN_REJECT' | 'ADMIN_REFUND'
  ) {
    const res = await apiFetch('/api/payments', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        action,
        paymentId,
        reason:
          action === 'ADMIN_REFUND'
            ? 'Authorised clinic refund processed by Doctor'
            : action === 'ADMIN_REJECT'
            ? 'UTR / payment not found in clinic bank account (a72549567212@axl)'
            : undefined,
      }),
    });
    const d = await res.json();
    flash(
      res.ok
        ? action === 'ADMIN_VERIFY'
          ? 'Payment verified & appointment confirmed!'
          : action === 'ADMIN_REJECT'
          ? 'Unverified payment rejected & slot released.'
          : 'Secure refund processed & logged.'
        : d.error || 'Failed.'
    );
    if (res.ok) refreshAll();
  }

  async function submitPrescription(e: React.FormEvent) {
    e.preventDefault();
    const validMeds = rxMeds.filter((m) => m.name.trim().length > 1);
    if (!rxForm.patientId || validMeds.length === 0) {
      flash('Select a patient and enter at least one medicine.');
      return;
    }
    const res = await apiFetch('/api/prescriptions', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...rxForm, medicines: validMeds }),
    });
    const d = await res.json();
    if (!res.ok) {
      flash(d.error || 'Could not issue prescription.');
      return;
    }
    flash(
      `Prescription ${d.prescriptionNo} ${
        d.status === 'AUTHORISED' ? 'digitally authorised & published to patient portal!' : 'saved as draft.'
      }`
    );
    setRxForm({ ...rxForm, clinicalImpression: '', symptomsSummary: '', followupDate: '' });
    setRxMeds([
      { name: '', dosage: '4 globules (size 30)', frequency: 'Twice daily', duration: '14 days', instructions: '20 mins before meals on clean tongue' },
    ]);
    refreshAll();
  }

  async function saveConsultationNotes(e: React.FormEvent) {
    e.preventDefault();
    if (!activeCons) return;
    const res = await apiFetch('/api/consultations', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        action: 'SAVE_NOTES',
        consultationId: activeCons.id,
        clinicalNotes: activeCons.clinical_notes || '',
        homoeopathicCaseSummary: activeCons.homoeopathic_case_summary || '',
        provisionalImpression: activeCons.provisional_impression || '',
        advice: activeCons.advice || '',
        referralAdvised: Boolean(activeCons.referral_advised),
        referralDetails: activeCons.referral_details || '',
        followupDate: activeCons.followup_date || '',
        markCompleted: Boolean(activeCons.markCompleted),
      }),
    });
    if (res.ok) {
      flash('Clinical consultation notes saved.');
      setActiveCons(null);
      refreshAll();
    }
  }

  async function handleLogout() {
    clearClientSession();
    await fetch('/api/auth/logout', { method: 'POST', credentials: 'include' }).catch(() => {});
    window.location.assign('/login');
  }

  const kpis = adminData?.kpis || {};
  const filteredAppts = appointments.filter((a) => {
    const sOk = apptFilter === 'ALL' || a.status === apptFilter;
    const q = searchQ.trim().toLowerCase();
    const qOk =
      !q ||
      a.reference_no?.toLowerCase().includes(q) ||
      a.patient_display_name?.toLowerCase().includes(q) ||
      a.concern_category?.toLowerCase().includes(q);
    return sOk && qOk;
  });

  // Build current month calendar days
  const calBase = new Date(calSelectedDate + 'T00:00:00');
  const calYear = calBase.getFullYear();
  const calMonth = calBase.getMonth();
  const daysInMonth = new Date(calYear, calMonth + 1, 0).getDate();
  const firstDow = new Date(calYear, calMonth, 1).getDay();

  return (
    <div className="min-h-screen bg-surface-muted flex">
      {/* Sidebar */}
      <aside
        className={`fixed inset-y-0 left-0 z-50 w-64 bg-navy text-white flex flex-col transition-transform lg:static lg:translate-x-0 ${
          sidebarOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div className="px-5 py-4 border-b border-white/10 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2.5">
            <div className="rounded-lg bg-white/10 p-0.5">
              <BrandMark className="h-8 w-8" />
            </div>
            <div className="leading-tight">
              <span className="block font-heading text-sm font-bold text-white">Clinic Console</span>
              <span className="block text-[10.5px] text-teal-200">{sessionUser.role} ACCESS</span>
            </div>
          </Link>
          <button
            type="button"
            onClick={() => setSidebarOpen(false)}
            className="lg:hidden text-slate-300"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <nav className="flex-1 overflow-y-auto px-2.5 py-3 space-y-0.5">
          {visibleNav.map((item) => {
            const Icon = item.icon;
            const active = tab === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => {
                  setTab(item.id);
                  setSidebarOpen(false);
                }}
                className={`w-full flex items-center gap-2.5 rounded-xl px-3 py-2 text-xs font-semibold transition-colors ${
                  active
                    ? 'bg-teal text-white'
                    : 'text-slate-200 hover:bg-white/10 hover:text-white'
                }`}
              >
                <Icon className="h-3.5 w-3.5 shrink-0" />
                <span className="truncate">{item.label}</span>
              </button>
            );
          })}
        </nav>

        <div className="p-3 border-t border-white/10 space-y-1">
          <Link
            href="/"
            className="flex items-center gap-2 rounded-xl px-3 py-2 text-xs text-slate-300 hover:bg-white/10"
          >
            <Home className="h-3.5 w-3.5" /> View Public Website
          </Link>
          <button
            type="button"
            onClick={handleLogout}
            className="w-full flex items-center gap-2 rounded-xl px-3 py-2 text-xs text-rose-200 hover:bg-white/10"
          >
            <LogOut className="h-3.5 w-3.5" /> Sign Out
          </button>
        </div>
      </aside>

      {sidebarOpen && (
        <div
          className="fixed inset-0 z-40 bg-navy/40 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Main Content */}
      <div className="flex-1 flex flex-col min-w-0">
        <header className="sticky top-0 z-30 bg-white border-b border-slate-200 px-4 sm:px-7 h-16 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3 min-w-0">
            <button
              type="button"
              onClick={() => setSidebarOpen(true)}
              className="lg:hidden rounded-xl border border-slate-200 p-2 text-navy"
              aria-label="Toggle menu"
            >
              <Menu className="h-5 w-5" />
            </button>
            <div>
              <h1 className="font-heading text-base sm:text-lg font-bold text-navy truncate">
                {NAV_ITEMS.find((n) => n.id === tab)?.label}
              </h1>
              <p className="text-[11px] text-slate-500 truncate">
                {sessionUser.fullName} · Mon–Sat 3:00 PM – 8:00 PM IST
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            {isDoctor && (
              <button
                type="button"
                onClick={() => setTab('prescriptions')}
                className="hidden sm:inline-flex items-center gap-1.5 rounded-xl bg-teal px-3.5 py-2 text-xs font-semibold text-white hover:bg-teal-600"
              >
                <Plus className="h-3.5 w-3.5" /> Issue Rx
              </button>
            )}
          </div>
        </header>

        {toast && (
          <div className="mx-4 sm:mx-7 mt-4 rounded-xl border border-teal/30 bg-aqua px-4 py-3 text-xs font-semibold text-navy flex items-center justify-between">
            <span>{toast}</span>
            <button type="button" onClick={() => setToast('')}>
              <X className="h-3.5 w-3.5" />
            </button>
          </div>
        )}

        <main className="flex-1 p-4 sm:p-7 max-w-7xl w-full mx-auto space-y-6">
          <IncomingCallBanner
            mode="CLINIC"
            sessionToken={sessionToken}
            activeCallId={activeCallId}
            onAccept={(sess) => {
              setAcceptedCall(sess);
              setActiveCallId(sess.callId);
              setTab('chat');
            }}
          />
          {loading || !adminData ? (
            <div className="card-surface p-10 text-center text-sm text-slate-500">
              Loading clinic dashboard…
            </div>
          ) : (
            <>
              {/* 1. DASHBOARD OVERVIEW */}
              {tab === 'overview' && (
                <div className="space-y-6">
                  <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3.5">
                    {[
                      { label: "Today's Slots", val: kpis.todayAppts, sub: '3 PM – 8 PM' },
                      { label: 'Pending Requests', val: kpis.pendingAppts, sub: 'Needs review' },
                      { label: 'Upcoming', val: kpis.upcomingAppts, sub: 'Scheduled' },
                      { label: 'Completed', val: kpis.completedAppts, sub: 'Consultations' },
                      { label: 'Patients', val: kpis.totalPatients, sub: 'Registered' },
                      { label: 'Verified Revenue', val: `₹${kpis.totalRevenue}`, sub: `₹${kpis.pendingPayments} pending` },
                    ].map((card) => (
                      <div key={card.label} className="card-surface p-4">
                        <p className="text-[11px] font-semibold uppercase tracking-wide text-slate-500">
                          {card.label}
                        </p>
                        <p className="font-heading text-2xl font-bold text-navy tabular mt-1">
                          {card.val}
                        </p>
                        <p className="text-[11px] text-teal font-medium mt-0.5">{card.sub}</p>
                      </div>
                    ))}
                  </div>

                  {/* Charts Row */}
                  <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                    <div className="lg:col-span-7 card-surface p-6 space-y-4">
                      <div className="flex items-center justify-between">
                        <h2 className="text-sm font-bold text-navy">
                          Consultations by Medical Area
                        </h2>
                        <button
                          type="button"
                          onClick={() => setTab('analytics')}
                          className="text-xs font-semibold text-teal hover:underline"
                        >
                          Full Analytics →
                        </button>
                      </div>
                      <div className="space-y-3">
                        {(adminData.analytics?.byConcern || []).map((row: any) => {
                          const max = Math.max(
                            1,
                            ...(adminData.analytics.byConcern || []).map((r: any) => r.count)
                          );
                          const pct = Math.round((row.count / max) * 100);
                          return (
                            <div key={row.label} className="space-y-1">
                              <div className="flex justify-between text-xs">
                                <span className="font-medium text-navy">{row.label}</span>
                                <span className="text-slate-500 tabular">
                                  {row.count} bookings · ₹{row.revenue}
                                </span>
                              </div>
                              <div className="h-2.5 rounded-full bg-aqua overflow-hidden">
                                <div
                                  className="h-full rounded-full bg-teal"
                                  style={{ width: `${pct}%` }}
                                />
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>

                    <div className="lg:col-span-5 card-surface p-6 space-y-4">
                      <h2 className="text-sm font-bold text-navy">Payment Method Summary</h2>
                      <div className="space-y-2.5">
                        {(adminData.analytics?.byPaymentMethod || []).map((pm: any) => (
                          <div
                            key={pm.label}
                            className="flex items-center justify-between rounded-xl bg-surface-muted px-3.5 py-2.5 text-xs"
                          >
                            <span className="font-semibold text-navy">
                              {pm.label.replace('_', ' ')}
                            </span>
                            <span className="tabular font-bold text-teal">
                              ₹{pm.total} ({pm.count})
                            </span>
                          </div>
                        ))}
                      </div>
                      {kpis.pendingPayments > 0 && (
                        <button
                          type="button"
                          onClick={() => setTab('payments')}
                          className="btn-primary w-full py-2.5 text-xs"
                        >
                          Verify Pending UPI Payments (₹{kpis.pendingPayments})
                        </button>
                      )}
                    </div>
                  </div>

                  {/* Upcoming Schedule + Notifications */}
                  <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                    <div className="lg:col-span-7 card-surface p-6 space-y-3">
                      <div className="flex items-center justify-between">
                        <h2 className="text-sm font-bold text-navy">
                          Today’s & Upcoming Consultations
                        </h2>
                        <button
                          type="button"
                          onClick={() => setTab('appointments')}
                          className="text-xs font-semibold text-teal hover:underline"
                        >
                          Manage all
                        </button>
                      </div>
                      <div className="space-y-2.5">
                        {appointments
                          .filter((a) => ['PENDING', 'CONFIRMED', 'RESCHEDULED'].includes(a.status))
                          .slice(0, 5)
                          .map((a) => (
                            <div
                              key={a.id}
                              className="rounded-xl border border-slate-100 bg-surface-muted p-3.5 flex flex-wrap items-center justify-between gap-3 text-xs"
                            >
                              <div>
                                <p className="font-bold text-navy">
                                  {a.patient_display_name}{' '}
                                  <span className="font-normal text-slate-500">
                                    · {a.concern_category}
                                  </span>
                                </p>
                                <p className="text-slate-600 tabular">
                                  {a.appointment_date} · {fmt12(a.start_time)} IST · {a.reference_no}
                                </p>
                              </div>
                              <div className="flex items-center gap-2">
                                <StatusBadge status={a.status} />
                                {a.status === 'PENDING' && (
                                  <button
                                    type="button"
                                    onClick={() =>
                                      updateAppointment(
                                        a.id,
                                        { action: 'APPROVE' },
                                        'Appointment approved & video link dispatched!'
                                      )
                                    }
                                    className="rounded-lg bg-teal px-2.5 py-1 text-[11px] font-semibold text-white hover:bg-teal-600"
                                  >
                                    Approve
                                  </button>
                                )}
                              </div>
                            </div>
                          ))}
                      </div>
                    </div>

                    <div className="lg:col-span-5 card-surface p-6 space-y-3">
                      <h2 className="text-sm font-bold text-navy">Recent Clinic Alerts</h2>
                      {(adminData.recentNotifications || []).slice(0, 5).map((n: any) => (
                        <div key={n.id} className="rounded-xl bg-surface-muted p-3 text-xs">
                          <p className="font-semibold text-navy">{n.title}</p>
                          <p className="text-slate-600 mt-0.5">{n.message}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* 2. APPOINTMENT MANAGEMENT */}
              {tab === 'appointments' && (
                <div className="space-y-4">
                  <div className="flex flex-col sm:flex-row gap-3 justify-between">
                    <div className="flex flex-wrap gap-1.5">
                      {['ALL', 'PENDING', 'CONFIRMED', 'RESCHEDULED', 'COMPLETED', 'CANCELLED'].map(
                        (st) => (
                          <button
                            key={st}
                            type="button"
                            onClick={() => setApptFilter(st)}
                            className={`rounded-full px-3 py-1.5 text-xs font-semibold ${
                              apptFilter === st ? 'bg-navy text-white' : 'bg-white border border-slate-200 text-slate-600'
                            }`}
                          >
                            {st}
                          </button>
                        )
                      )}
                    </div>
                    <div className="relative sm:w-64">
                      <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-slate-400" />
                      <input
                        type="search"
                        value={searchQ}
                        onChange={(e) => setSearchQ(e.target.value)}
                        placeholder="Search ref, patient, concern..."
                        className="input-field pl-9 py-2 text-xs"
                      />
                    </div>
                  </div>

                  <div className="space-y-3">
                    {filteredAppts.map((a) => (
                      <div key={a.id} className="card-surface p-5 space-y-3">
                        <div className="flex flex-wrap items-start justify-between gap-3">
                          <div>
                            <div className="flex flex-wrap items-center gap-2 mb-1">
                              <span className="font-mono text-xs font-bold text-teal">
                                {a.reference_no}
                              </span>
                              <StatusBadge status={a.status} />
                              <StatusBadge status={a.payment_status} />
                              {a.patient_is_demo ? (
                                <span className="rounded bg-slate-100 px-1.5 py-0.5 text-[10px] font-semibold text-slate-500">
                                  DEMO
                                </span>
                              ) : null}
                            </div>
                            <h3 className="text-sm sm:text-base font-bold text-navy">
                              {a.patient_display_name} — {a.consultation_type_name}
                            </h3>
                            <p className="text-xs text-slate-500 tabular">
                              {a.appointment_date} · {fmt12(a.start_time)} – {fmt12(a.end_time)} IST ·{' '}
                              {a.concern_category} · ₹{a.fee_inr} · Ph: {a.patient_phone || 'N/A'}
                            </p>
                          </div>
                          <div className="flex flex-wrap gap-2">
                            {a.status === 'PENDING' && (
                              <>
                                <button
                                  type="button"
                                  onClick={() =>
                                    updateAppointment(a.id, { action: 'APPROVE' }, 'Booking approved!')
                                  }
                                  className="btn-primary py-1.5 px-3 text-xs"
                                >
                                  <Check className="h-3.5 w-3.5" /> Approve
                                </button>
                                <button
                                  type="button"
                                  onClick={() =>
                                    updateAppointment(
                                      a.id,
                                      { action: 'REJECT', reason: 'Slot unavailable — please choose another slot.' },
                                      'Booking rejected.'
                                    )
                                  }
                                  className="rounded-xl border border-rose-200 px-3 py-1.5 text-xs font-semibold text-rose-700 hover:bg-rose-50"
                                >
                                  Reject
                                </button>
                              </>
                            )}
                            {['PENDING', 'CONFIRMED', 'RESCHEDULED'].includes(a.status) && (
                              <>
                                <button
                                  type="button"
                                  onClick={() => {
                                    setReschedTarget(a);
                                    setReschedDate(a.appointment_date);
                                    setReschedTime(a.start_time);
                                  }}
                                  className="btn-secondary py-1.5 px-3 text-xs"
                                >
                                  Reschedule
                                </button>
                                <button
                                  type="button"
                                  onClick={() =>
                                    updateAppointment(a.id, { action: 'SEND_REMINDER' }, 'Reminder dispatched!')
                                  }
                                  className="btn-secondary py-1.5 px-3 text-xs"
                                >
                                  Send Reminder
                                </button>
                              </>
                            )}
                            {a.status === 'CONFIRMED' && isDoctor && (
                              <>
                                <button
                                  type="button"
                                  onClick={() =>
                                    updateAppointment(a.id, { action: 'COMPLETE' }, 'Marked completed.')
                                  }
                                  className="btn-navy py-1.5 px-3 text-xs"
                                >
                                  Complete
                                </button>
                                <button
                                  type="button"
                                  onClick={() => {
                                    setRxForm({
                                      ...rxForm,
                                      patientId: a.patient_id,
                                      appointmentId: a.id,
                                      symptomsSummary: a.chief_complaint || '',
                                    });
                                    setTab('prescriptions');
                                  }}
                                  className="rounded-xl bg-aqua px-3 py-1.5 text-xs font-semibold text-navy hover:bg-teal hover:text-white"
                                >
                                  Write Rx
                                </button>
                              </>
                            )}
                          </div>
                        </div>
                        <p className="text-xs text-slate-600 bg-surface-muted rounded-xl p-3">
                          <strong>Chief Complaint:</strong> {a.chief_complaint}
                          {a.upi_utr ? ` · Submitted UTR: ${a.upi_utr}` : ''}
                        </p>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* 3. PATIENT MANAGEMENT */}
              {tab === 'patients' && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {(adminData.patients || []).map((p: any) => (
                    <div key={p.id} className="card-surface p-5 space-y-3 text-xs">
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-mono font-bold text-teal">
                              {p.patient_code || 'PAT'}
                            </span>
                            {p.is_demo ? (
                              <span className="rounded bg-amber-50 border border-amber-200 px-1.5 py-0.5 text-[10px] font-semibold text-amber-700">
                                DEMO RECORD
                              </span>
                            ) : null}
                            {p.is_minor_account ? (
                              <span className="rounded bg-aqua px-2 py-0.5 text-[10px] font-semibold text-navy">
                                GUARDIAN ACCOUNT
                              </span>
                            ) : null}
                          </div>
                          <h3 className="text-base font-bold text-navy mt-1">{p.full_name}</h3>
                          <p className="text-slate-500">
                            {p.email} · {p.phone || 'No phone'} · Sign-in: {p.auth_provider}
                          </p>
                        </div>
                        <span className="rounded-lg bg-surface-muted px-2.5 py-1 font-semibold text-navy tabular">
                          {p.appointment_count} Visits · {p.rx_count} Rx
                        </span>
                      </div>

                      {p.is_minor_account ? (
                        <div className="rounded-xl bg-aqua/70 p-2.5 text-navy">
                          <strong>Minor Patient:</strong> {p.minor_patient_name} (DOB:{' '}
                          {p.minor_date_of_birth || 'N/A'}) · {p.guardian_relation}
                        </div>
                      ) : null}

                      <div className="grid grid-cols-2 gap-2 text-slate-600 pt-1">
                        <p>
                          <strong>Sex / Blood:</strong> {p.gender || '—'} / {p.blood_group || '—'}
                        </p>
                        <p>
                          <strong>Location:</strong> {p.city || 'India'}
                        </p>
                        {isDoctorOrAdmin && p.chronic_conditions && (
                          <p className="col-span-2">
                            <strong>History:</strong> {p.chronic_conditions}
                          </p>
                        )}
                        {isDoctorOrAdmin && p.allergies && (
                          <p className="col-span-2">
                            <strong>Allergies:</strong> {p.allergies}
                          </p>
                        )}
                      </div>

                      {isDoctor && (
                        <div className="pt-2 border-t border-slate-100">
                          <button
                            type="button"
                            onClick={() => {
                              setRxForm({ ...rxForm, patientId: p.id, appointmentId: '' });
                              setTab('prescriptions');
                            }}
                            className="text-xs font-semibold text-teal hover:underline"
                          >
                            + Issue Prescription for {p.full_name}
                          </button>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}

              {/* LIVE PATIENT CHAT, AUDIO CALL & VIDEO CALL CONSOLE */}
              {tab === 'chat' && (
                <ClinicLiveComm
                  mode="CLINIC"
                  currentUserName={sessionUser.fullName}
                  sessionToken={sessionToken}
                  externalSession={acceptedCall}
                  onClearExternalSession={() => setAcceptedCall(null)}
                  onActiveCallChange={setActiveCallId}
                />
              )}

              {/* 4. CONSULTATION & VIDEO MANAGEMENT */}
              {tab === 'consultations' && (
                <div className="space-y-4">
                  <div className="rounded-xl bg-aqua p-4 flex flex-wrap items-center justify-between gap-3 text-xs text-navy">
                    <span>
                      Clinic Official Audio/Video/Chat Line: <strong>+91 8123108149</strong> · All WebRTC sessions have <strong>automatic recording disabled</strong>.
                    </span>
                    <button
                      type="button"
                      onClick={() => setTab('chat')}
                      className="btn-primary py-1.5 px-3 text-xs"
                    >
                      <MessageCircle className="h-3.5 w-3.5" /> Open Live Chat &amp; Call Console
                    </button>
                  </div>
                  {consultations.map((c) => {
                    const pDigits = String(c.patient_phone || '').replace(/\D/g, '');
                    const pWa = pDigits.length === 10 ? `91${pDigits}` : pDigits;
                    return (
                      <div key={c.id} className="card-surface p-5 space-y-3">
                        <div className="flex flex-wrap items-start justify-between gap-3">
                          <div>
                            <div className="flex items-center gap-2 mb-1">
                              <StatusBadge status={c.status} />
                              <span className="text-xs text-slate-500 font-mono">{c.reference_no}</span>
                              <span className="text-[11px] text-teal font-semibold">Recording: OFF</span>
                            </div>
                            <h3 className="text-base font-bold text-navy">
                              {c.patient_display_name} · {c.consultation_type_name}
                            </h3>
                            <p className="text-xs text-slate-500 tabular">
                              {c.appointment_date} at {fmt12(c.start_time)} IST · {c.concern_category}
                              {c.patient_phone ? ` · Mobile: +91 ${c.patient_phone}` : ''}
                            </p>
                          </div>
                          <div className="flex flex-wrap gap-2">
                            <button
                              type="button"
                              onClick={() =>
                                startDoctorRtcCall(
                                  c.patient_id,
                                  c.patient_name || c.patient_display_name,
                                  c.patient_phone || null,
                                  'VIDEO',
                                  c.id
                                )
                              }
                              className="btn-primary py-2 px-3.5 text-xs"
                            >
                              <Video className="h-3.5 w-3.5" /> Live Video Call
                            </button>
                            <button
                              type="button"
                              onClick={() =>
                                startDoctorRtcCall(
                                  c.patient_id,
                                  c.patient_name || c.patient_display_name,
                                  c.patient_phone || null,
                                  'AUDIO',
                                  c.id
                                )
                              }
                              className="btn-secondary py-2 px-3 text-xs"
                            >
                              <Phone className="h-3.5 w-3.5 text-teal" /> Live Audio Call
                            </button>
                            {pWa && (
                              <a
                                href={`https://wa.me/${pWa}?text=${encodeURIComponent(
                                  `Namaste ${c.patient_name}, this is Dr. Aparna Mishra (+91 8123108149). Ready for your online consultation (Ref: ${c.reference_no}).`
                                )}`}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="rounded-xl border border-emerald-200 bg-emerald-50 px-3 py-2 text-xs font-semibold text-emerald-800 hover:bg-emerald-100"
                              >
                                WhatsApp Call/Chat
                              </a>
                            )}
                            {isDoctor && (
                              <button
                                type="button"
                                onClick={() => setActiveCons({ ...c, markCompleted: false })}
                                className="btn-secondary py-2 px-3.5 text-xs"
                              >
                                Clinical Notes
                              </button>
                            )}
                          </div>
                        </div>
                        {isDoctor && c.provisional_impression && (
                          <div className="rounded-xl bg-surface-muted p-3 text-xs text-slate-700">
                            <strong>Impression:</strong> {c.provisional_impression}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}

              {/* 5. PRESCRIPTION MANAGEMENT (DOCTOR ONLY) */}
              {tab === 'prescriptions' && isDoctorOrAdmin && (
                <div className="space-y-8">
                  {isDoctor && (
                    <form onSubmit={submitPrescription} className="card-surface p-6 space-y-5">
                      <div>
                        <h2 className="text-lg font-bold text-navy">
                          Issue Authorised Digital Prescription (Rx)
                        </h2>
                        <p className="text-xs text-slate-500">
                          Restricted strictly to Dr. Aparna Mishra (BHMS). Generates a digitally signed PDF inside the patient’s private portal.
                        </p>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                        <div>
                          <label className="label-text">Select Patient *</label>
                          <select
                            required
                            value={rxForm.patientId}
                            onChange={(e) => setRxForm({ ...rxForm, patientId: e.target.value })}
                            className="input-field"
                          >
                            <option value="">Choose patient...</option>
                            {(adminData.patients || []).map((p: any) => (
                              <option key={p.id} value={p.id}>
                                {p.full_name} ({p.patient_code})
                              </option>
                            ))}
                          </select>
                        </div>
                        <div>
                          <label className="label-text">Clinical Impression / Assessment *</label>
                          <input
                            type="text"
                            required
                            value={rxForm.clinicalImpression}
                            onChange={(e) =>
                              setRxForm({ ...rxForm, clinicalImpression: e.target.value })
                            }
                            placeholder="e.g. Allergic Rhinitis — Constitutional Care"
                            className="input-field"
                          />
                        </div>
                        <div>
                          <label className="label-text">Recommended Follow-Up Date</label>
                          <input
                            type="date"
                            value={rxForm.followupDate}
                            onChange={(e) => setRxForm({ ...rxForm, followupDate: e.target.value })}
                            className="input-field"
                          />
                        </div>
                      </div>

                      <div>
                        <label className="label-text">Presenting Symptoms Summary</label>
                        <input
                          type="text"
                          value={rxForm.symptomsSummary}
                          onChange={(e) => setRxForm({ ...rxForm, symptomsSummary: e.target.value })}
                          placeholder="Brief case notes visible on prescription"
                          className="input-field"
                        />
                      </div>

                      {/* Medicines Table Builder */}
                      <div className="space-y-3">
                        <div className="flex items-center justify-between">
                          <label className="label-text mb-0">Medicines / Remedies & Dosage *</label>
                          <button
                            type="button"
                            onClick={() =>
                              setRxMeds([
                                ...rxMeds,
                                { name: '', dosage: '4 globules', frequency: 'Twice daily', duration: '14 days', instructions: '' },
                              ])
                            }
                            className="text-xs font-semibold text-teal hover:underline"
                          >
                            + Add Medicine Row
                          </button>
                        </div>
                        {rxMeds.map((m, idx) => (
                          <div
                            key={idx}
                            className="grid grid-cols-1 sm:grid-cols-12 gap-2.5 rounded-xl bg-surface-muted p-3"
                          >
                            <input
                              type="text"
                              required
                              placeholder="Medicine & Potency (e.g. Nux Vomica 30C)"
                              value={m.name}
                              onChange={(e) => {
                                const copy = [...rxMeds];
                                copy[idx].name = e.target.value;
                                setRxMeds(copy);
                              }}
                              className="input-field sm:col-span-4 text-xs"
                            />
                            <input
                              type="text"
                              required
                              placeholder="Dosage"
                              value={m.dosage}
                              onChange={(e) => {
                                const copy = [...rxMeds];
                                copy[idx].dosage = e.target.value;
                                setRxMeds(copy);
                              }}
                              className="input-field sm:col-span-2 text-xs"
                            />
                            <input
                              type="text"
                              required
                              placeholder="Frequency"
                              value={m.frequency}
                              onChange={(e) => {
                                const copy = [...rxMeds];
                                copy[idx].frequency = e.target.value;
                                setRxMeds(copy);
                              }}
                              className="input-field sm:col-span-2 text-xs"
                            />
                            <input
                              type="text"
                              required
                              placeholder="Duration"
                              value={m.duration}
                              onChange={(e) => {
                                const copy = [...rxMeds];
                                copy[idx].duration = e.target.value;
                                setRxMeds(copy);
                              }}
                              className="input-field sm:col-span-2 text-xs"
                            />
                            <div className="sm:col-span-2 flex gap-1.5">
                              <input
                                type="text"
                                placeholder="Note"
                                value={m.instructions}
                                onChange={(e) => {
                                  const copy = [...rxMeds];
                                  copy[idx].instructions = e.target.value;
                                  setRxMeds(copy);
                                }}
                                className="input-field text-xs"
                              />
                              {rxMeds.length > 1 && (
                                <button
                                  type="button"
                                  onClick={() => setRxMeds(rxMeds.filter((_, i) => i !== idx))}
                                  className="text-rose-500 px-1"
                                >
                                  <Trash2 className="h-4 w-4" />
                                </button>
                              )}
                            </div>
                          </div>
                        ))}
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                          <label className="label-text">General Instructions</label>
                          <textarea
                            rows={2}
                            value={rxForm.generalInstructions}
                            onChange={(e) =>
                              setRxForm({ ...rxForm, generalInstructions: e.target.value })
                            }
                            className="input-field text-xs"
                          />
                        </div>
                        <div>
                          <label className="label-text">Dietary & Lifestyle Advice</label>
                          <textarea
                            rows={2}
                            value={rxForm.dietaryAdvice}
                            onChange={(e) => setRxForm({ ...rxForm, dietaryAdvice: e.target.value })}
                            className="input-field text-xs"
                          />
                        </div>
                      </div>

                      <div className="flex flex-wrap items-center justify-between gap-3">
                        <label className="flex items-center gap-2 text-xs font-medium text-navy">
                          <input
                            type="checkbox"
                            checked={rxForm.publishNow}
                            onChange={(e) => setRxForm({ ...rxForm, publishNow: e.target.checked })}
                            className="h-4 w-4 rounded text-teal"
                          />
                          Digitally Authorise & Publish Immediately to Patient Portal
                        </label>
                        <button type="submit" className="btn-primary text-xs">
                          {rxForm.publishNow
                            ? 'Authorise & Publish Prescription'
                            : 'Save Draft Prescription'}
                        </button>
                      </div>
                    </form>
                  )}

                  {/* Issued Prescriptions Ledger */}
                  <div className="space-y-3">
                    <h3 className="text-base font-bold text-navy">Issued Prescriptions</h3>
                    {prescriptions.map((rx) => (
                      <div
                        key={rx.id}
                        className="card-surface p-5 flex flex-wrap items-center justify-between gap-4 text-xs"
                      >
                        <div>
                          <div className="flex items-center gap-2 mb-1">
                            <span className="font-mono font-bold text-teal">{rx.prescription_no}</span>
                            <StatusBadge status={rx.status} />
                          </div>
                          <p className="text-sm font-bold text-navy">
                            {rx.patient_name} ({rx.patient_code}) — {rx.clinical_impression}
                          </p>
                          <p className="text-slate-500">
                            {rx.authorised_at || rx.created_at} · Sig: {rx.digital_signature_hash || 'Pending'}
                          </p>
                        </div>
                        <div className="flex gap-2">
                          {rx.status === 'DRAFT' && isDoctor && (
                            <button
                              type="button"
                              onClick={async () => {
                                await apiFetch('/api/prescriptions', {
                                  method: 'PATCH',
                                  headers: { 'Content-Type': 'application/json' },
                                  body: JSON.stringify({ action: 'AUTHORISE', prescriptionId: rx.id }),
                                });
                                flash('Draft prescription authorised & published!');
                                refreshAll();
                              }}
                              className="btn-primary py-2 px-3 text-xs"
                            >
                              Authorise Now
                            </button>
                          )}
                          <a
                            href={`/api/prescriptions/${rx.id}/pdf?_st=${encodeURIComponent(sessionToken)}`}
                            className="btn-secondary py-2 px-3.5 text-xs"
                          >
                            <Download className="h-3.5 w-3.5 text-teal" /> PDF
                          </a>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* 6. MEDICAL REPORT MANAGEMENT */}
              {tab === 'reports' && isDoctorOrAdmin && (
                <div className="space-y-4">
                  {reports.map((rp) => (
                    <div key={rp.id} className="card-surface p-5 space-y-3 text-xs">
                      <div className="flex flex-wrap items-start justify-between gap-3">
                        <div>
                          <div className="flex items-center gap-2 mb-1">
                            <StatusBadge status={rp.review_status} />
                            <span className="text-slate-500">{rp.category}</span>
                          </div>
                          <h3 className="text-base font-bold text-navy">{rp.title}</h3>
                          <p className="text-slate-500">
                            Patient: <strong>{rp.patient_name}</strong> ({rp.patient_code}) ·{' '}
                            {rp.original_filename} · AES-256-GCM Encrypted
                          </p>
                        </div>
                        <a
                          href={`/api/reports/${rp.id}/download?_st=${encodeURIComponent(sessionToken)}`}
                          className="btn-secondary py-2 px-3.5 text-xs"
                        >
                          <Download className="h-3.5 w-3.5 text-teal" /> Decrypt & Download
                        </a>
                      </div>
                      {isDoctor && (
                        <div className="flex flex-col sm:flex-row gap-2 pt-2 border-t border-slate-100">
                          <input
                            type="text"
                            placeholder="Enter clinical review note for patient..."
                            value={reportRemarks[rp.id] ?? rp.doctor_remarks ?? ''}
                            onChange={(e) =>
                              setReportRemarks({ ...reportRemarks, [rp.id]: e.target.value })
                            }
                            className="input-field text-xs flex-1"
                          />
                          <button
                            type="button"
                            onClick={async () => {
                              await apiFetch('/api/reports', {
                                method: 'PATCH',
                                headers: { 'Content-Type': 'application/json' },
                                body: JSON.stringify({
                                  reportId: rp.id,
                                  doctorRemarks: reportRemarks[rp.id] ?? rp.doctor_remarks ?? '',
                                }),
                              });
                              flash('Report marked reviewed & patient notified.');
                              refreshAll();
                            }}
                            className="btn-primary py-2 px-4 text-xs shrink-0"
                          >
                            Save Review Note
                          </button>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}

              {/* 7. PAYMENTS & BILLING */}
              {tab === 'payments' && (
                <div className="space-y-6">
                  <div className="card-surface p-5 flex flex-col sm:flex-row items-center justify-between gap-4">
                    <div className="flex items-center gap-4">
                      <img
                        src={adminData.doctorProfile.upi_qr_url}
                        alt="Clinic PhonePe QR"
                        className="h-20 w-20 rounded-xl border border-slate-200 object-contain"
                      />
                      <div className="text-xs space-y-1">
                        <p className="font-heading text-sm font-bold text-navy">
                          Active Clinic UPI & Payment Gateway
                        </p>
                        <p className="text-slate-600">
                          PhonePe / UPI VPA: <strong className="font-mono text-teal">{adminData.doctorProfile.upi_id}</strong> ({adminData.doctorProfile.upi_payee_name})
                        </p>
                        <p className="text-slate-500">
                          Cards, NetBanking, UPI ID & Wallets enabled via server-verified Razorpay integration.
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-xs text-slate-500">Total Verified Collection</p>
                      <p className="font-heading text-2xl font-bold text-navy tabular">
                        ₹{kpis.totalRevenue}
                      </p>
                    </div>
                  </div>

                  <div className="space-y-3">
                    {payments.map((p) => (
                      <div
                        key={p.id}
                        className="card-surface p-5 flex flex-wrap items-center justify-between gap-4 text-xs"
                      >
                        <div>
                          <div className="flex items-center gap-2 mb-1">
                            <span className="font-mono font-bold text-navy">{p.receipt_no}</span>
                            <StatusBadge status={p.status} />
                            <span className="rounded bg-aqua px-2 py-0.5 text-[10px] font-semibold text-navy">
                              {p.payment_method}
                            </span>
                          </div>
                          <p className="text-sm font-bold text-navy">
                            {p.patient_name} — ₹{p.amount_inr} ({p.appointment_ref})
                          </p>
                          <p className="text-slate-500">
                            {p.payer_detail || p.gateway} · {p.created_at}
                          </p>
                        </div>
                        <div className="flex flex-wrap gap-2">
                          {Boolean(p.has_proof) && (
                            <a
                              href={`/api/payments/${p.id}/proof?_st=${encodeURIComponent(sessionToken)}`}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="btn-secondary py-2 px-3 text-xs"
                            >
                              View Screenshot
                            </a>
                          )}
                          {p.status === 'PENDING_VERIFICATION' && (
                            <>
                              <button
                                type="button"
                                onClick={() => handlePaymentAction(p.id, 'ADMIN_VERIFY')}
                                className="btn-primary py-2 px-3.5 text-xs"
                              >
                                Confirm ₹ &amp; Approve
                              </button>
                              <button
                                type="button"
                                onClick={() => handlePaymentAction(p.id, 'ADMIN_REJECT')}
                                className="rounded-xl border border-rose-200 bg-rose-50 px-3 py-2 text-xs font-semibold text-rose-700 hover:bg-rose-100"
                              >
                                Reject &amp; Cancel Slot
                              </button>
                            </>
                          )}
                          {p.status === 'PAID' && isDoctorOrAdmin && (
                            <button
                              type="button"
                              onClick={() => handlePaymentAction(p.id, 'ADMIN_REFUND')}
                              className="rounded-xl border border-rose-200 px-3 py-2 text-xs font-semibold text-rose-700 hover:bg-rose-50"
                            >
                              Issue Refund
                            </button>
                          )}
                          {(p.status === 'PAID' || p.status === 'REFUNDED') && (
                            <a
                              href={`/api/payments/${p.id}/receipt?_st=${encodeURIComponent(sessionToken)}`}
                              className="btn-secondary py-2 px-3 text-xs"
                            >
                              <Download className="h-3.5 w-3.5 text-teal" /> Receipt
                            </a>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* 8. APPOINTMENT CALENDAR */}
              {tab === 'calendar' && (
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                  <div className="lg:col-span-7 card-surface p-6 space-y-4">
                    <div className="flex items-center justify-between">
                      <h2 className="text-base font-bold text-navy">
                        {calBase.toLocaleString('en-IN', { month: 'long', year: 'numeric' })}
                      </h2>
                      <input
                        type="date"
                        value={calSelectedDate}
                        onChange={(e) => e.target.value && setCalSelectedDate(e.target.value)}
                        className="input-field w-auto py-1.5 text-xs"
                      />
                    </div>
                    <div className="grid grid-cols-7 gap-1.5 text-center text-[11px] font-semibold text-slate-400">
                      {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((d) => (
                        <div key={d}>{d}</div>
                      ))}
                    </div>
                    <div className="grid grid-cols-7 gap-1.5">
                      {Array.from({ length: firstDow }).map((_, i) => (
                        <div key={`e_${i}`} />
                      ))}
                      {Array.from({ length: daysInMonth }).map((_, idx) => {
                        const day = idx + 1;
                        const dStr = `${calYear}-${String(calMonth + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
                        const count = appointments.filter(
                          (a) => a.appointment_date === dStr && !['CANCELLED', 'REJECTED'].includes(a.status)
                        ).length;
                        const isBlocked = (adminData.blockedDates || []).some(
                          (b: any) => b.blocked_date === dStr
                        );
                        const selected = calSelectedDate === dStr;
                        return (
                          <button
                            key={dStr}
                            type="button"
                            onClick={() => setCalSelectedDate(dStr)}
                            className={`rounded-xl border p-2 text-xs font-semibold tabular transition-colors ${
                              selected
                                ? 'bg-navy text-white border-navy'
                                : isBlocked
                                ? 'bg-rose-50 text-rose-700 border-rose-200'
                                : count > 0
                                ? 'bg-aqua text-navy border-teal/40'
                                : 'bg-white text-slate-700 border-slate-100 hover:bg-surface-muted'
                            }`}
                          >
                            <span>{day}</span>
                            {count > 0 && (
                              <span className="block text-[10px] text-teal font-bold">
                                {count} slot{count > 1 ? 's' : ''}
                              </span>
                            )}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  <div className="lg:col-span-5 card-surface p-6 space-y-3">
                    <h3 className="text-base font-bold text-navy">
                      Schedule for {calSelectedDate} (3:00 PM – 8:00 PM)
                    </h3>
                    {appointments.filter((a) => a.appointment_date === calSelectedDate).length === 0 ? (
                      <p className="text-xs text-slate-500">No bookings on this date.</p>
                    ) : (
                      appointments
                        .filter((a) => a.appointment_date === calSelectedDate)
                        .map((a) => (
                          <div key={a.id} className="rounded-xl bg-surface-muted p-3.5 text-xs space-y-1">
                            <div className="flex justify-between">
                              <strong className="text-navy tabular">
                                {fmt12(a.start_time)} – {fmt12(a.end_time)}
                              </strong>
                              <StatusBadge status={a.status} />
                            </div>
                            <p className="font-semibold text-slate-800">{a.patient_display_name}</p>
                            <p className="text-slate-500">{a.concern_category} · {a.reference_no}</p>
                          </div>
                        ))
                    )}
                  </div>
                </div>
              )}

              {/* 9. DOCTOR AVAILABILITY & CONSULTATION FEES */}
              {tab === 'availability' && (
                <div className="space-y-6">
                  <div className="card-surface p-6 space-y-4">
                    <h2 className="text-base font-bold text-navy">
                      Weekly Consultation Hours (Default: Mon–Sat, 3:00 PM – 8:00 PM)
                    </h2>
                    <div className="space-y-2.5">
                      {availDraft.map((row, idx) => (
                        <div
                          key={row.day_of_week}
                          className="grid grid-cols-2 sm:grid-cols-5 items-center gap-3 rounded-xl bg-surface-muted p-3 text-xs"
                        >
                          <label className="flex items-center gap-2 font-semibold text-navy">
                            <input
                              type="checkbox"
                              disabled={!isDoctorOrAdmin}
                              checked={Boolean(row.is_enabled)}
                              onChange={(e) => {
                                const c = [...availDraft];
                                c[idx] = { ...row, is_enabled: e.target.checked ? 1 : 0 };
                                setAvailDraft(c);
                              }}
                              className="h-4 w-4 rounded text-teal"
                            />
                            {row.day_name}
                          </label>
                          <input
                            type="time"
                            disabled={!row.is_enabled || !isDoctorOrAdmin}
                            value={row.start_time}
                            onChange={(e) => {
                              const c = [...availDraft];
                              c[idx] = { ...row, start_time: e.target.value };
                              setAvailDraft(c);
                            }}
                            className="input-field py-1.5 text-xs"
                          />
                          <input
                            type="time"
                            disabled={!row.is_enabled || !isDoctorOrAdmin}
                            value={row.end_time}
                            onChange={(e) => {
                              const c = [...availDraft];
                              c[idx] = { ...row, end_time: e.target.value };
                              setAvailDraft(c);
                            }}
                            className="input-field py-1.5 text-xs"
                          />
                          <select
                            disabled={!row.is_enabled || !isDoctorOrAdmin}
                            value={row.slot_interval_minutes}
                            onChange={(e) => {
                              const c = [...availDraft];
                              c[idx] = { ...row, slot_interval_minutes: Number(e.target.value) };
                              setAvailDraft(c);
                            }}
                            className="input-field py-1.5 text-xs"
                          >
                            <option value={15}>15 min interval</option>
                            <option value={20}>20 min interval</option>
                            <option value={30}>30 min interval</option>
                            <option value={45}>45 min interval</option>
                          </select>
                          <span className="text-slate-500">
                            {row.is_enabled ? `${fmt12(row.start_time)} – ${fmt12(row.end_time)}` : 'Clinic Closed'}
                          </span>
                        </div>
                      ))}
                    </div>
                    {isDoctorOrAdmin && (
                      <button
                        type="button"
                        onClick={() => postAdmin({ action: 'UPDATE_AVAILABILITY', schedule: availDraft })}
                        className="btn-primary text-xs"
                      >
                        Save Weekly Availability
                      </button>
                    )}
                  </div>

                  {/* Block Unavailable Dates + Fee Manager */}
                  {isDoctorOrAdmin && (
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                      <div className="card-surface p-6 space-y-4">
                        <h3 className="text-sm font-bold text-navy">Block Unavailable / Leave Dates</h3>
                        <div className="flex flex-wrap gap-2">
                          <input
                            type="date"
                            value={blockDateInput}
                            onChange={(e) => setBlockDateInput(e.target.value)}
                            className="input-field w-auto text-xs py-2"
                          />
                          <input
                            type="text"
                            placeholder="Reason (e.g. Conference)"
                            value={blockReasonInput}
                            onChange={(e) => setBlockReasonInput(e.target.value)}
                            className="input-field flex-1 text-xs py-2"
                          />
                          <button
                            type="button"
                            onClick={() => {
                              postAdmin(
                                {
                                  action: 'ADD_BLOCKED_DATE',
                                  blockedDate: blockDateInput,
                                  reason: blockReasonInput,
                                },
                                'Date blocked.'
                              );
                              setBlockDateInput('');
                              setBlockReasonInput('');
                            }}
                            className="btn-navy py-2 px-3.5 text-xs"
                          >
                            Block Date
                          </button>
                        </div>
                        <div className="space-y-2">
                          {(adminData.blockedDates || []).map((b: any) => (
                            <div
                              key={b.id}
                              className="flex items-center justify-between rounded-xl bg-rose-50 px-3.5 py-2 text-xs text-rose-800"
                            >
                              <span>
                                <strong>{b.blocked_date}</strong> — {b.reason}
                              </span>
                              <button
                                type="button"
                                onClick={() =>
                                  postAdmin({ action: 'REMOVE_BLOCKED_DATE', id: b.id }, 'Date unblocked.')
                                }
                                className="font-semibold underline"
                              >
                                Unblock
                              </button>
                            </div>
                          ))}
                        </div>
                      </div>

                      <div className="card-surface p-6 space-y-3">
                        <h3 className="text-sm font-bold text-navy">Consultation Duration & Fees (INR)</h3>
                        {(adminData.consultationTypes || []).map((ct: any) => (
                          <div
                            key={ct.id}
                            className="flex flex-wrap items-center justify-between gap-2 rounded-xl bg-surface-muted p-3 text-xs"
                          >
                            <span className="font-semibold text-navy">{ct.name}</span>
                            <div className="flex items-center gap-2">
                              <input
                                type="number"
                                defaultValue={ct.fee_inr}
                                onBlur={(e) => {
                                  const v = Number(e.target.value);
                                  if (v !== ct.fee_inr) {
                                    postAdmin({
                                      action: 'UPDATE_CONSULTATION_TYPE',
                                      id: ct.id,
                                      name: ct.name,
                                      duration_minutes: ct.duration_minutes,
                                      fee_inr: v,
                                      is_active: true,
                                    });
                                  }
                                }}
                                className="input-field w-24 py-1 text-xs tabular"
                              />
                              <span className="text-slate-500">{ct.duration_minutes}m</span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* 10. WHATSAPP BUSINESS NOTIFICATIONS */}
              {tab === 'whatsapp' && (
                <div className="space-y-6">
                  <div className="card-surface p-6 space-y-4">
                    <h2 className="text-base font-bold text-navy">
                      Send Approved WhatsApp Business Template
                    </h2>
                    <p className="text-xs text-slate-500">
                      Privacy-safe templates: zero diagnosis or prescription drug details are ever exposed in external messages.
                    </p>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                      <select
                        value={waPatientId}
                        onChange={(e) => setWaPatientId(e.target.value)}
                        className="input-field text-xs"
                      >
                        {(adminData.patients || []).map((p: any) => (
                          <option key={p.id} value={p.id}>
                            {p.full_name} ({p.phone || 'Portal'})
                          </option>
                        ))}
                      </select>
                      <select
                        value={waTemplate}
                        onChange={(e) => setWaTemplate(e.target.value)}
                        className="input-field text-xs"
                      >
                        {(adminData.whatsappTemplates || []).map((t: any) => (
                          <option key={t.id} value={t.template_name}>
                            {t.template_name} ({t.event_trigger})
                          </option>
                        ))}
                      </select>
                      <button
                        type="button"
                        onClick={() =>
                          postAdmin({
                            action: 'SEND_WHATSAPP',
                            patientId: waPatientId,
                            templateName: waTemplate,
                          })
                        }
                        className="btn-primary text-xs"
                      >
                        <Send className="h-3.5 w-3.5" /> Dispatch Template
                      </button>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <div className="card-surface p-6 space-y-3">
                      <h3 className="text-sm font-bold text-navy">Approved Templates</h3>
                      {(adminData.whatsappTemplates || []).map((t: any) => (
                        <div key={t.id} className="rounded-xl bg-surface-muted p-3.5 text-xs space-y-1">
                          <div className="flex justify-between">
                            <code className="font-bold text-navy">{t.template_name}</code>
                            <StatusBadge status={t.approval_status} />
                          </div>
                          <p className="text-slate-600">{t.body_template}</p>
                        </div>
                      ))}
                    </div>

                    <div className="card-surface p-6 space-y-3">
                      <h3 className="text-sm font-bold text-navy">WhatsApp & Email Dispatch Log</h3>
                      <div className="space-y-2.5 max-h-96 overflow-y-auto">
                        {(adminData.whatsappLogs || []).map((l: any) => (
                          <div key={l.id} className="rounded-xl bg-surface-muted p-3 text-xs space-y-1">
                            <div className="flex justify-between">
                              <span className="font-semibold text-navy">
                                {l.channel} → {l.recipient_name}
                              </span>
                              <StatusBadge status={l.delivery_status} />
                            </div>
                            <p className="text-slate-600">{l.message}</p>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* 11. AI CHATBOT MANAGEMENT & SUPPORT TICKETS */}
              {tab === 'chatbot' && (
                <div className="space-y-6">
                  {/* Live Safety Guardrail Verification Sandbox */}
                  <div className="card-surface p-6 space-y-4">
                    <h2 className="text-base font-bold text-navy">
                      AI Patient-Support Assistant & Safety Guardrail Tester
                    </h2>
                    <p className="text-xs text-slate-500">
                      Mandatory clinical locks: refuses diagnosis, refuses medicine/dosage advice, and immediately directs emergencies to 112 / 108.
                    </p>
                    <div className="flex flex-wrap gap-2">
                      {[
                        'I have severe chest pain and breathlessness',
                        'Suggest a homoeopathic medicine and dosage for PCOS',
                        'What are Dr. Aparna Mishra’s consultation timings and fees?',
                      ].map((sample) => (
                        <button
                          key={sample}
                          type="button"
                          onClick={async () => {
                            setTestPrompt(sample);
                            const r = await apiFetch('/api/chatbot', {
                              method: 'POST',
                              headers: { 'Content-Type': 'application/json' },
                              body: JSON.stringify({ message: sample }),
                            });
                            setTestResult(await r.json());
                          }}
                          className="rounded-full bg-aqua px-3 py-1.5 text-xs font-semibold text-navy hover:bg-teal hover:text-white"
                        >
                          Test: “{sample.slice(0, 42)}…”
                        </button>
                      ))}
                    </div>
                    {testResult && (
                      <div className="rounded-xl bg-surface-muted border border-slate-200 p-4 text-xs space-y-1">
                        <p className="font-bold text-navy">
                          Prompt: “{testPrompt}” · Guardrail:{' '}
                          <span className="text-teal">
                            {testResult.safetyTriggered || testResult.category}
                          </span>
                        </p>
                        <p className="text-slate-700 whitespace-pre-line">{testResult.reply}</p>
                      </div>
                    )}
                  </div>

                  {/* Support Enquiries / Human Escalations */}
                  <div className="card-surface p-6 space-y-4">
                    <h3 className="text-sm font-bold text-navy">
                      Patient Support Tickets & Human Escalations
                    </h3>
                    {(adminData.supportTickets || []).map((t: any) => (
                      <div key={t.id} className="rounded-xl bg-surface-muted p-4 space-y-2.5 text-xs">
                        <div className="flex justify-between">
                          <span className="font-bold text-navy">
                            {t.ticket_no} · {t.sender_name} ({t.sender_email}) — {t.subject}
                          </span>
                          <StatusBadge status={t.status} />
                        </div>
                        <p className="text-slate-700">{t.message}</p>
                        {t.staff_reply ? (
                          <p className="text-teal font-medium">
                            Replied ({t.replied_by}): {t.staff_reply}
                          </p>
                        ) : (
                          <div className="flex gap-2">
                            <input
                              type="text"
                              placeholder="Type official clinic response..."
                              value={ticketReplies[t.id] || ''}
                              onChange={(e) =>
                                setTicketReplies({ ...ticketReplies, [t.id]: e.target.value })
                              }
                              className="input-field py-1.5 text-xs flex-1"
                            />
                            <button
                              type="button"
                              onClick={() =>
                                postAdmin(
                                  {
                                    action: 'REPLY_TICKET',
                                    ticketId: t.id,
                                    reply: ticketReplies[t.id] || '',
                                  },
                                  'Reply sent to patient.'
                                )
                              }
                              className="btn-primary py-1.5 px-3.5 text-xs"
                            >
                              Send Reply
                            </button>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* 12. WEBSITE CONTENT MANAGEMENT (CMS) */}
              {tab === 'cms' && isDoctorOrAdmin && (
                <div className="space-y-6">
                  {/* Doctor Profile Live Editor */}
                  <div className="card-surface p-6 space-y-4">
                    <h2 className="text-base font-bold text-navy">
                      Doctor Profile & Clinic Contact (Live on Public Website)
                    </h2>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                      <div>
                        <label className="label-text">Doctor Name</label>
                        <input
                          type="text"
                          value={docDraft.display_name || ''}
                          onChange={(e) => setDocDraft({ ...docDraft, display_name: e.target.value })}
                          className="input-field text-xs"
                        />
                      </div>
                      <div>
                        <label className="label-text">Qualification</label>
                        <input
                          type="text"
                          value={docDraft.qualification || ''}
                          onChange={(e) => setDocDraft({ ...docDraft, qualification: e.target.value })}
                          className="input-field text-xs"
                        />
                      </div>
                      <div>
                        <label className="label-text">Experience (Years)</label>
                        <input
                          type="number"
                          value={docDraft.experience_years || 7}
                          onChange={(e) =>
                            setDocDraft({ ...docDraft, experience_years: Number(e.target.value) })
                          }
                          className="input-field text-xs"
                        />
                      </div>
                      <div>
                        <label className="label-text">Council Registration No.</label>
                        <input
                          type="text"
                          value={docDraft.registration_number || ''}
                          onChange={(e) =>
                            setDocDraft({ ...docDraft, registration_number: e.target.value })
                          }
                          className="input-field text-xs"
                        />
                      </div>
                      <div>
                        <label className="label-text">Phone / WhatsApp</label>
                        <input
                          type="text"
                          value={docDraft.phone || ''}
                          onChange={(e) => setDocDraft({ ...docDraft, phone: e.target.value })}
                          className="input-field text-xs"
                        />
                      </div>
                      <div>
                        <label className="label-text">Professional Email</label>
                        <input
                          type="email"
                          value={docDraft.email || ''}
                          onChange={(e) => setDocDraft({ ...docDraft, email: e.target.value })}
                          className="input-field text-xs"
                        />
                      </div>
                      <div>
                        <label className="label-text">Website Tagline</label>
                        <input
                          type="text"
                          value={docDraft.tagline || ''}
                          onChange={(e) => setDocDraft({ ...docDraft, tagline: e.target.value })}
                          className="input-field text-xs"
                        />
                      </div>
                      <div>
                        <label className="label-text">Timings Display</label>
                        <input
                          type="text"
                          value={docDraft.timings_summary || ''}
                          onChange={(e) =>
                            setDocDraft({ ...docDraft, timings_summary: e.target.value })
                          }
                          className="input-field text-xs"
                        />
                      </div>
                      <div>
                        <label className="label-text">PhonePe / UPI ID</label>
                        <input
                          type="text"
                          value={docDraft.upi_id || ''}
                          onChange={(e) => setDocDraft({ ...docDraft, upi_id: e.target.value })}
                          className="input-field text-xs font-mono"
                        />
                      </div>
                    </div>
                    <textarea
                      rows={2}
                      value={docDraft.bio || ''}
                      onChange={(e) => setDocDraft({ ...docDraft, bio: e.target.value })}
                      className="input-field text-xs"
                    />
                    <button
                      type="button"
                      onClick={() => postAdmin({ action: 'UPDATE_DOCTOR_PROFILE', ...docDraft })}
                      className="btn-primary text-xs"
                    >
                      Publish Doctor Profile Changes
                    </button>
                  </div>

                  {/* Clinic Announcement Banner */}
                  <div className="card-surface p-6 space-y-3">
                    <h3 className="text-sm font-bold text-navy">Top Clinic Announcement Banner</h3>
                    <div className="flex flex-col sm:flex-row gap-2">
                      <input
                        type="text"
                        value={annText}
                        onChange={(e) => setAnnText(e.target.value)}
                        className="input-field text-xs flex-1"
                      />
                      <button
                        type="button"
                        onClick={() =>
                          postAdmin(
                            {
                              action: 'SAVE_ANNOUNCEMENT',
                              id: adminData.cms.announcements[0]?.id,
                              title: 'Notice',
                              message: annText,
                              is_active: Boolean(annText.trim()),
                            },
                            'Announcement updated.'
                          )
                        }
                        className="btn-secondary text-xs py-2 px-4"
                      >
                        Update Banner
                      </button>
                    </div>
                  </div>

                  {/* Blog & FAQ Manager */}
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <div className="card-surface p-6 space-y-3">
                      <h3 className="text-sm font-bold text-navy">Publish Health & Wellness Article</h3>
                      <input
                        type="text"
                        placeholder="Article title"
                        value={newArticle.title}
                        onChange={(e) => setNewArticle({ ...newArticle, title: e.target.value })}
                        className="input-field text-xs"
                      />
                      <select
                        value={newArticle.category}
                        onChange={(e) => setNewArticle({ ...newArticle, category: e.target.value })}
                        className="input-field text-xs"
                      >
                        <option>Women&apos;s Health</option>
                        <option>Thyroid Health</option>
                        <option>Skin &amp; Hair</option>
                        <option>Digestive Health</option>
                        <option>Joint Health</option>
                        <option>Respiratory Health</option>
                      </select>
                      <textarea
                        rows={3}
                        placeholder="Doctor-approved educational article body..."
                        value={newArticle.content}
                        onChange={(e) => setNewArticle({ ...newArticle, content: e.target.value })}
                        className="input-field text-xs"
                      />
                      <button
                        type="button"
                        onClick={async () => {
                          const ok = await postAdmin(
                            { action: 'ADD_ARTICLE', ...newArticle },
                            'Article published!'
                          );
                          if (ok) setNewArticle({ title: '', category: "Women's Health", excerpt: '', content: '' });
                        }}
                        className="btn-primary py-2 px-4 text-xs"
                      >
                        Publish Article
                      </button>
                    </div>

                    <div className="card-surface p-6 space-y-3">
                      <h3 className="text-sm font-bold text-navy">Add Website FAQ</h3>
                      <input
                        type="text"
                        placeholder="Question"
                        value={newFaq.question}
                        onChange={(e) => setNewFaq({ ...newFaq, question: e.target.value })}
                        className="input-field text-xs"
                      />
                      <textarea
                        rows={3}
                        placeholder="Clear patient-friendly answer..."
                        value={newFaq.answer}
                        onChange={(e) => setNewFaq({ ...newFaq, answer: e.target.value })}
                        className="input-field text-xs"
                      />
                      <button
                        type="button"
                        onClick={async () => {
                          const ok = await postAdmin({ action: 'ADD_FAQ', ...newFaq }, 'FAQ added!');
                          if (ok) setNewFaq({ ...newFaq, question: '', answer: '' });
                        }}
                        className="btn-primary py-2 px-4 text-xs"
                      >
                        Add FAQ
                      </button>
                    </div>
                  </div>

                  {/* Patient Feedback Moderation */}
                  <div className="card-surface p-6 space-y-3">
                    <h3 className="text-sm font-bold text-navy">Patient Feedback Moderation</h3>
                    {(adminData.cms.reviews || []).map((r: any) => (
                      <div
                        key={r.id}
                        className="flex flex-wrap items-center justify-between gap-3 rounded-xl bg-surface-muted p-3 text-xs"
                      >
                        <div>
                          <strong>{r.patient_initials}</strong> ({r.rating}/5 · {r.concern_area}): “
                          {r.comment}”
                        </div>
                        <button
                          type="button"
                          onClick={() =>
                            postAdmin({ action: 'TOGGLE_FEEDBACK', id: r.id }, 'Review visibility updated.')
                          }
                          className="btn-secondary py-1 px-3 text-xs"
                        >
                          {r.is_approved ? 'Hide' : 'Approve'}
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* 13. ANALYTICS & REPORTS */}
              {tab === 'analytics' && (
                <div className="space-y-6">
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <p className="text-xs text-slate-600">
                      Real-time clinic performance across appointments, consultation areas, and payment channels.
                    </p>
                    {isDoctorOrAdmin && (
                      <a href={`/api/admin/backup?format=csv&_st=${encodeURIComponent(sessionToken)}`} className="btn-primary py-2 px-4 text-xs">
                        <Download className="h-3.5 w-3.5" /> Export Appointments CSV
                      </a>
                    )}
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="card-surface p-6 space-y-3">
                      <h3 className="text-sm font-bold text-navy">Appointments by Status</h3>
                      {(adminData.analytics.byStatus || []).map((s: any) => (
                        <div
                          key={s.label}
                          className="flex items-center justify-between rounded-xl bg-surface-muted px-4 py-2.5 text-xs"
                        >
                          <StatusBadge status={s.label} />
                          <span className="font-bold text-navy tabular">{s.count}</span>
                        </div>
                      ))}
                    </div>

                    <div className="card-surface p-6 space-y-3">
                      <h3 className="text-sm font-bold text-navy">Schedule Volume by Date</h3>
                      {(adminData.analytics.byDate || []).map((d: any) => (
                        <div
                          key={d.date}
                          className="flex items-center justify-between rounded-xl bg-surface-muted px-4 py-2.5 text-xs tabular"
                        >
                          <span className="font-medium text-navy">{d.date}</span>
                          <span className="text-teal font-bold">
                            {d.count} bookings · ₹{d.revenue}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* 14. STAFF MANAGEMENT */}
              {tab === 'staff' && isDoctorOrAdmin && (
                <div className="space-y-6">
                  <div className="card-surface p-6 space-y-4">
                    <h2 className="text-base font-bold text-navy">Add Clinic Staff Member</h2>
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
                      <input
                        type="text"
                        placeholder="Staff Full Name"
                        value={newStaff.fullName}
                        onChange={(e) => setNewStaff({ ...newStaff, fullName: e.target.value })}
                        className="input-field text-xs"
                      />
                      <input
                        type="email"
                        placeholder="Email"
                        value={newStaff.email}
                        onChange={(e) => setNewStaff({ ...newStaff, email: e.target.value })}
                        className="input-field text-xs"
                      />
                      <input
                        type="tel"
                        placeholder="Phone"
                        value={newStaff.phone}
                        onChange={(e) => setNewStaff({ ...newStaff, phone: e.target.value })}
                        className="input-field text-xs"
                      />
                      <input
                        type="text"
                        placeholder="Designation"
                        value={newStaff.designation}
                        onChange={(e) => setNewStaff({ ...newStaff, designation: e.target.value })}
                        className="input-field text-xs"
                      />
                      <input
                        type="password"
                        placeholder="Temp Password (8+)"
                        value={newStaff.password}
                        onChange={(e) => setNewStaff({ ...newStaff, password: e.target.value })}
                        className="input-field text-xs"
                      />
                    </div>
                    <button
                      type="button"
                      onClick={async () => {
                        const ok = await postAdmin({ action: 'ADD_STAFF', ...newStaff }, 'Staff account created!');
                        if (ok)
                          setNewStaff({
                            fullName: '',
                            email: '',
                            phone: '',
                            designation: 'Appointment & Care Coordinator',
                            password: '',
                          });
                      }}
                      className="btn-primary py-2 px-4 text-xs"
                    >
                      Create Staff Account
                    </button>
                  </div>

                  <div className="space-y-3">
                    {(adminData.staffList || []).map((s: any) => (
                      <div
                        key={s.id}
                        className="card-surface p-5 flex flex-wrap items-center justify-between gap-3 text-xs"
                      >
                        <div>
                          <p className="text-sm font-bold text-navy">
                            {s.full_name} ({s.staff_code})
                          </p>
                          <p className="text-slate-500">
                            {s.designation} · {s.email} · {s.phone || '—'}
                          </p>
                        </div>
                        <div className="flex items-center gap-2">
                          <StatusBadge status={s.is_active ? 'ACTIVE' : 'CANCELLED'} />
                          <button
                            type="button"
                            onClick={() =>
                              postAdmin(
                                { action: 'TOGGLE_STAFF_ACTIVE', userId: s.user_id },
                                'Staff status updated.'
                              )
                            }
                            className="btn-secondary py-1.5 px-3 text-xs"
                          >
                            {s.is_active ? 'Deactivate' : 'Reactivate'}
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* 15. ROLES & PERMISSIONS */}
              {tab === 'roles' && (
                <div className="card-surface p-6 overflow-x-auto">
                  <h2 className="text-base font-bold text-navy mb-1">
                    Enforced Role-Based Access Control (RBAC) Matrix
                  </h2>
                  <p className="text-xs text-slate-500 mb-4">
                    Enforced server-side across every API route, PDF generator, and encrypted report download.
                  </p>
                  <table className="w-full text-left text-xs">
                    <thead>
                      <tr className="border-b border-slate-200 text-slate-500 uppercase">
                        <th className="py-2.5 pr-4">Platform Capability</th>
                        <th className="py-2.5 px-3">Doctor</th>
                        <th className="py-2.5 px-3">Admin</th>
                        <th className="py-2.5 px-3">Clinic Staff</th>
                        <th className="py-2.5 pl-3">Patient</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {RBAC_MATRIX.map((r) => (
                        <tr key={r.capability}>
                          <td className="py-3 pr-4 font-medium text-navy">{r.capability}</td>
                          {[r.doctor, r.admin, r.staff, r.patient].map((cell, i) => (
                            <td key={i} className="py-3 px-3">
                              {cell === true ? (
                                <span className="font-bold text-emerald-700">Allowed</span>
                              ) : cell === false ? (
                                <span className="text-slate-400">Restricted</span>
                              ) : (
                                <span className="font-semibold text-teal">{cell}</span>
                              )}
                            </td>
                          ))}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}

              {/* 16. SECURITY, INTEGRATIONS, DPDP CONSENTS, AUDIT LOGS & BACKUPS */}
              {tab === 'security' && isDoctorOrAdmin && (
                <div className="space-y-6">
                  <div className="card-surface p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div>
                      <h2 className="text-base font-bold text-navy">
                        Clinic Data Backup & Disaster Recovery
                      </h2>
                      <p className="text-xs text-slate-500">
                        Download an on-demand JSON recovery snapshot (excludes password & OTP hashes; logged in Audit Trail).
                      </p>
                    </div>
                    <a href={`/api/admin/backup?_st=${encodeURIComponent(sessionToken)}`} className="btn-navy py-2.5 px-4 text-xs shrink-0">
                      <Download className="h-4 w-4" /> Download Recovery Backup
                    </a>
                  </div>

                  {/* External Service Integration Status */}
                  <div className="card-surface p-6 space-y-3">
                    <h3 className="text-sm font-bold text-navy">
                      Integration & Security Posture
                    </h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      {(adminData.integrations || []).map((ig: any) => (
                        <div key={ig.key} className="rounded-xl bg-surface-muted p-4 text-xs space-y-1.5">
                          <div className="flex items-center justify-between gap-2">
                            <strong className="text-navy">{ig.name}</strong>
                            <StatusBadge status={ig.status} />
                          </div>
                          <p className="text-slate-600 leading-relaxed">{ig.detail}</p>
                          <p className="text-[10.5px] font-mono text-slate-400">
                            Env: {ig.envVars.join(', ')}
                          </p>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Immutable Security Audit Logs */}
                  <div className="card-surface p-6 space-y-3">
                    <h3 className="text-sm font-bold text-navy">
                      Immutable Security & Clinical Audit Logs (Latest 80)
                    </h3>
                    <div className="max-h-80 overflow-y-auto divide-y divide-slate-100 text-xs">
                      {(adminData.auditLogs || []).map((log: any) => (
                        <div key={log.id} className="py-2.5 flex flex-wrap items-center justify-between gap-2">
                          <div>
                            <span className="font-mono font-bold text-teal">{log.action}</span>{' '}
                            <span className="text-navy font-medium">by {log.actor_name}</span>{' '}
                            <span className="text-slate-400">({log.actor_role})</span>
                            {log.details && (
                              <p className="text-slate-600 text-[11.5px]">{log.details}</p>
                            )}
                          </div>
                          <span className="text-[11px] text-slate-400 tabular">{log.created_at}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </>
          )}
        </main>
      </div>

      {/* Doctor Consultation Notes Modal */}
      {activeCons && isDoctor && (
        <div className="fixed inset-0 z-50 bg-navy/50 flex items-center justify-center p-4">
          <form
            onSubmit={saveConsultationNotes}
            className="card-surface max-w-lg w-full p-6 space-y-3.5 max-h-[90vh] overflow-y-auto"
          >
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-navy">
                Clinical Case Notes · {activeCons.patient_display_name}
              </h3>
              <button type="button" onClick={() => setActiveCons(null)}>
                <X className="h-4 w-4" />
              </button>
            </div>
            <div>
              <label className="label-text">Provisional Impression</label>
              <input
                type="text"
                value={activeCons.provisional_impression || ''}
                onChange={(e) =>
                  setActiveCons({ ...activeCons, provisional_impression: e.target.value })
                }
                className="input-field text-xs"
              />
            </div>
            <div>
              <label className="label-text">Private Clinical & Homoeopathic Case Notes</label>
              <textarea
                rows={3}
                value={activeCons.clinical_notes || ''}
                onChange={(e) => setActiveCons({ ...activeCons, clinical_notes: e.target.value })}
                className="input-field text-xs"
              />
            </div>
            <div>
              <label className="label-text">Patient Care Advice & Follow-Up Plan</label>
              <textarea
                rows={2}
                value={activeCons.advice || ''}
                onChange={(e) => setActiveCons({ ...activeCons, advice: e.target.value })}
                className="input-field text-xs"
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="label-text">Follow-Up Date</label>
                <input
                  type="date"
                  value={activeCons.followup_date || ''}
                  onChange={(e) => setActiveCons({ ...activeCons, followup_date: e.target.value })}
                  className="input-field text-xs"
                />
              </div>
              <label className="flex items-center gap-2 text-xs font-semibold text-navy pt-5">
                <input
                  type="checkbox"
                  checked={Boolean(activeCons.markCompleted)}
                  onChange={(e) =>
                    setActiveCons({ ...activeCons, markCompleted: e.target.checked })
                  }
                  className="h-4 w-4 rounded text-teal"
                />
                Mark Consultation Completed
              </label>
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setActiveCons(null)}
                className="btn-secondary py-2 px-4 text-xs"
              >
                Cancel
              </button>
              <button type="submit" className="btn-primary py-2 px-4 text-xs">
                Save Notes
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Admin Reschedule Modal */}
      {reschedTarget && (
        <div className="fixed inset-0 z-50 bg-navy/50 flex items-center justify-center p-4">
          <div className="card-surface max-w-sm w-full p-6 space-y-4">
            <h3 className="text-base font-bold text-navy">
              Reschedule {reschedTarget.reference_no}
            </h3>
            <div>
              <label className="label-text">New Date (Mon–Sat)</label>
              <input
                type="date"
                value={reschedDate}
                onChange={(e) => setReschedDate(e.target.value)}
                className="input-field text-xs"
              />
            </div>
            <div>
              <label className="label-text">Start Time (3:00 PM – 8:00 PM)</label>
              <select
                value={reschedTime}
                onChange={(e) => setReschedTime(e.target.value)}
                className="input-field text-xs"
              >
                {['15:00', '15:30', '16:00', '16:30', '17:00', '17:30', '18:00', '18:30', '19:00', '19:30'].map(
                  (t) => (
                    <option key={t} value={t}>
                      {fmt12(t)} IST
                    </option>
                  )
                )}
              </select>
            </div>
            <div className="flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setReschedTarget(null)}
                className="btn-secondary py-2 px-3 text-xs"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  updateAppointment(
                    reschedTarget.id,
                    { action: 'RESCHEDULE', appointmentDate: reschedDate, startTime: reschedTime },
                    'Rescheduled & notified patient!'
                  );
                  setReschedTarget(null);
                }}
                className="btn-primary py-2 px-4 text-xs"
              >
                Confirm Reschedule
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
