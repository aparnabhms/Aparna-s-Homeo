import React from 'react';

export function BrandMark({ className = 'h-8 w-8' }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 40 40"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      aria-hidden="true"
    >
      <rect width="40" height="40" rx="11" fill="#153B5B" />
      <path
        d="M20 10V30M10 20H30"
        stroke="#FFFFFF"
        strokeWidth="2.8"
        strokeLinecap="round"
      />
      <path
        d="M20 20C20 14.5 24.5 11.5 28.5 11.5C28.5 15.5 25.5 20 20 20Z"
        fill="#168B83"
        stroke="#EAF4F5"
        strokeWidth="1.4"
        strokeLinejoin="round"
      />
    </svg>
  );
}

/**
 * Clean, calm clinical line illustrations for Dr. Aparna Mishra's Areas of Consultation
 */
export function ServiceIllustration({
  iconKey,
  className = 'h-12 w-12',
}: {
  iconKey: string;
  className?: string;
}) {
  switch (iconKey) {
    case 'womens':
      return (
        <svg viewBox="0 0 48 48" fill="none" className={className} aria-hidden="true">
          <rect width="48" height="48" rx="14" fill="#EAF4F5" />
          <path
            d="M24 34C24 34 13 27.2 13 19.5C13 15.9 15.8 13 19.3 13C21.4 13 23.1 14.1 24 15.6C24.9 14.1 26.6 13 28.7 13C32.2 13 35 15.9 35 19.5C35 27.2 24 34 24 34Z"
            fill="#FFFFFF"
            stroke="#153B5B"
            strokeWidth="2"
            strokeLinejoin="round"
          />
          <path
            d="M24 19.5C24 23.5 21 26 21 26M24 19.5C24 23.5 27 26 27 26M24 18V29"
            stroke="#168B83"
            strokeWidth="1.9"
            strokeLinecap="round"
          />
        </svg>
      );
    case 'thyroid':
      return (
        <svg viewBox="0 0 48 48" fill="none" className={className} aria-hidden="true">
          <rect width="48" height="48" rx="14" fill="#EAF4F5" />
          <path d="M24 11V37" stroke="#153B5B" strokeWidth="2" strokeLinecap="round" strokeDasharray="2.5 2.5" />
          <path
            d="M22 22C19.5 16.5 14 15.5 13 20C12 24.5 13.5 32 18 32C20.5 32 22 28.5 24 26C26 28.5 27.5 32 30 32C34.5 32 36 24.5 35 20C34 15.5 28.5 16.5 26 22C25.2 23.2 22.8 23.2 22 22Z"
            fill="#FFFFFF"
            stroke="#168B83"
            strokeWidth="2.1"
            strokeLinejoin="round"
          />
        </svg>
      );
    case 'skin':
      return (
        <svg viewBox="0 0 48 48" fill="none" className={className} aria-hidden="true">
          <rect width="48" height="48" rx="14" fill="#EAF4F5" />
          <rect x="11" y="22" width="26" height="13" rx="4" fill="#FFFFFF" stroke="#153B5B" strokeWidth="2" />
          <path d="M12 27.5C16 25.5 20 29.5 24 27.5C28 25.5 32 29.5 36 27.5" stroke="#168B83" strokeWidth="1.8" strokeLinecap="round" />
          <path d="M22 26C22 19.5 25 15 28.5 12" stroke="#153B5B" strokeWidth="2.1" strokeLinecap="round" />
          <circle cx="32" cy="16" r="2.2" fill="#168B83" />
        </svg>
      );
    case 'digestive':
      return (
        <svg viewBox="0 0 48 48" fill="none" className={className} aria-hidden="true">
          <rect width="48" height="48" rx="14" fill="#EAF4F5" />
          <path
            d="M23 11V16.5C23 18 26.5 17 29.5 19C33.5 21.6 34 27.5 30 31C26.5 34 20 33.5 17.5 31C15.5 29 15.5 26 17.5 24.5C19.5 23 21.5 24 22 22C22.4 20.4 20 19 20 16.5"
            fill="#FFFFFF"
            stroke="#153B5B"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          <path d="M18 32.5V37" stroke="#168B83" strokeWidth="2.1" strokeLinecap="round" />
          <path d="M25 25.5C27 25.5 28.5 27 27.5 29" stroke="#168B83" strokeWidth="1.9" strokeLinecap="round" />
        </svg>
      );
    case 'joint':
      return (
        <svg viewBox="0 0 48 48" fill="none" className={className} aria-hidden="true">
          <rect width="48" height="48" rx="14" fill="#EAF4F5" />
          <path
            d="M21 11V18C19 19 18.5 21.5 21 22H27C29.5 21.5 29 19 27 18V11"
            fill="#FFFFFF"
            stroke="#153B5B"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          <path
            d="M21 37V30C19 29 18.5 26.5 21 26H27C29.5 26.5 29 29 27 30V37"
            fill="#FFFFFF"
            stroke="#153B5B"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          <path d="M14 24H17M31 24H34" stroke="#168B83" strokeWidth="2.2" strokeLinecap="round" />
          <circle cx="24" cy="24" r="2" fill="#168B83" />
        </svg>
      );
    case 'respiratory':
      return (
        <svg viewBox="0 0 48 48" fill="none" className={className} aria-hidden="true">
          <rect width="48" height="48" rx="14" fill="#EAF4F5" />
          <path
            d="M21 17C16.5 17.5 12 23 12 30.5C12 33.5 14.2 35 17 34.5C20 34 21.8 32 21.8 29V17H21Z"
            fill="#FFFFFF"
            stroke="#153B5B"
            strokeWidth="2"
            strokeLinejoin="round"
          />
          <path
            d="M27 17C31.5 17.5 36 23 36 30.5C36 33.5 33.8 35 31 34.5C28 34 26.2 32 26.2 29V17H27Z"
            fill="#FFFFFF"
            stroke="#153B5B"
            strokeWidth="2"
            strokeLinejoin="round"
          />
          <path d="M24 11V22M24 21L18 26M24 21L30 26" stroke="#168B83" strokeWidth="2" strokeLinecap="round" />
        </svg>
      );
    default:
      return (
        <svg viewBox="0 0 48 48" fill="none" className={className} aria-hidden="true">
          <rect width="48" height="48" rx="14" fill="#EAF4F5" />
          <circle cx="24" cy="24" r="12" fill="#FFFFFF" stroke="#153B5B" strokeWidth="2" />
          <path d="M24 18V30M18 24H30" stroke="#168B83" strokeWidth="2.4" strokeLinecap="round" />
        </svg>
      );
  }
}

export function GoogleIcon({ className = 'h-4 w-4' }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={className} aria-hidden="true">
      <path fill="#4285F4" d="M23.49 12.27c0-.79-.07-1.54-.19-2.27H12v4.51h6.47c-.29 1.48-1.14 2.73-2.4 3.58v3h3.86c2.26-2.09 3.56-5.17 3.56-8.82z" />
      <path fill="#34A853" d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.86-3c-1.08.72-2.45 1.16-4.07 1.16-3.13 0-5.78-2.11-6.73-4.96H1.29v3.09C3.26 21.3 7.31 24 12 24z" />
      <path fill="#FBBC05" d="M5.27 14.29c-.25-.72-.38-1.49-.38-2.29s.14-1.57.38-2.29V6.62H1.29C.47 8.24 0 10.06 0 12s.47 3.76 1.29 5.38l3.98-3.09z" />
      <path fill="#EA4335" d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.31 0 3.26 2.7 1.29 6.62l3.98 3.09c.95-2.85 3.6-4.96 6.73-4.96z" />
    </svg>
  );
}

export function AppleIcon({ className = 'h-4 w-4' }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" className={className} aria-hidden="true">
      <path d="M17.05 20.28c-.98.95-2.05.8-3.08.35-1.09-.46-2.09-.48-3.24 0-1.44.62-2.2.44-3.06-.35C2.79 15.25 3.51 7.59 9.05 7.31c1.35.07 2.29.74 3.08.8 1.18-.24 2.31-.93 3.57-.84 1.51.12 2.65.72 3.4 1.8-3.12 1.87-2.38 5.98.48 7.13-.57 1.5-1.31 2.99-2.53 4.08zM12.03 7.25c-.15-2.23 1.66-4.07 3.74-4.25.29 2.58-2.34 4.5-3.74 4.25z" />
    </svg>
  );
}

export function StatusBadge({ status }: { status: string }) {
  const map: Record<string, string> = {
    CONFIRMED: 'bg-emerald-50 text-emerald-700 border-emerald-200',
    PAID: 'bg-emerald-50 text-emerald-700 border-emerald-200',
    AUTHORISED: 'bg-emerald-50 text-emerald-700 border-emerald-200',
    REVIEWED: 'bg-emerald-50 text-emerald-700 border-emerald-200',
    READY: 'bg-teal-50 text-teal-700 border-teal-200',
    IN_PROGRESS: 'bg-sky-50 text-sky-700 border-sky-200',
    COMPLETED: 'bg-navy-50 text-navy border-navy-200',
    RESOLVED: 'bg-emerald-50 text-emerald-700 border-emerald-200',
    APPROVED: 'bg-emerald-50 text-emerald-700 border-emerald-200',
    ACTIVE: 'bg-emerald-50 text-emerald-700 border-emerald-200',
    PENDING: 'bg-amber-50 text-amber-700 border-amber-200',
    PENDING_VERIFICATION: 'bg-amber-50 text-amber-700 border-amber-200',
    PENDING_REVIEW: 'bg-amber-50 text-amber-700 border-amber-200',
    RESCHEDULED: 'bg-sky-50 text-sky-700 border-sky-200',
    SCHEDULED: 'bg-slate-100 text-slate-700 border-slate-200',
    DRAFT: 'bg-slate-100 text-slate-700 border-slate-200',
    OPEN: 'bg-amber-50 text-amber-700 border-amber-200',
    UNPAID: 'bg-slate-100 text-slate-600 border-slate-200',
    INITIATED: 'bg-slate-100 text-slate-600 border-slate-200',
    CANCELLED: 'bg-rose-50 text-rose-700 border-rose-200',
    REJECTED: 'bg-rose-50 text-rose-700 border-rose-200',
    FAILED: 'bg-rose-50 text-rose-700 border-rose-200',
    REFUNDED: 'bg-purple-50 text-purple-700 border-purple-200',
    QUEUED_SANDBOX: 'bg-amber-50 text-amber-700 border-amber-200',
    TEST_SANDBOX: 'bg-amber-50 text-amber-700 border-amber-200',
    DELIVERED: 'bg-emerald-50 text-emerald-700 border-emerald-200',
    SENT: 'bg-emerald-50 text-emerald-700 border-emerald-200',
  };
  const cls = map[status] || 'bg-slate-100 text-slate-700 border-slate-200';
  return (
    <span
      className={`inline-flex items-center rounded-full border px-2.5 py-0.5 text-[11px] font-semibold tracking-wide ${cls}`}
    >
      {status.replace(/_/g, ' ')}
    </span>
  );
}
