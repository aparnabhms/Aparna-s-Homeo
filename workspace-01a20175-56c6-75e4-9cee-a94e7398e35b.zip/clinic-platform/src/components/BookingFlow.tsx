'use client';

import React, { useState, useEffect, useCallback } from 'react';
import Link from 'next/link';
import {
  Building2,
  Calendar,
  Check,
  CheckCircle2,
  Clock,
  Copy,
  CreditCard,
  Download,
  Lock,
  Phone,
  QrCode,
  ShieldCheck,
  Smartphone,
  Upload,
  Video,
  Wallet,
  ArrowRight,
  AlertCircle,
} from 'lucide-react';
import GoogleSignInButton from './GoogleSignInButton';
import {
  authFetch,
  getClientSessionToken,
  saveClientSession,
} from '@/lib/clientSession';

export interface ConsultationTypeOption {
  id: string;
  name: string;
  description: string;
  mode: string;
  duration_minutes: number;
  fee_inr: number;
}

const CONCERN_AREAS = [
  "Women's Health",
  'Thyroid Health',
  'Skin & Hair',
  'Digestive Health',
  'Joint Health',
  'Respiratory Health',
  'General Wellness',
];

const INDIAN_BANKS = [
  'State Bank of India (SBI)',
  'HDFC Bank',
  'ICICI Bank',
  'Axis Bank',
  'Kotak Mahindra Bank',
  'Punjab National Bank (PNB)',
  'Bank of Baroda',
  'Canara Bank',
];

const WALLETS = [
  'PhonePe Wallet',
  'Paytm Wallet',
  'Amazon Pay Balance',
  'MobiKwik / ZIP Pay Later',
  'Freecharge',
];

function getDefaultBookingDate(): string {
  const d = new Date();
  d.setDate(d.getDate() + 1);
  if (d.getDay() === 0) d.setDate(d.getDate() + 1); // Skip Sunday
  return d.toISOString().slice(0, 10);
}

export default function BookingFlow({
  consultationTypes,
  initialConcern,
  initialTypeId,
  initialUser,
  sessionToken,
  onBooked,
  compact = false,
}: {
  consultationTypes: ConsultationTypeOption[];
  initialConcern?: string;
  initialTypeId?: string;
  initialUser?: { fullName: string; email: string; role: string } | null;
  sessionToken?: string;
  onBooked?: () => void;
  compact?: boolean;
}) {
  const [user, setUser] = useState(initialUser || null);
  const [activeToken, setActiveToken] = useState<string>(sessionToken || '');
  const [step, setStep] = useState<1 | 2 | 3 | 4>(1);

  // Step 1: Service & Slot
  const [selectedTypeId, setSelectedTypeId] = useState(
    initialTypeId || consultationTypes[0]?.id || 'ct_video_new'
  );
  const [concern, setConcern] = useState(
    initialConcern && CONCERN_AREAS.includes(initialConcern) ? initialConcern : CONCERN_AREAS[0]
  );
  const [date, setDate] = useState(getDefaultBookingDate());
  const [slotsData, setSlotsData] = useState<{
    available: boolean;
    reason?: string;
    dayName: string;
    slots: Array<{ startTime: string; endTime: string; label: string; isBooked: boolean }>;
  } | null>(null);
  const [slotsLoading, setSlotsLoading] = useState(false);
  const [selectedSlot, setSelectedSlot] = useState('');

  // Step 2: Inline Auth (if guest) + Patient Details (Google or Gmail/Password — no OTP clutter)
  const [authTab, setAuthTab] = useState<'login' | 'register'>('login');
  const [authEmail, setAuthEmail] = useState('');
  const [authPass, setAuthPass] = useState('');
  const [authName, setAuthName] = useState('');
  const [authPhone, setAuthPhone] = useState('');
  const [authBusy, setAuthBusy] = useState(false);
  const [authErr, setAuthErr] = useState('');

  const [forMinor, setForMinor] = useState(false);
  const [minorName, setMinorName] = useState('');
  const [callChannel, setCallChannel] = useState<
    'WHATSAPP_VIDEO' | 'WHATSAPP_AUDIO' | 'PHONE_AUDIO' | 'INAPP_VIDEO' | 'INAPP_AUDIO'
  >('WHATSAPP_VIDEO');
  const [chiefComplaint, setChiefComplaint] = useState('');
  const [symptomDuration, setSymptomDuration] = useState('');
  const [notesForDoctor, setNotesForDoctor] = useState('');
  const [teleConsent, setTeleConsent] = useState(true);

  // Step 3: Payment
  const [bookingBusy, setBookingBusy] = useState(false);
  const [bookingError, setBookingError] = useState('');
  const [createdBooking, setCreatedBooking] = useState<{
    appointment: {
      id: string;
      referenceNo: string;
      date: string;
      timeLabel: string;
      consultationType: string;
      concernCategory: string;
      feeInr: number;
    };
    payment: {
      id: string;
      receiptNo: string;
      amountInr: number;
      razorpay: { orderId: string; amountPaise?: number; currency?: string; keyId?: string; mode: string };
      upi: {
        upiUri: string;
        phonePeUri: string;
        gpayUri: string;
        paytmUri: string;
        upiId: string;
        payeeName: string;
        qrUrl: string;
      };
    };
  } | null>(null);

  type PayTab = 'PHONEPE_QR' | 'RAZORPAY_LIVE';
  const [payTab, setPayTab] = useState<PayTab>('PHONEPE_QR');
  const [utr, setUtr] = useState('');
  const [upiApp, setUpiApp] = useState('PhonePe');
  const [payerUpiId, setPayerUpiId] = useState(initialUser?.fullName || '');
  const [proofFile, setProofFile] = useState<File | null>(null);
  const [copiedUpi, setCopiedUpi] = useState(false);
  const [payBusy, setPayBusy] = useState(false);
  const [payErr, setPayErr] = useState('');

  // Step 4: Confirmed
  const [finalOutcome, setFinalOutcome] = useState<{
    paymentStatus: string;
    appointmentStatus: string;
    receiptNo: string;
    message?: string;
  } | null>(null);

  const selectedType =
    consultationTypes.find((c) => c.id === selectedTypeId) || consultationTypes[0];

  const loadSlots = useCallback(async () => {
    if (!date || !selectedTypeId) return;
    setSlotsLoading(true);
    setSelectedSlot('');
    try {
      const res = await fetch(
        `/api/slots?date=${encodeURIComponent(date)}&consultationTypeId=${encodeURIComponent(selectedTypeId)}`
      );
      const data = await res.json();
      setSlotsData(data);
      const firstOpen = (data.slots || []).find((s: { isBooked: boolean }) => !s.isBooked);
      if (firstOpen) setSelectedSlot(firstOpen.startTime);
    } catch {
      setSlotsData({ available: false, reason: 'Could not load slots.', dayName: '', slots: [] });
    } finally {
      setSlotsLoading(false);
    }
  }, [date, selectedTypeId]);

  useEffect(() => {
    loadSlots();
  }, [loadSlots]);

  // Hydrate signed-in patient when third-party cookies are restricted in embedded preview
  useEffect(() => {
    if (sessionToken) {
      saveClientSession(sessionToken);
      setActiveToken(sessionToken);
    }
    if (user) return;
    const tok = getClientSessionToken(sessionToken);
    if (!tok) return;
    authFetch('/api/auth/me', undefined, tok)
      .then((r) => (r.ok ? r.json() : null))
      .then((d) => {
        if (d?.user) {
          setUser(d.user);
          setActiveToken(tok);
        }
      })
      .catch(() => {});
  }, [user, sessionToken]);

  async function handleInlineAuth(e: React.FormEvent) {
    e.preventDefault();
    setAuthBusy(true);
    setAuthErr('');
    try {
      const url = authTab === 'login' ? '/api/auth/login' : '/api/auth/register';
      const payload =
        authTab === 'login'
          ? { method: 'EMAIL', email: authEmail, password: authPass }
          : {
              fullName: authName,
              email: authEmail,
              phone: authPhone,
              password: authPass,
              dpdpConsent: true,
              telemedicineConsent: true,
              whatsappConsent: true,
            };
      const res = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (!res.ok) {
        setAuthErr(data.error || 'Authentication failed.');
      } else {
        if (data.sessionToken) {
          saveClientSession(data.sessionToken);
          setActiveToken(data.sessionToken);
        }
        setUser(data.user);
      }
    } finally {
      setAuthBusy(false);
    }
  }

  async function handleDemoPatientAuth() {
    setAuthBusy(true);
    setAuthErr('');
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ method: 'DEMO_QUICK', demoAccount: 'PATIENT' }),
      });
      const data = await res.json();
      if (res.ok) {
        if (data.sessionToken) {
          saveClientSession(data.sessionToken);
          setActiveToken(data.sessionToken);
        }
        setUser(data.user);
      }
    } finally {
      setAuthBusy(false);
    }
  }

  async function handleReserveAndProceedToPayment(e: React.FormEvent) {
    e.preventDefault();
    setBookingBusy(true);
    setBookingError('');
    try {
      const res = await authFetch(
        '/api/appointments',
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            consultationTypeId: selectedTypeId,
            concernCategory: concern,
            appointmentDate: date,
            startTime: selectedSlot,
            chiefComplaint,
            symptomDuration,
            notesForDoctor,
            forMinor,
            minorName,
            callChannel,
            telemedicineConsent: teleConsent,
          }),
        },
        activeToken || sessionToken
      );
      const data = await res.json();
      if (!res.ok) {
        setBookingError(data.error || 'Unable to book selected slot.');
        return;
      }
      setCreatedBooking(data);
      setStep(3);
    } catch {
      setBookingError('Network error while reserving appointment.');
    } finally {
      setBookingBusy(false);
    }
  }

  async function handleCompletePayment(e: React.FormEvent) {
    e.preventDefault();
    if (!createdBooking) return;
    setPayBusy(true);
    setPayErr('');

    try {
      if (payTab === 'PHONEPE_QR') {
        const digitsOnly = utr.replace(/\D/g, '');
        if (digitsOnly.length !== 12) {
          setPayErr('Please enter the exact 12-digit numeric UPI UTR / Ref No. from your payment receipt.');
          return;
        }
        const senderClean = (payerUpiId || user?.fullName || '').trim();
        if (senderClean.length < 3) {
          setPayErr('Please enter the Sender Name or UPI ID you paid from (e.g. yourname@ybl).');
          return;
        }
        if (!proofFile) {
          setPayErr(
            `Please upload the screenshot of your completed ₹${createdBooking.payment.amountInr} UPI payment so Dr. Aparna can verify it.`
          );
          return;
        }

        const fd = new FormData();
        fd.append('action', 'SUBMIT_UPI_UTR');
        fd.append('paymentId', createdBooking.payment.id);
        fd.append('utr', digitsOnly);
        fd.append('upiApp', upiApp);
        fd.append('payerUpiId', senderClean);
        fd.append('screenshot', proofFile);

        const res = await authFetch(
          '/api/payments',
          { method: 'POST', body: fd },
          activeToken || sessionToken
        );
        const data = await res.json();
        if (!res.ok) {
          setPayErr(data.error || 'Payment verification submission failed.');
          return;
        }
        setFinalOutcome({
          paymentStatus: data.paymentStatus,
          appointmentStatus: data.appointmentStatus,
          receiptNo: data.receiptNo,
          message: data.message,
        });
        setStep(4);
        onBooked?.();
        return;
      }

      // Live Razorpay SDK bank-verified checkout (active when RAZORPAY_KEY_ID & RAZORPAY_KEY_SECRET are set)
      if (createdBooking.payment.razorpay.mode !== 'LIVE_OR_TEST_API' || !createdBooking.payment.razorpay.keyId) {
        setPayErr(
          'Automatic gateway checkout requires live RAZORPAY_KEY_ID & RAZORPAY_KEY_SECRET in server .env. Please use PhonePe / UPI QR and upload your payment screenshot + 12-digit UTR.'
        );
        return;
      }

      const loadRzp = () =>
        new Promise<boolean>((resolve) => {
          if ((window as unknown as { Razorpay?: unknown }).Razorpay) return resolve(true);
          const s = document.createElement('script');
          s.src = 'https://checkout.razorpay.com/v1/checkout.js';
          s.onload = () => resolve(true);
          s.onerror = () => resolve(false);
          document.body.appendChild(s);
        });

      const sdkOk = await loadRzp();
      if (!sdkOk) {
        setPayErr('Unable to load Razorpay Checkout. Please use the PhonePe / UPI QR option.');
        return;
      }

      type RzpResponse = {
        razorpay_order_id: string;
        razorpay_payment_id: string;
        razorpay_signature: string;
      };
      const RzpCtor = (
        window as unknown as {
          Razorpay: new (opts: Record<string, unknown>) => { open: () => void };
        }
      ).Razorpay;

      const rzp = new RzpCtor({
        key: createdBooking.payment.razorpay.keyId,
        amount: createdBooking.payment.razorpay.amountPaise || createdBooking.payment.amountInr * 100,
        currency: 'INR',
        name: 'Dr. Aparna Mishra Digital Clinic',
        description: `${createdBooking.appointment.consultationType} (${createdBooking.appointment.referenceNo})`,
        order_id: createdBooking.payment.razorpay.orderId,
        prefill: { name: user?.fullName || '', email: user?.email || '' },
        theme: { color: '#0F766E' },
        handler: async (response: RzpResponse) => {
          const res = await authFetch(
            '/api/payments',
            {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                action: 'VERIFY_RAZORPAY',
                paymentId: createdBooking.payment.id,
                paymentMethod: 'UPI',
                razorpayOrderId: response.razorpay_order_id,
                razorpayPaymentId: response.razorpay_payment_id,
                razorpaySignature: response.razorpay_signature,
              }),
            },
            activeToken || sessionToken
          );
          const data = await res.json();
          if (!res.ok || !data.ok) {
            setPayErr(data.error || 'Bank signature verification failed.');
            return;
          }
          setFinalOutcome({
            paymentStatus: data.paymentStatus,
            appointmentStatus: data.appointmentStatus,
            receiptNo: data.receiptNo,
            message: data.message,
          });
          setStep(4);
          onBooked?.();
        },
      });
      rzp.open();
    } finally {
      setPayBusy(false);
    }
  }

  function copyUpi(val: string) {
    navigator.clipboard?.writeText(val);
    setCopiedUpi(true);
    setTimeout(() => setCopiedUpi(false), 2000);
  }

  const todayIso = new Date().toISOString().slice(0, 10);

  return (
    <div className="space-y-6">
      {/* Progress Stepper */}
      <div className="grid grid-cols-4 gap-2 sm:gap-3">
        {[
          { n: 1, label: 'Slot & Service' },
          { n: 2, label: 'Patient Details' },
          { n: 3, label: 'Payment' },
          { n: 4, label: 'Confirmation' },
        ].map((s) => {
          const active = step === s.n;
          const done = step > s.n;
          return (
            <div
              key={s.n}
              className={`rounded-xl border px-3 py-2.5 flex items-center gap-2.5 ${
                active
                  ? 'border-teal bg-aqua text-navy'
                  : done
                  ? 'border-emerald-200 bg-emerald-50/70 text-emerald-800'
                  : 'border-slate-200 bg-white text-slate-400'
              }`}
            >
              <span
                className={`flex h-6 w-6 shrink-0 items-center justify-center rounded-full text-xs font-bold ${
                  active
                    ? 'bg-teal text-white'
                    : done
                    ? 'bg-emerald-600 text-white'
                    : 'bg-slate-100 text-slate-500'
                }`}
              >
                {done ? <Check className="h-3.5 w-3.5" /> : s.n}
              </span>
              <span className="text-xs font-semibold truncate">{s.label}</span>
            </div>
          );
        })}
      </div>

      {/* STEP 1: CONSULTATION TYPE, CONCERN, DATE & TIME SLOT */}
      {step === 1 && (
        <div className="card-surface p-5 sm:p-7 space-y-6">
          <div>
            <h2 className="text-lg font-bold text-navy mb-1">1. Select Consultation Type</h2>
            <p className="text-xs text-slate-500 mb-4">
              All sessions are conducted privately online by Dr. Aparna Mishra (BHMS) · Mon–Sat, 3:00 PM – 8:00 PM IST.
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
              {consultationTypes.map((ct) => {
                const selected = ct.id === selectedTypeId;
                return (
                  <button
                    key={ct.id}
                    type="button"
                    onClick={() => setSelectedTypeId(ct.id)}
                    className={`text-left rounded-2xl border p-4 transition-all ${
                      selected
                        ? 'border-teal bg-aqua/70 ring-1 ring-teal'
                        : 'border-slate-200 bg-white hover:border-teal/40'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-3 mb-1.5">
                      <span className="font-heading text-sm font-bold text-navy">{ct.name}</span>
                      <span className="shrink-0 font-heading text-base font-bold text-teal tabular">
                        ₹{ct.fee_inr}
                      </span>
                    </div>
                    <p className="text-xs text-slate-600 leading-relaxed mb-2.5">
                      {ct.description}
                    </p>
                    <div className="flex items-center gap-3 text-[11px] font-semibold text-navy/80">
                      <span className="inline-flex items-center gap-1">
                        {ct.mode === 'AUDIO' ? (
                          <Phone className="h-3 w-3 text-teal" />
                        ) : (
                          <Video className="h-3 w-3 text-teal" />
                        )}
                        {ct.mode.replace('_', ' ')}
                      </span>
                      <span className="inline-flex items-center gap-1 tabular">
                        <Clock className="h-3 w-3 text-teal" /> {ct.duration_minutes} mins
                      </span>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-5 pt-2 border-t border-slate-100">
            <div>
              <label className="label-text">Area of Consultation</label>
              <select
                value={concern}
                onChange={(e) => setConcern(e.target.value)}
                className="input-field"
              >
                {CONCERN_AREAS.map((area) => (
                  <option key={area} value={area}>
                    {area}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="label-text">Preferred Date (Monday – Saturday)</label>
              <input
                type="date"
                min={todayIso}
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="input-field tabular"
              />
            </div>
          </div>

          {/* Available Time Slots */}
          <div>
            <div className="flex items-center justify-between mb-2.5">
              <label className="label-text mb-0">
                Available Online Slots (3:00 PM – 8:00 PM IST)
              </label>
              {slotsData?.dayName && (
                <span className="text-xs font-medium text-teal">{slotsData.dayName}</span>
              )}
            </div>

            {slotsLoading ? (
              <div className="rounded-xl bg-surface-muted p-6 text-center text-xs text-slate-500">
                Checking doctor’s live schedule…
              </div>
            ) : !slotsData?.available ? (
              <div className="rounded-xl border border-amber-200 bg-amber-50 p-4 text-sm text-amber-900 flex items-start gap-2.5">
                <AlertCircle className="h-4 w-4 shrink-0 mt-0.5 text-amber-600" />
                <span>{slotsData?.reason || 'No slots available on this date.'}</span>
              </div>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-2.5">
                {slotsData.slots.map((slot) => {
                  const chosen = selectedSlot === slot.startTime;
                  return (
                    <button
                      key={slot.startTime}
                      type="button"
                      disabled={slot.isBooked}
                      onClick={() => setSelectedSlot(slot.startTime)}
                      className={`rounded-xl border px-3 py-2.5 text-xs font-semibold tabular transition-colors ${
                        slot.isBooked
                          ? 'border-slate-100 bg-slate-50 text-slate-400 line-through cursor-not-allowed'
                          : chosen
                          ? 'border-teal bg-teal text-white shadow-sm'
                          : 'border-slate-200 bg-white text-navy hover:border-teal hover:bg-aqua'
                      }`}
                    >
                      {slot.label}
                      {slot.isBooked && <span className="block text-[10px] no-underline">Booked</span>}
                    </button>
                  );
                })}
              </div>
            )}
          </div>

          <div className="pt-4 border-t border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="text-sm text-slate-600">
              Consultation Fee:{' '}
              <strong className="text-navy font-heading text-lg tabular">
                ₹{selectedType?.fee_inr ?? 500}
              </strong>{' '}
              <span className="text-xs text-slate-400">({selectedType?.duration_minutes} mins)</span>
            </div>
            <button
              type="button"
              disabled={!selectedSlot || !slotsData?.available}
              onClick={() => setStep(2)}
              className="btn-primary"
            >
              Continue to Patient Details
              <ArrowRight className="h-4 w-4" />
            </button>
          </div>
        </div>
      )}

      {/* STEP 2: AUTHENTICATION (IF NEEDED) + CLINICAL INTAKE */}
      {step === 2 && (
        <div className="card-surface p-5 sm:p-7 space-y-6">
          {!user ? (
            <div className="space-y-5">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <h2 className="text-lg font-bold text-navy">Sign In or Create Patient Account</h2>
                  <p className="text-xs text-slate-500">
                    Required so your video session link, receipt, and prescription stay securely inside your private portal.
                  </p>
                </div>
                <Link
                  href="/login?next=/book"
                  className="text-xs font-semibold text-teal hover:underline"
                >
                  Full Sign-In Page →
                </Link>
              </div>

              {/* Passwordless Sign in with Google right inside booking */}
              <div className="max-w-lg space-y-4">
                <GoogleSignInButton
                  label="Sign in with Google"
                  sublabel="Continue your booking instantly without using a password"
                  nextPath="/book"
                  onSuccess={(u, _redirect, tok) => {
                    if (tok) {
                      saveClientSession(tok);
                      setActiveToken(tok);
                    }
                    setAuthErr('');
                    setUser(u);
                  }}
                  onError={(msg) => setAuthErr(msg)}
                />
                <div className="relative flex items-center">
                  <div className="flex-grow border-t border-slate-200" />
                  <span className="mx-3 shrink-0 text-[11px] font-medium uppercase tracking-wider text-slate-400">
                    or use email &amp; password
                  </span>
                  <div className="flex-grow border-t border-slate-200" />
                </div>
              </div>

              <div className="inline-flex flex-wrap rounded-xl bg-surface-muted p-1 border border-slate-200 gap-1">
                <button
                  type="button"
                  onClick={() => { setAuthTab('login'); setAuthErr(''); }}
                  className={`rounded-lg px-3.5 py-1.5 text-xs font-semibold ${
                    authTab === 'login' ? 'bg-white text-navy shadow-sm' : 'text-slate-600'
                  }`}
                >
                  Gmail &amp; Password
                </button>
                <button
                  type="button"
                  onClick={() => { setAuthTab('register'); setAuthErr(''); }}
                  className={`rounded-lg px-3.5 py-1.5 text-xs font-semibold ${
                    authTab === 'register' ? 'bg-white text-navy shadow-sm' : 'text-slate-600'
                  }`}
                >
                  Create Account
                </button>
              </div>

              <form onSubmit={handleInlineAuth} className="space-y-3.5 max-w-lg">
                {authTab === 'register' && (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="label-text">Full Name *</label>
                      <input
                        type="text"
                        required
                        value={authName}
                        onChange={(e) => setAuthName(e.target.value)}
                        className="input-field"
                        placeholder="Full name"
                      />
                    </div>
                    <div>
                      <label className="label-text">Mobile Number (Optional)</label>
                      <input
                        type="tel"
                        value={authPhone}
                        onChange={(e) => setAuthPhone(e.target.value)}
                        className="input-field"
                        placeholder="10-digit WhatsApp/mobile"
                      />
                    </div>
                  </div>
                )}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="label-text">Gmail / Email *</label>
                    <input
                      type="email"
                      required
                      value={authEmail}
                      onChange={(e) => setAuthEmail(e.target.value)}
                      className="input-field"
                      placeholder="yourname@gmail.com"
                    />
                  </div>
                  <div>
                    <label className="label-text">Password *</label>
                    <input
                      type="password"
                      required
                      minLength={6}
                      value={authPass}
                      onChange={(e) => setAuthPass(e.target.value)}
                      className="input-field"
                      placeholder="Your password"
                    />
                  </div>
                </div>
                {authErr && <p className="text-xs text-rose-600 font-medium">{authErr}</p>}
                <div className="flex flex-wrap items-center gap-3 pt-1">
                  <button type="submit" disabled={authBusy} className="btn-primary">
                    {authBusy
                      ? 'Please wait…'
                      : authTab === 'login'
                      ? 'Sign In & Continue'
                      : 'Create Account & Continue'}
                  </button>
                  <button
                    type="button"
                    disabled={authBusy}
                    onClick={handleDemoPatientAuth}
                    className="btn-secondary text-xs"
                  >
                    Use Demo Patient Account
                  </button>
                </div>
              </form>
            </div>
          ) : (
            <form onSubmit={handleReserveAndProceedToPayment} className="space-y-5">
              <div className="rounded-xl bg-aqua p-4 flex flex-wrap items-center justify-between gap-3 text-xs">
                <div>
                  <span className="font-semibold text-navy">Booking as: {user.fullName}</span>{' '}
                  <span className="text-slate-600">({user.email})</span>
                </div>
                <div className="font-semibold text-teal tabular">
                  {selectedType?.name} · {date} ·{' '}
                  {slotsData?.slots.find((s) => s.startTime === selectedSlot)?.label} · ₹
                  {selectedType?.fee_inr}
                </div>
              </div>

              {/* Preferred Audio / Video Calling Channel (+91 8123108149 + In-App) */}
              <div>
                <label className="label-text">
                  Preferred Audio / Video Calling Mode (Dr. Aparna’s Number: +91 8123108149) *
                </label>
                <select
                  value={callChannel}
                  onChange={(e) =>
                    setCallChannel(
                      e.target.value as
                        | 'WHATSAPP_VIDEO'
                        | 'WHATSAPP_AUDIO'
                        | 'PHONE_AUDIO'
                        | 'INAPP_VIDEO'
                        | 'INAPP_AUDIO'
                    )
                  }
                  className="input-field"
                >
                  <option value="WHATSAPP_VIDEO">WhatsApp Video Call (+91 8123108149)</option>
                  <option value="INAPP_VIDEO">Live In-Portal HD Video Call + Chat</option>
                  <option value="WHATSAPP_AUDIO">WhatsApp Audio Call (+91 8123108149)</option>
                  <option value="PHONE_AUDIO">Direct Phone Voice Call (+91 8123108149)</option>
                  <option value="INAPP_AUDIO">Live In-Portal Audio Call + Chat</option>
                </select>
              </div>

              {/* Minor / Guardian Option */}
              <div className="rounded-xl border border-slate-200 p-4 space-y-3">
                <label className="flex items-center gap-2.5 text-sm font-medium text-navy cursor-pointer">
                  <input
                    type="checkbox"
                    checked={forMinor}
                    onChange={(e) => setForMinor(e.target.checked)}
                    className="h-4 w-4 rounded border-slate-300 text-teal focus:ring-teal"
                  />
                  Booking as Parent / Legal Guardian for a Minor Patient (under 18 years)
                </label>
                {forMinor && (
                  <div>
                    <label className="label-text">Minor Child’s Full Name & Age *</label>
                    <input
                      type="text"
                      required
                      value={minorName}
                      onChange={(e) => setMinorName(e.target.value)}
                      placeholder="e.g. Aarav Sinha, 9 yrs"
                      className="input-field"
                    />
                  </div>
                )}
              </div>

              <div>
                <label className="label-text">Primary Health Concern / Symptoms *</label>
                <textarea
                  required
                  rows={3}
                  value={chiefComplaint}
                  onChange={(e) => setChiefComplaint(e.target.value)}
                  placeholder={`Briefly describe your ${concern.toLowerCase()} symptoms for Dr. Aparna Mishra...`}
                  className="input-field"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="label-text">Since How Long?</label>
                  <input
                    type="text"
                    value={symptomDuration}
                    onChange={(e) => setSymptomDuration(e.target.value)}
                    placeholder="e.g. 2 weeks, 6 months"
                    className="input-field"
                  />
                </div>
                <div>
                  <label className="label-text">Ongoing Medicines / Allergies (Optional)</label>
                  <input
                    type="text"
                    value={notesForDoctor}
                    onChange={(e) => setNotesForDoctor(e.target.value)}
                    placeholder="List current tablets or known allergies"
                    className="input-field"
                  />
                </div>
              </div>

              <label className="flex items-start gap-2.5 rounded-xl bg-surface-muted p-3.5 text-xs text-slate-600 cursor-pointer">
                <input
                  type="checkbox"
                  required
                  checked={teleConsent}
                  onChange={(e) => setTeleConsent(e.target.checked)}
                  className="mt-0.5 h-4 w-4 rounded border-slate-300 text-teal focus:ring-teal"
                />
                <span>
                  I consent to an online tele-consultation with Dr. Aparna Mishra (BHMS) under India’s Telemedicine Practice Guidelines and DPDP Act 2023. I understand this is for non-emergency care and in-person medical evaluation may be advised where needed.
                </span>
              </label>

              {bookingError && (
                <div className="rounded-xl border border-rose-200 bg-rose-50 p-3.5 text-xs font-medium text-rose-700">
                  {bookingError}
                </div>
              )}

              <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
                <button type="button" onClick={() => setStep(1)} className="btn-secondary">
                  ← Change Slot
                </button>
                <button type="submit" disabled={bookingBusy} className="btn-primary">
                  {bookingBusy
                    ? 'Reserving Slot…'
                    : `Reserve & Pay ₹${selectedType?.fee_inr ?? 500}`}
                  <ArrowRight className="h-4 w-4" />
                </button>
              </div>
            </form>
          )}
        </div>
      )}

      {/* STEP 3: COMPLETE MULTI-METHOD INDIAN PAYMENT CHECKOUT */}
      {step === 3 && createdBooking && (
        <div className="card-surface p-5 sm:p-7 space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-100">
            <div>
              <span className="text-xs font-semibold uppercase tracking-wider text-teal">
                Ref: {createdBooking.appointment.referenceNo}
              </span>
              <h2 className="text-lg font-bold text-navy">
                Complete Consultation Payment
              </h2>
              <p className="text-xs text-slate-500">
                {createdBooking.appointment.consultationType} · {createdBooking.appointment.date} ·{' '}
                {createdBooking.appointment.timeLabel}
              </p>
            </div>
            <div className="rounded-xl bg-navy px-4 py-2.5 text-white text-right shrink-0">
              <span className="block text-[10px] uppercase tracking-wider text-teal-200">
                Amount Payable
              </span>
              <span className="font-heading text-xl font-bold tabular">
                ₹{createdBooking.payment.amountInr}.00
              </span>
            </div>
          </div>

          {/* Verified Payment Methods Selector */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            <button
              type="button"
              onClick={() => {
                setPayTab('PHONEPE_QR');
                setPayErr('');
              }}
              className={`flex items-center gap-3 rounded-xl border p-3.5 text-left text-xs font-semibold transition-all ${
                payTab === 'PHONEPE_QR'
                  ? 'border-teal bg-aqua text-navy ring-1 ring-teal'
                  : 'border-slate-200 bg-white text-slate-600 hover:border-teal/40'
              }`}
            >
              <QrCode className="h-5 w-5 text-teal shrink-0" />
              <div>
                <p className="font-bold text-navy">PhonePe / Google Pay / Paytm / BHIM QR</p>
                <p className="text-[11px] font-normal text-slate-500">
                  12-digit UTR + screenshot · Verified by clinic before confirming
                </p>
              </div>
            </button>
            <button
              type="button"
              onClick={() => {
                setPayTab('RAZORPAY_LIVE');
                setPayErr('');
              }}
              className={`flex items-center gap-3 rounded-xl border p-3.5 text-left text-xs font-semibold transition-all ${
                payTab === 'RAZORPAY_LIVE'
                  ? 'border-teal bg-aqua text-navy ring-1 ring-teal'
                  : 'border-slate-200 bg-white text-slate-600 hover:border-teal/40'
              }`}
            >
              <CreditCard className="h-5 w-5 text-teal shrink-0" />
              <div>
                <p className="font-bold text-navy">Instant UPI / Card / NetBanking (Razorpay)</p>
                <p className="text-[11px] font-normal text-slate-500">
                  Automatic real-time bank verification &amp; instant confirmation
                </p>
              </div>
            </button>
          </div>

          <form onSubmit={handleCompletePayment} className="space-y-5">
            {payTab === 'PHONEPE_QR' && (
              <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-start rounded-2xl border border-slate-200 bg-surface-muted p-5">
                <div className="md:col-span-5 flex flex-col items-center text-center bg-white rounded-2xl p-4 border border-slate-200">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-navy mb-2">
                    Scan with Any UPI App
                  </span>
                  <img
                    src={createdBooking.payment.upi.qrUrl}
                    alt="Dr. Aparna Mishra Official PhonePe UPI QR Code"
                    className="w-48 h-48 object-contain rounded-lg border border-slate-100"
                  />
                  <p className="mt-2.5 font-heading text-xs font-bold text-navy">
                    Payee: {createdBooking.payment.upi.payeeName}
                  </p>
                  <div className="mt-1.5 inline-flex items-center gap-1.5 rounded-lg bg-aqua px-2.5 py-1 text-xs font-mono text-navy">
                    <span>{createdBooking.payment.upi.upiId}</span>
                    <button
                      type="button"
                      onClick={() => copyUpi(createdBooking.payment.upi.upiId)}
                      className="text-teal hover:text-navy"
                      title="Copy UPI ID"
                    >
                      {copiedUpi ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
                    </button>
                  </div>
                </div>

                <div className="md:col-span-7 space-y-3.5">
                  <div>
                    <h3 className="font-heading text-sm font-bold text-navy mb-1">
                      Pay ₹{createdBooking.payment.amountInr} &amp; Upload Genuine Payment Proof
                    </h3>
                    <p className="text-xs text-slate-600 leading-relaxed">
                      Scan the QR code and pay <strong className="text-navy">₹{createdBooking.payment.amountInr}</strong> to{' '}
                      <strong className="text-navy">APARNA MISHRA</strong>. Then enter the genuine 12-digit UTR and upload your payment screenshot. Random/unmatched numbers are rejected and never confirm an appointment.
                    </p>
                  </div>

                  <div className="flex flex-wrap gap-2">
                    {[
                      { name: 'PhonePe', href: createdBooking.payment.upi.phonePeUri },
                      { name: 'Google Pay', href: createdBooking.payment.upi.gpayUri },
                      { name: 'Paytm', href: createdBooking.payment.upi.paytmUri },
                      { name: 'BHIM / Any UPI', href: createdBooking.payment.upi.upiUri },
                    ].map((app) => (
                      <a
                        key={app.name}
                        href={app.href}
                        onClick={() => setUpiApp(app.name)}
                        className="rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-semibold text-navy hover:border-teal hover:bg-aqua"
                      >
                        Open {app.name}
                      </a>
                    ))}
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="label-text">UPI App Used *</label>
                      <select
                        value={upiApp}
                        onChange={(e) => setUpiApp(e.target.value)}
                        className="input-field"
                      >
                        <option>PhonePe</option>
                        <option>Google Pay (GPay)</option>
                        <option>Paytm UPI</option>
                        <option>BHIM / Bank UPI</option>
                        <option>CRED / Amazon Pay UPI</option>
                      </select>
                    </div>
                    <div>
                      <label className="label-text">
                        12-Digit UTR / UPI Ref No. * ({utr.length}/12)
                      </label>
                      <input
                        type="text"
                        inputMode="numeric"
                        maxLength={12}
                        required
                        value={utr}
                        onChange={(e) => setUtr(e.target.value.replace(/\D/g, '').slice(0, 12))}
                        placeholder="12-digit numeric UTR only"
                        className="input-field tabular font-mono"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="label-text">Paid From (Sender Name or Your UPI ID) *</label>
                    <input
                      type="text"
                      required
                      value={payerUpiId}
                      onChange={(e) => setPayerUpiId(e.target.value)}
                      placeholder="e.g. yourname@ybl or bank holder name"
                      className="input-field"
                    />
                  </div>

                  <div>
                    <label className="label-text">Upload Payment Screenshot (JPG / PNG / PDF) *</label>
                    <label className="flex items-center justify-between gap-2 rounded-xl border border-dashed border-teal/50 bg-white px-3.5 py-2.5 text-xs text-slate-600 cursor-pointer hover:bg-aqua/40">
                      <span className="inline-flex items-center gap-2 truncate">
                        <Upload className="h-4 w-4 text-teal shrink-0" />
                        <span className="truncate font-medium text-navy">
                          {proofFile ? proofFile.name : 'Choose UPI payment success screenshot…'}
                        </span>
                      </span>
                      <span className="rounded-lg bg-aqua px-2.5 py-1 text-[11px] font-semibold text-teal shrink-0">
                        Browse
                      </span>
                      <input
                        type="file"
                        accept="image/jpeg,image/png,image/webp,application/pdf"
                        required
                        onChange={(e) => setProofFile(e.target.files?.[0] || null)}
                        className="hidden"
                      />
                    </label>
                  </div>
                </div>
              </div>
            )}

            {payTab === 'RAZORPAY_LIVE' && (
              <div className="rounded-2xl border border-slate-200 bg-surface-muted p-5 space-y-2.5 text-xs text-slate-600">
                <p className="inline-flex items-center gap-1.5 font-bold text-sm text-navy">
                  <Lock className="h-4 w-4 text-teal" />
                  Razorpay Direct Bank Verification (UPI, RuPay/Visa/Mastercard, NetBanking, Wallets)
                </p>
                {createdBooking.payment.razorpay.mode === 'LIVE_OR_TEST_API' ? (
                  <p>
                    Click <strong>Pay ₹{createdBooking.payment.amountInr} Securely</strong> below to pay via official Razorpay Checkout. Your appointment is confirmed automatically the second your bank verifies payment.
                  </p>
                ) : (
                  <p className="rounded-xl bg-amber-50 border border-amber-200 p-3 text-amber-900">
                    Add your live <code>RAZORPAY_KEY_ID</code> &amp; <code>RAZORPAY_KEY_SECRET</code> in <code>.env</code> to activate automatic instant gateway verification. Right now, please select <strong>PhonePe / Google Pay / Paytm / BHIM QR</strong> above to pay and submit your 12-digit UTR + screenshot for Dr. Aparna’s verification.
                  </p>
                )}
              </div>
            )}

            {payErr && (
              <div className="rounded-xl border border-rose-200 bg-rose-50 p-3.5 text-xs font-medium text-rose-700">
                {payErr}
              </div>
            )}

            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-2">
              <span className="inline-flex items-center gap-1.5 text-xs text-slate-500">
                <ShieldCheck className="h-4 w-4 text-teal" />
                Strict NPCI UTR + Screenshot check · Confirmed only after ₹ hits clinic account
              </span>
              <button
                type="submit"
                disabled={payBusy || (payTab === 'RAZORPAY_LIVE' && createdBooking.payment.razorpay.mode !== 'LIVE_OR_TEST_API')}
                className="btn-primary disabled:opacity-50"
              >
                {payBusy
                  ? 'Submitting Verification…'
                  : payTab === 'PHONEPE_QR'
                  ? 'Submit Payment Proof for Verification'
                  : `Pay ₹${createdBooking.payment.amountInr} Securely`}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* STEP 4: BOOKING CONFIRMATION & RECEIPT */}
      {step === 4 && createdBooking && finalOutcome && (
        <div className="card-surface p-6 sm:p-9 text-center space-y-5">
          <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-emerald-50 text-emerald-600 border border-emerald-200">
            <CheckCircle2 className="h-8 w-8" />
          </div>
          <div>
            <p className="text-xs font-semibold uppercase tracking-widest text-teal mb-1">
              Booking Reference · {createdBooking.appointment.referenceNo}
            </p>
            <h2 className="text-2xl font-bold text-navy">
              {finalOutcome.appointmentStatus === 'CONFIRMED'
                ? 'Online Consultation Confirmed!'
                : 'Pending Bank Verification (Not Confirmed Yet)'}
            </h2>
            <p className="text-sm text-slate-600 max-w-xl mx-auto mt-2">
              {finalOutcome.message}
            </p>
          </div>

          <div className="max-w-lg mx-auto rounded-2xl bg-surface-muted border border-slate-200 p-5 text-left text-sm space-y-2">
            <div className="flex justify-between">
              <span className="text-slate-500">Doctor</span>
              <span className="font-semibold text-navy">Dr. Aparna Mishra (BHMS)</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Service</span>
              <span className="font-medium text-slate-800">{createdBooking.appointment.consultationType}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Date & Time</span>
              <span className="font-semibold text-navy tabular">
                {createdBooking.appointment.date} · {createdBooking.appointment.timeLabel}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Call &amp; Chat No.</span>
              <span className="font-semibold text-teal tabular">+91 8123108149 (Video · Audio · Chat)</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Receipt No.</span>
              <span className="font-mono text-xs font-semibold text-slate-800">
                {finalOutcome.receiptNo} ({finalOutcome.paymentStatus.replace(/_/g, ' ')})
              </span>
            </div>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-2.5 pt-2">
            {finalOutcome.paymentStatus === "PAID" && (<a
              href={`/api/payments/${createdBooking.payment.id}/receipt${(activeToken || sessionToken) ? `?_st=${encodeURIComponent(activeToken || sessionToken || "")}` : ""}`}
              className="btn-secondary text-xs"
            >
              <Download className="h-4 w-4 text-teal" />
              PDF Receipt
            </a>)}
            <a href="tel:+918123108149" className="btn-secondary text-xs tabular">
              <Phone className="h-4 w-4 text-teal" />
              Audio Call 8123108149
            </a>
            <a
              href={`https://wa.me/918123108149?text=${encodeURIComponent(
                `Namaste Dr. Aparna Mishra, my consultation is booked (Ref: ${createdBooking.appointment.referenceNo}, ${createdBooking.appointment.date} ${createdBooking.appointment.timeLabel}). Ready to connect for Video/Audio Call.`
              )}`}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-2.5 text-xs font-semibold text-emerald-800 hover:bg-emerald-100"
            >
              <Video className="h-4 w-4" />
              WhatsApp Video / Chat
            </a>
            {!compact && (
              <Link href="/portal?tab=chat" className="btn-primary text-xs">
                <Calendar className="h-4 w-4" />
                Live Chat &amp; Video Portal
              </Link>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
