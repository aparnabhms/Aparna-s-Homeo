'use client';

import React, { useEffect, useState } from 'react';
import { PhoneCall, PhoneOff, Video } from 'lucide-react';
import { ActiveRtcSession } from './NativeWebRTCCall';
import { authFetch } from '@/lib/clientSession';

interface IncomingCallPayload {
  id: string;
  patient_id: string;
  patient_name: string;
  initiator_name: string;
  call_type: 'AUDIO' | 'VIDEO';
  peer_key?: string | null;
}

export default function IncomingCallBanner({
  mode,
  sessionToken,
  activeCallId,
  onAccept,
}: {
  mode: 'PATIENT' | 'CLINIC';
  sessionToken?: string;
  activeCallId?: string | null;
  onAccept: (session: ActiveRtcSession) => void;
}) {
  const [incoming, setIncoming] = useState<IncomingCallPayload | null>(null);
  const [dismissedIds, setDismissedIds] = useState<string[]>([]);

  useEffect(() => {
    let mounted = true;
    const poll = async () => {
      try {
        const res = await authFetch('/api/rtc?mode=incoming', undefined, sessionToken);
        if (!res.ok || !mounted) return;
        const data = await res.json();
        const inc = data.incomingCall as IncomingCallPayload | null;
        if (inc && inc.id !== activeCallId && !dismissedIds.includes(inc.id)) {
          setIncoming(inc);
        } else {
          setIncoming(null);
        }
      } catch {
        // silent poll
      }
    };
    poll();
    const timer = setInterval(poll, 2500);
    return () => {
      mounted = false;
      clearInterval(timer);
    };
  }, [activeCallId, dismissedIds, sessionToken]);

  useEffect(() => {
    if (!incoming) return;
    let ctx: AudioContext | null = null;
    const chime = () => {
      try {
        const Ctx =
          window.AudioContext ||
          (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
        if (!Ctx) return;
        if (!ctx) ctx = new Ctx();
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(523.25, ctx.currentTime);
        osc.frequency.setValueAtTime(659.25, ctx.currentTime + 0.18);
        gain.gain.setValueAtTime(0.05, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.65);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start();
        osc.stop(ctx.currentTime + 0.65);
      } catch {
        // ignore if audio context awaits user gesture
      }
    };
    chime();
    const t = setInterval(chime, 2600);
    return () => {
      clearInterval(t);
      if (ctx) ctx.close().catch(() => {});
    };
  }, [incoming]);

  if (!incoming) return null;

  async function handleDecline() {
    if (!incoming) return;
    const id = incoming.id;
    const rk = incoming.peer_key || undefined;
    setDismissedIds((prev) => [...prev, id]);
    setIncoming(null);
    await authFetch(
      '/api/rtc',
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'DECLINE', callId: id, roomKey: rk }),
      },
      sessionToken
    ).catch(() => {});
  }

  function handleAnswer() {
    if (!incoming) return;
    const sess: ActiveRtcSession = {
      callId: incoming.id,
      callType: incoming.call_type,
      role: 'CALLEE',
      peerName:
        mode === 'PATIENT'
          ? 'Dr. Aparna Mishra'
          : incoming.patient_name || incoming.initiator_name,
      roomKey: incoming.peer_key || null,
    };
    setIncoming(null);
    onAccept(sess);
  }

  return (
    <div className="mb-5 rounded-2xl border-2 border-teal bg-navy px-5 py-4 text-white shadow-elevated flex flex-wrap items-center justify-between gap-4">
      <div className="flex items-center gap-3.5">
        <span className="flex h-11 w-11 items-center justify-center rounded-full bg-teal text-white animate-pulse">
          {incoming.call_type === 'VIDEO' ? (
            <Video className="h-5 w-5" />
          ) : (
            <PhoneCall className="h-5 w-5" />
          )}
        </span>
        <div>
          <p className="text-[11px] font-semibold uppercase tracking-wider text-teal-200">
            Incoming Live {incoming.call_type === 'VIDEO' ? 'Video' : 'Audio'} Call · +91 8123108149
          </p>
          <p className="font-heading text-base font-bold">
            {mode === 'PATIENT' ? 'Dr. Aparna Mishra, BHMS' : incoming.patient_name}
          </p>
        </div>
      </div>

      <div className="flex items-center gap-2.5">
        <button
          type="button"
          onClick={handleAnswer}
          className="inline-flex items-center gap-1.5 rounded-xl bg-emerald-500 px-4 py-2.5 text-xs font-bold text-white hover:bg-emerald-600 transition-colors shadow-sm"
        >
          {incoming.call_type === 'VIDEO' ? (
            <Video className="h-4 w-4" />
          ) : (
            <PhoneCall className="h-4 w-4" />
          )}
          Answer Call
        </button>
        <button
          type="button"
          onClick={handleDecline}
          className="inline-flex items-center gap-1.5 rounded-xl bg-rose-600 px-3.5 py-2.5 text-xs font-semibold text-white hover:bg-rose-700 transition-colors"
        >
          <PhoneOff className="h-4 w-4" /> Decline
        </button>
      </div>
    </div>
  );
}
