'use client';

import React, { useState } from 'react';
import { CheckCircle2, Send, Star } from 'lucide-react';

export function ContactForm({
  defaultName = '',
  defaultEmail = '',
  defaultPhone = '',
}: {
  defaultName?: string;
  defaultEmail?: string;
  defaultPhone?: string;
}) {
  const [name, setName] = useState(defaultName);
  const [email, setEmail] = useState(defaultEmail);
  const [phone, setPhone] = useState(defaultPhone);
  const [category, setCategory] = useState('APPOINTMENT');
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<{ ok: boolean; msg: string } | null>(null);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setResult(null);
    try {
      const res = await fetch('/api/support', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, email, phone, category, subject, message }),
      });
      const data = await res.json();
      if (!res.ok) {
        setResult({ ok: false, msg: data.error || 'Could not send enquiry.' });
      } else {
        setResult({ ok: true, msg: data.message });
        setSubject('');
        setMessage('');
      }
    } catch {
      setResult({ ok: false, msg: 'Network error. Please call +91 8123108149.' });
    } finally {
      setLoading(false);
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <label className="label-text">Full Name *</label>
          <input
            type="text"
            required
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Your full name"
            className="input-field"
          />
        </div>
        <div>
          <label className="label-text">Mobile Number</label>
          <input
            type="tel"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            placeholder="10-digit mobile number"
            className="input-field"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <label className="label-text">Email Address *</label>
          <input
            type="email"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="you@example.com"
            className="input-field"
          />
        </div>
        <div>
          <label className="label-text">Enquiry Topic</label>
          <select
            value={category}
            onChange={(e) => setCategory(e.target.value)}
            className="input-field"
          >
            <option value="APPOINTMENT">Appointment Scheduling</option>
            <option value="ONLINE_CONSULT">Video / Audio Consultation Help</option>
            <option value="PAYMENT">Payment & Receipt Query</option>
            <option value="PRESCRIPTION">Prescription / Report Access</option>
            <option value="GENERAL">General Clinic Enquiry</option>
          </select>
        </div>
      </div>

      <div>
        <label className="label-text">Subject *</label>
        <input
          type="text"
          required
          value={subject}
          onChange={(e) => setSubject(e.target.value)}
          placeholder="How can our clinic desk help you?"
          className="input-field"
        />
      </div>

      <div>
        <label className="label-text">Message *</label>
        <textarea
          required
          rows={4}
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          placeholder="Please do not include sensitive emergency details here. For urgent care dial 112/108."
          className="input-field"
        />
      </div>

      {result && (
        <div
          className={`rounded-xl p-3.5 text-sm flex items-start gap-2.5 ${
            result.ok
              ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
              : 'bg-rose-50 text-rose-800 border border-rose-200'
          }`}
        >
          {result.ok && <CheckCircle2 className="h-4 w-4 shrink-0 mt-0.5 text-emerald-600" />}
          <span>{result.msg}</span>
        </div>
      )}

      <button type="submit" disabled={loading} className="btn-primary w-full sm:w-auto">
        <Send className="h-4 w-4" />
        {loading ? 'Sending Enquiry…' : 'Send Clinic Enquiry'}
      </button>
    </form>
  );
}

export function FeedbackForm() {
  const [rating, setRating] = useState(5);
  const [patientInitials, setPatientInitials] = useState('');
  const [city, setCity] = useState('');
  const [concernArea, setConcernArea] = useState("Women's Health");
  const [comment, setComment] = useState('');
  const [loading, setLoading] = useState(false);
  const [status, setStatus] = useState<string | null>(null);

  async function submitFeedback(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setStatus(null);
    try {
      const res = await fetch('/api/support', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          kind: 'FEEDBACK',
          rating,
          patientInitials,
          city,
          concernArea,
          comment,
        }),
      });
      const data = await res.json();
      setStatus(data.message || data.error);
      if (res.ok) {
        setComment('');
        setPatientInitials('');
        setCity('');
      }
    } finally {
      setLoading(false);
    }
  }

  return (
    <form onSubmit={submitFeedback} className="space-y-4">
      <div>
        <label className="label-text">Experience Rating</label>
        <div className="flex items-center gap-1.5">
          {[1, 2, 3, 4, 5].map((n) => (
            <button
              key={n}
              type="button"
              onClick={() => setRating(n)}
              className="p-1 rounded-lg hover:bg-aqua"
              aria-label={`Rate ${n} out of 5`}
            >
              <Star
                className={`h-5 w-5 ${
                  n <= rating ? 'fill-amber-400 text-amber-400' : 'text-slate-300'
                }`}
              />
            </button>
          ))}
        </div>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <input
          type="text"
          required
          value={patientInitials}
          onChange={(e) => setPatientInitials(e.target.value)}
          placeholder="Your Name / Initials (e.g. S. M.)"
          className="input-field"
        />
        <input
          type="text"
          value={city}
          onChange={(e) => setCity(e.target.value)}
          placeholder="City (optional)"
          className="input-field"
        />
        <select
          value={concernArea}
          onChange={(e) => setConcernArea(e.target.value)}
          className="input-field"
        >
          <option>Women&apos;s Health</option>
          <option>Thyroid Health</option>
          <option>Skin &amp; Hair</option>
          <option>Digestive Health</option>
          <option>Joint Health</option>
          <option>Respiratory Health</option>
          <option>General Consultation</option>
        </select>
      </div>
      <textarea
        required
        rows={3}
        value={comment}
        onChange={(e) => setComment(e.target.value)}
        placeholder="Share your consultation and booking experience..."
        className="input-field"
      />
      {status && (
        <p className="text-xs font-medium text-teal bg-aqua rounded-xl px-3.5 py-2.5">{status}</p>
      )}
      <button type="submit" disabled={loading} className="btn-secondary">
        {loading ? 'Submitting…' : 'Submit Patient Feedback'}
      </button>
    </form>
  );
}
