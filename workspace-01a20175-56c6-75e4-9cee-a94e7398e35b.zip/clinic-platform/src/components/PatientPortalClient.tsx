'use client';

import React, { useState, useEffect, useCallback } from 'react';
import Link from 'next/link';
import {
  Bell,
  Calendar,
  CalendarPlus,
  CheckCircle2,
  ClipboardList,
  Clock,
  CreditCard,
  Download,
  ExternalLink,
  FileText,
  FolderHeart,
  Headphones,
  History,
  Home,
  LayoutDashboard,
  Lock,
  LogOut,
  Menu,
  MessageSquare,
  Phone,
  PhoneCall,
  RefreshCw,
  ShieldCheck,
  Upload,
  User,
  Video,
  X,
} from 'lucide-react';
import { BrandMark, StatusBadge } from './MedicalIcons';
import BookingFlow, { ConsultationTypeOption } from './BookingFlow';
import { FeedbackForm } from './ContactFeedbackForms';
import ClinicLiveComm from './ClinicLiveComm';
import IncomingCallBanner from './IncomingCallBanner';
import { ActiveRtcSession } from './NativeWebRTCCall';
import { authFetch, clearClientSession, saveClientSession } from '@/lib/clientSession';

type PortalTab =
  | 'dashboard'
  | 'chat'
  | 'profile'
  | 'book'
  | 'appointments'
  | 'history'
  | 'video'
  | 'prescriptions'
  | 'reports'
  | 'payments'
  | 'followups'
  | 'notifications'
  | 'support';

const MENU: Array<{ id: PortalTab; label: string; icon: React.ComponentType<{ className?: string }> }> = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'book', label: 'Book Appointment', icon: CalendarPlus },
  { id: 'chat', label: 'Live Chat & Calls', icon: MessageSquare },
  { id: 'video', label: 'Audio & Video Call', icon: Video },
  { id: 'appointments', label: 'My Appointments', icon: Calendar },
  { id: 'prescriptions', label: 'My Prescriptions', icon: ClipboardList },
  { id: 'reports', label: 'Medical Reports', icon: FolderHeart },
  { id: 'payments', label: 'Payment History', icon: CreditCard },
  { id: 'followups', label: 'Follow-up Info', icon: RefreshCw },
  { id: 'history', label: 'Appointment History', icon: History },
  { id: 'notifications', label: 'Notifications', icon: Bell },
  { id: 'profile', label: 'My Profile & Privacy', icon: User },
  { id: 'support', label: 'Support', icon: Headphones },
];

function fmt12(hhmm?: string) {
  if (!hhmm) return '';
  const [hS, mS] = hhmm.split(':');
  const h = Number(hS);
  const suf = h >= 12 ? 'PM' : 'AM';
  const h12 = h % 12 === 0 ? 12 : h % 12;
  return `${h12}:${mS} ${suf}`;
}

interface AppointmentItem {
  id: string;
  reference_no: string;
  consultation_type_id: string;
  consultation_type_name: string;
  consultation_mode: string;
  concern_category: string;
  appointment_date: string;
  start_time: string;
  end_time: string;
  duration_minutes: number;
  status: string;
  patient_display_name: string;
  chief_complaint: string;
  fee_inr: number;
  payment_status: string;
  followup_date: string | null;
  followup_notes: string | null;
  meeting_url: string | null;
  consultation_id: string | null;
  consultation_status: string | null;
  payment_id: string | null;
  receipt_no: string | null;
  rejection_or_cancel_reason: string | null;
}

interface PrescriptionItem {
  id: string;
  prescription_no: string;
  doctor_name: string;
  doctor_qualification: string;
  appointment_ref: string | null;
  clinical_impression: string;
  symptoms_summary: string | null;
  medicines_json: string;
  general_instructions: string | null;
  dietary_advice: string | null;
  followup_date: string | null;
  referral_note: string | null;
  authorised_at: string;
  digital_signature_hash: string;
}

interface ReportItem {
  id: string;
  title: string;
  category: string;
  report_date: string | null;
  original_filename: string;
  file_size_bytes: number;
  review_status: string;
  doctor_remarks: string | null;
  reviewed_at: string | null;
  created_at: string;
}

interface PaymentItem {
  id: string;
  receipt_no: string;
  appointment_ref: string;
  appointment_date: string;
  start_time: string;
  consultation_type_name: string;
  amount_inr: number;
  gateway: string;
  payment_method: string;
  upi_utr: string | null;
  payer_detail: string | null;
  status: string;
  created_at: string;
}

interface NotificationItem {
  id: string;
  channel: string;
  title: string;
  message: string;
  delivery_status: string;
  is_read: number;
  created_at: string;
}

interface TicketItem {
  id: string;
  ticket_no: string;
  subject: string;
  category: string;
  message: string;
  status: string;
  staff_reply: string | null;
  replied_by: string | null;
  created_at: string;
}

export default function PatientPortalClient({
  initialTab,
  initialStartCall = null,
  sessionToken,
  sessionUser,
  consultationTypes,
  clinicContact,
}: {
  initialTab: string;
  initialStartCall?: 'AUDIO' | 'VIDEO' | null;
  sessionToken: string;
  sessionUser: { id: string; fullName: string; email: string; role: string; isDemo?: boolean };
  consultationTypes: ConsultationTypeOption[];
  clinicContact: {
    doctorName: string;
    phone: string;
    whatsapp: string;
    email: string;
    timings: string;
    upiId: string;
    qrUrl: string;
  };
}) {
  // Synchronously persist SSR session token into window global/storage BEFORE any child effect runs
  if (typeof window !== 'undefined' && sessionToken) {
    saveClientSession(sessionToken);
  }
  const apiFetch = useCallback(
    (path: string, init?: RequestInit) => authFetch(path, init, sessionToken),
    [sessionToken]
  );

  const validInitial = MENU.some((m) => m.id === initialTab) ? (initialTab as PortalTab) : 'dashboard';
  const [tab, setTab] = useState<PortalTab>(validInitial);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [loading, setLoading] = useState(true);
  const [toast, setToast] = useState('');

  // Data state
  const [appointments, setAppointments] = useState<AppointmentItem[]>([]);
  const [prescriptions, setPrescriptions] = useState<PrescriptionItem[]>([]);
  const [reports, setReports] = useState<ReportItem[]>([]);
  const [payments, setPayments] = useState<PaymentItem[]>([]);
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [tickets, setTickets] = useState<TicketItem[]>([]);
  const [profile, setProfile] = useState<Record<string, string | number | null>>({});
  const [userPhone, setUserPhone] = useState('');
  const [userName, setUserName] = useState(sessionUser.fullName);
  const [waConsent, setWaConsent] = useState(true);

  // Reschedule modal
  const [reschedAppt, setReschedAppt] = useState<AppointmentItem | null>(null);
  const [reschedDate, setReschedDate] = useState('');
  const [reschedSlots, setReschedSlots] = useState<Array<{ startTime: string; label: string; isBooked: boolean }>>([]);
  const [reschedTime, setReschedTime] = useState('');

  // Report upload state
  const [repTitle, setRepTitle] = useState('');
  const [repCategory, setRepCategory] = useState('Thyroid Profile');
  const [repDate, setRepDate] = useState('');
  const [repFile, setRepFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);

  // Password change
  const [curPw, setCurPw] = useState('');
  const [newPw, setNewPw] = useState('');

  // Support ticket
  const [supSubject, setSupSubject] = useState('');
  const [supCat, setSupCat] = useState('APPOINTMENT');
  const [supMsg, setSupMsg] = useState('');

  // Pending UPI UTR inline submit
  const [payUtrMap, setPayUtrMap] = useState<Record<string, string>>({});

  // Live WebRTC Audio / Video Call Launch & Incoming Call State
  const [autoCallMode, setAutoCallMode] = useState<'AUDIO' | 'VIDEO' | null>(initialStartCall);
  const [acceptedCall, setAcceptedCall] = useState<ActiveRtcSession | null>(null);
  const [activeCallId, setActiveCallId] = useState<string | null>(null);

  function launchPortalCall(callType: 'AUDIO' | 'VIDEO') {
    setAutoCallMode(callType);
    setTab('video');
  }

  function flash(msg: string) {
    setToast(msg);
    setTimeout(() => setToast(''), 4000);
  }

  const refreshAll = useCallback(async () => {
    setLoading(true);
    try {
      const [meR, apR, rxR, rpR, pyR, spR] = await Promise.all([
        apiFetch('/api/auth/me'),
        apiFetch('/api/appointments'),
        apiFetch('/api/prescriptions'),
        apiFetch('/api/reports'),
        apiFetch('/api/payments'),
        apiFetch('/api/support'),
      ]);
      const [meD, apD, rxD, rpD, pyD, spD] = await Promise.all(
        [meR, apR, rxR, rpR, pyR, spR].map((r) => (r.ok ? r.json().catch(() => ({})) : Promise.resolve({})))
      );
      if (meD.profile) setProfile(meD.profile);
      if (meD.user?.details) {
        setUserPhone(meD.user.details.phone || '');
        setUserName(meD.user.details.full_name || sessionUser.fullName);
      }
      if (Array.isArray(meD.consents)) {
        const wc = meD.consents.find((c: { consent_type: string }) => c.consent_type === 'WHATSAPP_COMMUNICATION');
        setWaConsent(wc ? Boolean(wc.granted) : false);
      }
      setNotifications(meD.notifications || []);
      setUnreadCount(meD.unreadCount || 0);
      setAppointments(apD.appointments || []);
      setPrescriptions(rxD.prescriptions || []);
      setReports(rpD.reports || []);
      setPayments(pyD.payments || []);
      setTickets(spD.tickets || []);
    } finally {
      setLoading(false);
    }
  }, [sessionUser.fullName]);

  useEffect(() => {
    refreshAll();
  }, [refreshAll]);

  async function handleLogout() {
    clearClientSession();
    await fetch('/api/auth/logout', { method: 'POST', credentials: 'include' }).catch(() => {});
    window.location.assign('/login');
  }

  async function cancelAppointment(id: string) {
    const res = await apiFetch(`/api/appointments/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'CANCEL', reason: 'Cancelled by patient via portal' }),
    });
    if (res.ok) {
      flash('Appointment cancelled.');
      refreshAll();
    }
  }

  async function openReschedule(appt: AppointmentItem) {
    setReschedAppt(appt);
    setReschedDate(appt.appointment_date);
    const res = await fetch(
      `/api/slots?date=${appt.appointment_date}&consultationTypeId=${appt.consultation_type_id}&excludeAppointmentId=${appt.id}`
    );
    const data = await res.json();
    setReschedSlots(data.slots || []);
    setReschedTime(appt.start_time);
  }

  async function loadReschedSlots(newDate: string) {
    if (!reschedAppt) return;
    setReschedDate(newDate);
    setReschedTime('');
    const res = await fetch(
      `/api/slots?date=${newDate}&consultationTypeId=${reschedAppt.consultation_type_id}&excludeAppointmentId=${reschedAppt.id}`
    );
    const data = await res.json();
    setReschedSlots(data.slots || []);
  }

  async function confirmReschedule() {
    if (!reschedAppt || !reschedDate || !reschedTime) return;
    const res = await apiFetch(`/api/appointments/${reschedAppt.id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        action: 'RESCHEDULE',
        appointmentDate: reschedDate,
        startTime: reschedTime,
      }),
    });
    const data = await res.json();
    if (!res.ok) {
      flash(data.error || 'Could not reschedule.');
      return;
    }
    setReschedAppt(null);
    flash('Appointment rescheduled successfully.');
    refreshAll();
  }

  async function handleUploadReport(e: React.FormEvent) {
    e.preventDefault();
    if (!repFile) return;
    setUploading(true);
    try {
      const fd = new FormData();
      fd.append('file', repFile);
      fd.append('title', repTitle || repFile.name);
      fd.append('category', repCategory);
      if (repDate) fd.append('reportDate', repDate);
      const res = await apiFetch('/api/reports', { method: 'POST', body: fd });
      const data = await res.json();
      if (!res.ok) {
        flash(data.error || 'Upload failed.');
        return;
      }
      setRepTitle('');
      setRepDate('');
      setRepFile(null);
      flash(data.message);
      refreshAll();
    } finally {
      setUploading(false);
    }
  }

  async function handleSaveProfile(e: React.FormEvent) {
    e.preventDefault();
    const res = await apiFetch('/api/auth/me', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        action: 'UPDATE_PROFILE',
        fullName: userName,
        phone: userPhone,
        dateOfBirth: profile.date_of_birth || '',
        gender: profile.gender || '',
        bloodGroup: profile.blood_group || '',
        city: profile.city || '',
        state: profile.state || '',
        address: profile.address || '',
        allergies: profile.allergies || '',
        chronicConditions: profile.chronic_conditions || '',
        currentMedications: profile.current_medications || '',
        emergencyContactName: profile.emergency_contact_name || '',
        emergencyContactPhone: profile.emergency_contact_phone || '',
        isMinorAccount: Boolean(profile.is_minor_account),
        guardianName: profile.guardian_name || userName,
        guardianRelation: profile.guardian_relation || '',
        minorPatientName: profile.minor_patient_name || '',
        minorDateOfBirth: profile.minor_date_of_birth || '',
      }),
    });
    const d = await res.json();
    flash(d.message || d.error);
    refreshAll();
  }

  async function handleChangePassword(e: React.FormEvent) {
    e.preventDefault();
    const res = await apiFetch('/api/auth/me', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'CHANGE_PASSWORD', currentPassword: curPw, newPassword: newPw }),
    });
    const d = await res.json();
    flash(d.message || d.error);
    if (res.ok) {
      setCurPw('');
      setNewPw('');
    }
  }

  async function markAllRead() {
    await apiFetch('/api/auth/me', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'MARK_NOTIFICATIONS_READ' }),
    });
    refreshAll();
  }

  async function submitTicket(e: React.FormEvent) {
    e.preventDefault();
    const res = await apiFetch('/api/support', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        name: userName,
        email: sessionUser.email,
        phone: userPhone,
        category: supCat,
        subject: supSubject,
        message: supMsg,
      }),
    });
    const d = await res.json();
    if (res.ok) {
      setSupSubject('');
      setSupMsg('');
      flash(d.message);
      refreshAll();
    } else {
      flash(d.error || 'Could not submit ticket.');
    }
  }

  async function logAndJoinVideo(consultationId: string | null, url: string) {
    if (consultationId) {
      apiFetch('/api/consultations', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'JOIN_LOG', consultationId }),
      }).catch(() => {});
    }
    window.open(url, '_blank', 'noopener,noreferrer');
  }

  async function submitPendingUtr(paymentId: string) {
    const utr = (payUtrMap[paymentId] || '').trim();
    if (!utr) return;
    const res = await apiFetch('/api/payments', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'SUBMIT_UPI_UTR', paymentId, utr, upiApp: 'PhonePe QR' }),
    });
    const d = await res.json();
    flash(d.message || d.error);
    if (res.ok) refreshAll();
  }

  const upcomingList = appointments.filter((a) =>
    ['PENDING', 'CONFIRMED', 'RESCHEDULED'].includes(a.status)
  );
  const historyList = appointments.filter((a) =>
    ['COMPLETED', 'CANCELLED', 'REJECTED'].includes(a.status)
  );
  const nextAppt = upcomingList[upcomingList.length - 1] || upcomingList[0] || null;
  const followupItems = appointments.filter((a) => Boolean(a.followup_date));

  return (
    <div className="min-h-screen bg-surface-muted flex">
      {/* Sidebar */}
      <aside
        className={`fixed inset-y-0 left-0 z-50 w-64 bg-navy text-white flex flex-col transition-transform lg:static lg:translate-x-0 ${
          sidebarOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div className="px-5 py-5 border-b border-white/10 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2.5">
            <div className="rounded-lg bg-white/10 p-0.5">
              <BrandMark className="h-8 w-8" />
            </div>
            <div className="leading-tight">
              <span className="block font-heading text-sm font-bold text-white">Patient Portal</span>
              <span className="block text-[11px] text-teal-200">Dr. Aparna Mishra</span>
            </div>
          </Link>
          <button
            type="button"
            onClick={() => setSidebarOpen(false)}
            className="lg:hidden text-slate-300 hover:text-white"
            aria-label="Close sidebar"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <nav className="flex-1 overflow-y-auto px-3 py-4 space-y-1">
          {MENU.map((m) => {
            const Icon = m.icon;
            const active = tab === m.id;
            return (
              <button
                key={m.id}
                type="button"
                onClick={() => {
                  setTab(m.id);
                  setSidebarOpen(false);
                }}
                className={`w-full flex items-center justify-between rounded-xl px-3.5 py-2.5 text-xs font-semibold transition-colors ${
                  active
                    ? 'bg-teal text-white shadow-sm'
                    : 'text-slate-200 hover:bg-white/10 hover:text-white'
                }`}
              >
                <span className="flex items-center gap-2.5">
                  <Icon className="h-4 w-4 shrink-0" />
                  {m.label}
                </span>
                {m.id === 'notifications' && unreadCount > 0 && (
                  <span className="rounded-full bg-white px-2 py-0.5 text-[10px] font-bold text-navy tabular">
                    {unreadCount}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        <div className="p-3 border-t border-white/10 space-y-1.5">
          <Link
            href="/"
            className="flex items-center gap-2.5 rounded-xl px-3.5 py-2 text-xs text-slate-300 hover:bg-white/10 hover:text-white"
          >
            <Home className="h-4 w-4" /> Public Website
          </Link>
          <button
            type="button"
            onClick={handleLogout}
            className="w-full flex items-center gap-2.5 rounded-xl px-3.5 py-2 text-xs text-rose-200 hover:bg-white/10 hover:text-white"
          >
            <LogOut className="h-4 w-4" /> Sign Out
          </button>
        </div>
      </aside>

      {sidebarOpen && (
        <div
          className="fixed inset-0 z-40 bg-navy/40 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Top Bar */}
        <header className="sticky top-0 z-30 bg-white border-b border-slate-200 px-4 sm:px-8 h-16 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3 min-w-0">
            <button
              type="button"
              onClick={() => setSidebarOpen(true)}
              className="lg:hidden rounded-xl border border-slate-200 p-2 text-navy"
              aria-label="Open menu"
            >
              <Menu className="h-5 w-5" />
            </button>
            <div className="min-w-0">
              <h1 className="font-heading text-base sm:text-lg font-bold text-navy truncate">
                {MENU.find((m) => m.id === tab)?.label}
              </h1>
              {sessionUser.isDemo && (
                <p className="text-[11px] text-teal font-medium">
                  Demo Patient Record · Private RBAC Isolated
                </p>
              )}
            </div>
          </div>

          <div className="flex items-center gap-2.5 shrink-0">
            <button
              type="button"
              onClick={() => setTab('book')}
              className="hidden sm:inline-flex items-center gap-1.5 rounded-xl bg-teal px-3.5 py-2 text-xs font-semibold text-white hover:bg-teal-600"
            >
              <CalendarPlus className="h-3.5 w-3.5" /> New Appointment
            </button>
            <button
              type="button"
              onClick={() => setTab('notifications')}
              className="relative rounded-xl border border-slate-200 p-2 text-navy hover:bg-aqua"
              aria-label="Notifications"
            >
              <Bell className="h-4 w-4" />
              {unreadCount > 0 && (
                <span className="absolute -top-1 -right-1 h-4 w-4 rounded-full bg-teal text-[10px] font-bold text-white flex items-center justify-center">
                  {unreadCount}
                </span>
              )}
            </button>
          </div>
        </header>

        {toast && (
          <div className="mx-4 sm:mx-8 mt-4 rounded-xl border border-teal/30 bg-aqua px-4 py-3 text-xs font-semibold text-navy flex items-center justify-between">
            <span>{toast}</span>
            <button type="button" onClick={() => setToast('')} className="text-slate-500">
              <X className="h-3.5 w-3.5" />
            </button>
          </div>
        )}

        <main className="flex-1 p-4 sm:p-8 max-w-6xl w-full mx-auto space-y-6">
          <IncomingCallBanner
            mode="PATIENT"
            sessionToken={sessionToken}
            activeCallId={activeCallId}
            onAccept={(sess) => {
              setAcceptedCall(sess);
              setActiveCallId(sess.callId);
              setTab('chat');
            }}
          />
          {loading ? (
            <div className="card-surface p-10 text-center text-sm text-slate-500">
              Loading your secure health records…
            </div>
          ) : (
            <>
              {/* 1. DASHBOARD OVERVIEW */}
              {tab === 'dashboard' && (
                <div className="space-y-6">
                  <div className="rounded-2xl bg-navy text-white p-6 sm:p-7 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div>
                      <p className="text-xs text-teal-200 font-semibold uppercase tracking-wider">
                        Patient ID · {String(profile.patient_code || 'VERIFIED')}
                      </p>
                      <h2 className="text-xl sm:text-2xl font-bold text-white mt-1">
                        Namaste, {userName}
                      </h2>
                      <p className="text-xs sm:text-sm text-slate-300 mt-1">
                        {profile.is_minor_account
                          ? `Parent / Legal Guardian Account for Minor: ${profile.minor_patient_name}`
                          : `Online consultations with ${clinicContact.doctorName} · ${clinicContact.timings}`}
                      </p>
                    </div>
                    <div className="flex flex-wrap gap-2.5 shrink-0">
                      <button
                        type="button"
                        onClick={() => setTab('book')}
                        className="btn-primary text-xs"
                      >
                        <CalendarPlus className="h-4 w-4" /> Book Appointment
                      </button>
                      <button
                        type="button"
                        onClick={() => setTab('chat')}
                        className="inline-flex items-center gap-1.5 rounded-xl bg-white/15 border border-white/20 px-4 py-2.5 text-xs font-semibold text-white hover:bg-white/25"
                      >
                        <MessageSquare className="h-4 w-4 text-teal-200" /> Chat &amp; Call
                      </button>
                    </div>
                  </div>

                  {/* Direct Connect Strip: 1-Click Live Video Call, Live Audio Call, Live Chat & WhatsApp (+91 8123108149) */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                    <button
                      type="button"
                      onClick={() => launchPortalCall('VIDEO')}
                      className="card-surface p-3.5 flex items-center gap-3 text-left hover:border-teal hover:bg-aqua/40 transition-colors"
                    >
                      <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-teal text-white">
                        <Video className="h-4 w-4" />
                      </span>
                      <div>
                        <p className="font-heading text-xs font-bold text-navy">Start Video Call</p>
                        <p className="text-[11px] text-teal font-medium">Live HD Call</p>
                      </div>
                    </button>
                    <button
                      type="button"
                      onClick={() => launchPortalCall('AUDIO')}
                      className="card-surface p-3.5 flex items-center gap-3 text-left hover:border-teal hover:bg-aqua/40 transition-colors"
                    >
                      <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-navy text-white">
                        <PhoneCall className="h-4 w-4" />
                      </span>
                      <div>
                        <p className="font-heading text-xs font-bold text-navy">Start Audio Call</p>
                        <p className="text-[11px] text-slate-600 tabular">Live · 8123108149</p>
                      </div>
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setAutoCallMode(null);
                        setTab('chat');
                      }}
                      className="card-surface p-3.5 flex items-center gap-3 text-left hover:border-teal hover:bg-aqua/40 transition-colors"
                    >
                      <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-aqua text-teal">
                        <MessageSquare className="h-4 w-4" />
                      </span>
                      <div>
                        <p className="font-heading text-xs font-bold text-navy">Live Doctor Chat</p>
                        <p className="text-[11px] text-slate-500">Portal Messaging</p>
                      </div>
                    </button>
                    <a
                      href={`https://wa.me/${clinicContact.whatsapp}?text=${encodeURIComponent(
                        `Namaste Dr. Aparna Mishra, I am ${userName} connecting for online consultation.`
                      )}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="card-surface p-3.5 flex items-center gap-3 text-left hover:border-emerald-400 transition-colors"
                    >
                      <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-emerald-50 text-emerald-700">
                        <Phone className="h-4 w-4" />
                      </span>
                      <div>
                        <p className="font-heading text-xs font-bold text-navy">WhatsApp Call/Chat</p>
                        <p className="text-[11px] text-emerald-700 tabular">+91 8123108149</p>
                      </div>
                    </a>
                  </div>

                  {/* Upcoming Appointment Highlight */}
                  <div className="card-surface p-6">
                    <div className="flex items-center justify-between mb-3">
                      <h3 className="text-base font-bold text-navy">Upcoming Consultation</h3>
                      {nextAppt && <StatusBadge status={nextAppt.status} />}
                    </div>
                    {nextAppt ? (
                      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 rounded-xl bg-aqua/70 p-4 border border-teal/20">
                        <div className="space-y-1">
                          <p className="text-xs font-semibold text-teal">
                            Ref: {nextAppt.reference_no} · {nextAppt.concern_category}
                          </p>
                          <p className="font-heading text-base font-bold text-navy">
                            {nextAppt.consultation_type_name}
                          </p>
                          <p className="text-xs text-slate-600 tabular flex items-center gap-2">
                            <Clock className="h-3.5 w-3.5 text-teal" />
                            {nextAppt.appointment_date} · {fmt12(nextAppt.start_time)} –{' '}
                            {fmt12(nextAppt.end_time)} IST
                          </p>
                        </div>
                        <div className="flex flex-wrap gap-2">
                          {nextAppt.meeting_url && nextAppt.status === 'CONFIRMED' && (
                            <button
                              type="button"
                              onClick={() =>
                                logAndJoinVideo(nextAppt.consultation_id, nextAppt.meeting_url!)
                              }
                              className="btn-primary text-xs py-2.5"
                            >
                              <Video className="h-4 w-4" /> Join Video Call
                            </button>
                          )}
                          <button
                            type="button"
                            onClick={() => setTab('appointments')}
                            className="btn-secondary text-xs py-2.5"
                          >
                            Manage Booking
                          </button>
                        </div>
                      </div>
                    ) : (
                      <p className="text-sm text-slate-500">
                        You have no upcoming appointments. Slots are available Monday–Saturday, 3:00 PM – 8:00 PM IST.
                      </p>
                    )}
                  </div>

                  {/* Quick Portal Summaries */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
                    <div className="card-surface p-5 space-y-3">
                      <div className="flex items-center justify-between">
                        <h3 className="text-sm font-bold text-navy">Recent Prescriptions</h3>
                        <span className="text-xs font-bold text-teal tabular">
                          {prescriptions.length}
                        </span>
                      </div>
                      {prescriptions.length === 0 ? (
                        <p className="text-xs text-slate-500">No authorised prescriptions yet.</p>
                      ) : (
                        prescriptions.slice(0, 2).map((rx) => (
                          <div
                            key={rx.id}
                            className="rounded-xl bg-surface-muted p-3 flex items-center justify-between gap-2 text-xs"
                          >
                            <div className="min-w-0">
                              <p className="font-semibold text-navy truncate">
                                {rx.prescription_no}
                              </p>
                              <p className="text-slate-500 truncate">{rx.clinical_impression}</p>
                            </div>
                            <a
                              href={`/api/prescriptions/${rx.id}/pdf?_st=${encodeURIComponent(sessionToken)}`}
                              className="shrink-0 rounded-lg bg-white border border-slate-200 px-2.5 py-1.5 font-semibold text-teal hover:bg-aqua"
                            >
                              PDF
                            </a>
                          </div>
                        ))
                      )}
                      <button
                        type="button"
                        onClick={() => setTab('prescriptions')}
                        className="text-xs font-semibold text-teal hover:underline"
                      >
                        View all prescriptions →
                      </button>
                    </div>

                    <div className="card-surface p-5 space-y-3">
                      <div className="flex items-center justify-between">
                        <h3 className="text-sm font-bold text-navy">Medical Reports</h3>
                        <span className="text-xs font-bold text-teal tabular">{reports.length}</span>
                      </div>
                      {reports.length === 0 ? (
                        <p className="text-xs text-slate-500">Upload reports before your consultation.</p>
                      ) : (
                        reports.slice(0, 2).map((rp) => (
                          <div key={rp.id} className="rounded-xl bg-surface-muted p-3 text-xs space-y-1">
                            <p className="font-semibold text-navy truncate">{rp.title}</p>
                            <StatusBadge status={rp.review_status} />
                          </div>
                        ))
                      )}
                      <button
                        type="button"
                        onClick={() => setTab('reports')}
                        className="text-xs font-semibold text-teal hover:underline"
                      >
                        Upload or view reports →
                      </button>
                    </div>

                    <div className="card-surface p-5 space-y-3">
                      <div className="flex items-center justify-between">
                        <h3 className="text-sm font-bold text-navy">Payment Receipts</h3>
                        <span className="text-xs font-bold text-teal tabular">{payments.length}</span>
                      </div>
                      {payments.length === 0 ? (
                        <p className="text-xs text-slate-500">No transactions yet.</p>
                      ) : (
                        payments.slice(0, 2).map((p) => (
                          <div
                            key={p.id}
                            className="rounded-xl bg-surface-muted p-3 flex items-center justify-between text-xs"
                          >
                            <div>
                              <p className="font-semibold text-navy tabular">₹{p.amount_inr}</p>
                              <p className="text-slate-500">{p.receipt_no}</p>
                            </div>
                            <a
                              href={`/api/payments/${p.id}/receipt?_st=${encodeURIComponent(sessionToken)}`}
                              className="rounded-lg bg-white border border-slate-200 px-2.5 py-1.5 font-semibold text-teal hover:bg-aqua"
                            >
                              Receipt
                            </a>
                          </div>
                        ))
                      )}
                      <button
                        type="button"
                        onClick={() => setTab('payments')}
                        className="text-xs font-semibold text-teal hover:underline"
                      >
                        Payment history →
                      </button>
                    </div>
                  </div>

                  {/* Latest Notifications */}
                  <div className="card-surface p-5 space-y-3">
                    <div className="flex items-center justify-between">
                      <h3 className="text-sm font-bold text-navy">Recent Notifications</h3>
                      <button
                        type="button"
                        onClick={() => setTab('notifications')}
                        className="text-xs font-semibold text-teal hover:underline"
                      >
                        See all
                      </button>
                    </div>
                    {notifications.slice(0, 3).map((n) => (
                      <div
                        key={n.id}
                        className="rounded-xl bg-surface-muted px-4 py-3 flex items-start justify-between gap-3 text-xs"
                      >
                        <div>
                          <p className="font-semibold text-navy">{n.title}</p>
                          <p className="text-slate-600 mt-0.5">{n.message}</p>
                        </div>
                        <span className="shrink-0 rounded-md bg-white px-2 py-0.5 text-[10px] font-semibold text-slate-500 border border-slate-200">
                          {n.channel}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* 2. BOOK APPOINTMENT */}
              {tab === 'book' && (
                <BookingFlow
                  consultationTypes={consultationTypes}
                  initialUser={sessionUser}
                  sessionToken={sessionToken}
                  compact
                  onBooked={() => refreshAll()}
                />
              )}

              {/* 3. MY APPOINTMENTS */}
              {tab === 'appointments' && (
                <div className="space-y-4">
                  {upcomingList.length === 0 ? (
                    <div className="card-surface p-10 text-center space-y-3">
                      <p className="text-sm text-slate-500">No active upcoming appointments.</p>
                      <button type="button" onClick={() => setTab('book')} className="btn-primary">
                        Book Online Consultation
                      </button>
                    </div>
                  ) : (
                    upcomingList.map((a) => (
                      <div key={a.id} className="card-surface p-5 sm:p-6 space-y-4">
                        <div className="flex flex-wrap items-start justify-between gap-3">
                          <div>
                            <p className="text-xs font-semibold text-teal">
                              {a.reference_no} · {a.concern_category}
                            </p>
                            <h3 className="text-base font-bold text-navy mt-0.5">
                              {a.consultation_type_name}
                            </h3>
                            <p className="text-xs text-slate-600 tabular mt-1">
                              {a.appointment_date} · {fmt12(a.start_time)} – {fmt12(a.end_time)} IST · Fee: ₹{a.fee_inr}
                            </p>
                          </div>
                          <div className="flex items-center gap-2">
                            <StatusBadge status={a.status} />
                            <StatusBadge status={a.payment_status} />
                          </div>
                        </div>
                        <p className="text-xs text-slate-600 bg-surface-muted rounded-xl p-3">
                          <strong>Concern noted:</strong> {a.chief_complaint}
                        </p>
                        <div className="flex flex-wrap gap-2.5">
                          {a.meeting_url && a.status === 'CONFIRMED' && (
                            <button
                              type="button"
                              onClick={() => logAndJoinVideo(a.consultation_id, a.meeting_url!)}
                              className="btn-primary py-2 px-4 text-xs"
                            >
                              <Video className="h-3.5 w-3.5" /> Join Video Room
                            </button>
                          )}
                          <button
                            type="button"
                            onClick={() => openReschedule(a)}
                            className="btn-secondary py-2 px-4 text-xs"
                          >
                            Reschedule Slot
                          </button>
                          <button
                            type="button"
                            onClick={() => cancelAppointment(a.id)}
                            className="rounded-xl border border-rose-200 bg-rose-50 px-4 py-2 text-xs font-semibold text-rose-700 hover:bg-rose-100"
                          >
                            Cancel
                          </button>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              )}

              {/* 4. APPOINTMENT HISTORY */}
              {tab === 'history' && (
                <div className="space-y-4">
                  {historyList.length === 0 ? (
                    <div className="card-surface p-8 text-center text-sm text-slate-500">
                      No past appointments on record yet.
                    </div>
                  ) : (
                    historyList.map((a) => (
                      <div key={a.id} className="card-surface p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                        <div>
                          <div className="flex items-center gap-2 mb-1">
                            <span className="text-xs font-semibold text-teal">{a.reference_no}</span>
                            <StatusBadge status={a.status} />
                          </div>
                          <h3 className="font-heading text-sm font-bold text-navy">
                            {a.consultation_type_name} — {a.concern_category}
                          </h3>
                          <p className="text-xs text-slate-500 tabular mt-0.5">
                            {a.appointment_date} · {fmt12(a.start_time)} IST · ₹{a.fee_inr}
                          </p>
                          {a.rejection_or_cancel_reason && (
                            <p className="text-xs text-rose-600 mt-1">
                              Note: {a.rejection_or_cancel_reason}
                            </p>
                          )}
                        </div>
                        {a.payment_id && (
                          <a
                            href={`/api/payments/${a.payment_id}/receipt?_st=${encodeURIComponent(sessionToken)}`}
                            className="btn-secondary py-2 px-3.5 text-xs shrink-0"
                          >
                            <Download className="h-3.5 w-3.5 text-teal" /> Receipt PDF
                          </a>
                        )}
                      </div>
                    ))
                  )}
                </div>
              )}

              {/* LIVE CHAT & DIRECT AUDIO/VIDEO CALLS (+91 8123108149) */}
              {tab === 'chat' && (
                <ClinicLiveComm
                  mode="PATIENT"
                  currentUserName={userName}
                  sessionToken={sessionToken}
                  externalSession={acceptedCall}
                  onClearExternalSession={() => setAcceptedCall(null)}
                  onActiveCallChange={setActiveCallId}
                />
              )}

              {/* 5. AUDIO & VIDEO CONSULTATION (+91 8123108149 + In-App Rooms) */}
              {tab === 'video' && (
                <div className="space-y-6">
                  <div className="rounded-2xl bg-aqua border border-teal/25 p-5 space-y-2 text-xs text-navy">
                    <p className="font-bold text-sm flex items-center gap-2">
                      <ShieldCheck className="h-4 w-4 text-teal" /> Audio &amp; Video Consultation — Official Number: +91 8123108149
                    </p>
                    <ul className="list-disc pl-5 space-y-1 text-slate-700">
                      <li>Available Monday–Saturday, 3:00 PM – 8:00 PM IST by prior booking.</li>
                      <li>Connect via <strong>Live In-App HD Video/Audio Call</strong>, direct <strong>Voice Call (+91 8123108149)</strong>, or <strong>WhatsApp Video/Audio Call (+91 8123108149)</strong>, plus live two-way chat below.</li>
                      <li>Upload recent blood tests or scan reports in <strong>Medical Reports</strong> prior to joining.</li>
                      <li><strong>Privacy protection:</strong> Calls are strictly private and never automatically recorded.</li>
                    </ul>
                  </div>

                  {/* Scheduled Appointment Rooms */}
                  {upcomingList.filter((a) => a.meeting_url).length > 0 && (
                    <div className="space-y-3">
                      <h3 className="text-sm font-bold text-navy">Your Scheduled Appointment Sessions</h3>
                      {upcomingList
                        .filter((a) => a.meeting_url)
                        .map((a) => (
                          <div
                            key={a.id}
                            className="card-surface p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4"
                          >
                            <div className="space-y-1">
                              <div className="flex items-center gap-2">
                                <StatusBadge status={a.consultation_status || 'READY'} />
                                <span className="text-xs text-slate-500">Line: +91 8123108149 · Recording: OFF</span>
                              </div>
                              <h4 className="text-base font-bold text-navy">
                                {a.consultation_type_name} with {clinicContact.doctorName}
                              </h4>
                              <p className="text-xs text-slate-600 tabular">
                                Ref {a.reference_no} · {a.appointment_date} at {fmt12(a.start_time)} IST
                              </p>
                            </div>
                            <div className="flex flex-wrap gap-2">
                              <button
                                type="button"
                                onClick={() => {
                                  if (a.consultation_id) {
                                    apiFetch('/api/consultations', {
                                      method: 'PATCH',
                                      headers: { 'Content-Type': 'application/json' },
                                      body: JSON.stringify({ action: 'JOIN_LOG', consultationId: a.consultation_id }),
                                    }).catch(() => {});
                                  }
                                  setAutoCallMode(null);
                                  setTimeout(() => setAutoCallMode('VIDEO'), 10);
                                }}
                                className="btn-primary py-2 px-3.5 text-xs"
                              >
                                <Video className="h-4 w-4" /> Start Video Call
                              </button>
                              <button
                                type="button"
                                onClick={() => {
                                  setAutoCallMode(null);
                                  setTimeout(() => setAutoCallMode('AUDIO'), 10);
                                }}
                                className="btn-secondary py-2 px-3.5 text-xs"
                              >
                                <PhoneCall className="h-3.5 w-3.5 text-teal" /> Start Audio Call
                              </button>
                              <a
                                href={`https://wa.me/${clinicContact.whatsapp}?text=${encodeURIComponent(
                                  `Namaste Dr. Aparna Mishra, joining my scheduled consultation Ref ${a.reference_no} (${a.appointment_date} ${fmt12(a.start_time)}).`
                                )}`}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="rounded-xl border border-emerald-200 bg-emerald-50 px-3.5 py-2 text-xs font-semibold text-emerald-800 hover:bg-emerald-100"
                              >
                                WhatsApp (+91 8123108149)
                              </a>
                            </div>
                          </div>
                        ))}
                    </div>
                  )}

                  {/* Full Native WebRTC Live Audio Call, Video Call & Real-Time Chat Hub */}
                  <ClinicLiveComm
                    mode="PATIENT"
                    currentUserName={userName}
                    sessionToken={sessionToken}
                    initialCallMode={autoCallMode}
                    externalSession={acceptedCall}
                    onClearExternalSession={() => {
                      setAcceptedCall(null);
                      setAutoCallMode(null);
                    }}
                    onActiveCallChange={setActiveCallId}
                  />
                </div>
              )}

              {/* 6. MY PRESCRIPTIONS */}
              {tab === 'prescriptions' && (
                <div className="space-y-5">
                  {prescriptions.length === 0 ? (
                    <div className="card-surface p-10 text-center text-sm text-slate-500">
                      Doctor-authorised digital prescriptions appear here after your consultation.
                    </div>
                  ) : (
                    prescriptions.map((rx) => {
                      const meds = JSON.parse(rx.medicines_json) as Array<{
                        name: string;
                        dosage: string;
                        frequency: string;
                        duration: string;
                        instructions?: string;
                      }>;
                      return (
                        <div key={rx.id} className="card-surface p-6 space-y-4">
                          <div className="flex flex-wrap items-start justify-between gap-3 border-b border-slate-100 pb-4">
                            <div>
                              <div className="flex items-center gap-2 mb-1">
                                <span className="font-mono text-xs font-bold text-teal">
                                  {rx.prescription_no}
                                </span>
                                <StatusBadge status="AUTHORISED" />
                              </div>
                              <h3 className="text-base font-bold text-navy">
                                {rx.clinical_impression}
                              </h3>
                              <p className="text-xs text-slate-500 mt-0.5">
                                Issued by {rx.doctor_name} ({rx.doctor_qualification}) ·{' '}
                                {rx.authorised_at?.slice(0, 16)}
                              </p>
                            </div>
                            <a
                              href={`/api/prescriptions/${rx.id}/pdf?_st=${encodeURIComponent(sessionToken)}`}
                              className="btn-primary py-2.5 px-4 text-xs"
                            >
                              <Download className="h-4 w-4" /> Download PDF Prescription
                            </a>
                          </div>

                          <div className="overflow-x-auto">
                            <table className="w-full text-left text-xs">
                              <thead>
                                <tr className="border-b border-slate-200 text-slate-500 uppercase">
                                  <th className="py-2 pr-3">Medicine / Remedy</th>
                                  <th className="py-2 pr-3">Dosage</th>
                                  <th className="py-2 pr-3">Frequency</th>
                                  <th className="py-2">Duration</th>
                                </tr>
                              </thead>
                              <tbody className="divide-y divide-slate-100">
                                {meds.map((m, idx) => (
                                  <tr key={idx}>
                                    <td className="py-2.5 pr-3">
                                      <p className="font-semibold text-navy">{m.name}</p>
                                      {m.instructions && (
                                        <p className="text-[11px] text-slate-500">{m.instructions}</p>
                                      )}
                                    </td>
                                    <td className="py-2.5 pr-3 text-slate-700">{m.dosage}</td>
                                    <td className="py-2.5 pr-3 text-slate-700">{m.frequency}</td>
                                    <td className="py-2.5 text-slate-700">{m.duration}</td>
                                  </tr>
                                ))}
                              </tbody>
                            </table>
                          </div>

                          {(rx.general_instructions || rx.dietary_advice) && (
                            <div className="rounded-xl bg-surface-muted p-4 space-y-2 text-xs text-slate-600">
                              {rx.general_instructions && (
                                <p>
                                  <strong className="text-navy">Instructions:</strong>{' '}
                                  {rx.general_instructions}
                                </p>
                              )}
                              {rx.dietary_advice && (
                                <p>
                                  <strong className="text-navy">Dietary & Lifestyle Advice:</strong>{' '}
                                  {rx.dietary_advice}
                                </p>
                              )}
                            </div>
                          )}

                          <div className="flex flex-wrap items-center justify-between gap-2 text-[11px] text-slate-400">
                            <span>Digital Signature: {rx.digital_signature_hash}</span>
                            {rx.followup_date && (
                              <span className="font-semibold text-teal">
                                Recommended Follow-Up: {rx.followup_date}
                              </span>
                            )}
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>
              )}

              {/* 7. MEDICAL REPORTS (Private Encrypted Upload & Access) */}
              {tab === 'reports' && (
                <div className="space-y-6">
                  <form onSubmit={handleUploadReport} className="card-surface p-6 space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="text-base font-bold text-navy">
                          Upload Diagnostic / Lab Report
                        </h3>
                        <p className="text-xs text-slate-500">
                          PDF, JPG, PNG or TXT (max 5 MB) · Encrypted at rest with AES-256-GCM · Visible only to you & Dr. Aparna Mishra.
                        </p>
                      </div>
                      <Lock className="h-5 w-5 text-teal shrink-0" />
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                      <div>
                        <label className="label-text">Report Title *</label>
                        <input
                          type="text"
                          required
                          value={repTitle}
                          onChange={(e) => setRepTitle(e.target.value)}
                          placeholder="e.g. Thyroid TSH / Ultrasound"
                          className="input-field"
                        />
                      </div>
                      <div>
                        <label className="label-text">Category</label>
                        <select
                          value={repCategory}
                          onChange={(e) => setRepCategory(e.target.value)}
                          className="input-field"
                        >
                          <option>Thyroid Profile</option>
                          <option>Blood / CBC / Vitamins</option>
                          <option>Ultrasound / Imaging</option>
                          <option>Women&apos;s Health / Hormone</option>
                          <option>Skin / Allergy Report</option>
                          <option>Previous Prescription</option>
                        </select>
                      </div>
                      <div>
                        <label className="label-text">Report Date</label>
                        <input
                          type="date"
                          value={repDate}
                          onChange={(e) => setRepDate(e.target.value)}
                          className="input-field"
                        />
                      </div>
                    </div>
                    <div className="flex flex-col sm:flex-row sm:items-center gap-3">
                      <input
                        type="file"
                        required
                        accept=".pdf,.jpg,.jpeg,.png,.webp,.txt"
                        onChange={(e) => setRepFile(e.target.files?.[0] || null)}
                        className="block w-full text-xs text-slate-600 file:mr-3 file:rounded-lg file:border-0 file:bg-aqua file:px-3.5 file:py-2 file:text-xs file:font-semibold file:text-navy hover:file:bg-teal hover:file:text-white"
                      />
                      <button type="submit" disabled={uploading} className="btn-primary shrink-0 text-xs">
                        <Upload className="h-4 w-4" />
                        {uploading ? 'Encrypting & Uploading…' : 'Upload Privately'}
                      </button>
                    </div>
                  </form>

                  <div className="space-y-3">
                    {reports.map((rp) => (
                      <div key={rp.id} className="card-surface p-5 space-y-3">
                        <div className="flex flex-wrap items-start justify-between gap-3">
                          <div className="flex items-start gap-3">
                            <FileText className="h-5 w-5 text-teal shrink-0 mt-0.5" />
                            <div>
                              <h4 className="font-heading text-sm font-bold text-navy">{rp.title}</h4>
                              <p className="text-xs text-slate-500">
                                {rp.category} · {rp.report_date || rp.created_at.slice(0, 10)} ·{' '}
                                {(rp.file_size_bytes / 1024).toFixed(1)} KB · AES-256 Encrypted
                              </p>
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            <StatusBadge status={rp.review_status} />
                            <a
                              href={`/api/reports/${rp.id}/download?_st=${encodeURIComponent(sessionToken)}`}
                              className="btn-secondary py-1.5 px-3 text-xs"
                            >
                              <Download className="h-3.5 w-3.5 text-teal" /> Download
                            </a>
                          </div>
                        </div>
                        {rp.doctor_remarks && (
                          <div className="rounded-xl bg-aqua p-3.5 text-xs text-navy">
                            <strong>Dr. Aparna Mishra’s Review Note:</strong> {rp.doctor_remarks}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* 8. PAYMENT HISTORY */}
              {tab === 'payments' && (
                <div className="space-y-4">
                  {payments.map((p) => (
                    <div key={p.id} className="card-surface p-5 space-y-3">
                      <div className="flex flex-wrap items-center justify-between gap-3">
                        <div>
                          <div className="flex items-center gap-2 mb-0.5">
                            <span className="font-mono text-xs font-bold text-navy">{p.receipt_no}</span>
                            <StatusBadge status={p.status} />
                          </div>
                          <p className="text-sm font-semibold text-navy">
                            {p.consultation_type_name} ({p.appointment_ref})
                          </p>
                          <p className="text-xs text-slate-500">
                            {p.payment_method} · {p.payer_detail || p.gateway} · {p.created_at.slice(0, 16)}
                          </p>
                        </div>
                        <div className="flex items-center gap-3">
                          <span className="font-heading text-lg font-bold text-navy tabular">
                            ₹{p.amount_inr}
                          </span>
                          <a
                            href={`/api/payments/${p.id}/receipt?_st=${encodeURIComponent(sessionToken)}`}
                            className="btn-secondary py-2 px-3.5 text-xs"
                          >
                            <Download className="h-3.5 w-3.5 text-teal" /> PDF Receipt
                          </a>
                        </div>
                      </div>
                      {(p.status === 'INITIATED' || p.status === 'FAILED') && (
                        <div className="pt-3 border-t border-slate-100 flex flex-col sm:flex-row items-start sm:items-center gap-3">
                          <span className="text-xs text-slate-600">
                            Pay ₹{p.amount_inr} to UPI <code>{clinicContact.upiId}</code> & submit UTR:
                          </span>
                          <input
                            type="text"
                            placeholder="12-digit UPI UTR"
                            value={payUtrMap[p.id] || ''}
                            onChange={(e) =>
                              setPayUtrMap({ ...payUtrMap, [p.id]: e.target.value })
                            }
                            className="input-field py-1.5 text-xs sm:w-48 font-mono"
                          />
                          <button
                            type="button"
                            onClick={() => submitPendingUtr(p.id)}
                            className="btn-primary py-1.5 px-3 text-xs"
                          >
                            Submit UTR
                          </button>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}

              {/* 9. FOLLOW-UP INFORMATION */}
              {tab === 'followups' && (
                <div className="space-y-4">
                  {followupItems.length === 0 ? (
                    <div className="card-surface p-8 text-center text-sm text-slate-500">
                      Follow-up dates and care instructions issued by Dr. Aparna Mishra will appear here.
                    </div>
                  ) : (
                    followupItems.map((f) => (
                      <div key={f.id} className="card-surface p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                        <div className="space-y-1.5">
                          <span className="inline-flex items-center gap-1.5 text-xs font-bold text-teal">
                            <CheckCircle2 className="h-4 w-4" /> Recommended Follow-Up: {f.followup_date}
                          </span>
                          <h3 className="text-base font-bold text-navy">
                            {f.concern_category} (Previous Ref: {f.reference_no})
                          </h3>
                          {f.followup_notes && (
                            <p className="text-xs text-slate-600 leading-relaxed max-w-2xl">
                              {f.followup_notes}
                            </p>
                          )}
                        </div>
                        <button
                          type="button"
                          onClick={() => setTab('book')}
                          className="btn-primary py-2.5 px-4 text-xs shrink-0"
                        >
                          Book Follow-Up Slot
                        </button>
                      </div>
                    ))
                  )}
                </div>
              )}

              {/* 10. NOTIFICATIONS */}
              {tab === 'notifications' && (
                <div className="space-y-4">
                  <div className="flex justify-end">
                    <button type="button" onClick={markAllRead} className="btn-secondary py-2 px-3.5 text-xs">
                      Mark All as Read
                    </button>
                  </div>
                  {notifications.map((n) => (
                    <div
                      key={n.id}
                      className={`card-surface p-4 flex items-start justify-between gap-4 ${
                        !n.is_read ? 'border-teal/50 bg-aqua/40' : ''
                      }`}
                    >
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="rounded bg-navy/10 px-2 py-0.5 text-[10px] font-bold text-navy">
                            {n.channel}
                          </span>
                          <span className="font-heading text-sm font-bold text-navy">{n.title}</span>
                        </div>
                        <p className="text-xs text-slate-600 leading-relaxed">{n.message}</p>
                        <p className="text-[11px] text-slate-400">{n.created_at}</p>
                      </div>
                      <StatusBadge status={n.delivery_status} />
                    </div>
                  ))}
                </div>
              )}

              {/* 11. MY PROFILE & DPDP PRIVACY */}
              {tab === 'profile' && (
                <div className="space-y-6">
                  <form onSubmit={handleSaveProfile} className="card-surface p-6 space-y-4">
                    <h3 className="text-base font-bold text-navy">Personal & Clinical Profile</h3>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                      <div>
                        <label className="label-text">Full Name</label>
                        <input
                          type="text"
                          value={userName}
                          onChange={(e) => setUserName(e.target.value)}
                          className="input-field"
                        />
                      </div>
                      <div>
                        <label className="label-text">Mobile / WhatsApp</label>
                        <input
                          type="tel"
                          value={userPhone}
                          onChange={(e) => setUserPhone(e.target.value)}
                          className="input-field tabular"
                        />
                      </div>
                      <div>
                        <label className="label-text">Date of Birth</label>
                        <input
                          type="date"
                          value={String(profile.date_of_birth || '')}
                          onChange={(e) => setProfile({ ...profile, date_of_birth: e.target.value })}
                          className="input-field"
                        />
                      </div>
                      <div>
                        <label className="label-text">Gender</label>
                        <input
                          type="text"
                          value={String(profile.gender || '')}
                          onChange={(e) => setProfile({ ...profile, gender: e.target.value })}
                          className="input-field"
                        />
                      </div>
                      <div>
                        <label className="label-text">Blood Group</label>
                        <input
                          type="text"
                          value={String(profile.blood_group || '')}
                          onChange={(e) => setProfile({ ...profile, blood_group: e.target.value })}
                          className="input-field"
                        />
                      </div>
                      <div>
                        <label className="label-text">City</label>
                        <input
                          type="text"
                          value={String(profile.city || '')}
                          onChange={(e) => setProfile({ ...profile, city: e.target.value })}
                          className="input-field"
                        />
                      </div>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="label-text">Known Allergies</label>
                        <input
                          type="text"
                          value={String(profile.allergies || '')}
                          onChange={(e) => setProfile({ ...profile, allergies: e.target.value })}
                          className="input-field"
                        />
                      </div>
                      <div>
                        <label className="label-text">Ongoing Medical Conditions</label>
                        <input
                          type="text"
                          value={String(profile.chronic_conditions || '')}
                          onChange={(e) =>
                            setProfile({ ...profile, chronic_conditions: e.target.value })
                          }
                          className="input-field"
                        />
                      </div>
                      <div>
                        <label className="label-text">Current Medications</label>
                        <input
                          type="text"
                          value={String(profile.current_medications || '')}
                          onChange={(e) =>
                            setProfile({ ...profile, current_medications: e.target.value })
                          }
                          className="input-field"
                        />
                      </div>
                      <div>
                        <label className="label-text">Emergency Contact (Name & Phone)</label>
                        <input
                          type="text"
                          value={String(profile.emergency_contact_name || '')}
                          onChange={(e) =>
                            setProfile({ ...profile, emergency_contact_name: e.target.value })
                          }
                          className="input-field"
                        />
                      </div>
                    </div>
                    <button type="submit" className="btn-primary text-xs">
                      Save Profile Updates
                    </button>
                  </form>

                  {/* Password + DPDP Privacy Controls */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <form onSubmit={handleChangePassword} className="card-surface p-6 space-y-3">
                      <h3 className="text-sm font-bold text-navy">Change Account Password</h3>
                      <input
                        type="password"
                        required
                        placeholder="Current password"
                        value={curPw}
                        onChange={(e) => setCurPw(e.target.value)}
                        className="input-field"
                      />
                      <input
                        type="password"
                        required
                        minLength={8}
                        placeholder="New password (min. 8 characters)"
                        value={newPw}
                        onChange={(e) => setNewPw(e.target.value)}
                        className="input-field"
                      />
                      <button type="submit" className="btn-secondary text-xs">
                        Update Password
                      </button>
                    </form>

                    <div className="card-surface p-6 space-y-4">
                      <h3 className="text-sm font-bold text-navy">
                        DPDP Act 2023 Consent & Data Rights
                      </h3>
                      <label className="flex items-center justify-between text-xs text-slate-700">
                        <span>WhatsApp Appointment Notifications</span>
                        <input
                          type="checkbox"
                          checked={waConsent}
                          onChange={async (e) => {
                            const next = e.target.checked;
                            setWaConsent(next);
                            await apiFetch('/api/auth/me', {
                              method: 'PATCH',
                              headers: { 'Content-Type': 'application/json' },
                              body: JSON.stringify({
                                action: 'TOGGLE_WHATSAPP_CONSENT',
                                granted: next,
                              }),
                            });
                            flash('Consent preference saved.');
                          }}
                          className="h-4 w-4 rounded text-teal"
                        />
                      </label>
                      <div className="flex flex-wrap gap-2 pt-2">
                        <a href={`/api/auth/me?export=1&_st=${encodeURIComponent(sessionToken)}`} className="btn-secondary py-2 px-3 text-xs">
                          <Download className="h-3.5 w-3.5 text-teal" /> Export My Data (JSON)
                        </a>
                        <button
                          type="button"
                          onClick={async () => {
                            const r = await apiFetch('/api/auth/me', {
                              method: 'PATCH',
                              headers: { 'Content-Type': 'application/json' },
                              body: JSON.stringify({ action: 'REQUEST_DELETION' }),
                            });
                            const d = await r.json();
                            flash(d.message);
                            refreshAll();
                          }}
                          className="rounded-xl border border-rose-200 px-3 py-2 text-xs font-semibold text-rose-700 hover:bg-rose-50"
                        >
                          Request Account Deletion
                        </button>
                      </div>
                      {profile.deletion_requested_at && (
                        <p className="text-[11px] text-amber-700">
                          Deletion request logged on {String(profile.deletion_requested_at)}.
                        </p>
                      )}
                    </div>
                  </div>
                </div>
              )}

              {/* 12. SUPPORT */}
              {tab === 'support' && (
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                  <div className="lg:col-span-7 space-y-6">
                    <form onSubmit={submitTicket} className="card-surface p-6 space-y-4">
                      <h3 className="text-base font-bold text-navy">Message Clinic Support Desk</h3>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <select
                          value={supCat}
                          onChange={(e) => setSupCat(e.target.value)}
                          className="input-field"
                        >
                          <option value="APPOINTMENT">Appointment Help</option>
                          <option value="PAYMENT">Billing / Receipt</option>
                          <option value="REPORTS">Reports / Prescription</option>
                          <option value="TECHNICAL">Video Room Help</option>
                        </select>
                        <input
                          type="text"
                          required
                          placeholder="Subject"
                          value={supSubject}
                          onChange={(e) => setSupSubject(e.target.value)}
                          className="input-field"
                        />
                      </div>
                      <textarea
                        required
                        rows={3}
                        placeholder="Describe how our clinic desk can assist you..."
                        value={supMsg}
                        onChange={(e) => setSupMsg(e.target.value)}
                        className="input-field"
                      />
                      <button type="submit" className="btn-primary text-xs">
                        Submit Support Ticket
                      </button>
                    </form>

                    {tickets.length > 0 && (
                      <div className="card-surface p-6 space-y-3">
                        <h3 className="text-sm font-bold text-navy">My Support Tickets</h3>
                        {tickets.map((t) => (
                          <div key={t.id} className="rounded-xl bg-surface-muted p-4 space-y-1.5 text-xs">
                            <div className="flex items-center justify-between">
                              <span className="font-bold text-navy">
                                {t.ticket_no} · {t.subject}
                              </span>
                              <StatusBadge status={t.status} />
                            </div>
                            <p className="text-slate-600">{t.message}</p>
                            {t.staff_reply && (
                              <div className="mt-2 rounded-lg bg-aqua p-2.5 text-navy">
                                <strong>Clinic Reply ({t.replied_by}):</strong> {t.staff_reply}
                              </div>
                            )}
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  <div className="lg:col-span-5 space-y-6">
                    <div className="card-surface p-6 space-y-3 text-xs">
                      <h3 className="text-sm font-bold text-navy">Direct Clinic Helpline</h3>
                      <p className="text-slate-600">Hours: {clinicContact.timings}</p>
                      <a
                        href={`https://wa.me/${clinicContact.whatsapp}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="btn-primary w-full text-xs"
                      >
                        Chat on WhatsApp ({clinicContact.phone})
                      </a>
                      <a href={`mailto:${clinicContact.email}`} className="btn-secondary w-full text-xs">
                        Email {clinicContact.email}
                      </a>
                    </div>
                    <div className="card-surface p-6 space-y-3">
                      <h3 className="text-sm font-bold text-navy">Rate Your Consultation</h3>
                      <FeedbackForm />
                    </div>
                  </div>
                </div>
              )}
            </>
          )}
        </main>
      </div>

      {/* Reschedule Modal */}
      {reschedAppt && (
        <div className="fixed inset-0 z-50 bg-navy/50 flex items-center justify-center p-4">
          <div className="card-surface max-w-md w-full p-6 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-navy">
                Reschedule {reschedAppt.reference_no}
              </h3>
              <button type="button" onClick={() => setReschedAppt(null)}>
                <X className="h-4 w-4 text-slate-500" />
              </button>
            </div>
            <div>
              <label className="label-text">New Date (Mon–Sat)</label>
              <input
                type="date"
                min={new Date().toISOString().slice(0, 10)}
                value={reschedDate}
                onChange={(e) => loadReschedSlots(e.target.value)}
                className="input-field"
              />
            </div>
            <div>
              <label className="label-text">Select Open Slot (3:00 PM – 8:00 PM)</label>
              <div className="grid grid-cols-3 gap-2 max-h-44 overflow-y-auto">
                {reschedSlots.map((s) => (
                  <button
                    key={s.startTime}
                    type="button"
                    disabled={s.isBooked}
                    onClick={() => setReschedTime(s.startTime)}
                    className={`rounded-lg border py-2 text-xs font-semibold tabular ${
                      s.isBooked
                        ? 'opacity-40 line-through'
                        : reschedTime === s.startTime
                        ? 'bg-teal text-white border-teal'
                        : 'border-slate-200 text-navy hover:bg-aqua'
                    }`}
                  >
                    {s.label}
                  </button>
                ))}
              </div>
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setReschedAppt(null)}
                className="btn-secondary py-2 px-4 text-xs"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={!reschedTime}
                onClick={confirmReschedule}
                className="btn-primary py-2 px-4 text-xs"
              >
                Confirm New Slot
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
