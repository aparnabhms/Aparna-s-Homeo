import { NextRequest, NextResponse } from 'next/server';
import { jwtVerify } from 'jose';

const SESSION_COOKIE = 'aparna_clinic_session';

function getSecret() {
  const secret =
    process.env.JWT_SECRET ||
    'dr-aparna-mishra-clinic-dev-jwt-secret-change-in-production-2026-secure-key';
  return new TextEncoder().encode(secret);
}

function getPublicOrigin(req: NextRequest): string {
  const protoHeader = (req.headers.get('x-forwarded-proto') || '').split(',')[0].trim().toLowerCase();
  const hostHeader = (req.headers.get('x-forwarded-host') || req.headers.get('host') || '')
    .split(',')[0]
    .trim();
  if (hostHeader && !hostHeader.startsWith('0.0.0.0')) {
    const proto =
      protoHeader === 'https' || hostHeader.toLowerCase().endsWith('.e2b.app') ? 'https' : protoHeader || 'http';
    return `${proto}://${hostHeader}`;
  }
  return req.nextUrl.origin;
}

function isHttps(req: NextRequest): boolean {
  const proto = (req.headers.get('x-forwarded-proto') || '').split(',')[0].trim().toLowerCase();
  if (proto === 'https' || req.nextUrl.protocol === 'https:') return true;
  const host = (req.headers.get('x-forwarded-host') || req.headers.get('host') || '').toLowerCase();
  return host.endsWith('.e2b.app');
}

function buildRedirect(req: NextRequest, targetPath: string, params?: Record<string, string>) {
  const origin = getPublicOrigin(req);
  const url = new URL(targetPath, origin);
  if (params) {
    for (const [k, v] of Object.entries(params)) {
      if (v) url.searchParams.set(k, v);
    }
  }
  return NextResponse.redirect(url);
}

export async function middleware(req: NextRequest) {
  const { pathname, searchParams } = req.nextUrl;

  if (!pathname.startsWith('/portal') && !pathname.startsWith('/admin')) {
    return NextResponse.next();
  }

  const rawCookie = req.cookies.get(SESSION_COOKIE)?.value || '';
  let cookieToken = rawCookie;
  try {
    if (rawCookie.includes('%')) cookieToken = decodeURIComponent(rawCookie);
  } catch {
    cookieToken = rawCookie;
  }

  const queryToken = (searchParams.get('_st') || '').trim();
  const authHeader = req.headers.get('authorization') || '';
  const bearerToken = authHeader.startsWith('Bearer ') ? authHeader.slice(7).trim() : '';
  const customToken = (req.headers.get('x-clinic-session') || '').trim();

  // Prioritize explicit fresh handoff token (_st / Bearer) over potentially stale cookie
  const candidates = [queryToken, bearerToken, customToken, cookieToken].filter(Boolean);

  if (candidates.length === 0) {
    const cleanParams = new URLSearchParams(searchParams.toString());
    cleanParams.delete('_st');
    const fullNext = cleanParams.toString() ? `${pathname}?${cleanParams.toString()}` : pathname;
    return buildRedirect(req, '/login', {
      next: fullNext,
      autoresume: '1',
    });
  }

  let verifiedToken: string | null = null;
  let verifiedRole = '';

  for (const tok of candidates) {
    try {
      const { payload } = await jwtVerify(tok, getSecret(), {
        issuer: 'aparna-mishra-clinic',
      });
      if (payload.sub && payload.role) {
        verifiedToken = tok;
        verifiedRole = String(payload.role);
        break;
      }
    } catch {
      // try next candidate token
    }
  }

  if (!verifiedToken) {
    const cleanParams = new URLSearchParams(searchParams.toString());
    cleanParams.delete('_st');
    const fullNext = cleanParams.toString() ? `${pathname}?${cleanParams.toString()}` : pathname;
    const redir = buildRedirect(req, '/login', { next: fullNext });
    if (cookieToken) {
      if (isHttps(req)) {
        redir.headers.append(
          'Set-Cookie',
          `${SESSION_COOKIE}=; Path=/; Max-Age=0; HttpOnly; Secure; SameSite=None; Partitioned`
        );
      } else {
        redir.cookies.set(SESSION_COOKIE, '', { path: '/', maxAge: 0 });
      }
    }
    return redir;
  }

  const isClinicRole = ['DOCTOR', 'ADMIN', 'STAFF'].includes(verifiedRole);

  if (pathname.startsWith('/admin') && !isClinicRole) {
    return buildRedirect(req, '/portal', { _st: verifiedToken });
  }
  if (pathname.startsWith('/portal') && isClinicRole) {
    const startMode = searchParams.get('start');
    const targetTab = startMode || searchParams.get('tab') === 'video' || searchParams.get('tab') === 'chat' ? 'chat' : '';
    return buildRedirect(
      req,
      '/admin',
      targetTab ? { tab: targetTab, _st: verifiedToken } : { _st: verifiedToken }
    );
  }

  // Forward verified token to Server Components & refresh Partitioned cookie when needed
  const reqHeaders = new Headers(req.headers);
  reqHeaders.set('x-clinic-session', verifiedToken);
  const res = NextResponse.next({ request: { headers: reqHeaders } });

  if (verifiedToken !== cookieToken) {
    const maxAge = 60 * 60 * 24 * 7;
    if (isHttps(req)) {
      res.headers.append(
        'Set-Cookie',
        `${SESSION_COOKIE}=${encodeURIComponent(
          verifiedToken
        )}; Path=/; Max-Age=${maxAge}; HttpOnly; Secure; SameSite=None; Partitioned`
      );
    } else {
      res.cookies.set(SESSION_COOKIE, verifiedToken, {
        httpOnly: true,
        secure: false,
        sameSite: 'lax',
        path: '/',
        maxAge,
      });
    }
  }

  return res;
}

export const config = {
  matcher: ['/portal/:path*', '/admin/:path*'],
};
