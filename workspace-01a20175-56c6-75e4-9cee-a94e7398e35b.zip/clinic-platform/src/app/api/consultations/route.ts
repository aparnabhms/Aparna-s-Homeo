import { NextRequest, NextResponse } from 'next/server';
import { getDb, logAudit } from '@/lib/db';
import { getClientIp, getRequestUser } from '@/lib/auth';
import { provisionVideoConsultation } from '@/lib/services';

export async function GET(req: NextRequest) {
  const user = await getRequestUser(req);
  if (!user) return NextResponse.json({ error: 'Authentication required.' }, { status: 401 });

  const db = getDb();
  if (user.role === 'PATIENT') {
    // Patients never receive doctor's private internal clinical notes — only session metadata & advice
    const sessions = db
      .prepare(
        `SELECT c.id, c.appointment_id, c.provider, c.room_code, c.meeting_url, c.status, c.auto_recording,
                c.started_at, c.ended_at, c.advice, c.followup_date, c.referral_advised, c.referral_details,
                a.reference_no, a.appointment_date, a.start_time, a.end_time, a.concern_category,
                a.status as appointment_status, a.patient_display_name,
                ct.name as consultation_type_name, ct.mode as consultation_mode
         FROM consultations c
         JOIN appointments a ON a.id = c.appointment_id
         JOIN consultation_types ct ON ct.id = a.consultation_type_id
         WHERE c.patient_id = ?
         ORDER BY a.appointment_date DESC, a.start_time DESC`
      )
      .all(user.id);
    return NextResponse.json({ consultations: sessions });
  }

  if (!['DOCTOR', 'ADMIN', 'STAFF'].includes(user.role)) {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
  }

  // Staff sees operational fields only; Doctor sees full clinical notes
  const isDoctor = user.role === 'DOCTOR';
  const sessions = db
    .prepare(
      `SELECT c.id, c.appointment_id, c.patient_id, c.provider, c.room_code, c.meeting_url, c.status, c.auto_recording,
              c.started_at, c.ended_at,
              ${isDoctor ? 'c.clinical_notes, c.homoeopathic_case_summary, c.provisional_impression, c.advice, c.referral_advised, c.referral_details,' : ''}
              c.followup_date,
              a.reference_no, a.appointment_date, a.start_time, a.end_time, a.concern_category,
              a.chief_complaint, a.status as appointment_status, a.patient_display_name,
              u.full_name as patient_name, u.phone as patient_phone, pp.patient_code,
              ct.name as consultation_type_name, ct.mode as consultation_mode
       FROM consultations c
       JOIN appointments a ON a.id = c.appointment_id
       JOIN users u ON u.id = c.patient_id
       LEFT JOIN patient_profiles pp ON pp.user_id = c.patient_id
       JOIN consultation_types ct ON ct.id = a.consultation_type_id
       ORDER BY a.appointment_date DESC, a.start_time DESC`
    )
    .all();

  return NextResponse.json({ consultations: sessions });
}

export async function PATCH(req: NextRequest) {
  const user = await getRequestUser(req);
  if (!user) return NextResponse.json({ error: 'Authentication required.' }, { status: 401 });

  const db = getDb();
  const body = await req.json();
  const action = String(body.action || '');
  const ip = getClientIp(req);

  if (action === 'PROVISION') {
    if (!['DOCTOR', 'ADMIN', 'STAFF'].includes(user.role)) {
      return NextResponse.json({ error: 'Authorisation required.' }, { status: 403 });
    }
    const appt = db
      .prepare('SELECT id, patient_id, doctor_id, reference_no FROM appointments WHERE id = ?')
      .get(String(body.appointmentId || '')) as
      | { id: string; patient_id: string; doctor_id: string; reference_no: string }
      | undefined;
    if (!appt) return NextResponse.json({ error: 'Appointment not found.' }, { status: 404 });

    const vc = await provisionVideoConsultation({
      appointmentId: appt.id,
      patientId: appt.patient_id,
      doctorId: appt.doctor_id,
    });
    logAudit({
      actorId: user.id,
      actorRole: user.role,
      actorName: user.fullName,
      action: 'VIDEO_ROOM_PROVISIONED',
      entityType: 'CONSULTATION',
      entityId: vc.id,
      details: `Created authenticated non-recorded room for ${appt.reference_no}`,
      ipAddress: ip,
    });
    return NextResponse.json({ ok: true, consultation: vc });
  }

  const consId = String(body.consultationId || '');
  const cons = db.prepare('SELECT * FROM consultations WHERE id = ?').get(consId) as
    | { id: string; appointment_id: string; patient_id: string; status: string }
    | undefined;
  if (!cons) return NextResponse.json({ error: 'Consultation session not found.' }, { status: 404 });

  if (action === 'JOIN_LOG') {
    if (user.role === 'PATIENT' && cons.patient_id !== user.id) {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
    }
    if (user.role === 'DOCTOR' && cons.status !== 'COMPLETED') {
      db.prepare(
        "UPDATE consultations SET status = 'IN_PROGRESS', started_at = COALESCE(started_at, datetime('now')), updated_at = datetime('now') WHERE id = ?"
      ).run(cons.id);
    }
    logAudit({
      actorId: user.id,
      actorRole: user.role,
      actorName: user.fullName,
      action: 'VIDEO_SESSION_JOINED',
      entityType: 'CONSULTATION',
      entityId: cons.id,
      details: `${user.role} joined authenticated non-recorded video room.`,
      ipAddress: ip,
    });
    return NextResponse.json({ ok: true });
  }

  // SAVE_NOTES — Strictly DOCTOR only
  if (action === 'SAVE_NOTES') {
    if (user.role !== 'DOCTOR') {
      return NextResponse.json({ error: 'Only the authorised doctor can update clinical notes.' }, { status: 403 });
    }
    const nextStatus = body.markCompleted ? 'COMPLETED' : String(body.status || cons.status);
    const followupDate = body.followupDate ? String(body.followupDate) : null;

    db.prepare(`
      UPDATE consultations SET
        status = ?,
        clinical_notes = ?,
        homoeopathic_case_summary = ?,
        provisional_impression = ?,
        advice = ?,
        referral_advised = ?,
        referral_details = ?,
        followup_date = ?,
        ended_at = CASE WHEN ? = 'COMPLETED' THEN datetime('now') ELSE ended_at END,
        updated_at = datetime('now')
      WHERE id = ?
    `).run(
      nextStatus,
      body.clinicalNotes || null,
      body.homoeopathicCaseSummary || null,
      body.provisionalImpression || null,
      body.advice || null,
      body.referralAdvised ? 1 : 0,
      body.referralDetails || null,
      followupDate,
      nextStatus,
      cons.id
    );

    if (body.markCompleted || followupDate) {
      db.prepare(`
        UPDATE appointments SET
          status = CASE WHEN ? = 1 THEN 'COMPLETED' ELSE status END,
          followup_date = COALESCE(?, followup_date),
          followup_notes = COALESCE(?, followup_notes),
          updated_at = datetime('now')
        WHERE id = ?
      `).run(body.markCompleted ? 1 : 0, followupDate, body.advice || null, cons.appointment_id);
    }

    logAudit({
      actorId: user.id,
      actorRole: user.role,
      actorName: user.fullName,
      action: 'CONSULTATION_NOTES_SAVED',
      entityType: 'CONSULTATION',
      entityId: cons.id,
      ipAddress: ip,
    });

    return NextResponse.json({ ok: true });
  }

  return NextResponse.json({ error: 'Invalid consultation action.' }, { status: 400 });
}
