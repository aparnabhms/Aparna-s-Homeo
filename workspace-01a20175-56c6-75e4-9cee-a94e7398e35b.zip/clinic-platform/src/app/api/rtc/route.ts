import crypto from 'crypto';
import { NextRequest, NextResponse } from 'next/server';
import { getDb, logAudit } from '@/lib/db';
import { checkRateLimit, generateId, getClientIp, getRequestUser } from '@/lib/auth';

export const dynamic = 'force-dynamic';

interface RtcCallRow {
  id: string;
  patient_id: string;
  patient_name: string;
  initiator_id: string;
  initiator_role: string;
  initiator_name: string;
  call_type: 'AUDIO' | 'VIDEO';
  status: 'RINGING' | 'CONNECTED' | 'ENDED' | 'DECLINED' | 'MISSED';
  offer_sdp: string | null;
  answer_sdp: string | null;
  caller_key: string | null;
  peer_key: string | null;
  auto_recording: number;
  connected_at: string | null;
  ended_at: string | null;
  updated_at: string;
  created_at: string;
}

function getIceServers() {
  const servers: Array<{
    urls: string | string[];
    username?: string;
    credential?: string;
  }> = [
    {
      urls: [
        'stun:stun.l.google.com:19302',
        'stun:stun1.l.google.com:19302',
        'stun:stun2.l.google.com:19302',
      ],
    },
  ];
  if (process.env.TURN_SERVER_URL && process.env.TURN_USERNAME && process.env.TURN_CREDENTIAL) {
    servers.push({
      urls: process.env.TURN_SERVER_URL,
      username: process.env.TURN_USERNAME,
      credential: process.env.TURN_CREDENTIAL,
    });
  }
  return servers;
}

function safeKeyEqual(a: string | null | undefined, b: string | null | undefined): boolean {
  if (!a || !b || a.length !== b.length) return false;
  try {
    return crypto.timingSafeEqual(Buffer.from(a), Buffer.from(b));
  } catch {
    return false;
  }
}

/**
 * Resolves participant authorization & side (CALLER vs CALLEE) using either:
 * 1. One-time cryptographic room key (`ck` for caller full-tab launch, `jk` for counterparty join link)
 * 2. Verified clinic session (Cookie / Bearer / X-Clinic-Session / _st)
 */
function resolveCallParticipant(
  call: RtcCallRow,
  user: { id: string; role: string; fullName: string } | null,
  roomKey: string | null
): {
  allowed: boolean;
  side: 'CALLER' | 'CALLEE';
  participantMode: 'PATIENT' | 'CLINIC';
  displayName: string;
} | null {
  const initiatorIsPatient = call.initiator_role === 'PATIENT';

  if (roomKey) {
    if (safeKeyEqual(roomKey, call.caller_key)) {
      return {
        allowed: true,
        side: 'CALLER',
        participantMode: initiatorIsPatient ? 'PATIENT' : 'CLINIC',
        displayName: call.initiator_name,
      };
    }
    if (safeKeyEqual(roomKey, call.peer_key)) {
      return {
        allowed: true,
        side: 'CALLEE',
        participantMode: initiatorIsPatient ? 'CLINIC' : 'PATIENT',
        displayName: initiatorIsPatient ? 'Dr. Aparna Mishra' : call.patient_name,
      };
    }
  }

  if (!user) return null;

  const userIsClinic = ['DOCTOR', 'ADMIN', 'STAFF'].includes(user.role);
  const userIsOwnerPatient = user.role === 'PATIENT' && call.patient_id === user.id;

  if (!userIsClinic && !userIsOwnerPatient) return null;

  const userIsPatient = user.role === 'PATIENT';
  const side: 'CALLER' | 'CALLEE' = initiatorIsPatient === userIsPatient ? 'CALLER' : 'CALLEE';

  return {
    allowed: true,
    side,
    participantMode: userIsPatient ? 'PATIENT' : 'CLINIC',
    displayName: user.fullName,
  };
}

export async function GET(req: NextRequest) {
  const db = getDb();

  // Auto-expire stale RINGING calls after 5 minutes
  db.prepare(
    "UPDATE rtc_calls SET status = 'MISSED', ended_at = datetime('now'), updated_at = datetime('now') WHERE status = 'RINGING' AND created_at < datetime('now', '-5 minutes')"
  ).run();

  const callId = req.nextUrl.searchParams.get('callId');
  const roomKey =
    req.nextUrl.searchParams.get('rk') ||
    req.headers.get('x-call-key') ||
    null;
  const afterIce = Number(req.nextUrl.searchParams.get('afterIce') || '0') || 0;
  const user = await getRequestUser(req);

  if (callId) {
    const call = db.prepare('SELECT * FROM rtc_calls WHERE id = ?').get(callId) as
      | RtcCallRow
      | undefined;
    if (!call) {
      return NextResponse.json({ error: 'Call session not found or expired.' }, { status: 404 });
    }

    const participant = resolveCallParticipant(call, user, roomKey);
    if (!participant) {
      return NextResponse.json(
        { error: user ? 'Access denied to this private call.' : 'Authentication required.' },
        { status: user ? 403 : 401 }
      );
    }

    const remoteSide = participant.side === 'CALLER' ? 'CALLEE' : 'CALLER';
    const remoteCandidates = db
      .prepare(
        'SELECT id, candidate_json FROM rtc_ice_candidates WHERE call_id = ? AND sender_side = ? AND id > ? ORDER BY id ASC'
      )
      .all(call.id, remoteSide, afterIce) as Array<{ id: number; candidate_json: string }>;

    return NextResponse.json({
      call: {
        id: call.id,
        patientId: call.patient_id,
        patientName: call.patient_name,
        initiatorId: call.initiator_id,
        initiatorRole: call.initiator_role,
        initiatorName: call.initiator_name,
        callType: call.call_type,
        status: call.status,
        offerSdp: call.offer_sdp ? JSON.parse(call.offer_sdp) : null,
        answerSdp: call.answer_sdp ? JSON.parse(call.answer_sdp) : null,
        callerKey: participant.side === 'CALLER' ? call.caller_key : undefined,
        peerKey: participant.side === 'CALLER' ? call.peer_key : undefined,
        autoRecording: false,
        connectedAt: call.connected_at,
        endedAt: call.ended_at,
        createdAt: call.created_at,
      },
      mySide: participant.side,
      participantMode: participant.participantMode,
      displayName: participant.displayName,
      iceServers: getIceServers(),
      clinicPhone: '+91 8123108149',
      clinicWhatsapp: '918123108149',
      remoteCandidates: remoteCandidates.map((r) => ({
        id: r.id,
        candidate: JSON.parse(r.candidate_json),
      })),
    });
  }

  // Poll incoming ringing calls for logged-in user
  if (!user) {
    return NextResponse.json({ incomingCall: null }, { status: 200 });
  }

  const isClinic = ['DOCTOR', 'ADMIN', 'STAFF'].includes(user.role);
  const incoming = isClinic
    ? (db
        .prepare(
          `SELECT id, patient_id, patient_name, initiator_name, initiator_role, call_type, status, peer_key, created_at
           FROM rtc_calls
           WHERE status = 'RINGING' AND initiator_role = 'PATIENT'
           ORDER BY created_at DESC LIMIT 1`
        )
        .get() as RtcCallRow | undefined)
    : (db
        .prepare(
          `SELECT id, patient_id, patient_name, initiator_name, initiator_role, call_type, status, peer_key, created_at
           FROM rtc_calls
           WHERE status = 'RINGING' AND patient_id = ? AND initiator_role != 'PATIENT'
           ORDER BY created_at DESC LIMIT 1`
        )
        .get(user.id) as RtcCallRow | undefined);

  return NextResponse.json({
    incomingCall: incoming || null,
    iceServers: getIceServers(),
    clinicPhone: '+91 8123108149',
    clinicWhatsapp: '918123108149',
  });
}

export async function POST(req: NextRequest) {
  const ip = getClientIp(req);
  const body = await req.json();
  const action = String(body.action || '');
  const roomKey =
    (body.roomKey ? String(body.roomKey) : null) ||
    req.nextUrl.searchParams.get('rk') ||
    req.headers.get('x-call-key') ||
    null;
  const user = await getRequestUser(req);
  const db = getDb();

  if (action === 'START') {
    if (!user) {
      return NextResponse.json(
        { error: 'Your session expired. Please click Sign in with Google to reconnect.' },
        { status: 401 }
      );
    }

    const rl = checkRateLimit(`rtc-start:${user.id}`, 30, 5 * 60 * 1000);
    if (!rl.allowed) {
      return NextResponse.json(
        { error: 'Too many call attempts. Please wait a moment.' },
        { status: 429 }
      );
    }

    const isClinic = ['DOCTOR', 'ADMIN', 'STAFF'].includes(user.role);
    const patientId = isClinic ? String(body.patientId || '').trim() : user.id;
    if (!patientId) {
      return NextResponse.json({ error: 'Please select a patient to call.' }, { status: 400 });
    }

    const patRow = db
      .prepare('SELECT id, full_name, phone FROM users WHERE id = ?')
      .get(patientId) as { id: string; full_name: string; phone: string | null } | undefined;
    if (!patRow) {
      return NextResponse.json({ error: 'Patient account not found.' }, { status: 404 });
    }

    const callType: 'AUDIO' | 'VIDEO' = body.callType === 'AUDIO' ? 'AUDIO' : 'VIDEO';
    const callId = generateId('call');
    const callerKey = crypto.randomBytes(16).toString('hex');
    const peerKey = crypto.randomBytes(16).toString('hex');
    const offerStr = body.offerSdp ? JSON.stringify(body.offerSdp) : null;

    db.prepare(
      "UPDATE rtc_calls SET status = 'ENDED', ended_at = datetime('now'), updated_at = datetime('now') WHERE patient_id = ? AND initiator_id = ? AND status = 'RINGING'"
    ).run(patientId, user.id);

    db.prepare(`
      INSERT INTO rtc_calls (
        id, patient_id, patient_name, initiator_id, initiator_role, initiator_name,
        call_type, status, offer_sdp, caller_key, peer_key, auto_recording
      ) VALUES (?, ?, ?, ?, ?, ?, ?, 'RINGING', ?, ?, ?, 0)
    `).run(
      callId,
      patientId,
      patRow.full_name,
      user.id,
      user.role,
      user.fullName,
      callType,
      offerStr,
      callerKey,
      peerKey
    );

    const callUrl = `/call/${callId}`;
    const msgType = callType === 'AUDIO' ? 'AUDIO_CALL' : 'VIDEO_CALL';
    const label = callType === 'AUDIO' ? 'Live Audio Call' : 'Live HD Video Call';
    const msgContent = isClinic
      ? `Dr. Aparna Mishra (+91 8123108149) is calling you on ${label}. Tap Answer / Join Call now.`
      : `${patRow.full_name} started a ${label} (Clinic Line: +91 8123108149). Tap Answer / Join Call to connect.`;

    db.prepare(`
      INSERT INTO clinic_messages (
        id, patient_id, sender_id, sender_role, sender_name,
        message_type, content, call_url, call_phone, is_read
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, '+918123108149', 0)
    `).run(generateId('msg'), patientId, user.id, user.role, user.fullName, msgType, msgContent, callUrl);

    const recipientId = isClinic
      ? patientId
      : (db.prepare("SELECT id FROM users WHERE role = 'DOCTOR' LIMIT 1").get() as { id: string } | undefined)?.id;
    if (recipientId) {
      db.prepare(`
        INSERT INTO notifications (id, user_id, channel, title, message, delivery_status)
        VALUES (?, ?, 'IN_APP', ?, ?, 'DELIVERED')
      `).run(generateId('ntf'), recipientId, `Incoming ${label}`, msgContent);
    }

    logAudit({
      actorId: user.id,
      actorRole: user.role,
      actorName: user.fullName,
      action: `WEBRTC_${callType}_CALL_STARTED`,
      entityType: 'RTC_CALL',
      entityId: callId,
      details: `Started non-recorded WebRTC ${label} for ${patRow.full_name} (+91 8123108149)`,
      ipAddress: ip,
    });

    return NextResponse.json({
      ok: true,
      callId,
      callType,
      callUrl,
      callerKey,
      peerKey,
      iceServers: getIceServers(),
      patientName: patRow.full_name,
      patientPhone: patRow.phone,
      clinicPhone: '+91 8123108149',
      clinicWhatsapp: '918123108149',
    });
  }

  // Existing-call signaling actions (authenticated via session OR cryptographic roomKey)
  const callId = String(body.callId || '').trim();
  const call = db.prepare('SELECT * FROM rtc_calls WHERE id = ?').get(callId) as
    | RtcCallRow
    | undefined;
  if (!call) return NextResponse.json({ error: 'Call session not found.' }, { status: 404 });

  const participant = resolveCallParticipant(call, user, roomKey);
  if (!participant) {
    return NextResponse.json(
      { error: user ? 'Forbidden.' : 'Authentication required.' },
      { status: user ? 403 : 401 }
    );
  }

  if (action === 'OFFER') {
    if (!body.offerSdp) return NextResponse.json({ error: 'Missing offerSdp.' }, { status: 400 });
    if (body.resetIce) {
      db.prepare('DELETE FROM rtc_ice_candidates WHERE call_id = ?').run(call.id);
      db.prepare(
        "UPDATE rtc_calls SET offer_sdp = ?, answer_sdp = NULL, updated_at = datetime('now') WHERE id = ?"
      ).run(JSON.stringify(body.offerSdp), call.id);
    } else {
      db.prepare(
        "UPDATE rtc_calls SET offer_sdp = ?, updated_at = datetime('now') WHERE id = ?"
      ).run(JSON.stringify(body.offerSdp), call.id);
    }
    return NextResponse.json({ ok: true });
  }

  if (action === 'ANSWER') {
    if (!body.answerSdp) return NextResponse.json({ error: 'Missing answerSdp.' }, { status: 400 });
    db.prepare(`
      UPDATE rtc_calls
      SET answer_sdp = ?,
          status = 'CONNECTED',
          connected_at = COALESCE(connected_at, datetime('now')),
          updated_at = datetime('now')
      WHERE id = ?
    `).run(JSON.stringify(body.answerSdp), call.id);
    return NextResponse.json({ ok: true, status: 'CONNECTED' });
  }

  if (action === 'ICE') {
    if (!body.candidate) return NextResponse.json({ ok: true });
    db.prepare(
      'INSERT INTO rtc_ice_candidates (call_id, sender_side, candidate_json) VALUES (?, ?, ?)'
    ).run(call.id, participant.side, JSON.stringify(body.candidate));
    return NextResponse.json({ ok: true });
  }

  if (action === 'END' || action === 'DECLINE') {
    const newStatus = action === 'DECLINE' ? 'DECLINED' : 'ENDED';
    db.prepare(`
      UPDATE rtc_calls
      SET status = ?,
          ended_at = COALESCE(ended_at, datetime('now')),
          updated_at = datetime('now')
      WHERE id = ?
    `).run(newStatus, call.id);
    return NextResponse.json({ ok: true, status: newStatus });
  }

  return NextResponse.json({ error: 'Invalid RTC action.' }, { status: 400 });
}
