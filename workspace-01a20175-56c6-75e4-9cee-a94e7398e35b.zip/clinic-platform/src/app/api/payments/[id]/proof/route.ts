import fs from 'fs';
import path from 'path';
import { NextRequest, NextResponse } from 'next/server';
import { getDb, logAudit } from '@/lib/db';
import { decryptBuffer, getClientIp, getRequestUser } from '@/lib/auth';

export const dynamic = 'force-dynamic';

const PROOF_DIR = path.join(process.cwd(), 'private_storage', 'payment_proofs');

export async function GET(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  const user = await getRequestUser(req);
  if (!user) return NextResponse.json({ error: 'Authentication required.' }, { status: 401 });

  const db = getDb();
  const row = db
    .prepare(
      'SELECT id, patient_id, receipt_no, proof_storage_key, proof_filename, proof_mime FROM payments WHERE id = ?'
    )
    .get(params.id) as
    | {
        id: string;
        patient_id: string;
        receipt_no: string;
        proof_storage_key: string | null;
        proof_filename: string | null;
        proof_mime: string | null;
      }
    | undefined;

  if (!row || !row.proof_storage_key) {
    return NextResponse.json({ error: 'No payment screenshot attached.' }, { status: 404 });
  }

  const isClinic = ['DOCTOR', 'ADMIN', 'STAFF'].includes(user.role);
  if (!isClinic && row.patient_id !== user.id) {
    return NextResponse.json({ error: 'Forbidden.' }, { status: 403 });
  }

  const safeKey = path.basename(row.proof_storage_key);
  const fullPath = path.join(PROOF_DIR, safeKey);
  if (!fs.existsSync(fullPath)) {
    return NextResponse.json({ error: 'Payment proof file not found.' }, { status: 404 });
  }

  const encrypted = fs.readFileSync(fullPath);
  const plain = decryptBuffer(encrypted);

  logAudit({
    actorId: user.id,
    actorRole: user.role,
    actorName: user.fullName,
    action: 'PAYMENT_PROOF_VIEWED',
    entityType: 'PAYMENT',
    entityId: row.id,
    ipAddress: getClientIp(req),
  });

  const safeName = (row.proof_filename || `proof-${row.receipt_no}.png`).replace(/[^a-zA-Z0-9._-]/g, '_');

  return new NextResponse(new Uint8Array(plain), {
    headers: {
      'Content-Type': row.proof_mime || 'image/png',
      'Content-Disposition': `inline; filename="${safeName}"`,
      'Cache-Control': 'private, no-store',
    },
  });
}
