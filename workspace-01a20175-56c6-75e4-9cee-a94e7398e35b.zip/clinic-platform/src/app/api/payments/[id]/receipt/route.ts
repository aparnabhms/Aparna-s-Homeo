import { NextRequest, NextResponse } from 'next/server';
import { formatTime12h, getDb, getDoctorPublicProfile, logAudit } from '@/lib/db';
import { getClientIp, getRequestUser } from '@/lib/auth';
import { generateReceiptPdf } from '@/lib/pdf';

export async function GET(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  const user = await getRequestUser(req);
  if (!user) return NextResponse.json({ error: 'Authentication required.' }, { status: 401 });

  const db = getDb();
  const row = db
    .prepare(
      `SELECT p.*, u.full_name as patient_name, u.email as patient_email,
              a.reference_no as appointment_ref, a.appointment_date, a.start_time,
              ct.name as consultation_type_name
       FROM payments p
       JOIN users u ON u.id = p.patient_id
       JOIN appointments a ON a.id = p.appointment_id
       JOIN consultation_types ct ON ct.id = a.consultation_type_id
       WHERE p.id = ?`
    )
    .get(params.id) as
    | {
        id: string;
        receipt_no: string;
        patient_id: string;
        amount_inr: number;
        gateway: string;
        payment_method: string;
        gateway_payment_id: string | null;
        upi_utr: string | null;
        payer_detail: string | null;
        status: string;
        verified_at: string | null;
        created_at: string;
        patient_name: string;
        patient_email: string;
        appointment_ref: string;
        appointment_date: string;
        start_time: string;
        consultation_type_name: string;
      }
    | undefined;

  if (!row) return NextResponse.json({ error: 'Receipt not found.' }, { status: 404 });

  const isClinic = ['DOCTOR', 'ADMIN', 'STAFF'].includes(user.role);
  if (!isClinic && row.patient_id !== user.id) {
    return NextResponse.json({ error: 'Forbidden — you can only access your own receipts.' }, { status: 403 });
  }

  if (row.status !== 'PAID' && row.status !== 'REFUNDED') {
    return NextResponse.json(
      {
        error:
          'Official receipt is only generated after your payment is verified and received in Dr. Aparna Mishra’s clinic bank account.',
      },
      { status: 403 }
    );
  }

  const doc = getDoctorPublicProfile();
  const pdf = await generateReceiptPdf({
    receiptNo: row.receipt_no,
    paidAt: (row.verified_at || row.created_at).slice(0, 16),
    clinicName: doc.clinic_name,
    doctorName: doc.display_name,
    qualification: doc.qualification,
    phone: doc.phone,
    email: doc.email,
    patientName: row.patient_name,
    patientEmail: row.patient_email,
    appointmentRef: row.appointment_ref,
    consultationType: row.consultation_type_name,
    appointmentSlot: `${row.appointment_date} at ${formatTime12h(row.start_time)} IST`,
    amountInr: row.amount_inr,
    paymentMethod: row.payment_method,
    gateway: row.gateway,
    transactionRef: row.upi_utr || row.gateway_payment_id || row.payer_detail || 'Verified',
    status: row.status,
  });

  logAudit({
    actorId: user.id,
    actorRole: user.role,
    actorName: user.fullName,
    action: 'RECEIPT_DOWNLOADED',
    entityType: 'PAYMENT',
    entityId: row.id,
    ipAddress: getClientIp(req),
  });

  return new NextResponse(new Uint8Array(pdf), {
    headers: {
      'Content-Type': 'application/pdf',
      'Content-Disposition': `attachment; filename="${row.receipt_no}.pdf"`,
      'Cache-Control': 'private, no-store',
    },
  });
}
