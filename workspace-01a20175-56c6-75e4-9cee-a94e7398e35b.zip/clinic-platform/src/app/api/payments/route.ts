import fs from 'fs';
import path from 'path';
import { NextRequest, NextResponse } from 'next/server';
import { formatTime12h, getDb, getDoctorPublicProfile, logAudit } from '@/lib/db';
import {
  checkRateLimit,
  encryptBuffer,
  generateId,
  getClientIp,
  getRequestUser,
} from '@/lib/auth';
import {
  dispatchClinicNotification,
  isRazorpayLiveConfigured,
  provisionVideoConsultation,
  validateIndianUpiUtr,
  validatePaymentProofBuffer,
  verifyRazorpaySignature,
} from '@/lib/services';

export const dynamic = 'force-dynamic';

const PROOF_DIR = path.join(process.cwd(), 'private_storage', 'payment_proofs');

export async function GET(req: NextRequest) {
  const user = await getRequestUser(req);
  if (!user) return NextResponse.json({ error: 'Authentication required.' }, { status: 401 });

  const db = getDb();
  const doc = getDoctorPublicProfile();

  // Auto-release abandoned UNPAID drafts older than 15 minutes
  db.prepare(`
    UPDATE appointments
    SET status = 'CANCELLED',
        rejection_or_cancel_reason = 'Checkout expired — payment was not completed within 15 minutes',
        updated_at = datetime('now')
    WHERE status = 'PENDING'
      AND payment_status = 'UNPAID'
      AND created_at < datetime('now', '-15 minutes')
  `).run();

  if (user.role === 'PATIENT') {
    const payments = db
      .prepare(
        `SELECT p.id, p.receipt_no, p.appointment_id, p.amount_inr, p.currency, p.gateway,
                p.payment_method, p.upi_utr, p.payer_upi_id, p.payer_detail,
                p.proof_filename, (p.proof_storage_key IS NOT NULL) as has_proof,
                p.rejection_reason, p.status, p.server_verified, p.verified_at,
                p.refund_amount_inr, p.refund_reason, p.created_at,
                a.reference_no as appointment_ref, a.appointment_date, a.start_time, a.status as appointment_status,
                ct.name as consultation_type_name
         FROM payments p
         JOIN appointments a ON a.id = p.appointment_id
         JOIN consultation_types ct ON ct.id = a.consultation_type_id
         WHERE p.patient_id = ?
           AND NOT (p.status = 'INITIATED' AND a.status = 'CANCELLED')
         ORDER BY p.created_at DESC`
      )
      .all(user.id);

    return NextResponse.json({
      payments,
      clinicUpi: {
        upiId: doc.upi_id,
        payeeName: doc.upi_payee_name,
        qrUrl: doc.upi_qr_url,
      },
      razorpayLive: isRazorpayLiveConfigured(),
    });
  }

  const payments = db
    .prepare(
      `SELECT p.*, (p.proof_storage_key IS NOT NULL) as has_proof,
              u.full_name as patient_name, u.email as patient_email, u.phone as patient_phone,
              a.reference_no as appointment_ref, a.appointment_date, a.start_time, a.status as appointment_status,
              ct.name as consultation_type_name
       FROM payments p
       JOIN users u ON u.id = p.patient_id
       JOIN appointments a ON a.id = p.appointment_id
       JOIN consultation_types ct ON ct.id = a.consultation_type_id
       WHERE NOT (p.status = 'INITIATED' AND a.status = 'CANCELLED')
       ORDER BY
         CASE WHEN p.status = 'PENDING_VERIFICATION' THEN 0 ELSE 1 END ASC,
         p.created_at DESC`
    )
    .all();

  return NextResponse.json({
    payments,
    clinicUpi: {
      upiId: doc.upi_id,
      payeeName: doc.upi_payee_name,
      qrUrl: doc.upi_qr_url,
    },
    razorpayMode: isRazorpayLiveConfigured() ? 'LIVE_CONFIGURED' : 'QR_VERIFIED_ONLY',
  });
}

export async function POST(req: NextRequest) {
  const user = await getRequestUser(req);
  if (!user) return NextResponse.json({ error: 'Authentication required.' }, { status: 401 });

  const db = getDb();
  const ip = getClientIp(req);

  const contentType = (req.headers.get('content-type') || '').toLowerCase();
  let action = '';
  let paymentId = '';
  let rawUtr = '';
  let upiApp = 'PhonePe';
  let payerUpiId = '';
  let proofFile: File | null = null;
  let jsonBody: Record<string, unknown> = {};

  if (contentType.includes('multipart/form-data')) {
    const form = await req.formData();
    action = String(form.get('action') || 'SUBMIT_UPI_UTR');
    paymentId = String(form.get('paymentId') || '');
    rawUtr = String(form.get('utr') || '');
    upiApp = String(form.get('upiApp') || 'PhonePe').trim().slice(0, 40);
    payerUpiId = String(form.get('payerUpiId') || '').trim().slice(0, 80);
    const f = form.get('screenshot');
    if (f && typeof f === 'object' && 'arrayBuffer' in f) {
      proofFile = f as File;
    }
  } else {
    jsonBody = (await req.json()) as Record<string, unknown>;
    action = String(jsonBody.action || '');
    paymentId = String(jsonBody.paymentId || '');
    rawUtr = String(jsonBody.utr || '');
    upiApp = String(jsonBody.upiApp || 'PhonePe').trim().slice(0, 40);
    payerUpiId = String(jsonBody.payerUpiId || '').trim().slice(0, 80);
  }

  const pay = db
    .prepare(
      `SELECT p.*, a.id as appt_id, a.reference_no, a.doctor_id, a.appointment_date, a.start_time, a.status as appt_status,
              u.full_name as patient_name, u.email as patient_email, u.phone as patient_phone
       FROM payments p
       JOIN appointments a ON a.id = p.appointment_id
       JOIN users u ON u.id = p.patient_id
       WHERE p.id = ?`
    )
    .get(paymentId) as
    | {
        id: string;
        receipt_no: string;
        appointment_id: string;
        patient_id: string;
        amount_inr: number;
        gateway: string;
        gateway_order_id: string | null;
        status: string;
        appt_id: string;
        appt_status: string;
        reference_no: string;
        doctor_id: string;
        appointment_date: string;
        start_time: string;
        patient_name: string;
        patient_email: string;
        patient_phone: string | null;
      }
    | undefined;

  if (!pay) return NextResponse.json({ error: 'Payment record not found.' }, { status: 404 });

  /* =========================================================================
     1. STRICT VERIFIED UPI QR PAYMENT SUBMISSION
        - Validates genuine 12-digit NPCI RRN/UTR (rejects random/fake/old/letter strings)
        - Blocks duplicate/reused UTR across all bookings
        - Requires real payment screenshot proof (verified image/PDF magic bytes, AES-256 encrypted)
        - Requires sender name / UPI ID for bank statement matching
        - NEVER auto-confirms: holds in PENDING_VERIFICATION until Doctor confirms ₹ in bank
     ========================================================================= */
  if (action === 'SUBMIT_UPI_UTR') {
    if (pay.patient_id !== user.id) {
      return NextResponse.json({ error: 'Forbidden.' }, { status: 403 });
    }
    if (pay.status === 'PAID') {
      return NextResponse.json({ error: 'This payment is already verified and paid.' }, { status: 400 });
    }

    const rl = checkRateLimit(`utr-submit:${user.id}:${ip}`, 15, 10 * 60 * 1000);
    if (!rl.allowed) {
      return NextResponse.json(
        { error: `Too many invalid UTR attempts. Please retry after ${rl.retryAfterSec}s.` },
        { status: 429 }
      );
    }

    // Step A: Strict NPCI 12-digit UTR format, anti-dummy & Julian date validation
    const utrCheck = validateIndianUpiUtr(rawUtr, pay.patient_phone);
    if (!utrCheck.valid) {
      logAudit({
        actorId: user.id,
        actorRole: user.role,
        actorName: user.fullName,
        action: 'PAYMENT_INVALID_UTR_BLOCKED',
        entityType: 'PAYMENT',
        entityId: pay.id,
        details: `Rejected invalid UTR input "${rawUtr.slice(0, 24)}" for ${pay.reference_no}`,
        ipAddress: ip,
      });
      return NextResponse.json({ error: utrCheck.error }, { status: 400 });
    }
    const cleanUtr = utrCheck.cleanUtr;

    // Step B: Block reused/duplicate UTR across the entire clinic database
    const duplicate = db
      .prepare(
        "SELECT id FROM payments WHERE upi_utr = ? AND id != ? AND status != 'FAILED' LIMIT 1"
      )
      .get(cleanUtr, pay.id) as { id: string } | undefined;
    if (duplicate) {
      logAudit({
        actorId: user.id,
        actorRole: user.role,
        actorName: user.fullName,
        action: 'PAYMENT_DUPLICATE_UTR_BLOCKED',
        entityType: 'PAYMENT',
        entityId: pay.id,
        details: `Blocked duplicate UTR ${cleanUtr} on ${pay.reference_no}`,
        ipAddress: ip,
      });
      return NextResponse.json(
        {
          error:
            'This 12-digit UTR has already been submitted for another transaction. Each consultation requires its own fresh UPI payment.',
        },
        { status: 409 }
      );
    }

    // Step C: Require sender UPI ID or bank account holder name
    if (!payerUpiId || payerUpiId.length < 3) {
      return NextResponse.json(
        {
          error:
            'Please enter the Sender Name or UPI ID you paid from (e.g. yourname@ybl) so Dr. Aparna can match your payment in her bank statement.',
        },
        { status: 400 }
      );
    }

    // Step D: Require real UPI payment screenshot image/PDF & encrypt at rest
    if (!proofFile || proofFile.size === 0) {
      return NextResponse.json(
        {
          error:
            'Payment screenshot is required. Please upload the screenshot of your completed ₹' +
            pay.amount_inr +
            ' payment from PhonePe, Google Pay, Paytm, or BHIM.',
        },
        { status: 400 }
      );
    }

    const rawBytes = Buffer.from(await proofFile.arrayBuffer());
    const fileCheck = validatePaymentProofBuffer(rawBytes);
    if (!fileCheck.valid || !fileCheck.detectedMime) {
      return NextResponse.json({ error: fileCheck.error }, { status: 400 });
    }

    fs.mkdirSync(PROOF_DIR, { recursive: true });
    const storageKey = `${generateId('proof')}.enc`;
    const encrypted = encryptBuffer(rawBytes);
    fs.writeFileSync(path.join(PROOF_DIR, storageKey), encrypted, { mode: 0o600 });

    const origName = (proofFile.name || 'upi-payment-proof.png').slice(0, 120);
    const detailSummary = `${upiApp} · UTR ${cleanUtr} · From: ${payerUpiId}`;

    db.prepare(`
      UPDATE payments SET
        gateway = 'PHONEPE_UPI_QR',
        payment_method = 'PHONEPE_QR',
        upi_utr = ?,
        payer_upi_id = ?,
        payer_detail = ?,
        proof_storage_key = ?,
        proof_filename = ?,
        proof_mime = ?,
        rejection_reason = NULL,
        status = 'PENDING_VERIFICATION',
        server_verified = 0
      WHERE id = ?
    `).run(
      cleanUtr,
      payerUpiId,
      detailSummary,
      storageKey,
      origName,
      fileCheck.detectedMime,
      pay.id
    );

    db.prepare(
      "UPDATE appointments SET payment_status = 'PENDING_VERIFICATION', status = 'PENDING', rejection_or_cancel_reason = NULL, updated_at = datetime('now') WHERE id = ?"
    ).run(pay.appt_id);

    // Alert Doctor immediately via both Notification Center AND Live Chat thread
    const docNotice = `${pay.patient_name} requested appointment ${pay.reference_no} (${pay.appointment_date}, ${formatTime12h(
      pay.start_time
    )} IST) — Verify ₹${pay.amount_inr} in PhonePe/Bank: ${upiApp}, UTR ${cleanUtr}, Sender: ${payerUpiId} (Screenshot uploaded).`;

    db.prepare(`
      INSERT INTO notifications (id, user_id, appointment_id, channel, title, message, delivery_status)
      VALUES (?, ?, ?, 'IN_APP', ?, ?, 'DELIVERED')
    `).run(
      generateId('ntf'),
      pay.doctor_id,
      pay.appt_id,
      `Verify ₹${pay.amount_inr} UPI Payment (${pay.reference_no})`,
      docNotice
    );

    db.prepare(`
      INSERT INTO clinic_messages (
        id, patient_id, sender_id, sender_role, sender_name,
        message_type, content, call_phone, is_read
      ) VALUES (?, ?, ?, 'PATIENT', ?, 'TEXT', ?, '+918123108149', 0)
    `).run(
      generateId('msg'),
      pay.patient_id,
      pay.patient_id,
      pay.patient_name,
      `[Payment Verification Request · ${pay.reference_no}] Slot: ${pay.appointment_date} at ${formatTime12h(
        pay.start_time
      )} IST · Amount: ₹${pay.amount_inr} · App: ${upiApp} · UTR: ${cleanUtr} · Paid from: ${payerUpiId} · Payment screenshot uploaded for clinic verification.`
    );

    await dispatchClinicNotification({
      userId: pay.patient_id,
      appointmentId: pay.appt_id,
      inAppTitle: 'Awaiting Clinic Bank Verification (Not Confirmed Yet)',
      inAppMessage: `Your UTR (${cleanUtr}) and payment screenshot for Ref ${pay.reference_no} (${pay.appointment_date}, ${formatTime12h(
        pay.start_time
      )} IST) were submitted. Your appointment will be CONFIRMED only after Dr. Aparna Mishra verifies that ₹${
        pay.amount_inr
      } was received in a72549567212@axl. Unmatched or invalid claims are automatically cancelled.`,
      recipientEmail: pay.patient_email,
    });

    logAudit({
      actorId: user.id,
      actorRole: user.role,
      actorName: user.fullName,
      action: 'PAYMENT_PROOF_AND_UTR_SUBMITTED',
      entityType: 'PAYMENT',
      entityId: pay.id,
      details: `Submitted validated UTR ${cleanUtr} + encrypted screenshot (${upiApp}, Sender: ${payerUpiId}, INR ${pay.amount_inr})`,
      ipAddress: ip,
    });

    return NextResponse.json({
      ok: true,
      paymentStatus: 'PENDING_VERIFICATION',
      appointmentStatus: 'PENDING',
      receiptNo: pay.receipt_no,
      message: `Your UTR (${cleanUtr}) and payment screenshot have been sent to Dr. Aparna Mishra for bank verification. Your appointment is NOT confirmed yet — it becomes CONFIRMED (with PDF receipt & consultation link) only once ₹${pay.amount_inr} is verified in clinic account a72549567212@axl.`,
    });
  }

  /* =========================================================================
     2. LIVE RAZORPAY CRYPTOGRAPHIC HMAC-SHA256 VERIFICATION
        - Strictly requires live RAZORPAY_KEY_ID & RAZORPAY_KEY_SECRET + real bank callback
        - Fake/unverified auto-approvals are completely disabled so random numbers never book
     ========================================================================= */
  if (action === 'VERIFY_RAZORPAY') {
    if (!isRazorpayLiveConfigured()) {
      return NextResponse.json(
        {
          error:
            'Automatic live gateway checkout requires RAZORPAY_KEY_ID and RAZORPAY_KEY_SECRET. Please pay via Dr. Aparna Mishra’s official PhonePe/UPI QR code (a72549567212@axl) and upload your payment screenshot + 12-digit UTR.',
        },
        { status: 403 }
      );
    }
    if (pay.patient_id !== user.id) {
      return NextResponse.json({ error: 'Forbidden.' }, { status: 403 });
    }

    const orderId = String(jsonBody.razorpayOrderId || '');
    const rzpPaymentId = String(jsonBody.razorpayPaymentId || '');
    const signature = String(jsonBody.razorpaySignature || '');
    const method = ['UPI', 'CARD', 'NETBANKING', 'WALLET', 'PAY_LATER'].includes(
      String(jsonBody.paymentMethod || '')
    )
      ? String(jsonBody.paymentMethod)
      : 'UPI';
    const payerDetail = String(jsonBody.payerDetail || `Razorpay Verified ${method}`).slice(0, 100);

    if (!orderId || !rzpPaymentId || !signature || orderId !== pay.gateway_order_id) {
      return NextResponse.json(
        { error: 'Payment order mismatch — bank verification rejected.' },
        { status: 400 }
      );
    }

    if (!verifyRazorpaySignature(orderId, rzpPaymentId, signature)) {
      db.prepare("UPDATE payments SET status = 'FAILED', server_verified = 0 WHERE id = ?").run(
        pay.id
      );
      logAudit({
        actorId: user.id,
        actorRole: user.role,
        actorName: user.fullName,
        action: 'PAYMENT_SIGNATURE_INVALID',
        entityType: 'PAYMENT',
        entityId: pay.id,
        ipAddress: ip,
      });
      return NextResponse.json(
        { error: 'Cryptographic bank signature verification failed.' },
        { status: 400 }
      );
    }

    db.prepare(`
      UPDATE payments SET
        gateway = 'RAZORPAY',
        payment_method = ?,
        gateway_payment_id = ?,
        gateway_signature = ?,
        payer_detail = ?,
        status = 'PAID',
        server_verified = 1,
        verified_at = datetime('now')
      WHERE id = ?
    `).run(method, rzpPaymentId, signature, payerDetail, pay.id);

    db.prepare(
      "UPDATE appointments SET payment_status = 'PAID', status = 'CONFIRMED', updated_at = datetime('now') WHERE id = ?"
    ).run(pay.appt_id);

    const vc = await provisionVideoConsultation({
      appointmentId: pay.appt_id,
      patientId: pay.patient_id,
      doctorId: pay.doctor_id,
    });

    db.prepare(`
      INSERT INTO notifications (id, user_id, appointment_id, channel, title, message, delivery_status)
      VALUES (?, ?, ?, 'IN_APP', ?, ?, 'DELIVERED')
    `).run(
      generateId('ntf'),
      pay.doctor_id,
      pay.appt_id,
      `New Paid Booking Confirmed (₹${pay.amount_inr})`,
      `${pay.patient_name} paid ₹${pay.amount_inr} via Razorpay (${rzpPaymentId}) — Ref ${pay.reference_no} on ${pay.appointment_date} at ${formatTime12h(pay.start_time)} IST.`
    );

    await dispatchClinicNotification({
      userId: pay.patient_id,
      appointmentId: pay.appt_id,
      inAppTitle: `Appointment Confirmed & Receipt ${pay.receipt_no}`,
      inAppMessage: `Payment of ₹${pay.amount_inr} verified by Razorpay (${rzpPaymentId}). Your consultation (Ref: ${pay.reference_no}) with Dr. Aparna Mishra is confirmed for ${pay.appointment_date} at ${formatTime12h(pay.start_time)} IST.`,
      whatsappTemplate: 'appointment_confirmed_v1',
      whatsappParams: [
        pay.patient_name,
        pay.reference_no,
        pay.appointment_date,
        formatTime12h(pay.start_time),
      ],
      recipientPhone: pay.patient_phone,
      recipientEmail: pay.patient_email,
      emailSubject: `Confirmed: ${pay.reference_no} & Receipt ${pay.receipt_no}`,
    });

    logAudit({
      actorId: user.id,
      actorRole: user.role,
      actorName: user.fullName,
      action: 'PAYMENT_VERIFIED_RAZORPAY',
      entityType: 'PAYMENT',
      entityId: pay.id,
      details: `Razorpay HMAC verified ${rzpPaymentId} (INR ${pay.amount_inr}); room ${vc.roomCode} created.`,
      ipAddress: ip,
    });

    return NextResponse.json({
      ok: true,
      paymentStatus: 'PAID',
      appointmentStatus: 'CONFIRMED',
      receiptNo: pay.receipt_no,
      paymentId: pay.id,
      consultation: vc,
      message: `₹${pay.amount_inr} verified directly with your bank. Your appointment is confirmed!`,
    });
  }

  /* =========================================================================
     3. DOCTOR / STAFF APPROVE VERIFIED UPI PAYMENT -> CONFIRMS APPOINTMENT
     ========================================================================= */
  if (action === 'ADMIN_VERIFY') {
    if (!['DOCTOR', 'ADMIN', 'STAFF'].includes(user.role)) {
      return NextResponse.json({ error: 'Clinic authorisation required.' }, { status: 403 });
    }

    db.prepare(`
      UPDATE payments
      SET status = 'PAID',
          server_verified = 1,
          rejection_reason = NULL,
          verified_by = ?,
          verified_at = datetime('now')
      WHERE id = ?
    `).run(user.id, pay.id);

    db.prepare(
      "UPDATE appointments SET payment_status = 'PAID', status = 'CONFIRMED', updated_at = datetime('now') WHERE id = ?"
    ).run(pay.appt_id);

    await provisionVideoConsultation({
      appointmentId: pay.appt_id,
      patientId: pay.patient_id,
      doctorId: pay.doctor_id,
    });

    db.prepare(`
      INSERT INTO clinic_messages (
        id, patient_id, sender_id, sender_role, sender_name,
        message_type, content, call_phone, is_read
      ) VALUES (?, ?, ?, ?, ?, 'TEXT', ?, '+918123108149', 0)
    `).run(
      generateId('msg'),
      pay.patient_id,
      user.id,
      user.role,
      user.fullName,
      `Payment Verified (₹${pay.amount_inr} · Receipt ${pay.receipt_no})! Your consultation ${pay.reference_no} is now CONFIRMED for ${pay.appointment_date} at ${formatTime12h(
        pay.start_time
      )} IST. You can download your PDF receipt and join your Audio/Video Call here at appointment time.`
    );

    await dispatchClinicNotification({
      userId: pay.patient_id,
      appointmentId: pay.appt_id,
      inAppTitle: 'Payment Verified & Appointment Confirmed',
      inAppMessage: `Your payment of ₹${pay.amount_inr} (Receipt: ${pay.receipt_no}) for booking ${pay.reference_no} has been verified in clinic records. Your consultation on ${pay.appointment_date} at ${formatTime12h(
        pay.start_time
      )} IST is now CONFIRMED.`,
      whatsappTemplate: 'payment_confirmation_v1',
      whatsappParams: [pay.patient_name, String(pay.amount_inr), pay.receipt_no, pay.reference_no],
      recipientPhone: pay.patient_phone,
      recipientEmail: pay.patient_email,
    });

    logAudit({
      actorId: user.id,
      actorRole: user.role,
      actorName: user.fullName,
      action: 'PAYMENT_VERIFIED_BY_CLINIC',
      entityType: 'PAYMENT',
      entityId: pay.id,
      details: `Verified ₹${pay.amount_inr} receipt ${pay.receipt_no} for ${pay.reference_no}`,
      ipAddress: ip,
    });

    return NextResponse.json({ ok: true, status: 'PAID' });
  }

  /* =========================================================================
     4. DOCTOR / STAFF REJECT UNMATCHED / FAKE UTR -> CANCELS BOOKING & FREES SLOT
     ========================================================================= */
  if (action === 'ADMIN_REJECT') {
    if (!['DOCTOR', 'ADMIN', 'STAFF'].includes(user.role)) {
      return NextResponse.json({ error: 'Clinic authorisation required.' }, { status: 403 });
    }
    const reason = String(
      jsonBody.reason ||
        'Payment UTR / screenshot could not be matched in clinic bank statement (a72549567212@axl).'
    ).slice(0, 300);

    db.prepare(`
      UPDATE payments
      SET status = 'FAILED',
          server_verified = 0,
          rejection_reason = ?,
          verified_by = ?,
          verified_at = datetime('now')
      WHERE id = ?
    `).run(reason, user.id, pay.id);

    db.prepare(`
      UPDATE appointments
      SET payment_status = 'FAILED',
          status = 'CANCELLED',
          rejection_or_cancel_reason = ?,
          updated_at = datetime('now')
      WHERE id = ?
    `).run(`Payment rejected: ${reason}`, pay.appt_id);

    db.prepare(`
      INSERT INTO clinic_messages (
        id, patient_id, sender_id, sender_role, sender_name,
        message_type, content, call_phone, is_read
      ) VALUES (?, ?, ?, ?, ?, 'TEXT', ?, '+918123108149', 0)
    `).run(
      generateId('msg'),
      pay.patient_id,
      user.id,
      user.role,
      user.fullName,
      `Payment Not Verified (${pay.reference_no}): ${reason} The slot (${pay.appointment_date}, ${formatTime12h(
        pay.start_time
      )}) has been released. If you did transfer ₹${pay.amount_inr}, please re-upload the exact UPI screenshot & 12-digit UTR or message us on +91 8123108149.`
    );

    await dispatchClinicNotification({
      userId: pay.patient_id,
      appointmentId: pay.appt_id,
      inAppTitle: `Payment Not Received — Booking ${pay.reference_no} Cancelled`,
      inAppMessage: `${reason} Your slot on ${pay.appointment_date} at ${formatTime12h(
        pay.start_time
      )} IST has been cancelled.`,
      recipientEmail: pay.patient_email,
    });

    logAudit({
      actorId: user.id,
      actorRole: user.role,
      actorName: user.fullName,
      action: 'PAYMENT_REJECTED_UNVERIFIED_UTR',
      entityType: 'PAYMENT',
      entityId: pay.id,
      details: `Rejected payment ${pay.receipt_no} & cancelled ${pay.reference_no}: ${reason}`,
      ipAddress: ip,
    });

    return NextResponse.json({ ok: true, status: 'FAILED', appointmentStatus: 'CANCELLED' });
  }

  /* =========================================================================
     5. SECURE REFUND (Strictly DOCTOR / ADMIN only)
     ========================================================================= */
  if (action === 'ADMIN_REFUND') {
    if (!['DOCTOR', 'ADMIN'].includes(user.role)) {
      return NextResponse.json(
        { error: 'Only the doctor or administrator can issue refunds.' },
        { status: 403 }
      );
    }
    const reason = String(
      jsonBody.reason || 'Consultation cancelled — full refund processed'
    ).slice(0, 300);

    db.prepare(`
      UPDATE payments SET
        status = 'REFUNDED',
        refund_amount_inr = amount_inr,
        refund_reason = ?,
        refunded_at = datetime('now')
      WHERE id = ?
    `).run(reason, pay.id);

    db.prepare(
      "UPDATE appointments SET payment_status = 'REFUNDED', updated_at = datetime('now') WHERE id = ?"
    ).run(pay.appt_id);

    await dispatchClinicNotification({
      userId: pay.patient_id,
      appointmentId: pay.appt_id,
      inAppTitle: `Refund Processed — ₹${pay.amount_inr}`,
      inAppMessage: `A refund of ₹${pay.amount_inr} for Receipt ${pay.receipt_no} (Ref: ${pay.reference_no}) has been initiated. Note: ${reason}`,
      recipientEmail: pay.patient_email,
    });

    logAudit({
      actorId: user.id,
      actorRole: user.role,
      actorName: user.fullName,
      action: 'PAYMENT_REFUNDED',
      entityType: 'PAYMENT',
      entityId: pay.id,
      details: `Refunded INR ${pay.amount_inr} on ${pay.receipt_no}: ${reason}`,
      ipAddress: ip,
    });

    return NextResponse.json({ ok: true, status: 'REFUNDED' });
  }

  return NextResponse.json(
    {
      error:
        'Unverified payment method blocked. Please pay via Dr. Aparna Mishra’s official UPI QR code (a72549567212@axl) and submit your genuine 12-digit UTR + payment screenshot.',
    },
    { status: 400 }
  );
}
