import crypto from 'crypto';
import { NextRequest, NextResponse } from 'next/server';
import { getDb, getDoctorPublicProfile, logAudit } from '@/lib/db';
import { checkRateLimit, generateId, getClientIp, getRequestUser } from '@/lib/auth';

export const dynamic = 'force-dynamic';

/**
 * Generates a deterministic, private, non-recorded WebRTC Audio/Video call room
 * linking a specific patient and Dr. Aparna Mishra (+91 8123108149).
 */
function buildDirectClinicCallUrl(patientId: string, mode: 'AUDIO_CALL' | 'VIDEO_CALL'): string {
  const secret = process.env.JWT_SECRET || 'aparna-clinic-room-salt-2026';
  const roomHash = crypto
    .createHmac('sha256', secret)
    .update(`aparna-8123108149:${patientId}`)
    .digest('hex')
    .slice(0, 14);
  const domain = process.env.JITSI_DOMAIN || 'meet.jit.si';
  const audioOnly = mode === 'AUDIO_CALL' ? 'true' : 'false';
  return `https://${domain}/DrAparnaMishra8123108149-${roomHash}#config.startWithVideoMuted=${audioOnly}&config.startAudioOnly=${audioOnly}&config.fileRecordingsEnabled=false&config.liveStreamingEnabled=false&config.prejoinPageEnabled=false`;
}

export async function GET(req: NextRequest) {
  const user = await getRequestUser(req);
  if (!user) return NextResponse.json({ error: 'Authentication required.' }, { status: 401 });

  const db = getDb();
  const doc = getDoctorPublicProfile();
  const clinicNumber = {
    display: doc.phone || '+91 8123108149',
    tel: '+918123108149',
    whatsapp: doc.whatsapp_number || '918123108149',
    doctorName: doc.display_name,
    doctorPhoto: doc.photo_url,
    timings: doc.timings_summary,
  };

  // PATIENT: Strictly returns only their own private thread with Dr. Aparna Mishra
  if (user.role === 'PATIENT') {
    const markRead = req.nextUrl.searchParams.get('markRead') === '1';
    if (markRead) {
      db.prepare(
        "UPDATE clinic_messages SET is_read = 1 WHERE patient_id = ? AND sender_role != 'PATIENT' AND is_read = 0"
      ).run(user.id);
    }

    const messages = db
      .prepare('SELECT * FROM clinic_messages WHERE patient_id = ? ORDER BY created_at ASC LIMIT 200')
      .all(user.id);

    const unreadCount = (
      db
        .prepare(
          "SELECT COUNT(*) as c FROM clinic_messages WHERE patient_id = ? AND sender_role != 'PATIENT' AND is_read = 0"
        )
        .get(user.id) as { c: number }
    ).c;

    return NextResponse.json({
      messages,
      unreadCount,
      clinicNumber,
      liveRooms: {
        videoUrl: buildDirectClinicCallUrl(user.id, 'VIDEO_CALL'),
        audioUrl: buildDirectClinicCallUrl(user.id, 'AUDIO_CALL'),
      },
    });
  }

  // DOCTOR / STAFF / ADMIN: Returns patient thread directory + active patient's messages
  if (!['DOCTOR', 'ADMIN', 'STAFF'].includes(user.role)) {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
  }

  const threads = db
    .prepare(
      `SELECT u.id as patient_id, u.full_name, u.email, u.phone, u.is_demo,
              pp.patient_code, pp.is_minor_account, pp.minor_patient_name,
              (SELECT content FROM clinic_messages m WHERE m.patient_id = u.id ORDER BY m.created_at DESC LIMIT 1) as last_message,
              (SELECT created_at FROM clinic_messages m WHERE m.patient_id = u.id ORDER BY m.created_at DESC LIMIT 1) as last_message_at,
              (SELECT COUNT(*) FROM clinic_messages m WHERE m.patient_id = u.id AND m.sender_role = 'PATIENT' AND m.is_read = 0) as unread_count
       FROM users u
       LEFT JOIN patient_profiles pp ON pp.user_id = u.id
       WHERE u.role = 'PATIENT'
       ORDER BY COALESCE(last_message_at, u.created_at) DESC`
    )
    .all() as Array<{ patient_id: string; unread_count: number }>;

  const totalUnread = threads.reduce((sum, t) => sum + (t.unread_count || 0), 0);
  const selectedPatientId =
    req.nextUrl.searchParams.get('patientId') || threads[0]?.patient_id || '';

  let messages: unknown[] = [];
  let liveRooms = { videoUrl: '', audioUrl: '' };

  if (selectedPatientId) {
    if (req.nextUrl.searchParams.get('markRead') === '1') {
      db.prepare(
        "UPDATE clinic_messages SET is_read = 1 WHERE patient_id = ? AND sender_role = 'PATIENT' AND is_read = 0"
      ).run(selectedPatientId);
    }
    messages = db
      .prepare('SELECT * FROM clinic_messages WHERE patient_id = ? ORDER BY created_at ASC LIMIT 200')
      .all(selectedPatientId);
    liveRooms = {
      videoUrl: buildDirectClinicCallUrl(selectedPatientId, 'VIDEO_CALL'),
      audioUrl: buildDirectClinicCallUrl(selectedPatientId, 'AUDIO_CALL'),
    };
  }

  return NextResponse.json({
    threads,
    totalUnread,
    selectedPatientId,
    messages,
    clinicNumber,
    liveRooms,
  });
}

export async function POST(req: NextRequest) {
  const user = await getRequestUser(req);
  if (!user) return NextResponse.json({ error: 'Authentication required.' }, { status: 401 });

  const rl = checkRateLimit(`msg:${user.id}`, 45, 5 * 60 * 1000);
  if (!rl.allowed) {
    return NextResponse.json({ error: 'Sending too fast. Please wait a moment.' }, { status: 429 });
  }

  try {
    const body = await req.json();
    const db = getDb();
    const ip = getClientIp(req);

    const isClinic = ['DOCTOR', 'ADMIN', 'STAFF'].includes(user.role);
    const patientId = isClinic ? String(body.patientId || '') : user.id;

    if (!patientId) {
      return NextResponse.json({ error: 'Select a patient conversation.' }, { status: 400 });
    }

    const msgType =
      body.messageType === 'AUDIO_CALL'
        ? 'AUDIO_CALL'
        : body.messageType === 'VIDEO_CALL'
        ? 'VIDEO_CALL'
        : 'TEXT';

    let content = String(body.content || '').trim().slice(0, 1500);
    let callUrl: string | null = null;
    const callPhone = '+918123108149';

    if (msgType === 'AUDIO_CALL' || msgType === 'VIDEO_CALL') {
      callUrl = buildDirectClinicCallUrl(patientId, msgType);
      const label = msgType === 'AUDIO_CALL' ? 'Audio Consultation Call' : 'Video Consultation Call';
      if (!content) {
        content = isClinic
          ? `${user.fullName} started a live ${label} (Clinic Line: +91 8123108149). Tap Join Call or connect on WhatsApp +91 8123108149.`
          : `${user.fullName} is ready for a ${label} (Clinic Line: +91 8123108149).`;
      }
      logAudit({
        actorId: user.id,
        actorRole: user.role,
        actorName: user.fullName,
        action: `${msgType}_INITIATED`,
        entityType: 'CLINIC_CHAT',
        entityId: patientId,
        details: `Initiated ${label} linked to +91 8123108149`,
        ipAddress: ip,
      });
    } else if (!content) {
      return NextResponse.json({ error: 'Message cannot be empty.' }, { status: 400 });
    }

    const id = generateId('msg');
    db.prepare(`
      INSERT INTO clinic_messages (
        id, patient_id, sender_id, sender_role, sender_name, appointment_id,
        message_type, content, call_url, call_phone, is_read
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0)
    `).run(
      id,
      patientId,
      user.id,
      user.role,
      user.fullName,
      body.appointmentId || null,
      msgType,
      content,
      callUrl,
      callPhone
    );

    // Also drop an in-app notification for call invites
    if (msgType !== 'TEXT') {
      const recipientId = isClinic
        ? patientId
        : (db.prepare("SELECT id FROM users WHERE role = 'DOCTOR' LIMIT 1").get() as { id: string } | undefined)?.id;
      if (recipientId) {
        db.prepare(`
          INSERT INTO notifications (id, user_id, channel, title, message, delivery_status)
          VALUES (?, ?, 'IN_APP', ?, ?, 'DELIVERED')
        `).run(
          generateId('ntf'),
          recipientId,
          msgType === 'AUDIO_CALL' ? 'Incoming Clinic Audio Call' : 'Incoming Clinic Video Call',
          content
        );
      }
    }

    const saved = db.prepare('SELECT * FROM clinic_messages WHERE id = ?').get(id);
    return NextResponse.json({ ok: true, message: saved, callUrl });
  } catch (err) {
    console.error('Message error:', err);
    return NextResponse.json({ error: 'Failed to send message.' }, { status: 500 });
  }
}
