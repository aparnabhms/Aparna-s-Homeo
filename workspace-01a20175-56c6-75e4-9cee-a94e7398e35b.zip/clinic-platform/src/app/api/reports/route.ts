import fs from 'fs';
import path from 'path';
import { NextRequest, NextResponse } from 'next/server';
import { getDb, logAudit, PRIVATE_REPORTS_DIR } from '@/lib/db';
import {
  checkRateLimit,
  encryptBuffer,
  generateId,
  getClientIp,
  getRequestUser,
} from '@/lib/auth';
import { dispatchClinicNotification } from '@/lib/services';

const ALLOWED_MIMES = new Set([
  'application/pdf',
  'image/jpeg',
  'image/png',
  'image/webp',
  'text/plain',
]);
const MAX_SIZE_BYTES = 5 * 1024 * 1024; // 5 MB

export async function GET(req: NextRequest) {
  const user = await getRequestUser(req);
  if (!user) return NextResponse.json({ error: 'Authentication required.' }, { status: 401 });

  const db = getDb();
  if (user.role === 'PATIENT') {
    const reports = db
      .prepare(
        `SELECT id, patient_id, appointment_id, title, category, report_date, original_filename,
                mime_type, file_size_bytes, is_encrypted, review_status, doctor_remarks, reviewed_at, created_at
         FROM medical_reports
         WHERE patient_id = ?
         ORDER BY created_at DESC`
      )
      .all(user.id);
    return NextResponse.json({ reports });
  }

  if (user.role !== 'DOCTOR' && user.role !== 'ADMIN') {
    return NextResponse.json(
      { error: 'Sensitive medical reports are restricted to the authorised physician.' },
      { status: 403 }
    );
  }

  const reports = db
    .prepare(
      `SELECT m.id, m.patient_id, m.appointment_id, m.title, m.category, m.report_date,
              m.original_filename, m.mime_type, m.file_size_bytes, m.is_encrypted,
              m.review_status, m.doctor_remarks, m.reviewed_at, m.created_at,
              u.full_name as patient_name, pp.patient_code
       FROM medical_reports m
       JOIN users u ON u.id = m.patient_id
       LEFT JOIN patient_profiles pp ON pp.user_id = m.patient_id
       ORDER BY m.created_at DESC`
    )
    .all();

  return NextResponse.json({ reports });
}

export async function POST(req: NextRequest) {
  const user = await getRequestUser(req);
  if (!user) return NextResponse.json({ error: 'Authentication required.' }, { status: 401 });

  const rl = checkRateLimit(`upload:${user.id}`, 10, 15 * 60 * 1000);
  if (!rl.allowed) {
    return NextResponse.json({ error: 'Upload rate limit reached. Please try shortly.' }, { status: 429 });
  }

  try {
    const formData = await req.formData();
    const file = formData.get('file');
    if (!file || !(file instanceof File)) {
      return NextResponse.json({ error: 'Please select a PDF or image report file to upload.' }, { status: 400 });
    }

    if (file.size === 0 || file.size > MAX_SIZE_BYTES) {
      return NextResponse.json({ error: 'File must be between 1 byte and 5 MB.' }, { status: 400 });
    }

    const mime = file.type || 'application/octet-stream';
    if (!ALLOWED_MIMES.has(mime)) {
      return NextResponse.json(
        { error: 'Only PDF, JPG, PNG, WebP, or TXT medical reports are accepted.' },
        { status: 400 }
      );
    }

    const title = String(formData.get('title') || file.name).trim().slice(0, 180);
    const category = String(formData.get('category') || 'Lab Investigation').trim().slice(0, 80);
    const reportDate = String(formData.get('reportDate') || '').slice(0, 10) || null;
    const appointmentId = String(formData.get('appointmentId') || '').trim() || null;

    // Patient uploads for self; Doctor may upload an authorised summary for a selected patient
    const targetPatientId =
      user.role === 'DOCTOR' && formData.get('patientId')
        ? String(formData.get('patientId'))
        : user.id;

    const rawBuffer = Buffer.from(await file.arrayBuffer());
    const encrypted = encryptBuffer(rawBuffer);

    fs.mkdirSync(PRIVATE_REPORTS_DIR, { recursive: true });
    const id = generateId('rep');
    const storageKey = `${id}.enc`;
    const fullPath = path.join(PRIVATE_REPORTS_DIR, storageKey);
    fs.writeFileSync(fullPath, encrypted, { mode: 0o600 });

    const safeOriginalName = file.name.replace(/[^a-zA-Z0-9._-]/g, '_').slice(0, 120);
    const db = getDb();

    db.prepare(`
      INSERT INTO medical_reports (
        id, patient_id, appointment_id, uploaded_by, title, category, report_date,
        original_filename, storage_key, mime_type, file_size_bytes, is_encrypted, review_status
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?)
    `).run(
      id,
      targetPatientId,
      appointmentId,
      user.id,
      title,
      category,
      reportDate,
      safeOriginalName,
      storageKey,
      mime,
      file.size,
      user.role === 'DOCTOR' ? 'REVIEWED' : 'PENDING_REVIEW'
    );

    if (user.role === 'PATIENT') {
      const doc = db.prepare("SELECT id FROM users WHERE role = 'DOCTOR' LIMIT 1").get() as { id: string } | undefined;
      if (doc) {
        db.prepare(`
          INSERT INTO notifications (id, user_id, channel, title, message, delivery_status)
          VALUES (?, ?, 'IN_APP', ?, ?, 'DELIVERED')
        `).run(
          generateId('ntf'),
          doc.id,
          'New Patient Medical Report Uploaded',
          `${user.fullName} securely uploaded "${title}" (${category}) for clinical review.`
        );
      }
    }

    logAudit({
      actorId: user.id,
      actorRole: user.role,
      actorName: user.fullName,
      action: 'MEDICAL_REPORT_UPLOADED',
      entityType: 'MEDICAL_REPORT',
      entityId: id,
      details: `Encrypted & stored "${title}" (${file.size} bytes, AES-256-GCM)`,
      ipAddress: getClientIp(req),
    });

    return NextResponse.json({
      ok: true,
      id,
      message: 'Medical report encrypted (AES-256-GCM) and uploaded securely for doctor review.',
    });
  } catch (err) {
    console.error('Report upload error:', err);
    return NextResponse.json({ error: 'Unable to upload report.' }, { status: 500 });
  }
}

export async function PATCH(req: NextRequest) {
  const user = await getRequestUser(req);
  if (!user || user.role !== 'DOCTOR') {
    return NextResponse.json({ error: 'Only the authorised physician can review medical reports.' }, { status: 403 });
  }

  const db = getDb();
  const body = await req.json();
  const reportId = String(body.reportId || '');
  const remarks = String(body.doctorRemarks || '').trim().slice(0, 1000);

  const report = db
    .prepare(
      `SELECT m.id, m.patient_id, m.title, u.email as patient_email
       FROM medical_reports m JOIN users u ON u.id = m.patient_id WHERE m.id = ?`
    )
    .get(reportId) as { id: string; patient_id: string; title: string; patient_email: string } | undefined;

  if (!report) return NextResponse.json({ error: 'Report not found.' }, { status: 404 });

  db.prepare(`
    UPDATE medical_reports SET
      review_status = 'REVIEWED',
      doctor_remarks = ?,
      reviewed_by = ?,
      reviewed_at = datetime('now')
    WHERE id = ?
  `).run(remarks || 'Reviewed by Dr. Aparna Mishra.', user.id, report.id);

  await dispatchClinicNotification({
    userId: report.patient_id,
    inAppTitle: 'Medical Report Reviewed by Doctor',
    inAppMessage: `Dr. Aparna Mishra has reviewed your uploaded document "${report.title}". Sign in to Medical Reports to view clinical notes.`,
    recipientEmail: report.patient_email,
  });

  logAudit({
    actorId: user.id,
    actorRole: user.role,
    actorName: user.fullName,
    action: 'MEDICAL_REPORT_REVIEWED',
    entityType: 'MEDICAL_REPORT',
    entityId: report.id,
    ipAddress: getClientIp(req),
  });

  return NextResponse.json({ ok: true });
}
