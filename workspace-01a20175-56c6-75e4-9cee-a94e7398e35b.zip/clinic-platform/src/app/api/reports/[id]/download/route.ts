import fs from 'fs';
import path from 'path';
import { NextRequest, NextResponse } from 'next/server';
import { getDb, logAudit, PRIVATE_REPORTS_DIR } from '@/lib/db';
import { decryptBuffer, getClientIp, getRequestUser } from '@/lib/auth';

export async function GET(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  const user = await getRequestUser(req);
  if (!user) return NextResponse.json({ error: 'Authentication required.' }, { status: 401 });

  const db = getDb();
  const report = db
    .prepare('SELECT * FROM medical_reports WHERE id = ?')
    .get(params.id) as
    | {
        id: string;
        patient_id: string;
        original_filename: string;
        storage_key: string;
        mime_type: string;
        is_encrypted: number;
      }
    | undefined;

  if (!report) return NextResponse.json({ error: 'Report not found.' }, { status: 404 });

  // Strict patient isolation + Doctor-only clinical access
  if (user.role === 'PATIENT' && report.patient_id !== user.id) {
    return NextResponse.json({ error: 'Forbidden — private document access denied.' }, { status: 403 });
  }
  if (user.role === 'STAFF') {
    return NextResponse.json(
      { error: 'Forbidden — private clinical reports are restricted to the doctor and patient.' },
      { status: 403 }
    );
  }

  // Prevent path traversal
  const safeKey = path.basename(report.storage_key);
  const fullPath = path.join(PRIVATE_REPORTS_DIR, safeKey);
  if (!fs.existsSync(fullPath)) {
    return NextResponse.json({ error: 'Stored file missing on server.' }, { status: 404 });
  }

  const stored = fs.readFileSync(fullPath);
  const plain = report.is_encrypted ? decryptBuffer(stored) : stored;

  logAudit({
    actorId: user.id,
    actorRole: user.role,
    actorName: user.fullName,
    action: 'MEDICAL_REPORT_DOWNLOADED',
    entityType: 'MEDICAL_REPORT',
    entityId: report.id,
    ipAddress: getClientIp(req),
  });

  return new NextResponse(new Uint8Array(plain), {
    headers: {
      'Content-Type': report.mime_type,
      'Content-Disposition': `attachment; filename="${report.original_filename}"`,
      'Cache-Control': 'private, no-store, max-age=0',
    },
  });
}
