import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import {
  computeAvailableSlots,
  formatTime12h,
  getDb,
  getDoctorPublicProfile,
  logAudit,
  minutesToTime,
  timeToMinutes,
} from '@/lib/db';
import {
  checkRateLimit,
  generateId,
  generateRefCode,
  getClientIp,
  getRequestUser,
} from '@/lib/auth';
import { buildClinicUpiIntent, createRazorpayOrder } from '@/lib/services';

const createBookingSchema = z.object({
  consultationTypeId: z.string().min(2),
  concernCategory: z.string().trim().min(2).max(80),
  appointmentDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  startTime: z.string().regex(/^\d{2}:\d{2}$/),
  chiefComplaint: z.string().trim().min(4, 'Please describe your primary health concern').max(1000),
  symptomDuration: z.string().trim().max(120).optional().default(''),
  notesForDoctor: z.string().trim().max(1000).optional().default(''),
  forMinor: z.boolean().optional().default(false),
  minorName: z.string().trim().max(120).optional().default(''),
  callChannel: z
    .enum(['WHATSAPP_VIDEO', 'WHATSAPP_AUDIO', 'PHONE_AUDIO', 'INAPP_VIDEO', 'INAPP_AUDIO'])
    .optional()
    .default('WHATSAPP_VIDEO'),
  telemedicineConsent: z.literal(true, {
    errorMap: () => ({ message: 'Please confirm telemedicine consultation consent.' }),
  }),
});

export async function GET(req: NextRequest) {
  const user = await getRequestUser(req);
  if (!user) return NextResponse.json({ error: 'Authentication required.' }, { status: 401 });

  const db = getDb();

  // Auto-release abandoned UNPAID checkout holds older than 15 minutes
  db.prepare(`
    UPDATE appointments
    SET status = 'CANCELLED',
        rejection_or_cancel_reason = 'Checkout expired — payment was not completed within 15 minutes',
        updated_at = datetime('now')
    WHERE status = 'PENDING'
      AND payment_status = 'UNPAID'
      AND created_at < datetime('now', '-15 minutes')
  `).run();

  if (user.role === 'PATIENT') {
    const appointments = db
      .prepare(
        `SELECT a.*, ct.name as consultation_type_name, ct.mode as consultation_mode,
                c.id as consultation_id, c.meeting_url, c.status as consultation_status, c.room_code,
                p.id as payment_id, p.receipt_no, p.payment_method, p.status as pay_record_status, p.upi_utr, p.rejection_reason
         FROM appointments a
         JOIN consultation_types ct ON ct.id = a.consultation_type_id
         LEFT JOIN consultations c ON c.appointment_id = a.id
         LEFT JOIN payments p ON p.appointment_id = a.id
         WHERE a.patient_id = ?
           AND NOT (a.payment_status = 'UNPAID')
         ORDER BY a.appointment_date DESC, a.start_time DESC`
      )
      .all(user.id);
    return NextResponse.json({ appointments });
  }

  // DOCTOR / STAFF / ADMIN (excludes incomplete UNPAID checkout drafts — only PAID or PENDING_VERIFICATION appear)
  const statusFilter = req.nextUrl.searchParams.get('status');
  const dateFilter = req.nextUrl.searchParams.get('date');

  let sql = `
    SELECT a.*, u.full_name as account_holder_name, u.email as patient_email, u.phone as patient_phone, u.is_demo as patient_is_demo,
           pp.patient_code, pp.gender, pp.date_of_birth, pp.allergies, pp.is_minor_account, pp.guardian_relation,
           ct.name as consultation_type_name, ct.mode as consultation_mode,
           c.id as consultation_id, c.meeting_url, c.status as consultation_status, c.room_code,
           p.id as payment_id, p.receipt_no, p.payment_method, p.gateway, p.status as pay_record_status,
           p.upi_utr, p.payer_upi_id, p.payer_detail, (p.proof_storage_key IS NOT NULL) as has_proof
    FROM appointments a
    JOIN users u ON u.id = a.patient_id
    LEFT JOIN patient_profiles pp ON pp.user_id = a.patient_id
    JOIN consultation_types ct ON ct.id = a.consultation_type_id
    LEFT JOIN consultations c ON c.appointment_id = a.id
    LEFT JOIN payments p ON p.appointment_id = a.id
    WHERE a.payment_status != 'UNPAID'
  `;
  const args: string[] = [];
  if (statusFilter && statusFilter !== 'ALL') {
    sql += ' AND a.status = ?';
    args.push(statusFilter);
  }
  if (dateFilter) {
    sql += ' AND a.appointment_date = ?';
    args.push(dateFilter);
  }
  sql += ' ORDER BY a.appointment_date DESC, a.start_time ASC';

  const appointments = db.prepare(sql).all(...args);
  return NextResponse.json({ appointments });
}

export async function POST(req: NextRequest) {
  const user = await getRequestUser(req);
  if (!user) {
    return NextResponse.json({ error: 'Please sign in or register to book an appointment.' }, { status: 401 });
  }

  const ip = getClientIp(req);
  const rl = checkRateLimit(`book:${user.id}`, 12, 15 * 60 * 1000);
  if (!rl.allowed) {
    return NextResponse.json({ error: 'Too many booking requests. Please wait a minute.' }, { status: 429 });
  }

  try {
    const body = await req.json();
    const parsed = createBookingSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json(
        { error: parsed.error.issues[0]?.message || 'Invalid booking details.' },
        { status: 400 }
      );
    }

    const d = parsed.data;
    const todayIso = new Date().toISOString().slice(0, 10);
    if (d.appointmentDate < todayIso) {
      return NextResponse.json({ error: 'Cannot book appointments on past dates.' }, { status: 400 });
    }

    const db = getDb();
    const ct = db
      .prepare('SELECT * FROM consultation_types WHERE id = ? AND is_active = 1')
      .get(d.consultationTypeId) as
      | { id: string; name: string; duration_minutes: number; fee_inr: number }
      | undefined;
    if (!ct) {
      return NextResponse.json({ error: 'Selected consultation type is not available.' }, { status: 400 });
    }

    const doctor = getDoctorPublicProfile();
    const apptId = generateId('appt');
    const refNo = generateRefCode('APM');
    const endTime = minutesToTime(timeToMinutes(d.startTime) + ct.duration_minutes);

    const displayName =
      d.forMinor && d.minorName
        ? `${d.minorName} (Minor · Guardian: ${user.fullName})`
        : user.fullName;

    // Atomic slot check & reservation to prevent double-booking or overlap
    const bookTx = db.transaction(() => {
      const slotCheck = computeAvailableSlots(d.appointmentDate, ct.duration_minutes);
      if (!slotCheck.available) {
        throw new Error(slotCheck.reason || 'Selected date is unavailable.');
      }
      const chosen = slotCheck.slots.find((s) => s.startTime === d.startTime);
      if (!chosen) {
        throw new Error('Selected time falls outside clinic hours (3:00 PM – 8:00 PM IST).');
      }
      if (chosen.isBooked) {
        throw new Error(
          'That slot was just booked or overlaps with another consultation. Please select another time slot.'
        );
      }

      db.prepare(`
        INSERT INTO appointments (
          id, reference_no, patient_id, doctor_id, consultation_type_id, concern_category,
          appointment_date, start_time, end_time, duration_minutes, status, for_minor,
          patient_display_name, chief_complaint, symptom_duration, notes_for_doctor,
          call_channel, fee_inr, payment_status
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'PENDING', ?, ?, ?, ?, ?, ?, ?, 'UNPAID')
      `).run(
        apptId,
        refNo,
        user.id,
        doctor.user_id,
        ct.id,
        d.concernCategory,
        d.appointmentDate,
        d.startTime,
        endTime,
        ct.duration_minutes,
        d.forMinor ? 1 : 0,
        displayName,
        d.chiefComplaint,
        d.symptomDuration || null,
        d.notesForDoctor || null,
        d.callChannel || 'WHATSAPP_VIDEO',
        ct.fee_inr
      );

      db.prepare(`
        INSERT INTO consent_records (id, user_id, consent_type, granted, guardian_declaration, ip_address)
        VALUES (?, ?, 'TELEMEDICINE_CONSULTATION', 1, ?, ?)
      `).run(
        generateId('cns'),
        user.id,
        d.forMinor ? `Guardian ${user.fullName} consented for minor appointment ${refNo}` : `Booking ${refNo}`,
        ip
      );
    });

    try {
      bookTx();
    } catch (slotErr) {
      return NextResponse.json(
        { error: slotErr instanceof Error ? slotErr.message : 'Slot conflict detected.' },
        { status: 409 }
      );
    }

    // Prepare both Razorpay server order & Clinic PhonePe UPI QR intent
    const receiptNo = generateRefCode('RCP');
    const rzpOrder = await createRazorpayOrder({
      amountInr: ct.fee_inr,
      receiptNo,
      appointmentRef: refNo,
    });
    const upiIntent = buildClinicUpiIntent({
      amountInr: ct.fee_inr,
      appointmentRef: refNo,
    });

    const paymentId = generateId('pay');
    db.prepare(`
      INSERT INTO payments (
        id, receipt_no, appointment_id, patient_id, amount_inr, currency, gateway,
        payment_method, gateway_order_id, status, server_verified
      ) VALUES (?, ?, ?, ?, ?, 'INR', ?, 'UPI', ?, 'INITIATED', 0)
    `).run(
      paymentId,
      receiptNo,
      apptId,
      user.id,
      ct.fee_inr,
      rzpOrder.mode === 'LIVE_OR_TEST_API' ? 'RAZORPAY' : 'RAZORPAY_TEST',
      rzpOrder.orderId
    );

    logAudit({
      actorId: user.id,
      actorRole: user.role,
      actorName: user.fullName,
      action: 'APPOINTMENT_CREATED',
      entityType: 'APPOINTMENT',
      entityId: apptId,
      details: `Created booking ${refNo} for ${d.appointmentDate} ${formatTime12h(d.startTime)} (INR ${ct.fee_inr})`,
      ipAddress: ip,
    });

    return NextResponse.json({
      appointment: {
        id: apptId,
        referenceNo: refNo,
        date: d.appointmentDate,
        startTime: d.startTime,
        endTime,
        timeLabel: `${formatTime12h(d.startTime)} – ${formatTime12h(endTime)} IST`,
        consultationType: ct.name,
        concernCategory: d.concernCategory,
        feeInr: ct.fee_inr,
        status: 'PENDING',
      },
      payment: {
        id: paymentId,
        receiptNo,
        amountInr: ct.fee_inr,
        razorpay: rzpOrder,
        upi: upiIntent,
      },
    });
  } catch (err) {
    console.error('Create appointment error:', err);
    return NextResponse.json({ error: 'Unable to create booking.' }, { status: 500 });
  }
}
