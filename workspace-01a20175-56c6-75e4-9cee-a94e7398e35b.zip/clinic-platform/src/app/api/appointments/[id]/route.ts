import { NextRequest, NextResponse } from 'next/server';
import {
  computeAvailableSlots,
  formatTime12h,
  getDb,
  logAudit,
  minutesToTime,
  timeToMinutes,
} from '@/lib/db';
import { getClientIp, getRequestUser } from '@/lib/auth';
import { dispatchClinicNotification, provisionVideoConsultation } from '@/lib/services';

export async function PATCH(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  const user = await getRequestUser(req);
  if (!user) return NextResponse.json({ error: 'Authentication required.' }, { status: 401 });

  const db = getDb();
  const ip = getClientIp(req);
  const appt = db
    .prepare(
      `SELECT a.*, u.email as patient_email, u.phone as patient_phone, u.full_name as patient_name
       FROM appointments a JOIN users u ON u.id = a.patient_id WHERE a.id = ?`
    )
    .get(params.id) as
    | {
        id: string;
        reference_no: string;
        patient_id: string;
        doctor_id: string;
        appointment_date: string;
        start_time: string;
        end_time: string;
        duration_minutes: number;
        status: string;
        patient_email: string;
        patient_phone: string | null;
        patient_name: string;
      }
    | undefined;

  if (!appt) {
    return NextResponse.json({ error: 'Appointment not found.' }, { status: 404 });
  }

  const isClinicStaff = ['DOCTOR', 'ADMIN', 'STAFF'].includes(user.role);
  if (!isClinicStaff && appt.patient_id !== user.id) {
    return NextResponse.json({ error: 'Access denied to this appointment.' }, { status: 403 });
  }

  const body = await req.json();
  const action = String(body.action || '');

  // APPROVE (Doctor / Staff / Admin)
  if (action === 'APPROVE') {
    if (!isClinicStaff) return NextResponse.json({ error: 'Clinic authorisation required.' }, { status: 403 });

    db.prepare("UPDATE appointments SET status = 'CONFIRMED', updated_at = datetime('now') WHERE id = ?").run(appt.id);
    const vc = await provisionVideoConsultation({
      appointmentId: appt.id,
      patientId: appt.patient_id,
      doctorId: appt.doctor_id,
    });

    await dispatchClinicNotification({
      userId: appt.patient_id,
      appointmentId: appt.id,
      inAppTitle: 'Appointment Approved & Confirmed',
      inAppMessage: `Your online appointment (Ref: ${appt.reference_no}) with Dr. Aparna Mishra is confirmed for ${appt.appointment_date} at ${formatTime12h(appt.start_time)} IST. Your secure video session is ready in the Patient Portal.`,
      whatsappTemplate: 'appointment_confirmed_v1',
      whatsappParams: [appt.patient_name, appt.reference_no, appt.appointment_date, formatTime12h(appt.start_time)],
      recipientPhone: appt.patient_phone,
      recipientEmail: appt.patient_email,
      emailSubject: `Confirmed: Appointment ${appt.reference_no} — Dr. Aparna Mishra`,
    });

    logAudit({
      actorId: user.id,
      actorRole: user.role,
      actorName: user.fullName,
      action: 'APPOINTMENT_APPROVED',
      entityType: 'APPOINTMENT',
      entityId: appt.id,
      details: `Approved ${appt.reference_no}; provisioned secure session ${vc.roomCode}`,
      ipAddress: ip,
    });

    return NextResponse.json({ ok: true, status: 'CONFIRMED', consultation: vc });
  }

  // REJECT (Doctor / Staff / Admin)
  if (action === 'REJECT') {
    if (!isClinicStaff) return NextResponse.json({ error: 'Clinic authorisation required.' }, { status: 403 });
    const reason = String(body.reason || 'Doctor schedule conflict — please select an alternate slot.').slice(0, 300);

    db.prepare(
      "UPDATE appointments SET status = 'REJECTED', rejection_or_cancel_reason = ?, updated_at = datetime('now') WHERE id = ?"
    ).run(reason, appt.id);

    await dispatchClinicNotification({
      userId: appt.patient_id,
      appointmentId: appt.id,
      inAppTitle: 'Appointment Request Update',
      inAppMessage: `Appointment ${appt.reference_no} (${appt.appointment_date}) could not be confirmed: ${reason}`,
      whatsappTemplate: 'appointment_cancelled_v1',
      whatsappParams: [appt.patient_name, appt.reference_no, appt.appointment_date],
      recipientPhone: appt.patient_phone,
      recipientEmail: appt.patient_email,
    });

    logAudit({
      actorId: user.id,
      actorRole: user.role,
      actorName: user.fullName,
      action: 'APPOINTMENT_REJECTED',
      entityType: 'APPOINTMENT',
      entityId: appt.id,
      details: `Rejected ${appt.reference_no}: ${reason}`,
      ipAddress: ip,
    });
    return NextResponse.json({ ok: true, status: 'REJECTED' });
  }

  // CANCEL (Patient or Clinic)
  if (action === 'CANCEL') {
    const reason = String(body.reason || `Cancelled by ${user.role.toLowerCase()}`).slice(0, 300);
    db.prepare(
      "UPDATE appointments SET status = 'CANCELLED', rejection_or_cancel_reason = ?, updated_at = datetime('now') WHERE id = ?"
    ).run(reason, appt.id);

    await dispatchClinicNotification({
      userId: appt.patient_id,
      appointmentId: appt.id,
      inAppTitle: 'Appointment Cancelled',
      inAppMessage: `Your appointment (Ref: ${appt.reference_no}) scheduled for ${appt.appointment_date} at ${formatTime12h(appt.start_time)} has been cancelled. Reason: ${reason}`,
      whatsappTemplate: 'appointment_cancelled_v1',
      whatsappParams: [appt.patient_name, appt.reference_no, appt.appointment_date],
      recipientPhone: appt.patient_phone,
      recipientEmail: appt.patient_email,
    });

    logAudit({
      actorId: user.id,
      actorRole: user.role,
      actorName: user.fullName,
      action: 'APPOINTMENT_CANCELLED',
      entityType: 'APPOINTMENT',
      entityId: appt.id,
      details: `Cancelled ${appt.reference_no}: ${reason}`,
      ipAddress: ip,
    });
    return NextResponse.json({ ok: true, status: 'CANCELLED' });
  }

  // RESCHEDULE (Patient or Clinic — strict conflict check!)
  if (action === 'RESCHEDULE') {
    const newDate = String(body.appointmentDate || '');
    const newStart = String(body.startTime || '');
    if (!/^\d{4}-\d{2}-\d{2}$/.test(newDate) || !/^\d{2}:\d{2}$/.test(newStart)) {
      return NextResponse.json({ error: 'Valid new date and start time are required.' }, { status: 400 });
    }

    const slotCheck = computeAvailableSlots(newDate, appt.duration_minutes, appt.id);
    if (!slotCheck.available) {
      return NextResponse.json({ error: slotCheck.reason || 'Selected day is unavailable.' }, { status: 409 });
    }
    const slot = slotCheck.slots.find((s) => s.startTime === newStart);
    if (!slot || slot.isBooked) {
      return NextResponse.json(
        { error: 'The selected time slot is unavailable or already booked.' },
        { status: 409 }
      );
    }

    const newEnd = minutesToTime(timeToMinutes(newStart) + appt.duration_minutes);
    const nextStatus = isClinicStaff ? 'CONFIRMED' : 'RESCHEDULED';
    db.prepare(
      `UPDATE appointments SET appointment_date = ?, start_time = ?, end_time = ?, status = ?, updated_at = datetime('now') WHERE id = ?`
    ).run(newDate, newStart, newEnd, nextStatus, appt.id);

    await dispatchClinicNotification({
      userId: appt.patient_id,
      appointmentId: appt.id,
      inAppTitle: 'Appointment Rescheduled',
      inAppMessage: `Your appointment (Ref: ${appt.reference_no}) is now scheduled for ${newDate} at ${formatTime12h(newStart)} IST.`,
      whatsappTemplate: 'appointment_rescheduled_v1',
      whatsappParams: [appt.patient_name, appt.reference_no, newDate, formatTime12h(newStart)],
      recipientPhone: appt.patient_phone,
      recipientEmail: appt.patient_email,
    });

    logAudit({
      actorId: user.id,
      actorRole: user.role,
      actorName: user.fullName,
      action: 'APPOINTMENT_RESCHEDULED',
      entityType: 'APPOINTMENT',
      entityId: appt.id,
      details: `Rescheduled ${appt.reference_no} to ${newDate} ${formatTime12h(newStart)}`,
      ipAddress: ip,
    });
    return NextResponse.json({ ok: true, status: nextStatus });
  }

  // COMPLETE (Doctor / Admin)
  if (action === 'COMPLETE') {
    if (!['DOCTOR', 'ADMIN'].includes(user.role)) {
      return NextResponse.json({ error: 'Only the doctor can mark a consultation completed.' }, { status: 403 });
    }
    const followupDate = body.followupDate ? String(body.followupDate) : null;
    const followupNotes = body.followupNotes ? String(body.followupNotes).slice(0, 600) : null;

    db.prepare(
      `UPDATE appointments SET status = 'COMPLETED', followup_date = COALESCE(?, followup_date), followup_notes = COALESCE(?, followup_notes), updated_at = datetime('now') WHERE id = ?`
    ).run(followupDate, followupNotes, appt.id);

    db.prepare(
      `UPDATE consultations SET status = 'COMPLETED', ended_at = datetime('now'), updated_at = datetime('now') WHERE appointment_id = ?`
    ).run(appt.id);

    if (followupDate) {
      await dispatchClinicNotification({
        userId: appt.patient_id,
        appointmentId: appt.id,
        inAppTitle: 'Consultation Completed & Follow-Up Scheduled',
        inAppMessage: `Thank you for consulting Dr. Aparna Mishra (Ref: ${appt.reference_no}). Recommended follow-up date: ${followupDate}.`,
        whatsappTemplate: 'followup_reminder_v1',
        whatsappParams: [appt.patient_name, followupDate],
        recipientPhone: appt.patient_phone,
        recipientEmail: appt.patient_email,
      });
    }

    logAudit({
      actorId: user.id,
      actorRole: user.role,
      actorName: user.fullName,
      action: 'APPOINTMENT_COMPLETED',
      entityType: 'APPOINTMENT',
      entityId: appt.id,
      details: `Marked ${appt.reference_no} completed.`,
      ipAddress: ip,
    });
    return NextResponse.json({ ok: true, status: 'COMPLETED' });
  }

  // SEND_REMINDER (Clinic WhatsApp Reminder)
  if (action === 'SEND_REMINDER') {
    if (!isClinicStaff) return NextResponse.json({ error: 'Clinic authorisation required.' }, { status: 403 });
    await dispatchClinicNotification({
      userId: appt.patient_id,
      appointmentId: appt.id,
      inAppTitle: 'Upcoming Consultation Reminder',
      inAppMessage: `Reminder: Your online consultation (Ref: ${appt.reference_no}) with Dr. Aparna Mishra is scheduled on ${appt.appointment_date} at ${formatTime12h(appt.start_time)} IST.`,
      whatsappTemplate: 'appointment_reminder_24h',
      whatsappParams: [appt.patient_name, appt.reference_no, appt.appointment_date, formatTime12h(appt.start_time)],
      recipientPhone: appt.patient_phone,
      recipientEmail: appt.patient_email,
    });
    return NextResponse.json({ ok: true, message: 'Reminder dispatched via Portal, WhatsApp & Email.' });
  }

  return NextResponse.json({ error: 'Unsupported appointment action.' }, { status: 400 });
}
