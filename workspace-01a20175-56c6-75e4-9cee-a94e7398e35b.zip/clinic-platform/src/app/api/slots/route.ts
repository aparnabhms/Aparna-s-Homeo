import { NextRequest, NextResponse } from 'next/server';
import { computeAvailableSlots, getDb } from '@/lib/db';

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
  const date = req.nextUrl.searchParams.get('date') || '';
  const typeId = req.nextUrl.searchParams.get('consultationTypeId') || 'ct_video_new';
  const excludeId = req.nextUrl.searchParams.get('excludeAppointmentId') || undefined;

  if (!date) {
    return NextResponse.json({ error: 'date query parameter is required (YYYY-MM-DD).' }, { status: 400 });
  }

  // Reject past dates
  const todayIso = new Date().toISOString().slice(0, 10);
  if (date < todayIso) {
    return NextResponse.json({
      available: false,
      reason: 'Past dates cannot be booked. Please select today or an upcoming day.',
      dayName: '',
      slots: [],
    });
  }

  const db = getDb();
  const ct = db
    .prepare('SELECT duration_minutes, fee_inr, name FROM consultation_types WHERE id = ?')
    .get(typeId) as { duration_minutes: number; fee_inr: number; name: string } | undefined;

  const duration = ct?.duration_minutes || 30;
  const result = computeAvailableSlots(date, duration, excludeId);

  return NextResponse.json({
    ...result,
    durationMinutes: duration,
    feeInr: ct?.fee_inr ?? 500,
    consultationTypeName: ct?.name ?? 'Online Consultation',
  });
}
