import { NextRequest, NextResponse } from 'next/server';
import { attachSessionCookie, getClientIp, signSessionToken } from '@/lib/auth';
import {
  findOrCreateGoogleUser,
  getGoogleOAuthConfig,
  getRequestOrigin,
  GOOGLE_STATE_COOKIE,
  sanitizeNextPath,
} from '@/lib/googleAuth';

export const dynamic = 'force-dynamic';

function redirectWithError(req: NextRequest, message: string, isPopup: boolean) {
  const origin = getRequestOrigin(req);
  const loginUrl = new URL('/login', origin);
  loginUrl.searchParams.set('error', message);

  if (isPopup) {
    const safeMsg = JSON.stringify(message);
    const safeUrl = JSON.stringify(loginUrl.toString());
    return new NextResponse(
      `<!DOCTYPE html><html><head><title>Google Sign-In</title></head><body><script>
        try {
          if (window.opener) {
            window.opener.postMessage({ type: 'CLINIC_GOOGLE_AUTH_ERROR', error: ${safeMsg} }, window.location.origin);
            window.close();
          } else {
            window.location.replace(${safeUrl});
          }
        } catch (e) { window.location.replace(${safeUrl}); }
      </script></body></html>`,
      { headers: { 'Content-Type': 'text/html; charset=utf-8' } }
    );
  }
  return NextResponse.redirect(loginUrl.toString());
}

/**
 * GET /api/auth/google/callback
 * Completes the OAuth 2.0 authorization code flow with Google, verifies email_verified,
 * establishes an HttpOnly JWT clinic session without any password, and redirects to the portal.
 */
export async function GET(req: NextRequest) {
  const rawStateCookie = req.cookies.get(GOOGLE_STATE_COOKIE)?.value || '';
  let expectedNonce = '';
  let nextPath = '';
  let isPopup = false;

  if (rawStateCookie) {
    try {
      const parsed = JSON.parse(
        Buffer.from(rawStateCookie, 'base64url').toString('utf8')
      ) as { nonce?: string; next?: string; popup?: boolean };
      expectedNonce = String(parsed.nonce || '');
      nextPath = sanitizeNextPath(parsed.next);
      isPopup = Boolean(parsed.popup);
    } catch {
      // invalid cookie falls through to state mismatch check
    }
  }

  const oauthError = req.nextUrl.searchParams.get('error');
  if (oauthError) {
    return redirectWithError(
      req,
      oauthError === 'access_denied'
        ? 'Google sign-in was cancelled.'
        : 'Google sign-in could not be completed.',
      isPopup
    );
  }

  const code = req.nextUrl.searchParams.get('code') || '';
  const returnedState = req.nextUrl.searchParams.get('state') || '';

  if (!code || !expectedNonce || returnedState !== expectedNonce) {
    return redirectWithError(
      req,
      'Security verification failed (expired or mismatched OAuth state). Please try Sign in with Google again.',
      isPopup
    );
  }

  const cfg = getGoogleOAuthConfig(req);
  if (!cfg.oauthConfigured) {
    return redirectWithError(
      req,
      'Google OAuth credentials are not configured on this server.',
      isPopup
    );
  }

  try {
    // 1. Exchange authorization code for Google access & ID tokens
    const tokenResp = await fetch('https://oauth2.googleapis.com/token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        code,
        client_id: cfg.clientId,
        client_secret: cfg.clientSecret,
        redirect_uri: cfg.redirectUri,
        grant_type: 'authorization_code',
      }).toString(),
      cache: 'no-store',
    });

    if (!tokenResp.ok) {
      return redirectWithError(
        req,
        'Could not exchange Google authorization code. Check GOOGLE_REDIRECT_URI and client secret.',
        isPopup
      );
    }

    const tokens = (await tokenResp.json()) as { access_token?: string };
    if (!tokens.access_token) {
      return redirectWithError(req, 'No access token received from Google.', isPopup);
    }

    // 2. Fetch verified OpenID Connect user profile
    const profileResp = await fetch('https://openidconnect.googleapis.com/v1/userinfo', {
      headers: { Authorization: `Bearer ${tokens.access_token}` },
      cache: 'no-store',
    });

    if (!profileResp.ok) {
      return redirectWithError(req, 'Could not fetch verified Google account profile.', isPopup);
    }

    const profile = (await profileResp.json()) as {
      sub?: string;
      email?: string;
      email_verified?: boolean;
      name?: string;
    };

    if (!profile.email || !profile.email_verified) {
      return redirectWithError(
        req,
        'Your Google account does not have a verified email address.',
        isPopup
      );
    }

    // 3. Find or auto-create clinic user & attach HttpOnly session cookie
    const outcome = await findOrCreateGoogleUser({
      email: profile.email,
      fullName: profile.name,
      googleSub: profile.sub || null,
      ipAddress: getClientIp(req),
      authAction: 'LOGIN_GOOGLE_OAUTH',
    });

    if (!outcome.ok) {
      return redirectWithError(req, outcome.error, isPopup);
    }

    const sessionToken = await signSessionToken(outcome.sessionUser);
    const isStaffRole = ['DOCTOR', 'ADMIN', 'STAFF'].includes(outcome.sessionUser.role);
    const targetPath =
      nextPath && !(isStaffRole && nextPath.startsWith('/portal'))
        ? nextPath
        : outcome.redirectTo;
    const targetUrlObj = new URL(targetPath, getRequestOrigin(req));
    targetUrlObj.searchParams.set('_st', sessionToken);
    const targetUrl = targetUrlObj.toString();

    let res: NextResponse;
    if (isPopup) {
      const payload = JSON.stringify({
        type: 'CLINIC_GOOGLE_AUTH_SUCCESS',
        user: outcome.sessionUser,
        redirectTo: targetPath,
        sessionToken,
      });
      res = new NextResponse(
        `<!DOCTYPE html><html><head><title>Signed In</title></head><body><script>
          try {
            if (window.opener) {
              window.opener.postMessage(${payload}, window.location.origin);
              window.close();
            } else {
              window.location.replace(${JSON.stringify(targetUrl)});
            }
          } catch (e) { window.location.replace(${JSON.stringify(targetUrl)}); }
        </script></body></html>`,
        { headers: { 'Content-Type': 'text/html; charset=utf-8' } }
      );
    } else {
      res = NextResponse.redirect(targetUrl);
    }

    res.cookies.set(GOOGLE_STATE_COOKIE, '', { httpOnly: true, path: '/', maxAge: 0 });
    return attachSessionCookie(res, sessionToken, req);
  } catch (err) {
    console.error('Google OAuth callback error:', err);
    return redirectWithError(req, 'Unexpected error completing Google sign-in.', isPopup);
  }
}
