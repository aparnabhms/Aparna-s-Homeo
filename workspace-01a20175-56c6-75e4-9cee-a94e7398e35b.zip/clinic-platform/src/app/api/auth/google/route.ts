import crypto from 'crypto';
import { NextRequest, NextResponse } from 'next/server';
import {
  attachSessionCookie,
  checkRateLimit,
  getClientIp,
  signSessionToken,
} from '@/lib/auth';
import {
  findOrCreateGoogleUser,
  getGoogleOAuthConfig,
  getRequestOrigin,
  GOOGLE_STATE_COOKIE,
  sanitizeNextPath,
} from '@/lib/googleAuth';

export const dynamic = 'force-dynamic';

function isValidGoogleEmail(email: string): boolean {
  return /^[a-zA-Z0-9._%+-]{2,}@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/.test(email);
}

/**
 * GET /api/auth/google
 * - ?mode=status  -> returns OAuth / GIS readiness for UI
 * - default       -> initiates Google OAuth 2.0 Authorization Code flow with CSRF state cookie
 */
export async function GET(req: NextRequest) {
  const cfg = getGoogleOAuthConfig(req);
  const mode = req.nextUrl.searchParams.get('mode') || 'redirect';
  const nextPath = sanitizeNextPath(req.nextUrl.searchParams.get('next'));
  const isPopup = req.nextUrl.searchParams.get('popup') === '1';

  if (mode === 'status') {
    return NextResponse.json({
      oauthConfigured: cfg.oauthConfigured,
      gisClientId: cfg.gisConfigured ? cfg.clientId : null,
      demoMode: cfg.demoMode,
      redirectUri: cfg.redirectUri,
    });
  }

  // If live GOOGLE_CLIENT_ID + GOOGLE_CLIENT_SECRET are not set yet, route cleanly to the login chooser
  if (!cfg.oauthConfigured) {
    const origin = getRequestOrigin(req);
    const fallback = new URL('/login', origin);
    fallback.searchParams.set('google', '1');
    if (nextPath) fallback.searchParams.set('next', nextPath);
    return NextResponse.redirect(fallback.toString());
  }

  const stateNonce = crypto.randomBytes(24).toString('hex');
  const statePayload = JSON.stringify({
    nonce: stateNonce,
    next: nextPath,
    popup: isPopup,
  });

  const googleAuthUrl = new URL('https://accounts.google.com/o/oauth2/v2/auth');
  googleAuthUrl.searchParams.set('client_id', cfg.clientId);
  googleAuthUrl.searchParams.set('redirect_uri', cfg.redirectUri);
  googleAuthUrl.searchParams.set('response_type', 'code');
  googleAuthUrl.searchParams.set('scope', 'openid email profile');
  googleAuthUrl.searchParams.set('state', stateNonce);
  googleAuthUrl.searchParams.set('prompt', 'select_account');
  googleAuthUrl.searchParams.set('access_type', 'online');

  const proto =
    req.headers.get('x-forwarded-proto') ||
    (req.nextUrl.protocol === 'https:' ? 'https' : 'http');
  const isHttps = proto === 'https';

  const res = NextResponse.redirect(googleAuthUrl.toString());
  res.cookies.set(GOOGLE_STATE_COOKIE, Buffer.from(statePayload).toString('base64url'), {
    httpOnly: true,
    secure: isHttps,
    sameSite: isHttps ? 'none' : 'lax',
    path: '/',
    maxAge: 600, // 10 minutes
  });
  return res;
}

/**
 * POST /api/auth/google
 * Supports:
 * 1. Production Google Identity Services (One-Tap / Sign in with Google button) ID token (`credential`)
 * 2. Instant passwordless Sandbox Google Account Chooser (`email` + optional `fullName`) when
 *    live Google OAuth credentials are not configured and NEXT_PUBLIC_DEMO_MODE !== 'false'.
 */
export async function POST(req: NextRequest) {
  const ip = getClientIp(req);
  const rl = checkRateLimit(`google-auth:${ip}`, 60, 10 * 60 * 1000);
  if (!rl.allowed) {
    return NextResponse.json(
      { error: `Too many attempts. Please wait ${rl.retryAfterSec}s.` },
      { status: 429 }
    );
  }

  try {
    const body = await req.json();
    const cfg = getGoogleOAuthConfig(req);
    const nextPath = sanitizeNextPath(body.next);

    // 1. Live Google Identity Services (OIDC ID Token verification)
    if (body.credential) {
      if (!cfg.clientId) {
        return NextResponse.json(
          { error: 'GOOGLE_CLIENT_ID is not configured on the server.' },
          { status: 400 }
        );
      }

      const credential = String(body.credential).trim();
      const verifyResp = await fetch(
        `https://oauth2.googleapis.com/tokeninfo?id_token=${encodeURIComponent(credential)}`,
        { cache: 'no-store' }
      );
      if (!verifyResp.ok) {
        return NextResponse.json(
          { error: 'Google token verification failed. Please try signing in again.' },
          { status: 401 }
        );
      }

      const tokenInfo = (await verifyResp.json()) as {
        aud?: string;
        iss?: string;
        sub?: string;
        email?: string;
        email_verified?: string | boolean;
        name?: string;
      };

      const validIssuer =
        tokenInfo.iss === 'accounts.google.com' ||
        tokenInfo.iss === 'https://accounts.google.com';
      const emailVerified =
        tokenInfo.email_verified === true || tokenInfo.email_verified === 'true';

      if (tokenInfo.aud !== cfg.clientId || !validIssuer || !emailVerified || !tokenInfo.email) {
        return NextResponse.json(
          { error: 'Google account could not be verified. Ensure your Google email is verified.' },
          { status: 401 }
        );
      }

      const outcome = await findOrCreateGoogleUser({
        email: tokenInfo.email,
        fullName: tokenInfo.name,
        googleSub: tokenInfo.sub || null,
        ipAddress: ip,
        authAction: 'LOGIN_GOOGLE_OIDC',
      });
      if (!outcome.ok) {
        return NextResponse.json({ error: outcome.error }, { status: outcome.status });
      }

      const sessionToken = await signSessionToken(outcome.sessionUser);
      const isStaffRole = ['DOCTOR', 'ADMIN', 'STAFF'].includes(outcome.sessionUser.role);
      const finalRedirect =
        nextPath && !(isStaffRole && nextPath === '/portal') ? nextPath : outcome.redirectTo;

      const res = NextResponse.json({
        ok: true,
        mode: 'GOOGLE_OIDC',
        user: outcome.sessionUser,
        isNewUser: outcome.isNewUser,
        redirectTo: finalRedirect,
        sessionToken,
      });
      return attachSessionCookie(res, sessionToken, req);
    }

    // 2. Passwordless Google Account Chooser (active in development/demo when GOOGLE_CLIENT_ID is unset)
    if (cfg.oauthConfigured || !cfg.demoMode) {
      return NextResponse.json(
        {
          error:
            'Direct Google OAuth 2.0 is required. Please use the official Google Sign-In redirect.',
        },
        { status: 403 }
      );
    }

    const email = String(body.email || '').trim().toLowerCase();
    const fullName = String(body.fullName || '').trim();

    if (!isValidGoogleEmail(email)) {
      return NextResponse.json(
        { error: 'Please enter a valid Google email address (e.g. yourname@gmail.com).' },
        { status: 400 }
      );
    }

    const syntheticSub = `google_sandbox_${crypto
      .createHash('sha256')
      .update(email)
      .digest('hex')
      .slice(0, 20)}`;

    const outcome = await findOrCreateGoogleUser({
      email,
      fullName,
      googleSub: syntheticSub,
      ipAddress: ip,
      authAction: 'LOGIN_GOOGLE_PASSWORDLESS',
    });
    if (!outcome.ok) {
      return NextResponse.json({ error: outcome.error }, { status: outcome.status });
    }

    const sessionToken = await signSessionToken(outcome.sessionUser);
    const isStaffRole = ['DOCTOR', 'ADMIN', 'STAFF'].includes(outcome.sessionUser.role);
    let finalRedirect = outcome.redirectTo;
    if (nextPath) {
      if (isStaffRole && nextPath.startsWith('/portal')) {
        finalRedirect = nextPath.includes('start=') || nextPath.includes('video') || nextPath.includes('chat')
          ? '/admin?tab=chat'
          : '/admin';
      } else if (!isStaffRole && nextPath.startsWith('/admin')) {
        finalRedirect = '/portal';
      } else {
        finalRedirect = nextPath;
      }
    }

    const res = NextResponse.json({
      ok: true,
      mode: 'GOOGLE_SANDBOX',
      user: outcome.sessionUser,
      isNewUser: outcome.isNewUser,
      redirectTo: finalRedirect,
      sessionToken,
    });
    return attachSessionCookie(res, sessionToken, req);
  } catch (err) {
    console.error('Google Sign-In error:', err);
    return NextResponse.json(
      { error: 'Could not complete Sign in with Google. Please try again.' },
      { status: 500 }
    );
  }
}
