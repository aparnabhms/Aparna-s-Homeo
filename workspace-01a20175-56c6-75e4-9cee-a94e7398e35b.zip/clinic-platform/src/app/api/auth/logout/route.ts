import { NextRequest, NextResponse } from 'next/server';
import { clearSessionCookie, getClientIp, getRequestUser } from '@/lib/auth';
import { logAudit } from '@/lib/db';

export async function POST(req: NextRequest) {
  const user = await getRequestUser(req);
  if (user) {
    logAudit({
      actorId: user.id,
      actorRole: user.role,
      actorName: user.fullName,
      action: 'LOGOUT',
      entityType: 'SESSION',
      entityId: user.id,
      ipAddress: getClientIp(req),
    });
  }
  const res = NextResponse.json({ ok: true });
  return clearSessionCookie(res, req);
}
