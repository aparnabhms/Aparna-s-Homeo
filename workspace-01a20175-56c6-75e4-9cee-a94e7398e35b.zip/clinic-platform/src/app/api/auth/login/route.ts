import { NextRequest, NextResponse } from 'next/server';
import { getDb, logAudit } from '@/lib/db';
import {
  attachSessionCookie,
  checkRateLimit,
  generateId,
  generateRefCode,
  getClientIp,
  hashPassword,
  signSessionToken,
  UserRole,
  verifyPassword,
} from '@/lib/auth';

interface DbUserRow {
  id: string;
  email: string;
  phone: string | null;
  password_hash: string | null;
  full_name: string;
  role: UserRole;
  is_active: number;
  is_demo: number;
}

function nameFromEmail(email: string): string {
  const local = email.split('@')[0] || 'Patient';
  const clean = local
    .replace(/[._0-9+-]+/g, ' ')
    .trim()
    .replace(/\b\w/g, (c) => c.toUpperCase());
  return clean.length >= 2 ? clean.slice(0, 120) : 'Patient';
}

export async function POST(req: NextRequest) {
  const ip = getClientIp(req);
  const rl = checkRateLimit(`login:${ip}`, 40, 10 * 60 * 1000);
  if (!rl.allowed) {
    return NextResponse.json(
      { error: `Too many sign-in attempts. Please retry after ${rl.retryAfterSec}s.` },
      { status: 429 }
    );
  }

  try {
    const body = await req.json();
    const method = String(body.method || 'EMAIL');
    const db = getDb();

    let user: DbUserRow | undefined;

    // 1. Gmail / Email & Password Sign-In (works seamlessly for existing & first-time Gmail users)
    if (method === 'EMAIL') {
      const email = String(body.email || '').trim().toLowerCase();
      const password = String(body.password || '');
      if (!email || !/^[a-zA-Z0-9._%+-]{2,}@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/.test(email)) {
        return NextResponse.json(
          { error: 'Please enter a valid Gmail or email address (e.g. yourname@gmail.com).' },
          { status: 400 }
        );
      }
      if (!password || password.length < 4) {
        return NextResponse.json(
          { error: 'Please enter your password (or click Sign in with Google above).' },
          { status: 400 }
        );
      }

      const row = db
        .prepare('SELECT * FROM users WHERE lower(email) = ?')
        .get(email) as DbUserRow | undefined;

      if (!row) {
        // First-time Gmail visitor entering email + password (6+ chars) -> create secure patient account seamlessly
        if (password.length < 6) {
          return NextResponse.json(
            { error: 'Password must be at least 6 characters for a new account (or use Sign in with Google).' },
            { status: 400 }
          );
        }
        const pwHash = await hashPassword(password);
        const newId = generateId('usr');
        const fullName = nameFromEmail(email);
        const patCode = generateRefCode('PAT').slice(0, 18);

        db.transaction(() => {
          db.prepare(`
            INSERT INTO users (
              id, email, phone, password_hash, full_name, role, auth_provider,
              email_verified, phone_verified, is_active, is_demo
            ) VALUES (?, ?, NULL, ?, ?, 'PATIENT', 'EMAIL', 1, 0, 1, 0)
          `).run(newId, email, pwHash, fullName);

          db.prepare(
            'INSERT INTO patient_profiles (id, user_id, patient_code) VALUES (?, ?, ?)'
          ).run(generateId('pp'), newId, patCode);

          db.prepare(`
            INSERT INTO consent_records (id, user_id, consent_type, granted, ip_address)
            VALUES
              (?, ?, 'DPDP_DATA_PROCESSING', 1, ?),
              (?, ?, 'TELEMEDICINE_CONSULTATION', 1, ?),
              (?, ?, 'WHATSAPP_COMMUNICATION', 1, ?)
          `).run(
            generateId('cns'), newId, ip,
            generateId('cns'), newId, ip,
            generateId('cns'), newId, ip
          );
        })();

        const doc = db
          .prepare("SELECT id FROM users WHERE role = 'DOCTOR' LIMIT 1")
          .get() as { id: string } | undefined;
        if (doc) {
          db.prepare(`
            INSERT INTO clinic_messages (
              id, patient_id, sender_id, sender_role, sender_name,
              message_type, content, call_phone, is_read
            ) VALUES (?, ?, ?, 'DOCTOR', 'Dr. Aparna Mishra', 'TEXT', ?, '+918123108149', 0)
          `).run(
            generateId('msg'),
            newId,
            doc.id,
            `Namaste ${fullName}! Welcome to Dr. Aparna Mishra’s Digital Clinic. Message me here or start a Live Audio/Video Call anytime during clinic hours (Mon–Sat, 3:00 PM – 8:00 PM IST · +91 8123108149).`
          );
        }

        user = db.prepare('SELECT * FROM users WHERE id = ?').get(newId) as DbUserRow;
      } else if (!row.password_hash) {
        // Account created previously via Google without password -> save password & sign in seamlessly
        if (password.length < 6) {
          return NextResponse.json(
            {
              error:
                'Click "Sign in with Google" above to enter without a password, or enter at least 6 characters to set a password.',
            },
            { status: 400 }
          );
        }
        const pwHash = await hashPassword(password);
        db.prepare("UPDATE users SET password_hash = ?, updated_at = datetime('now') WHERE id = ?").run(
          pwHash,
          row.id
        );
        user = row;
      } else {
        const ok = await verifyPassword(password, row.password_hash);
        if (!ok) {
          logAudit({
            actorRole: 'ANONYMOUS',
            action: 'LOGIN_FAILED_WRONG_PASSWORD',
            entityType: 'USER',
            details: `Incorrect password attempt for ${email}`,
            ipAddress: ip,
          });
          return NextResponse.json(
            {
              error:
                'Incorrect password. Enter your exact password, or click "Sign in with Google" above to sign in instantly without a password.',
            },
            { status: 401 }
          );
        }
        user = row;
      }
    }

    // 2. Demo Quick Switcher (1-click role access in preview mode)
    else if (method === 'DEMO_QUICK') {
      if (process.env.NEXT_PUBLIC_DEMO_MODE === 'false') {
        return NextResponse.json({ error: 'Demo login is disabled in production.' }, { status: 403 });
      }
      const demoRole = String(body.demoAccount || 'PATIENT');
      const emailMap: Record<string, string> = {
        DOCTOR: 'aparnabhms@gmail.com',
        STAFF: 'staff.demo@aparnaclinic.in',
        PATIENT: 'ananya.demo@example.com',
        GUARDIAN: 'priya.demo@example.com',
      };
      const targetEmail = emailMap[demoRole] || emailMap.PATIENT;
      user = db
        .prepare('SELECT * FROM users WHERE lower(email) = ?')
        .get(targetEmail) as DbUserRow | undefined;
    } else {
      return NextResponse.json(
        { error: 'Please use Sign in with Google or Email & Password.' },
        { status: 400 }
      );
    }

    if (!user) {
      return NextResponse.json({ error: 'Account not found.' }, { status: 404 });
    }
    if (!user.is_active) {
      return NextResponse.json(
        { error: 'This account is currently deactivated. Contact +91 8123108149.' },
        { status: 403 }
      );
    }

    db.prepare("UPDATE users SET last_login_at = datetime('now') WHERE id = ?").run(user.id);

    logAudit({
      actorId: user.id,
      actorRole: user.role,
      actorName: user.full_name,
      action: `LOGIN_${method}`,
      entityType: 'SESSION',
      entityId: user.id,
      details: `Authenticated via ${method}`,
      ipAddress: ip,
    });

    const sessionUser = {
      id: user.id,
      email: user.email,
      fullName: user.full_name,
      role: user.role,
      phone: user.phone,
      isDemo: Boolean(user.is_demo),
    };
    const token = await signSessionToken(sessionUser);
    const redirectTo =
      user.role === 'DOCTOR' || user.role === 'ADMIN' || user.role === 'STAFF'
        ? '/admin'
        : '/portal';

    const res = NextResponse.json({
      user: sessionUser,
      redirectTo,
      sessionToken: token,
    });
    return attachSessionCookie(res, token, req);
  } catch (err) {
    console.error('Login error:', err);
    return NextResponse.json({ error: 'Authentication failed.' }, { status: 500 });
  }
}
