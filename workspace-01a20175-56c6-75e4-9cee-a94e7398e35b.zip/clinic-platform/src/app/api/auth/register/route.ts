import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { getDb, logAudit } from '@/lib/db';
import {
  attachSessionCookie,
  checkRateLimit,
  generateId,
  generateRefCode,
  getClientIp,
  hashPassword,
  signSessionToken,
} from '@/lib/auth';
import { dispatchClinicNotification } from '@/lib/services';

const registerSchema = z.object({
  fullName: z.string().trim().min(2, 'Full name is required').max(120),
  email: z.string().trim().email('Valid email address is required').max(180),
  phone: z
    .string()
    .trim()
    .optional()
    .default('')
    .refine(
      (v) => v === '' || /^[+]?[0-9\s-]{10,15}$/.test(v),
      'Enter a valid 10-digit Indian mobile number'
    ),
  password: z
    .string()
    .min(6, 'Password must be at least 6 characters')
    .max(100),
  dateOfBirth: z.string().optional().default(''),
  gender: z.string().optional().default(''),
  bloodGroup: z.string().optional().default(''),
  city: z.string().trim().max(80).optional().default(''),
  state: z.string().trim().max(80).optional().default(''),
  isMinorAccount: z.boolean().optional().default(false),
  guardianRelation: z.string().trim().max(60).optional().default(''),
  minorPatientName: z.string().trim().max(120).optional().default(''),
  minorDateOfBirth: z.string().optional().default(''),
  dpdpConsent: z.literal(true, {
    errorMap: () => ({ message: 'DPDP Act privacy consent is required to register.' }),
  }),
  telemedicineConsent: z.literal(true, {
    errorMap: () => ({ message: 'Telemedicine consultation consent is required.' }),
  }),
  whatsappConsent: z.boolean().optional().default(true),
});

export async function POST(req: NextRequest) {
  const ip = getClientIp(req);
  const rl = checkRateLimit(`register:${ip}`, 35, 15 * 60 * 1000);
  if (!rl.allowed) {
    return NextResponse.json(
      { error: `Too many attempts. Please wait ${rl.retryAfterSec}s.` },
      { status: 429 }
    );
  }

  try {
    const body = await req.json();
    const parsed = registerSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json(
        { error: parsed.error.issues[0]?.message || 'Invalid registration details.' },
        { status: 400 }
      );
    }

    const data = parsed.data;
    if (data.isMinorAccount && (!data.minorPatientName || !data.guardianRelation)) {
      return NextResponse.json(
        { error: 'Minor patient name and parent/legal guardian relationship are required.' },
        { status: 400 }
      );
    }

    const db = getDb();
    const emailLower = data.email.toLowerCase();
    const rawPhone = data.phone.replace(/[\s-]/g, '').replace(/^\+91/, '');
    const cleanPhone: string | null = rawPhone.length > 0 ? rawPhone : null;

    const existingEmail = db
      .prepare('SELECT id FROM users WHERE lower(email) = ?')
      .get(emailLower);
    if (existingEmail) {
      return NextResponse.json(
        { error: 'An account with this email already exists. Use Gmail & Password or Sign in with Google.' },
        { status: 409 }
      );
    }

    if (cleanPhone) {
      const existingPhone = db
        .prepare('SELECT id FROM users WHERE phone = ?')
        .get(cleanPhone);
      if (existingPhone) {
        return NextResponse.json(
          { error: 'An account with this mobile number already exists. Please sign in.' },
          { status: 409 }
        );
      }
    }

    const passwordHash = await hashPassword(data.password);
    const userId = generateId('usr');
    const patientCode = generateRefCode('PAT').slice(0, 18);

    const createTx = db.transaction(() => {
      db.prepare(`
        INSERT INTO users (
          id, email, phone, password_hash, full_name, role, auth_provider,
          email_verified, phone_verified, is_active, is_demo, last_login_at
        ) VALUES (?, ?, ?, ?, ?, 'PATIENT', 'EMAIL', 1, 0, 1, 0, datetime('now'))
      `).run(userId, emailLower, cleanPhone, passwordHash, data.fullName);

      db.prepare(`
        INSERT INTO patient_profiles (
          id, user_id, patient_code, date_of_birth, gender, blood_group, city, state,
          is_minor_account, guardian_name, guardian_relation, minor_patient_name, minor_date_of_birth
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).run(
        generateId('pp'),
        userId,
        patientCode,
        data.dateOfBirth || null,
        data.gender || null,
        data.bloodGroup || null,
        data.city || null,
        data.state || null,
        data.isMinorAccount ? 1 : 0,
        data.isMinorAccount ? data.fullName : null,
        data.isMinorAccount ? data.guardianRelation : null,
        data.isMinorAccount ? data.minorPatientName : null,
        data.isMinorAccount ? data.minorDateOfBirth || null : null
      );

      const insConsent = db.prepare(`
        INSERT INTO consent_records (id, user_id, consent_type, granted, guardian_declaration, ip_address)
        VALUES (?, ?, ?, 1, ?, ?)
      `);
      insConsent.run(generateId('cns'), userId, 'DPDP_DATA_PROCESSING', null, ip);
      insConsent.run(generateId('cns'), userId, 'TELEMEDICINE_CONSULTATION', null, ip);
      if (data.whatsappConsent) {
        insConsent.run(generateId('cns'), userId, 'WHATSAPP_COMMUNICATION', null, ip);
      }
      if (data.isMinorAccount) {
        insConsent.run(
          generateId('cns'),
          userId,
          'MINOR_GUARDIAN_AUTHORISATION',
          `${data.fullName} (${data.guardianRelation}) authorised portal & teleconsultation access for minor ${data.minorPatientName}.`,
          ip
        );
      }
    });
    createTx();

    await dispatchClinicNotification({
      userId,
      inAppTitle: 'Welcome to Dr. Aparna Mishra Digital Clinic',
      inAppMessage:
        'Your secure Patient Portal account is active. You can now book online consultations (Mon–Sat, 3:00 PM – 8:00 PM IST), chat with the clinic, join audio/video calls on +91 8123108149, upload reports, and download prescriptions.',
      recipientEmail: emailLower,
      emailSubject: 'Welcome — Dr. Aparna Mishra Digital Clinic',
    });

    // Seed welcome message in private Doctor-Patient Live Chat
    const doctorUser = db.prepare("SELECT id FROM users WHERE role = 'DOCTOR' LIMIT 1").get() as
      | { id: string }
      | undefined;
    if (doctorUser) {
      db.prepare(`
        INSERT INTO clinic_messages (id, patient_id, sender_id, sender_role, sender_name, message_type, content, call_phone, is_read)
        VALUES (?, ?, ?, 'DOCTOR', 'Dr. Aparna Mishra', 'TEXT', ?, '+918123108149', 0)
      `).run(
        generateId('msg'),
        userId,
        doctorUser.id,
        `Namaste ${data.fullName}! Welcome to my online clinic. You can send messages here anytime or connect for scheduled Audio & Video Consultations on +91 8123108149 (Mon–Sat, 3:00 PM – 8:00 PM IST).`
      );
    }

    logAudit({
      actorId: userId,
      actorRole: 'PATIENT',
      actorName: data.fullName,
      action: 'PATIENT_REGISTERED',
      entityType: 'USER',
      entityId: userId,
      details: data.isMinorAccount
        ? `Registered Parent/Legal Guardian account for minor ${data.minorPatientName}`
        : `Registered adult patient account (${patientCode})`,
      ipAddress: ip,
    });

    const sessionUser = {
      id: userId,
      email: emailLower,
      fullName: data.fullName,
      role: 'PATIENT' as const,
      phone: cleanPhone,
      isDemo: false,
    };
    const token = await signSessionToken(sessionUser);
    const res = NextResponse.json({
      user: sessionUser,
      patientCode,
      redirectTo: '/portal',
      sessionToken: token,
    });
    return attachSessionCookie(res, token, req);
  } catch (err) {
    console.error('Register error:', err);
    return NextResponse.json({ error: 'Unable to complete registration.' }, { status: 500 });
  }
}
