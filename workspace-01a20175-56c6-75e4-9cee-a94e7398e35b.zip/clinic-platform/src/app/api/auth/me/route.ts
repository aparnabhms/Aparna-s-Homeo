import { NextRequest, NextResponse } from 'next/server';
import { getDb, logAudit } from '@/lib/db';
import {
  generateId,
  getClientIp,
  getRequestUser,
  hashPassword,
  verifyPassword,
} from '@/lib/auth';

export async function GET(req: NextRequest) {
  const session = await getRequestUser(req);
  if (!session) {
    return NextResponse.json({ user: null });
  }

  const db = getDb();
  const user = db
    .prepare(
      'SELECT id, email, phone, full_name, role, auth_provider, email_verified, phone_verified, is_demo, last_login_at, created_at FROM users WHERE id = ?'
    )
    .get(session.id);

  if (!user) {
    return NextResponse.json({ user: null });
  }

  const profile =
    session.role === 'PATIENT'
      ? db.prepare('SELECT * FROM patient_profiles WHERE user_id = ?').get(session.id)
      : null;

  const consents = db
    .prepare('SELECT * FROM consent_records WHERE user_id = ? ORDER BY granted_at DESC')
    .all(session.id);

  const unreadCount = (
    db
      .prepare('SELECT COUNT(*) as c FROM notifications WHERE user_id = ? AND is_read = 0')
      .get(session.id) as { c: number }
  ).c;

  // DPDP Act 2023 Data Portability Export for Patient
  if (req.nextUrl.searchParams.get('export') === '1' && session.role === 'PATIENT') {
    const appointments = db
      .prepare('SELECT reference_no, concern_category, appointment_date, start_time, status, fee_inr, payment_status FROM appointments WHERE patient_id = ?')
      .all(session.id);
    const prescriptions = db
      .prepare("SELECT prescription_no, clinical_impression, medicines_json, general_instructions, followup_date, authorised_at FROM prescriptions WHERE patient_id = ? AND status = 'AUTHORISED'")
      .all(session.id);
    const payments = db
      .prepare('SELECT receipt_no, amount_inr, payment_method, status, created_at FROM payments WHERE patient_id = ?')
      .all(session.id);

    logAudit({
      actorId: session.id,
      actorRole: session.role,
      actorName: session.fullName,
      action: 'DPDP_DATA_EXPORTED',
      entityType: 'USER',
      entityId: session.id,
      ipAddress: getClientIp(req),
    });

    return new NextResponse(
      JSON.stringify(
        {
          exportedAt: new Date().toISOString(),
          regulation: 'India Digital Personal Data Protection (DPDP) Act, 2023',
          user,
          profile,
          consents,
          appointments,
          prescriptions,
          payments,
        },
        null,
        2
      ),
      {
        headers: {
          'Content-Type': 'application/json',
          'Content-Disposition': `attachment; filename="my-health-data-${session.id.slice(-6)}.json"`,
        },
      }
    );
  }

  const notifications = db
    .prepare('SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 40')
    .all(session.id);

  return NextResponse.json({
    user: {
      ...session,
      details: user,
    },
    profile,
    consents,
    notifications,
    unreadCount,
  });
}

export async function PATCH(req: NextRequest) {
  const session = await getRequestUser(req);
  if (!session) {
    return NextResponse.json({ error: 'Authentication required.' }, { status: 401 });
  }

  const db = getDb();
  const body = await req.json();
  const action = String(body.action || 'UPDATE_PROFILE');
  const ip = getClientIp(req);

  if (action === 'MARK_NOTIFICATIONS_READ') {
    if (body.notificationId) {
      db.prepare('UPDATE notifications SET is_read = 1 WHERE id = ? AND user_id = ?').run(
        String(body.notificationId),
        session.id
      );
    } else {
      db.prepare('UPDATE notifications SET is_read = 1 WHERE user_id = ?').run(session.id);
    }
    return NextResponse.json({ ok: true });
  }

  if (action === 'CHANGE_PASSWORD') {
    const currentPassword = String(body.currentPassword || '');
    const newPassword = String(body.newPassword || '');
    if (newPassword.length < 8) {
      return NextResponse.json({ error: 'New password must be at least 8 characters.' }, { status: 400 });
    }
    const row = db
      .prepare('SELECT password_hash FROM users WHERE id = ?')
      .get(session.id) as { password_hash: string | null } | undefined;

    if (row?.password_hash) {
      const ok = await verifyPassword(currentPassword, row.password_hash);
      if (!ok) {
        return NextResponse.json({ error: 'Current password is incorrect.' }, { status: 401 });
      }
    }
    const hashed = await hashPassword(newPassword);
    db.prepare("UPDATE users SET password_hash = ?, updated_at = datetime('now') WHERE id = ?").run(
      hashed,
      session.id
    );
    logAudit({
      actorId: session.id,
      actorRole: session.role,
      actorName: session.fullName,
      action: 'PASSWORD_CHANGED',
      entityType: 'USER',
      entityId: session.id,
      ipAddress: ip,
    });
    return NextResponse.json({ ok: true, message: 'Password changed successfully.' });
  }

  if (action === 'TOGGLE_WHATSAPP_CONSENT') {
    const granted = body.granted ? 1 : 0;
    const existing = db
      .prepare("SELECT id FROM consent_records WHERE user_id = ? AND consent_type = 'WHATSAPP_COMMUNICATION' LIMIT 1")
      .get(session.id) as { id: string } | undefined;

    if (existing) {
      db.prepare(
        `UPDATE consent_records SET granted = ?, revoked_at = CASE WHEN ? = 0 THEN datetime('now') ELSE NULL END WHERE id = ?`
      ).run(granted, granted, existing.id);
    } else {
      db.prepare(
        `INSERT INTO consent_records (id, user_id, consent_type, granted, ip_address) VALUES (?, ?, 'WHATSAPP_COMMUNICATION', ?, ?)`
      ).run(generateId('cns'), session.id, granted, ip);
    }
    logAudit({
      actorId: session.id,
      actorRole: session.role,
      actorName: session.fullName,
      action: granted ? 'CONSENT_GRANTED_WHATSAPP' : 'CONSENT_REVOKED_WHATSAPP',
      entityType: 'CONSENT',
      entityId: session.id,
      ipAddress: ip,
    });
    return NextResponse.json({ ok: true });
  }

  if (action === 'REQUEST_DELETION' && session.role === 'PATIENT') {
    db.prepare(
      "UPDATE patient_profiles SET deletion_requested_at = datetime('now'), updated_at = datetime('now') WHERE user_id = ?"
    ).run(session.id);
    logAudit({
      actorId: session.id,
      actorRole: session.role,
      actorName: session.fullName,
      action: 'DPDP_DELETION_REQUESTED',
      entityType: 'PATIENT_PROFILE',
      entityId: session.id,
      details: 'Patient submitted DPDP erasure request (subject to statutory medical record retention rules).',
      ipAddress: ip,
    });
    return NextResponse.json({
      ok: true,
      message:
        'Your DPDP data deletion request has been recorded and queued for compliance review (subject to statutory medical record retention guidelines).',
    });
  }

  // UPDATE_PROFILE
  if (body.fullName && String(body.fullName).trim().length >= 2) {
    db.prepare("UPDATE users SET full_name = ?, phone = ?, updated_at = datetime('now') WHERE id = ?").run(
      String(body.fullName).trim().slice(0, 120),
      String(body.phone || '').replace(/[\s-]/g, '').replace(/^\+91/, '').slice(0, 15) || null,
      session.id
    );
  }

  if (session.role === 'PATIENT') {
    db.prepare(`
      UPDATE patient_profiles SET
        date_of_birth = ?,
        gender = ?,
        blood_group = ?,
        city = ?,
        state = ?,
        address = ?,
        allergies = ?,
        chronic_conditions = ?,
        current_medications = ?,
        emergency_contact_name = ?,
        emergency_contact_phone = ?,
        is_minor_account = ?,
        guardian_name = ?,
        guardian_relation = ?,
        minor_patient_name = ?,
        minor_date_of_birth = ?,
        updated_at = datetime('now')
      WHERE user_id = ?
    `).run(
      body.dateOfBirth || null,
      body.gender || null,
      body.bloodGroup || null,
      body.city || null,
      body.state || null,
      body.address || null,
      body.allergies || null,
      body.chronicConditions || null,
      body.currentMedications || null,
      body.emergencyContactName || null,
      body.emergencyContactPhone || null,
      body.isMinorAccount ? 1 : 0,
      body.isMinorAccount ? body.guardianName || session.fullName : null,
      body.isMinorAccount ? body.guardianRelation || null : null,
      body.isMinorAccount ? body.minorPatientName || null : null,
      body.isMinorAccount ? body.minorDateOfBirth || null : null,
      session.id
    );

    logAudit({
      actorId: session.id,
      actorRole: session.role,
      actorName: session.fullName,
      action: 'PATIENT_PROFILE_UPDATED',
      entityType: 'PATIENT_PROFILE',
      entityId: session.id,
      ipAddress: ip,
    });
  }

  return NextResponse.json({ ok: true, message: 'Profile saved successfully.' });
}
