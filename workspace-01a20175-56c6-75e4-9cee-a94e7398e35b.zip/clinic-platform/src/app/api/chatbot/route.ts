import { NextRequest, NextResponse } from 'next/server';
import { checkRateLimit, getClientIp } from '@/lib/auth';
import { getDb } from '@/lib/db';
import { generateSafeChatbotReply } from '@/lib/services';

export async function POST(req: NextRequest) {
  const ip = getClientIp(req);
  const rl = checkRateLimit(`chat:${ip}`, 30, 5 * 60 * 1000);
  if (!rl.allowed) {
    return NextResponse.json({ error: 'Too many messages. Please wait a moment.' }, { status: 429 });
  }

  try {
    const db = getDb();
    const cfg = db
      .prepare('SELECT is_enabled FROM chatbot_settings WHERE id = ?')
      .get('default') as { is_enabled: number } | undefined;
    if (cfg && !cfg.is_enabled) {
      return NextResponse.json({
        reply:
          'Our automated assistant is temporarily offline. Please reach our clinic desk on WhatsApp/Phone at +91 8123108149 or email aparnabhms@gmail.com.',
        category: 'OFFLINE',
        safetyTriggered: null,
        suggestedActions: [{ label: 'Contact Clinic', href: '/contact' }],
      });
    }

    const body = await req.json();
    const message = String(body.message || '').trim();
    const sessionKey = String(body.sessionKey || ip).slice(0, 64);
    if (!message) {
      return NextResponse.json({ error: 'Please type a question.' }, { status: 400 });
    }

    const result = generateSafeChatbotReply(message, sessionKey);
    return NextResponse.json(result);
  } catch {
    return NextResponse.json({ error: 'Assistant temporarily unavailable.' }, { status: 500 });
  }
}
