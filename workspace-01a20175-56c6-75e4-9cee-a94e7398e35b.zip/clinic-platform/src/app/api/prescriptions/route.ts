import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { getDb, logAudit } from '@/lib/db';
import {
  generateId,
  generateRefCode,
  getClientIp,
  getRequestUser,
  signDigitalHash,
} from '@/lib/auth';
import { dispatchClinicNotification } from '@/lib/services';

const medicineSchema = z.object({
  name: z.string().trim().min(2, 'Medicine name is required').max(160),
  dosage: z.string().trim().min(1, 'Dosage is required').max(100),
  frequency: z.string().trim().min(1, 'Frequency is required').max(100),
  duration: z.string().trim().min(1, 'Duration is required').max(80),
  instructions: z.string().trim().max(300).optional().default(''),
});

const createRxSchema = z.object({
  patientId: z.string().min(3),
  appointmentId: z.string().optional().nullable(),
  clinicalImpression: z.string().trim().min(3, 'Clinical impression is required').max(500),
  symptomsSummary: z.string().trim().max(800).optional().default(''),
  medicines: z.array(medicineSchema).min(1, 'Add at least one medicine'),
  generalInstructions: z.string().trim().max(1200).optional().default(''),
  dietaryAdvice: z.string().trim().max(1200).optional().default(''),
  followupDate: z.string().optional().default(''),
  referralNote: z.string().trim().max(600).optional().default(''),
  publishNow: z.boolean().optional().default(true),
});

export async function GET(req: NextRequest) {
  const user = await getRequestUser(req);
  if (!user) return NextResponse.json({ error: 'Authentication required.' }, { status: 401 });

  const db = getDb();
  if (user.role === 'PATIENT') {
    // Patients may ONLY see their own AUTHORISED prescriptions
    const prescriptions = db
      .prepare(
        `SELECT r.*, d.display_name as doctor_name, d.qualification as doctor_qualification,
                a.reference_no as appointment_ref, a.appointment_date
         FROM prescriptions r
         JOIN doctor_profiles d ON d.user_id = r.doctor_id
         LEFT JOIN appointments a ON a.id = r.appointment_id
         WHERE r.patient_id = ? AND r.status = 'AUTHORISED'
         ORDER BY r.authorised_at DESC, r.created_at DESC`
      )
      .all(user.id);
    return NextResponse.json({ prescriptions });
  }

  if (user.role !== 'DOCTOR' && user.role !== 'ADMIN') {
    return NextResponse.json(
      { error: 'Clinical prescription records are restricted to the authorised physician.' },
      { status: 403 }
    );
  }

  const prescriptions = db
    .prepare(
      `SELECT r.*, u.full_name as patient_name, u.email as patient_email, u.phone as patient_phone,
              pp.patient_code, a.reference_no as appointment_ref
       FROM prescriptions r
       JOIN users u ON u.id = r.patient_id
       LEFT JOIN patient_profiles pp ON pp.user_id = r.patient_id
       LEFT JOIN appointments a ON a.id = r.appointment_id
       ORDER BY r.created_at DESC`
    )
    .all();

  return NextResponse.json({ prescriptions });
}

export async function POST(req: NextRequest) {
  const user = await getRequestUser(req);
  // STRICT RULE: Only the authorised DOCTOR can issue prescriptions
  if (!user || user.role !== 'DOCTOR') {
    return NextResponse.json(
      { error: 'Strictly forbidden: Only the authorised physician (Dr. Aparna Mishra) can issue prescriptions.' },
      { status: 403 }
    );
  }

  try {
    const body = await req.json();
    const parsed = createRxSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json(
        { error: parsed.error.issues[0]?.message || 'Invalid prescription details.' },
        { status: 400 }
      );
    }

    const d = parsed.data;
    const db = getDb();
    const ip = getClientIp(req);

    const patient = db
      .prepare("SELECT id, full_name, email, phone FROM users WHERE id = ? AND role = 'PATIENT'")
      .get(d.patientId) as { id: string; full_name: string; email: string; phone: string | null } | undefined;
    if (!patient) return NextResponse.json({ error: 'Patient not found.' }, { status: 404 });

    const id = generateId('rx');
    const rxNo = generateRefCode('RX');
    const nowIso = new Date().toISOString().replace('T', ' ').slice(0, 19);
    const status = d.publishNow ? 'AUTHORISED' : 'DRAFT';
    const sigHash = d.publishNow ? signDigitalHash(`${rxNo}|${patient.id}|${user.id}|${nowIso}`) : null;

    db.prepare(`
      INSERT INTO prescriptions (
        id, prescription_no, appointment_id, patient_id, doctor_id,
        clinical_impression, symptoms_summary, medicines_json, general_instructions,
        dietary_advice, followup_date, referral_note, status, authorised_at, digital_signature_hash
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      id,
      rxNo,
      d.appointmentId || null,
      patient.id,
      user.id,
      d.clinicalImpression,
      d.symptomsSummary || null,
      JSON.stringify(d.medicines),
      d.generalInstructions || null,
      d.dietaryAdvice || null,
      d.followupDate || null,
      d.referralNote ||
        'Seek prompt in-person medical evaluation or emergency hospital care if symptoms worsen or acute warning signs develop.',
      status,
      d.publishNow ? nowIso : null,
      sigHash
    );

    if (d.appointmentId && d.followupDate) {
      db.prepare('UPDATE appointments SET followup_date = ?, followup_notes = ? WHERE id = ?').run(
        d.followupDate,
        d.generalInstructions || 'Follow prescribed regimen and schedule timely review.',
        d.appointmentId
      );
    }

    if (d.publishNow) {
      // Privacy-safe notification: never includes diagnosis or medicine names in notification channel
      await dispatchClinicNotification({
        userId: patient.id,
        appointmentId: d.appointmentId || null,
        inAppTitle: `Authorised Prescription Ready (${rxNo})`,
        inAppMessage: `Dr. Aparna Mishra has digitally authorised your prescription (${rxNo}). View and download your secure PDF in My Prescriptions.`,
        recipientEmail: patient.email,
        emailSubject: `Prescription ${rxNo} Available in Patient Portal`,
      });
    }

    logAudit({
      actorId: user.id,
      actorRole: user.role,
      actorName: user.fullName,
      action: d.publishNow ? 'PRESCRIPTION_AUTHORISED' : 'PRESCRIPTION_DRAFT_SAVED',
      entityType: 'PRESCRIPTION',
      entityId: id,
      details: `${status} ${rxNo} for patient ${patient.full_name}`,
      ipAddress: ip,
    });

    return NextResponse.json({ ok: true, id, prescriptionNo: rxNo, status });
  } catch (err) {
    console.error('Prescription create error:', err);
    return NextResponse.json({ error: 'Unable to create prescription.' }, { status: 500 });
  }
}

export async function PATCH(req: NextRequest) {
  const user = await getRequestUser(req);
  if (!user || user.role !== 'DOCTOR') {
    return NextResponse.json({ error: 'Only the authorised doctor can authorise prescriptions.' }, { status: 403 });
  }

  const db = getDb();
  const body = await req.json();
  const rxId = String(body.prescriptionId || '');
  const rx = db
    .prepare(
      `SELECT r.*, u.email as patient_email, u.full_name as patient_name
       FROM prescriptions r JOIN users u ON u.id = r.patient_id WHERE r.id = ?`
    )
    .get(rxId) as
    | { id: string; prescription_no: string; patient_id: string; appointment_id: string | null; patient_email: string; patient_name: string }
    | undefined;
  if (!rx) return NextResponse.json({ error: 'Prescription not found.' }, { status: 404 });

  if (body.action === 'AUTHORISE') {
    const nowIso = new Date().toISOString().replace('T', ' ').slice(0, 19);
    const sig = signDigitalHash(`${rx.prescription_no}|${rx.patient_id}|${user.id}|${nowIso}`);
    db.prepare(
      "UPDATE prescriptions SET status = 'AUTHORISED', authorised_at = ?, digital_signature_hash = ? WHERE id = ?"
    ).run(nowIso, sig, rx.id);

    await dispatchClinicNotification({
      userId: rx.patient_id,
      appointmentId: rx.appointment_id,
      inAppTitle: `Authorised Prescription Published (${rx.prescription_no})`,
      inAppMessage: `Dr. Aparna Mishra has authorised prescription ${rx.prescription_no}. You can download the PDF in My Prescriptions.`,
      recipientEmail: rx.patient_email,
    });

    logAudit({
      actorId: user.id,
      actorRole: user.role,
      actorName: user.fullName,
      action: 'PRESCRIPTION_AUTHORISED',
      entityType: 'PRESCRIPTION',
      entityId: rx.id,
      details: `Published ${rx.prescription_no} to ${rx.patient_name}'s portal`,
      ipAddress: getClientIp(req),
    });
    return NextResponse.json({ ok: true });
  }

  return NextResponse.json({ error: 'Invalid action.' }, { status: 400 });
}
