import { NextRequest, NextResponse } from 'next/server';
import { getDb, getDoctorPublicProfile, logAudit } from '@/lib/db';
import { getClientIp, getRequestUser } from '@/lib/auth';
import { generatePrescriptionPdf, MedicineItem } from '@/lib/pdf';

export async function GET(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  const user = await getRequestUser(req);
  if (!user) return NextResponse.json({ error: 'Authentication required.' }, { status: 401 });

  const db = getDb();
  const rx = db
    .prepare(
      `SELECT r.*, u.full_name as patient_name, pp.patient_code, pp.gender, pp.date_of_birth,
              pp.is_minor_account, pp.minor_patient_name, a.reference_no as appointment_ref
       FROM prescriptions r
       JOIN users u ON u.id = r.patient_id
       LEFT JOIN patient_profiles pp ON pp.user_id = r.patient_id
       LEFT JOIN appointments a ON a.id = r.appointment_id
       WHERE r.id = ?`
    )
    .get(params.id) as
    | {
        id: string;
        prescription_no: string;
        patient_id: string;
        clinical_impression: string;
        symptoms_summary: string | null;
        medicines_json: string;
        general_instructions: string | null;
        dietary_advice: string | null;
        followup_date: string | null;
        referral_note: string | null;
        status: string;
        authorised_at: string | null;
        digital_signature_hash: string | null;
        created_at: string;
        patient_name: string;
        patient_code: string | null;
        gender: string | null;
        date_of_birth: string | null;
        is_minor_account: number | null;
        minor_patient_name: string | null;
        appointment_ref: string | null;
      }
    | undefined;

  if (!rx) return NextResponse.json({ error: 'Prescription not found.' }, { status: 404 });

  // Strict patient isolation & doctor RBAC
  if (user.role === 'PATIENT') {
    if (rx.patient_id !== user.id || rx.status !== 'AUTHORISED') {
      return NextResponse.json(
        { error: 'Forbidden — you may only download your own authorised prescriptions.' },
        { status: 403 }
      );
    }
  } else if (user.role !== 'DOCTOR' && user.role !== 'ADMIN') {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
  }

  const doc = getDoctorPublicProfile();
  let ageStr = '';
  if (rx.date_of_birth) {
    const birthYear = Number(rx.date_of_birth.slice(0, 4));
    if (birthYear > 1900) {
      ageStr = `${new Date().getFullYear() - birthYear} yrs`;
    }
  }
  const genderAge = [ageStr, rx.gender].filter(Boolean).join(' / ') || 'On File';
  const patientDisplay =
    rx.is_minor_account && rx.minor_patient_name
      ? `${rx.minor_patient_name} (Guardian: ${rx.patient_name})`
      : rx.patient_name;

  const medicines = JSON.parse(rx.medicines_json) as MedicineItem[];
  const pdf = await generatePrescriptionPdf({
    prescriptionNo: rx.prescription_no,
    authorisedAt: rx.authorised_at || rx.created_at,
    digitalSignatureHash: rx.digital_signature_hash || 'DRAFT-UNAUTHORISED',
    doctorName: doc.display_name,
    qualification: doc.qualification,
    specialisation: doc.specialisation,
    registrationNumber: doc.registration_number,
    clinicName: doc.clinic_name,
    phone: doc.phone,
    email: doc.email,
    timings: doc.timings_summary,
    patientName: patientDisplay,
    patientCode: rx.patient_code || 'PAT',
    patientGenderAge: genderAge,
    appointmentRef: rx.appointment_ref || undefined,
    clinicalImpression: rx.clinical_impression,
    symptomsSummary: rx.symptoms_summary || undefined,
    medicines,
    generalInstructions: rx.general_instructions || undefined,
    dietaryAdvice: rx.dietary_advice || undefined,
    followupDate: rx.followup_date || undefined,
    referralNote: rx.referral_note || undefined,
  });

  logAudit({
    actorId: user.id,
    actorRole: user.role,
    actorName: user.fullName,
    action: 'PRESCRIPTION_PDF_DOWNLOADED',
    entityType: 'PRESCRIPTION',
    entityId: rx.id,
    details: `Downloaded ${rx.prescription_no}`,
    ipAddress: getClientIp(req),
  });

  return new NextResponse(new Uint8Array(pdf), {
    headers: {
      'Content-Type': 'application/pdf',
      'Content-Disposition': `attachment; filename="${rx.prescription_no}.pdf"`,
      'Cache-Control': 'private, no-store',
    },
  });
}
