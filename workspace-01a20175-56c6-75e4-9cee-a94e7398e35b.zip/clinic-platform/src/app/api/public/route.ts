import { NextResponse } from 'next/server';
import { getDb, getDoctorPublicProfile } from '@/lib/db';

export const dynamic = 'force-dynamic';

export async function GET() {
  const db = getDb();
  const doctor = getDoctorPublicProfile();
  const services = db
    .prepare('SELECT * FROM medical_services WHERE is_active = 1 ORDER BY sort_order ASC')
    .all();
  const consultationTypes = db
    .prepare('SELECT * FROM consultation_types WHERE is_active = 1 ORDER BY sort_order ASC')
    .all();
  const availability = db
    .prepare('SELECT * FROM doctor_availability ORDER BY day_of_week ASC')
    .all();
  const announcements = db
    .prepare('SELECT * FROM announcements WHERE is_active = 1 ORDER BY created_at DESC')
    .all();
  const articles = db
    .prepare('SELECT * FROM blog_articles WHERE is_published = 1 ORDER BY published_at DESC')
    .all();
  const faqs = db
    .prepare('SELECT * FROM faqs WHERE is_active = 1 ORDER BY sort_order ASC')
    .all();
  const reviews = db
    .prepare('SELECT * FROM feedback_reviews WHERE is_approved = 1 ORDER BY created_at DESC LIMIT 8')
    .all();
  const chatbot = db
    .prepare('SELECT bot_name, welcome_message, escalation_note, is_enabled FROM chatbot_settings WHERE id = ?')
    .get('default');

  return NextResponse.json({
    doctor,
    services,
    consultationTypes,
    availability,
    announcements,
    articles,
    faqs,
    reviews,
    chatbot,
  });
}
