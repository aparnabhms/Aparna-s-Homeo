import { NextRequest, NextResponse } from 'next/server';
import { getDb, logAudit } from '@/lib/db';
import {
  checkRateLimit,
  generateId,
  generateRefCode,
  getClientIp,
  getRequestUser,
} from '@/lib/auth';

export async function GET(req: NextRequest) {
  const user = await getRequestUser(req);
  if (!user) return NextResponse.json({ error: 'Authentication required.' }, { status: 401 });

  const db = getDb();
  const tickets =
    user.role === 'PATIENT'
      ? db
          .prepare('SELECT * FROM support_tickets WHERE user_id = ? ORDER BY created_at DESC')
          .all(user.id)
      : db.prepare('SELECT * FROM support_tickets ORDER BY created_at DESC').all();

  return NextResponse.json({ tickets });
}

export async function POST(req: NextRequest) {
  const ip = getClientIp(req);
  const rl = checkRateLimit(`support:${ip}`, 10, 15 * 60 * 1000);
  if (!rl.allowed) {
    return NextResponse.json({ error: 'Too many submissions. Please try again later.' }, { status: 429 });
  }

  try {
    const user = await getRequestUser(req);
    const body = await req.json();
    const db = getDb();

    if (body.kind === 'FEEDBACK') {
      const rating = Math.min(5, Math.max(1, Number(body.rating || 5)));
      const comment = String(body.comment || '').trim().slice(0, 600);
      const initials = String(body.patientInitials || user?.fullName || 'Patient')
        .trim()
        .slice(0, 40);
      const city = String(body.city || '').trim().slice(0, 60);
      const concernArea = String(body.concernArea || 'Online Consultation').trim().slice(0, 60);

      if (comment.length < 8) {
        return NextResponse.json({ error: 'Please share at least a short feedback message.' }, { status: 400 });
      }

      const id = generateId('fb');
      db.prepare(`
        INSERT INTO feedback_reviews (id, user_id, patient_initials, city, rating, concern_area, comment, is_approved, is_demo)
        VALUES (?, ?, ?, ?, ?, ?, ?, 0, 0)
      `).run(id, user?.id || null, initials, city || null, rating, concernArea, comment);

      logAudit({
        actorId: user?.id,
        actorRole: user?.role || 'PUBLIC',
        actorName: initials,
        action: 'FEEDBACK_SUBMITTED',
        entityType: 'FEEDBACK',
        entityId: id,
        details: `Submitted ${rating}/5 patient feedback (pending clinic moderation).`,
        ipAddress: ip,
      });

      return NextResponse.json({
        ok: true,
        message: 'Thank you for your feedback! It has been submitted to the clinic team for review.',
      });
    }

    // Contact / Support Ticket
    const senderName = String(body.name || user?.fullName || '').trim().slice(0, 120);
    const senderEmail = String(body.email || user?.email || '').trim().slice(0, 160);
    const senderPhone = String(body.phone || user?.phone || '').trim().slice(0, 20);
    const subject = String(body.subject || 'Clinic Assistance Request').trim().slice(0, 160);
    const category = String(body.category || 'GENERAL').trim().slice(0, 40);
    const message = String(body.message || '').trim().slice(0, 1500);

    if (!senderName || !senderEmail.includes('@') || message.length < 5) {
      return NextResponse.json(
        { error: 'Please provide your name, valid email, and enquiry message.' },
        { status: 400 }
      );
    }

    const id = generateId('tkt');
    const ticketNo = generateRefCode('SUP');
    db.prepare(`
      INSERT INTO support_tickets (id, ticket_no, user_id, sender_name, sender_email, sender_phone, subject, category, message, status)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'OPEN')
    `).run(id, ticketNo, user?.id || null, senderName, senderEmail, senderPhone || null, subject, category, message);

    // Notify Doctor in admin dashboard
    const doc = db.prepare("SELECT id FROM users WHERE role = 'DOCTOR' LIMIT 1").get() as { id: string } | undefined;
    if (doc) {
      db.prepare(`
        INSERT INTO notifications (id, user_id, channel, title, message, delivery_status)
        VALUES (?, ?, 'IN_APP', ?, ?, 'DELIVERED')
      `).run(
        generateId('ntf'),
        doc.id,
        `New Support Enquiry (${ticketNo})`,
        `${senderName}: ${subject}`
      );
    }

    return NextResponse.json({
      ok: true,
      ticketNo,
      message: `Your message has been logged under Reference ${ticketNo}. Our clinic desk responds during consultation hours (Mon–Sat, 3:00 PM – 8:00 PM).`,
    });
  } catch (err) {
    console.error('Support error:', err);
    return NextResponse.json({ error: 'Unable to submit request.' }, { status: 500 });
  }
}
