import { NextRequest, NextResponse } from 'next/server';
import { getDb, logAudit } from '@/lib/db';
import { getClientIp, getRequestUser } from '@/lib/auth';

export async function GET(req: NextRequest) {
  const user = await getRequestUser(req);
  if (!user || (user.role !== 'DOCTOR' && user.role !== 'ADMIN')) {
    return NextResponse.json(
      { error: 'Only the authorised physician/administrator can export clinic backups.' },
      { status: 403 }
    );
  }

  const db = getDb();
  const format = req.nextUrl.searchParams.get('format') || 'json';
  const ip = getClientIp(req);

  if (format === 'csv') {
    const rows = db
      .prepare(
        `SELECT a.reference_no, a.appointment_date, a.start_time, a.patient_display_name,
                a.concern_category, ct.name as consultation_type, a.status, a.fee_inr, a.payment_status
         FROM appointments a
         JOIN consultation_types ct ON ct.id = a.consultation_type_id
         ORDER BY a.appointment_date DESC`
      )
      .all() as Array<Record<string, unknown>>;

    const header =
      'ReferenceNo,Date,Time,Patient,Concern,ConsultationType,Status,FeeINR,PaymentStatus';
    const csvLines = rows.map((r) =>
      [
        r.reference_no,
        r.appointment_date,
        r.start_time,
        `"${String(r.patient_display_name || '').replace(/"/g, '""')}"`,
        `"${String(r.concern_category || '')}"`,
        `"${String(r.consultation_type || '')}"`,
        r.status,
        r.fee_inr,
        r.payment_status,
      ].join(',')
    );

    logAudit({
      actorId: user.id,
      actorRole: user.role,
      actorName: user.fullName,
      action: 'ANALYTICS_CSV_EXPORTED',
      entityType: 'REPORT',
      ipAddress: ip,
    });

    return new NextResponse([header, ...csvLines].join('\n'), {
      headers: {
        'Content-Type': 'text/csv; charset=utf-8',
        'Content-Disposition': `attachment; filename="clinic-appointments-${new Date().toISOString().slice(0, 10)}.csv"`,
        'Cache-Control': 'private, no-store',
      },
    });
  }

  // Full structured recovery backup (excludes raw password hashes & OTP hashes)
  const snapshot = {
    backupVersion: '1.0',
    generatedAt: new Date().toISOString(),
    generatedBy: user.email,
    clinic: db.prepare('SELECT * FROM doctor_profiles').all(),
    availability: db.prepare('SELECT * FROM doctor_availability').all(),
    blockedDates: db.prepare('SELECT * FROM blocked_dates').all(),
    consultationTypes: db.prepare('SELECT * FROM consultation_types').all(),
    users: db
      .prepare('SELECT id, email, phone, full_name, role, auth_provider, is_active, is_demo, created_at FROM users')
      .all(),
    patientProfiles: db.prepare('SELECT * FROM patient_profiles').all(),
    appointments: db.prepare('SELECT * FROM appointments').all(),
    prescriptions: db.prepare('SELECT * FROM prescriptions').all(),
    payments: db.prepare('SELECT * FROM payments').all(),
    consentRecords: db.prepare('SELECT * FROM consent_records').all(),
    auditLogs: db.prepare('SELECT * FROM audit_logs ORDER BY created_at DESC LIMIT 500').all(),
  };

  logAudit({
    actorId: user.id,
    actorRole: user.role,
    actorName: user.fullName,
    action: 'CLINIC_BACKUP_DOWNLOADED',
    entityType: 'BACKUP',
    details: 'Downloaded clinic recovery backup archive.',
    ipAddress: ip,
  });

  return new NextResponse(JSON.stringify(snapshot, null, 2), {
    headers: {
      'Content-Type': 'application/json',
      'Content-Disposition': `attachment; filename="aparna-clinic-backup-${new Date().toISOString().slice(0, 10)}.json"`,
      'Cache-Control': 'private, no-store',
    },
  });
}
