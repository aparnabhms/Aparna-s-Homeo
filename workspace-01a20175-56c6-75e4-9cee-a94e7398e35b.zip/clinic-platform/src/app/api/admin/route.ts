import { NextRequest, NextResponse } from 'next/server';
import { getDb, getDoctorPublicProfile, logAudit } from '@/lib/db';
import {
  generateId,
  generateRefCode,
  getClientIp,
  getRequestUser,
  hashPassword,
} from '@/lib/auth';
import { dispatchClinicNotification, getIntegrationStatuses } from '@/lib/services';

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
  const user = await getRequestUser(req);
  if (!user || !['DOCTOR', 'ADMIN', 'STAFF'].includes(user.role)) {
    return NextResponse.json({ error: 'Clinic administration authorisation required.' }, { status: 403 });
  }

  const db = getDb();
  const isDoctorOrAdmin = user.role === 'DOCTOR' || user.role === 'ADMIN';
  const today = new Date().toISOString().slice(0, 10);

  // KPI summary
  const todayAppts = (
    db
      .prepare("SELECT COUNT(*) as c FROM appointments WHERE appointment_date = ? AND status NOT IN ('CANCELLED','REJECTED')")
      .get(today) as { c: number }
  ).c;
  const pendingAppts = (
    db.prepare("SELECT COUNT(*) as c FROM appointments WHERE status = 'PENDING'").get() as { c: number }
  ).c;
  const completedAppts = (
    db.prepare("SELECT COUNT(*) as c FROM appointments WHERE status = 'COMPLETED'").get() as { c: number }
  ).c;
  const upcomingAppts = (
    db
      .prepare("SELECT COUNT(*) as c FROM appointments WHERE appointment_date >= ? AND status IN ('CONFIRMED','PENDING','RESCHEDULED')")
      .get(today) as { c: number }
  ).c;
  const totalPatients = (
    db.prepare("SELECT COUNT(*) as c FROM users WHERE role = 'PATIENT'").get() as { c: number }
  ).c;
  const totalRevenue = (
    db.prepare("SELECT COALESCE(SUM(amount_inr), 0) as s FROM payments WHERE status = 'PAID'").get() as { s: number }
  ).s;
  const pendingPayments = (
    db
      .prepare("SELECT COALESCE(SUM(amount_inr), 0) as s FROM payments WHERE status = 'PENDING_VERIFICATION'")
      .get() as { s: number }
  ).s;
  const pendingReports = (
    db.prepare("SELECT COUNT(*) as c FROM medical_reports WHERE review_status = 'PENDING_REVIEW'").get() as { c: number }
  ).c;

  // Analytics breakdowns
  const byConcern = db
    .prepare(
      'SELECT concern_category as label, COUNT(*) as count, COALESCE(SUM(fee_inr),0) as revenue FROM appointments GROUP BY concern_category ORDER BY count DESC'
    )
    .all();
  const byStatus = db
    .prepare('SELECT status as label, COUNT(*) as count FROM appointments GROUP BY status')
    .all();
  const byPaymentMethod = db
    .prepare(
      "SELECT payment_method as label, COUNT(*) as count, COALESCE(SUM(amount_inr),0) as total FROM payments WHERE status IN ('PAID','PENDING_VERIFICATION') GROUP BY payment_method ORDER BY total DESC"
    )
    .all();
  const byDate = db
    .prepare(
      'SELECT appointment_date as date, COUNT(*) as count, COALESCE(SUM(fee_inr),0) as revenue FROM appointments GROUP BY appointment_date ORDER BY appointment_date ASC LIMIT 14'
    )
    .all();

  // Patients registry
  const patients = db
    .prepare(
      `SELECT u.id, u.full_name, u.email, u.phone, u.auth_provider, u.is_active, u.is_demo, u.created_at,
              pp.patient_code, pp.date_of_birth, pp.gender, pp.blood_group, pp.city, pp.state,
              ${isDoctorOrAdmin ? 'pp.allergies, pp.chronic_conditions, pp.current_medications,' : ''}
              pp.is_minor_account, pp.guardian_name, pp.guardian_relation, pp.minor_patient_name, pp.minor_date_of_birth,
              pp.deletion_requested_at,
              (SELECT COUNT(*) FROM appointments a WHERE a.patient_id = u.id) as appointment_count,
              (SELECT COUNT(*) FROM prescriptions r WHERE r.patient_id = u.id AND r.status = 'AUTHORISED') as rx_count
       FROM users u
       LEFT JOIN patient_profiles pp ON pp.user_id = u.id
       WHERE u.role = 'PATIENT'
       ORDER BY u.created_at DESC`
    )
    .all();

  const availability = db.prepare('SELECT * FROM doctor_availability ORDER BY day_of_week ASC').all();
  const blockedDates = db.prepare('SELECT * FROM blocked_dates ORDER BY blocked_date ASC').all();
  const consultationTypes = db.prepare('SELECT * FROM consultation_types ORDER BY sort_order ASC').all();
  const services = db.prepare('SELECT * FROM medical_services ORDER BY sort_order ASC').all();
  const doctorProfile = getDoctorPublicProfile();

  const whatsappTemplates = db.prepare('SELECT * FROM whatsapp_templates ORDER BY template_name ASC').all();
  const whatsappLogs = db
    .prepare(
      `SELECT n.*, u.full_name as recipient_name
       FROM notifications n JOIN users u ON u.id = n.user_id
       WHERE n.channel IN ('WHATSAPP', 'EMAIL')
       ORDER BY n.created_at DESC LIMIT 50`
    )
    .all();

  const recentNotifications = db
    .prepare('SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 20')
    .all(user.id);

  const supportTickets = db.prepare('SELECT * FROM support_tickets ORDER BY created_at DESC').all();

  const chatbotSettings = db.prepare('SELECT * FROM chatbot_settings WHERE id = ?').get('default');
  const chatbotLogs = db
    .prepare('SELECT * FROM chatbot_logs ORDER BY created_at DESC LIMIT 40')
    .all();

  const articles = db.prepare('SELECT * FROM blog_articles ORDER BY published_at DESC').all();
  const faqs = db.prepare('SELECT * FROM faqs ORDER BY sort_order ASC').all();
  const announcements = db.prepare('SELECT * FROM announcements ORDER BY created_at DESC').all();
  const reviews = db.prepare('SELECT * FROM feedback_reviews ORDER BY created_at DESC').all();

  const staffList = isDoctorOrAdmin
    ? db
        .prepare(
          `SELECT s.*, u.full_name, u.email, u.phone, u.role, u.is_active, u.is_demo, u.last_login_at
           FROM staff s JOIN users u ON u.id = s.user_id ORDER BY s.created_at DESC`
        )
        .all()
    : [];

  const auditLogs = isDoctorOrAdmin
    ? db.prepare('SELECT * FROM audit_logs ORDER BY created_at DESC LIMIT 80').all()
    : [];

  const consents = isDoctorOrAdmin
    ? db
        .prepare(
          `SELECT c.*, u.full_name as user_name, u.email as user_email
           FROM consent_records c JOIN users u ON u.id = c.user_id
           ORDER BY c.granted_at DESC LIMIT 60`
        )
        .all()
    : [];

  return NextResponse.json({
    role: user.role,
    today,
    kpis: {
      todayAppts,
      pendingAppts,
      completedAppts,
      upcomingAppts,
      totalPatients,
      totalRevenue,
      pendingPayments,
      pendingReports,
    },
    analytics: { byConcern, byStatus, byPaymentMethod, byDate },
    patients,
    availability,
    blockedDates,
    consultationTypes,
    services,
    doctorProfile,
    whatsappTemplates,
    whatsappLogs,
    recentNotifications,
    supportTickets,
    chatbotSettings,
    chatbotLogs,
    cms: { articles, faqs, announcements, reviews },
    staffList,
    auditLogs,
    consents,
    integrations: isDoctorOrAdmin ? getIntegrationStatuses() : [],
  });
}

export async function POST(req: NextRequest) {
  const user = await getRequestUser(req);
  if (!user || !['DOCTOR', 'ADMIN', 'STAFF'].includes(user.role)) {
    return NextResponse.json({ error: 'Clinic authorisation required.' }, { status: 403 });
  }

  const isDoctorOrAdmin = user.role === 'DOCTOR' || user.role === 'ADMIN';
  const db = getDb();
  const ip = getClientIp(req);
  const body = await req.json();
  const action = String(body.action || '');

  // 1. Update Weekly Doctor Availability (Doctor/Admin)
  if (action === 'UPDATE_AVAILABILITY') {
    if (!isDoctorOrAdmin) return NextResponse.json({ error: 'Doctor authorisation required.' }, { status: 403 });
    const schedule = Array.isArray(body.schedule) ? body.schedule : [];
    const stmt = db.prepare(`
      UPDATE doctor_availability
      SET is_enabled = ?, start_time = ?, end_time = ?, slot_interval_minutes = ?, buffer_minutes = ?
      WHERE day_of_week = ?
    `);
    const tx = db.transaction(() => {
      for (const row of schedule) {
        stmt.run(
          row.is_enabled ? 1 : 0,
          String(row.start_time || '15:00'),
          String(row.end_time || '20:00'),
          Math.max(15, Math.min(60, Number(row.slot_interval_minutes || 30))),
          Math.max(0, Math.min(30, Number(row.buffer_minutes || 0))),
          Number(row.day_of_week)
        );
      }
    });
    tx();
    logAudit({
      actorId: user.id,
      actorRole: user.role,
      actorName: user.fullName,
      action: 'AVAILABILITY_UPDATED',
      entityType: 'AVAILABILITY',
      ipAddress: ip,
    });
    return NextResponse.json({ ok: true, message: 'Consultation hours & slot settings updated.' });
  }

  // 2. Block / Unblock Date
  if (action === 'ADD_BLOCKED_DATE') {
    if (!isDoctorOrAdmin) return NextResponse.json({ error: 'Doctor authorisation required.' }, { status: 403 });
    const d = String(body.blockedDate || '');
    if (!/^\d{4}-\d{2}-\d{2}$/.test(d)) {
      return NextResponse.json({ error: 'Select a valid date to block.' }, { status: 400 });
    }
    db.prepare(
      'INSERT OR REPLACE INTO blocked_dates (id, blocked_date, reason, created_by) VALUES (?, ?, ?, ?)'
    ).run(generateId('blk'), d, String(body.reason || 'Doctor unavailable').slice(0, 200), user.id);
    logAudit({
      actorId: user.id,
      actorRole: user.role,
      actorName: user.fullName,
      action: 'DATE_BLOCKED',
      entityType: 'BLOCKED_DATE',
      details: `Blocked ${d}`,
      ipAddress: ip,
    });
    return NextResponse.json({ ok: true });
  }

  if (action === 'REMOVE_BLOCKED_DATE') {
    if (!isDoctorOrAdmin) return NextResponse.json({ error: 'Doctor authorisation required.' }, { status: 403 });
    db.prepare('DELETE FROM blocked_dates WHERE id = ?').run(String(body.id || ''));
    return NextResponse.json({ ok: true });
  }

  // 3. Update Consultation Type Fee & Duration
  if (action === 'UPDATE_CONSULTATION_TYPE') {
    if (!isDoctorOrAdmin) return NextResponse.json({ error: 'Doctor authorisation required.' }, { status: 403 });
    db.prepare(`
      UPDATE consultation_types SET name = ?, duration_minutes = ?, fee_inr = ?, is_active = ? WHERE id = ?
    `).run(
      String(body.name || '').trim().slice(0, 120),
      Math.max(10, Math.min(90, Number(body.duration_minutes || 30))),
      Math.max(0, Number(body.fee_inr || 500)),
      body.is_active ? 1 : 0,
      String(body.id || '')
    );
    logAudit({
      actorId: user.id,
      actorRole: user.role,
      actorName: user.fullName,
      action: 'CONSULTATION_FEE_UPDATED',
      entityType: 'CONSULTATION_TYPE',
      entityId: String(body.id || ''),
      ipAddress: ip,
    });
    return NextResponse.json({ ok: true, message: 'Consultation service updated.' });
  }

  // 4. Update Doctor Profile & Website CMS Details
  if (action === 'UPDATE_DOCTOR_PROFILE') {
    if (!isDoctorOrAdmin) return NextResponse.json({ error: 'Doctor authorisation required.' }, { status: 403 });
    db.prepare(`
      UPDATE doctor_profiles SET
        display_name = ?,
        qualification = ?,
        specialisation = ?,
        experience_years = ?,
        registration_number = ?,
        registration_council = ?,
        tagline = ?,
        bio = ?,
        approach_note = ?,
        timings_summary = ?,
        clinic_name = ?,
        clinic_address = ?,
        phone = ?,
        email = ?,
        upi_id = ?,
        upi_payee_name = ?,
        updated_at = datetime('now')
      WHERE id = 'doc_prof_aparna'
    `).run(
      String(body.display_name || 'Dr. Aparna Mishra').slice(0, 140),
      String(body.qualification || 'BHMS').slice(0, 160),
      String(body.specialisation || 'Homoeopathic Physician').slice(0, 200),
      Math.max(1, Number(body.experience_years || 7)),
      String(body.registration_number || '').slice(0, 120),
      String(body.registration_council || '').slice(0, 180),
      String(body.tagline || 'Compassionate Care, Individualized Healing.').slice(0, 220),
      String(body.bio || '').slice(0, 2000),
      String(body.approach_note || '').slice(0, 1500),
      String(body.timings_summary || 'Monday to Saturday · 3:00 PM – 8:00 PM IST').slice(0, 160),
      String(body.clinic_name || '').slice(0, 180),
      String(body.clinic_address || '').slice(0, 300),
      String(body.phone || '+91 8123108149').slice(0, 30),
      String(body.email || 'aparnabhms@gmail.com').slice(0, 160),
      String(body.upi_id || 'a72549567212@axl').slice(0, 100),
      String(body.upi_payee_name || 'APARNA MISHRA').slice(0, 120)
    );
    logAudit({
      actorId: user.id,
      actorRole: user.role,
      actorName: user.fullName,
      action: 'DOCTOR_PROFILE_UPDATED',
      entityType: 'CMS',
      ipAddress: ip,
    });
    return NextResponse.json({ ok: true, message: 'Doctor profile & clinic details published live.' });
  }

  // 5. CMS: Announcement / Blog Article / FAQ / Feedback Moderation
  if (action === 'SAVE_ANNOUNCEMENT') {
    if (!isDoctorOrAdmin) return NextResponse.json({ error: 'Doctor authorisation required.' }, { status: 403 });
    if (body.id) {
      db.prepare('UPDATE announcements SET title = ?, message = ?, is_active = ? WHERE id = ?').run(
        String(body.title || '').slice(0, 100),
        String(body.message || '').slice(0, 350),
        body.is_active ? 1 : 0,
        String(body.id)
      );
    } else {
      db.prepare('INSERT INTO announcements (id, title, message, is_active) VALUES (?, ?, ?, 1)').run(
        generateId('ann'),
        String(body.title || 'Clinic Notice').slice(0, 100),
        String(body.message || '').slice(0, 350)
      );
    }
    return NextResponse.json({ ok: true });
  }

  if (action === 'ADD_ARTICLE') {
    if (!isDoctorOrAdmin) return NextResponse.json({ error: 'Doctor authorisation required.' }, { status: 403 });
    const title = String(body.title || '').trim().slice(0, 180);
    const content = String(body.content || '').trim();
    if (!title || content.length < 20) {
      return NextResponse.json({ error: 'Article title and content are required.' }, { status: 400 });
    }
    const slug =
      title
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, '-')
        .replace(/^-|-$/g, '')
        .slice(0, 60) +
      '-' +
      Date.now().toString(36).slice(-4);
    db.prepare(`
      INSERT INTO blog_articles (id, slug, title, category, excerpt, content, read_time_minutes, reviewed_by, is_published)
      VALUES (?, ?, ?, ?, ?, ?, ?, 'Dr. Aparna Mishra, BHMS', 1)
    `).run(
      generateId('blg'),
      slug,
      title,
      String(body.category || 'General Wellness').slice(0, 60),
      String(body.excerpt || content.slice(0, 160)).slice(0, 260),
      content,
      Math.max(2, Math.ceil(content.split(/\s+/).length / 180))
    );
    return NextResponse.json({ ok: true, slug });
  }

  if (action === 'TOGGLE_ARTICLE') {
    if (!isDoctorOrAdmin) return NextResponse.json({ error: 'Doctor authorisation required.' }, { status: 403 });
    db.prepare('UPDATE blog_articles SET is_published = CASE WHEN is_published = 1 THEN 0 ELSE 1 END WHERE id = ?').run(
      String(body.id || '')
    );
    return NextResponse.json({ ok: true });
  }

  if (action === 'ADD_FAQ') {
    if (!isDoctorOrAdmin) return NextResponse.json({ error: 'Doctor authorisation required.' }, { status: 403 });
    const q = String(body.question || '').trim();
    const a = String(body.answer || '').trim();
    if (!q || !a) return NextResponse.json({ error: 'Question and answer are required.' }, { status: 400 });
    db.prepare('INSERT INTO faqs (id, category, question, answer, sort_order, is_active) VALUES (?, ?, ?, ?, 99, 1)').run(
      generateId('faq'),
      String(body.category || 'General').slice(0, 60),
      q.slice(0, 260),
      a.slice(0, 1000)
    );
    return NextResponse.json({ ok: true });
  }

  if (action === 'DELETE_FAQ') {
    if (!isDoctorOrAdmin) return NextResponse.json({ error: 'Doctor authorisation required.' }, { status: 403 });
    db.prepare('DELETE FROM faqs WHERE id = ?').run(String(body.id || ''));
    return NextResponse.json({ ok: true });
  }

  if (action === 'TOGGLE_FEEDBACK') {
    if (!isDoctorOrAdmin) return NextResponse.json({ error: 'Doctor authorisation required.' }, { status: 403 });
    db.prepare('UPDATE feedback_reviews SET is_approved = CASE WHEN is_approved = 1 THEN 0 ELSE 1 END WHERE id = ?').run(
      String(body.id || '')
    );
    return NextResponse.json({ ok: true });
  }

  // 6. Send Privacy-Safe WhatsApp Template Notification
  if (action === 'SEND_WHATSAPP') {
    const patientId = String(body.patientId || '');
    const templateName = String(body.templateName || 'appointment_reminder_24h');
    const pat = db
      .prepare('SELECT id, full_name, phone, email FROM users WHERE id = ?')
      .get(patientId) as { id: string; full_name: string; phone: string | null; email: string } | undefined;
    if (!pat) return NextResponse.json({ error: 'Patient not found.' }, { status: 404 });

    const paramList = Array.isArray(body.params) && body.params.length > 0
      ? body.params.map(String)
      : [pat.full_name, 'PORTAL-UPDATE', new Date().toISOString().slice(0, 10), '3:00 PM – 8:00 PM'];

    await dispatchClinicNotification({
      userId: pat.id,
      inAppTitle: 'Clinic Notification from Dr. Aparna Mishra Desk',
      inAppMessage: `A ${templateName.replace(/_/g, ' ')} notification was sent to your registered contact. Please review details inside your Patient Portal.`,
      whatsappTemplate: templateName,
      whatsappParams: paramList,
      recipientPhone: pat.phone || '9000000000',
    });

    logAudit({
      actorId: user.id,
      actorRole: user.role,
      actorName: user.fullName,
      action: 'WHATSAPP_TEMPLATE_SENT',
      entityType: 'NOTIFICATION',
      entityId: pat.id,
      details: `Dispatched ${templateName} to ${pat.full_name}`,
      ipAddress: ip,
    });
    return NextResponse.json({ ok: true, message: 'Approved WhatsApp template queued/dispatched safely.' });
  }

  // 7. AI Chatbot Configuration
  if (action === 'UPDATE_CHATBOT') {
    if (!isDoctorOrAdmin) return NextResponse.json({ error: 'Doctor authorisation required.' }, { status: 403 });
    db.prepare(`
      UPDATE chatbot_settings
      SET bot_name = ?, welcome_message = ?, escalation_note = ?, custom_kb_json = ?, is_enabled = ?, updated_at = datetime('now')
      WHERE id = 'default'
    `).run(
      String(body.bot_name || 'Clinic Care Assistant').slice(0, 80),
      String(body.welcome_message || '').slice(0, 500),
      String(body.escalation_note || '').slice(0, 400),
      typeof body.custom_kb_json === 'string' ? body.custom_kb_json : JSON.stringify(body.custom_kb || []),
      body.is_enabled ? 1 : 0
    );
    logAudit({
      actorId: user.id,
      actorRole: user.role,
      actorName: user.fullName,
      action: 'CHATBOT_SETTINGS_UPDATED',
      entityType: 'CHATBOT',
      ipAddress: ip,
    });
    return NextResponse.json({ ok: true, message: 'AI Assistant configuration saved (medical safety guardrails remain locked ON).' });
  }

  // 8. Reply to Support Ticket
  if (action === 'REPLY_TICKET') {
    const tktId = String(body.ticketId || '');
    const reply = String(body.reply || '').trim().slice(0, 1200);
    if (!reply) return NextResponse.json({ error: 'Reply text is required.' }, { status: 400 });

    const tkt = db.prepare('SELECT * FROM support_tickets WHERE id = ?').get(tktId) as
      | { id: string; ticket_no: string; user_id: string | null; sender_email: string }
      | undefined;
    if (!tkt) return NextResponse.json({ error: 'Ticket not found.' }, { status: 404 });

    db.prepare(`
      UPDATE support_tickets SET status = 'RESOLVED', staff_reply = ?, replied_by = ?, replied_at = datetime('now')
      WHERE id = ?
    `).run(reply, user.fullName, tkt.id);

    if (tkt.user_id) {
      await dispatchClinicNotification({
        userId: tkt.user_id,
        inAppTitle: `Support Reply (${tkt.ticket_no})`,
        inAppMessage: reply,
        recipientEmail: tkt.sender_email,
      });
    }
    return NextResponse.json({ ok: true });
  }

  // 9. Staff Management (Strictly Doctor / Admin only)
  if (action === 'ADD_STAFF') {
    if (!isDoctorOrAdmin) return NextResponse.json({ error: 'Only Dr. Aparna Mishra can add clinic staff.' }, { status: 403 });
    const fullName = String(body.fullName || '').trim();
    const email = String(body.email || '').trim().toLowerCase();
    const phone = String(body.phone || '').replace(/[\s-]/g, '').slice(0, 15);
    const designation = String(body.designation || 'Clinic Coordinator').trim();
    const password = String(body.password || '');

    if (!fullName || !email.includes('@') || password.length < 8) {
      return NextResponse.json({ error: 'Name, valid email, and password (8+ chars) are required.' }, { status: 400 });
    }
    const exists = db.prepare('SELECT id FROM users WHERE lower(email) = ?').get(email);
    if (exists) return NextResponse.json({ error: 'A user with this email already exists.' }, { status: 409 });

    const uid = generateId('usr');
    const stfCode = generateRefCode('STF').slice(0, 16);
    const pwHash = await hashPassword(password);
    const perms = Array.isArray(body.permissions)
      ? body.permissions
      : ['appointments:manage', 'patients:read', 'payments:verify', 'whatsapp:send', 'support:manage'];

    db.transaction(() => {
      db.prepare(`
        INSERT INTO users (id, email, phone, password_hash, full_name, role, auth_provider, email_verified, is_active, is_demo)
        VALUES (?, ?, ?, ?, ?, 'STAFF', 'EMAIL', 1, 1, 0)
      `).run(uid, email, phone || null, pwHash, fullName);
      db.prepare(`
        INSERT INTO staff (id, user_id, staff_code, designation, department, permissions_json, joined_at)
        VALUES (?, ?, ?, ?, 'Online Clinic Desk', ?, date('now'))
      `).run(generateId('stf'), uid, stfCode, designation, JSON.stringify(perms));
    })();

    logAudit({
      actorId: user.id,
      actorRole: user.role,
      actorName: user.fullName,
      action: 'STAFF_CREATED',
      entityType: 'STAFF',
      entityId: uid,
      details: `Added staff member ${fullName} (${designation})`,
      ipAddress: ip,
    });
    return NextResponse.json({ ok: true, staffCode: stfCode });
  }

  if (action === 'TOGGLE_STAFF_ACTIVE') {
    if (!isDoctorOrAdmin) return NextResponse.json({ error: 'Doctor authorisation required.' }, { status: 403 });
    const targetUserId = String(body.userId || '');
    db.prepare("UPDATE users SET is_active = CASE WHEN is_active = 1 THEN 0 ELSE 1 END WHERE id = ? AND role = 'STAFF'").run(
      targetUserId
    );
    logAudit({
      actorId: user.id,
      actorRole: user.role,
      actorName: user.fullName,
      action: 'STAFF_STATUS_TOGGLED',
      entityType: 'STAFF',
      entityId: targetUserId,
      ipAddress: ip,
    });
    return NextResponse.json({ ok: true });
  }

  return NextResponse.json({ error: 'Unknown admin action.' }, { status: 400 });
}
