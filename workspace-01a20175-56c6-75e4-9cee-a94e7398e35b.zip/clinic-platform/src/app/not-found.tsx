import Link from 'next/link';
import { ArrowLeft, Calendar, HelpCircle, Phone } from 'lucide-react';
import { BrandMark } from '@/components/MedicalIcons';

export default function NotFound() {
  return (
    <main className="min-h-screen bg-surface-muted flex items-center justify-center px-4 py-16">
      <div className="max-w-lg w-full card-surface p-8 sm:p-10 text-center">
        <div className="mx-auto mb-5 flex h-14 w-14 items-center justify-center rounded-2xl bg-aqua text-teal">
          <BrandMark className="h-8 w-8" />
        </div>
        <p className="text-xs font-semibold uppercase tracking-widest text-teal mb-2">
          Error 404 · Page Not Found
        </p>
        <h1 className="text-2xl sm:text-3xl font-bold text-navy mb-3">
          We couldn’t locate that clinic page
        </h1>
        <p className="text-sm text-slate-600 mb-8 leading-relaxed">
          The link you followed may have moved or expired. You can return to Dr. Aparna Mishra’s homepage, book an online consultation (Mon–Sat, 3:00 PM – 8:00 PM), or reach clinic support.
        </p>
        <div className="flex flex-col sm:flex-row gap-3 justify-center">
          <Link href="/" className="btn-navy">
            <ArrowLeft className="h-4 w-4" />
            Return Home
          </Link>
          <Link href="/book" className="btn-primary">
            <Calendar className="h-4 w-4" />
            Book Consultation
          </Link>
        </div>
        <div className="mt-7 pt-6 border-t border-slate-100 flex flex-wrap items-center justify-center gap-5 text-xs text-slate-500">
          <Link href="/faq" className="inline-flex items-center gap-1.5 hover:text-teal">
            <HelpCircle className="h-3.5 w-3.5" /> Patient FAQs
          </Link>
          <a href="tel:+918123108149" className="inline-flex items-center gap-1.5 hover:text-teal">
            <Phone className="h-3.5 w-3.5" /> +91 8123108149
          </a>
        </div>
      </div>
    </main>
  );
}
