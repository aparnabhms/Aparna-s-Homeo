import type { Metadata } from 'next';
import { Inter, Manrope } from 'next/font/google';
import AuthBridge from '@/components/AuthBridge';
import './globals.css';

const inter = Inter({
  subsets: ['latin'],
  variable: '--font-inter',
  display: 'swap',
});

const manrope = Manrope({
  subsets: ['latin'],
  variable: '--font-manrope',
  display: 'swap',
});

export const metadata: Metadata = {
  title: 'Dr. Aparna Mishra, BHMS | Online Homoeopathic & General Wellness Clinic',
  description:
    'Compassionate Care, Individualized Healing. Book online consultations with Dr. Aparna Mishra (BHMS, 7 years experience) — Mon–Sat, 3:00 PM to 8:00 PM IST. Women’s Health, Thyroid, Skin & Hair, Digestive, Joint & Respiratory Care.',
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className={`${inter.variable} ${manrope.variable}`}>
      <body className="min-h-screen flex flex-col bg-white text-slate-700">
        <AuthBridge />
        {children}
      </body>
    </html>
  );
}
