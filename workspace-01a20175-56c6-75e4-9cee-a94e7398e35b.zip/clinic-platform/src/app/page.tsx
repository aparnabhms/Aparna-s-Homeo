import React from 'react';
import Link from 'next/link';
import {
  ArrowRight,
  Award,
  Calendar,
  CheckCircle2,
  Clock,
  CreditCard,
  FileText,
  Mail,
  MapPin,
  Phone,
  ShieldCheck,
  Star,
  Stethoscope,
  Video,
} from 'lucide-react';
import PublicShell from '@/components/PublicShell';
import { ServiceIllustration } from '@/components/MedicalIcons';
import FaqAccordion, { FaqItem } from '@/components/FaqAccordion';
import { getPublicShellContext } from '@/lib/publicData';
import { getDb } from '@/lib/db';

export const dynamic = 'force-dynamic';

export default async function HomePage() {
  const ctx = await getPublicShellContext();
  const db = getDb();
  const { doctor } = ctx;

  const services = db
    .prepare('SELECT * FROM medical_services WHERE is_active = 1 ORDER BY sort_order ASC LIMIT 6')
    .all() as Array<{
    id: string;
    slug: string;
    title: string;
    short_description: string;
    conditions_json: string;
    icon_key: string;
  }>;

  const consultationTypes = db
    .prepare('SELECT * FROM consultation_types WHERE is_active = 1 ORDER BY sort_order ASC')
    .all() as Array<{
    id: string;
    name: string;
    description: string;
    mode: string;
    duration_minutes: number;
    fee_inr: number;
  }>;

  const faqs = db
    .prepare('SELECT id, category, question, answer FROM faqs WHERE is_active = 1 ORDER BY sort_order ASC LIMIT 6')
    .all() as FaqItem[];

  const reviews = db
    .prepare('SELECT * FROM feedback_reviews WHERE is_approved = 1 ORDER BY created_at DESC LIMIT 3')
    .all() as Array<{
    id: string;
    patient_initials: string;
    city: string | null;
    rating: number;
    concern_area: string;
    comment: string;
    is_demo: number;
  }>;

  return (
    <PublicShell
      announcement={ctx.announcement}
      user={ctx.user}
      doctor={doctor}
      chatbotWelcome={ctx.chatbotWelcome}
    >
      {/* HERO SECTION */}
      <section className="relative bg-aqua/65 border-b border-slate-200/70">
        <div className="clinic-container py-12 sm:py-16 lg:py-20">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-center">
            {/* Left Copy */}
            <div className="lg:col-span-7 space-y-6">
              <div className="inline-flex items-center gap-2 rounded-full border border-teal/25 bg-white px-3.5 py-1.5 text-xs font-semibold text-navy shadow-sm">
                <span className="h-2 w-2 rounded-full bg-teal" />
                Online Consultation · Mon–Sat · 3:00 PM – 8:00 PM IST
              </div>

              <h1 className="text-3xl sm:text-4xl lg:text-[46px] font-bold text-navy leading-[1.15]">
                {doctor.tagline}
              </h1>

              <p className="text-base sm:text-lg text-slate-600 max-w-2xl leading-relaxed">
                Get professional homoeopathic and primary wellness consultation from the comfort of your home with{' '}
                <strong className="text-navy font-semibold">{doctor.display_name}</strong> ({doctor.qualification}) — bringing{' '}
                <strong className="text-navy font-semibold">{doctor.experience_years} years</strong> of compassionate, individualized clinical care.
              </p>

              <div className="flex flex-wrap gap-3 pt-1">
                <Link href="/book" className="btn-primary px-6 py-3.5 text-sm">
                  <Calendar className="h-4 w-4" />
                  Book Your Consultation Today
                </Link>
                <Link href="/portal?tab=chat" className="btn-secondary px-5 py-3.5 text-sm">
                  <Video className="h-4 w-4 text-teal" />
                  Video / Audio Call &amp; Chat
                </Link>
              </div>

              {/* Direct Live Audio Call, Live Video Call & WhatsApp Strip (+91 8123108149) */}
              <div className="flex flex-wrap items-center gap-2.5 text-xs pt-0.5">
                <Link
                  href="/portal?tab=video&start=VIDEO"
                  className="inline-flex items-center gap-1.5 rounded-lg border border-teal/35 bg-white px-3 py-1.5 font-semibold text-navy hover:border-teal hover:bg-aqua transition-colors"
                >
                  <Video className="h-3.5 w-3.5 text-teal" /> Live Video Call
                </Link>
                <Link
                  href="/portal?tab=video&start=AUDIO"
                  className="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-3 py-1.5 font-semibold text-navy hover:border-teal hover:bg-aqua transition-colors tabular"
                >
                  <Phone className="h-3.5 w-3.5 text-teal" /> Live Audio Call · 8123108149
                </Link>
                <a
                  href={`https://wa.me/${doctor.whatsapp_number}?text=${encodeURIComponent(
                    'Namaste Dr. Aparna Mishra, I would like to connect for an Online Video/Audio Consultation.'
                  )}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 rounded-lg border border-emerald-200 bg-white px-3 py-1.5 font-semibold text-emerald-800 hover:bg-emerald-50 transition-colors tabular"
                >
                  WhatsApp: +91 8123108149
                </a>
              </div>

              {/* Key Clinic Facts */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-4">
                {[
                  { value: `${doctor.experience_years}+ Years`, label: 'Clinical Experience' },
                  { value: 'BHMS', label: 'Qualified Physician' },
                  { value: '3 – 8 PM', label: 'Monday to Saturday' },
                  { value: '100% Online', label: 'Video & Audio Care' },
                ].map((stat) => (
                  <div
                    key={stat.label}
                    className="rounded-xl border border-slate-200/80 bg-white px-3.5 py-3 shadow-sm"
                  >
                    <p className="font-heading text-base sm:text-lg font-bold text-navy tabular">
                      {stat.value}
                    </p>
                    <p className="text-xs text-slate-500">{stat.label}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Right Doctor Portrait Card */}
            <div className="lg:col-span-5">
              <div className="mx-auto max-w-md rounded-3xl border border-slate-200/90 bg-white p-4 shadow-elevated">
                <div className="relative overflow-hidden rounded-2xl bg-surface-muted aspect-[4/4.3]">
                  <img
                    src={doctor.photo_url}
                    alt={`${doctor.display_name} — Homoeopathic Physician (BHMS)`}
                    className="h-full w-full object-cover object-top"
                  />
                </div>
                <div className="pt-4 px-1.5 pb-1 space-y-2">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <h2 className="font-heading text-lg font-bold text-navy">
                        {doctor.display_name}
                      </h2>
                      <p className="text-xs font-semibold text-teal">
                        BHMS · Homoeopathic Physician
                      </p>
                    </div>
                    <span className="inline-flex items-center gap-1 rounded-full bg-aqua px-2.5 py-1 text-[11px] font-semibold text-navy">
                      <Award className="h-3.5 w-3.5 text-teal" /> {doctor.experience_years} Yrs Exp.
                    </span>
                  </div>
                  <div className="pt-2 border-t border-slate-100 flex flex-wrap items-center justify-between gap-2 text-xs text-slate-500">
                    <span className="inline-flex items-center gap-1.5">
                      <Video className="h-3.5 w-3.5 text-teal" /> Online · By Prior Booking
                    </span>
                    <span className="font-medium text-navy">{doctor.languages}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* AREAS OF CONSULTATION */}
      <section className="py-16 sm:py-20 bg-white">
        <div className="clinic-container">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-12">
            <div className="max-w-2xl">
              <p className="text-xs font-semibold uppercase tracking-widest text-teal mb-2">
                Areas of Consultation
              </p>
              <h2 className="text-2xl sm:text-3xl font-bold text-navy">
                Personalized Care Across Common & Chronic Concerns
              </h2>
              <p className="text-sm sm:text-base text-slate-600 mt-2">
                Whether you have a specific health complaint or seek structured guidance for overall well-being, each consultation is tailored to your complete health picture.
              </p>
            </div>
            <Link
              href="/services"
              className="inline-flex items-center gap-1.5 text-sm font-semibold text-teal hover:text-navy transition-colors shrink-0"
            >
              View all medical services <ArrowRight className="h-4 w-4" />
            </Link>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {services.map((svc) => {
              const tags = (JSON.parse(svc.conditions_json) as string[]).slice(0, 3);
              return (
                <div
                  key={svc.id}
                  className="card-surface p-6 flex flex-col justify-between hover:border-teal/40 transition-colors"
                >
                  <div>
                    <ServiceIllustration iconKey={svc.icon_key} className="h-12 w-12 mb-4" />
                    <h3 className="text-lg font-bold text-navy mb-1.5">{svc.title}</h3>
                    <p className="text-sm text-slate-600 mb-4 leading-relaxed">
                      {svc.short_description}
                    </p>
                    <ul className="space-y-1.5 mb-5">
                      {tags.map((t) => (
                        <li key={t} className="flex items-center gap-2 text-xs text-slate-600">
                          <CheckCircle2 className="h-3.5 w-3.5 text-teal shrink-0" />
                          <span>{t}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                  <Link
                    href={`/book?concern=${encodeURIComponent(svc.title)}`}
                    className="inline-flex items-center gap-1.5 text-xs font-semibold text-teal hover:text-navy pt-3 border-t border-slate-100"
                  >
                    Book for {svc.title} <ArrowRight className="h-3.5 w-3.5" />
                  </Link>
                </div>
              );
            })}
          </div>

          <p className="mt-8 text-xs text-slate-500 text-center">
            Clinical ethics note: Where in-person examination, laboratory investigation, or specialist care is required, timely medical evaluation and referral will be advised.
          </p>
        </div>
      </section>

      {/* ABOUT DOCTOR & DIGITAL CLINIC WORKFLOW */}
      <section className="py-16 sm:py-20 bg-surface-muted border-y border-slate-200/70">
        <div className="clinic-container grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
          {/* Doctor Introduction */}
          <div className="lg:col-span-6 card-surface p-7 sm:p-8 space-y-5">
            <div className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-teal">
              <Stethoscope className="h-4 w-4" /> Meet Your Physician
            </div>
            <h2 className="text-2xl sm:text-3xl font-bold text-navy">
              {doctor.display_name}
            </h2>
            <p className="text-sm text-slate-600 leading-relaxed">{doctor.bio}</p>
            <blockquote className="rounded-xl bg-aqua p-4 text-sm text-navy border-l-4 border-teal leading-relaxed">
              “{doctor.approach_note}”
            </blockquote>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1 text-xs">
              <div className="rounded-xl bg-surface-muted p-3.5">
                <span className="text-slate-500 block">Qualification</span>
                <strong className="text-navy">BHMS</strong>
              </div>
              <div className="rounded-xl bg-surface-muted p-3.5">
                <span className="text-slate-500 block">Experience</span>
                <strong className="text-navy">{doctor.experience_years} Years Clinical Practice</strong>
              </div>
              <div className="rounded-xl bg-surface-muted p-3.5 sm:col-span-2">
                <span className="text-slate-500 block">Council Registration</span>
                <strong className="text-navy">{doctor.registration_number}</strong>
                <span className="block text-[11px] text-slate-500">{doctor.registration_council}</span>
              </div>
            </div>
            <div className="pt-2">
              <Link href="/about" className="btn-secondary">
                Read Full Profile <ArrowRight className="h-4 w-4 text-teal" />
              </Link>
            </div>
          </div>

          {/* Complete Digital Clinic Platform Journey */}
          <div className="lg:col-span-6 space-y-5">
            <div>
              <p className="text-xs font-semibold uppercase tracking-widest text-teal mb-2">
                How Online Consultation Works
              </p>
              <h2 className="text-2xl sm:text-3xl font-bold text-navy">
                A Seamless, Private Digital Clinic Experience
              </h2>
            </div>

            <div className="space-y-3.5">
              {[
                {
                  step: '01',
                  title: 'Choose Slot & Sign In Easily',
                  desc: 'Pick a live Monday–Saturday slot between 3:00 PM and 8:00 PM. Sign in with Email, Mobile OTP, Google, or Apple (parent/guardian accounts supported for minors).',
                  icon: Calendar,
                },
                {
                  step: '02',
                  title: 'Pay via Any Preferred Method',
                  desc: 'Scan Dr. Aparna Mishra’s official PhonePe/UPI QR or pay seamlessly via UPI ID, RuPay/Visa/Mastercard, NetBanking, or Wallets with downloadable PDF receipts.',
                  icon: CreditCard,
                },
                {
                  step: '03',
                  title: 'Upload Reports & Attend Secure Video Call',
                  desc: 'Share past lab reports privately (AES-256-GCM encrypted) and join your authenticated online video/audio session—never automatically recorded.',
                  icon: Video,
                },
                {
                  step: '04',
                  title: 'Download Authorised Prescription & Follow Up',
                  desc: 'Receive your doctor-authorised PDF prescription in the Patient Portal along with WhatsApp/email appointment updates and follow-up reminders.',
                  icon: FileText,
                },
              ].map((item) => {
                const Icon = item.icon;
                return (
                  <div key={item.step} className="card-surface p-5 flex items-start gap-4">
                    <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-aqua text-teal">
                      <Icon className="h-5 w-5" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-[11px] font-bold text-teal tabular">
                          STEP {item.step}
                        </span>
                        <h3 className="font-heading text-sm sm:text-base font-bold text-navy">
                          {item.title}
                        </h3>
                      </div>
                      <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                        {item.desc}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </section>

      {/* CONSULTATION OPTIONS & TIMINGS + MAP */}
      <section className="py-16 sm:py-20 bg-white">
        <div className="clinic-container space-y-12">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {consultationTypes.map((ct) => (
              <div key={ct.id} className="card-surface p-5 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between text-xs font-semibold text-teal mb-2">
                    <span>{ct.mode.replace('_', ' ')}</span>
                    <span className="tabular">{ct.duration_minutes} mins</span>
                  </div>
                  <h3 className="font-heading text-base font-bold text-navy mb-2">{ct.name}</h3>
                  <p className="text-xs text-slate-600 leading-relaxed mb-4">{ct.description}</p>
                </div>
                <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
                  <span className="font-heading text-xl font-bold text-navy tabular">
                    ₹{ct.fee_inr}
                  </span>
                  <Link
                    href={`/book?type=${ct.id}`}
                    className="rounded-lg bg-aqua px-3 py-1.5 text-xs font-semibold text-navy hover:bg-teal hover:text-white transition-colors"
                  >
                    Select Slot
                  </Link>
                </div>
              </div>
            ))}
          </div>

          {/* Timings, Contact & Map Card */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
            <div className="lg:col-span-5 rounded-2xl bg-navy text-white p-7 sm:p-8 flex flex-col justify-between space-y-6">
              <div className="space-y-4">
                <p className="text-xs font-semibold uppercase tracking-widest text-teal-200">
                  Consultation Schedule & Contact
                </p>
                <h3 className="text-2xl font-bold text-white">Clinic Timings</h3>
                <div className="rounded-xl bg-white/10 p-4 space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-slate-200">Monday – Saturday</span>
                    <span className="font-semibold text-white tabular">3:00 PM – 8:00 PM</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-300">Sunday</span>
                    <span className="text-teal-200">Closed</span>
                  </div>
                  <div className="flex justify-between pt-1 border-t border-white/10 text-xs">
                    <span className="text-slate-300">Consultation Mode</span>
                    <span className="font-medium text-white">Online · By Prior Booking</span>
                  </div>
                </div>

                <div className="space-y-2.5 pt-2 text-sm">
                  <a href="tel:+918123108149" className="flex items-center gap-3 text-slate-200 hover:text-white">
                    <Phone className="h-4 w-4 text-teal-300" />
                    <span className="tabular">{doctor.phone} (Call / WhatsApp)</span>
                  </a>
                  <a href={`mailto:${doctor.email}`} className="flex items-center gap-3 text-slate-200 hover:text-white">
                    <Mail className="h-4 w-4 text-teal-300" />
                    <span>{doctor.email}</span>
                  </a>
                  <div className="flex items-start gap-3 text-slate-300 text-xs pt-1">
                    <MapPin className="h-4 w-4 text-teal-300 shrink-0 mt-0.5" />
                    <span>{doctor.clinic_address}</span>
                  </div>
                </div>
              </div>

              <div className="flex flex-wrap gap-3">
                <Link href="/book" className="btn-primary flex-1">
                  Book Slot Now
                </Link>
                <a
                  href={`https://wa.me/${doctor.whatsapp_number}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center justify-center rounded-xl border border-white/20 px-4 py-3 text-xs font-semibold text-white hover:bg-white/10"
                >
                  WhatsApp Desk
                </a>
              </div>
            </div>

            <div className="lg:col-span-7 card-surface overflow-hidden flex flex-col">
              <div className="px-6 py-4 border-b border-slate-100 flex flex-wrap items-center justify-between gap-2">
                <div>
                  <h3 className="font-heading text-base font-bold text-navy">
                    Pan-India Online Tele-Consultation Reach
                  </h3>
                  <p className="text-xs text-slate-500">
                    Consult from anywhere in India · Interactive practice region map (customisable in Admin CMS)
                  </p>
                </div>
                <span className="inline-flex items-center gap-1 text-xs font-semibold text-teal">
                  <ShieldCheck className="h-4 w-4" /> Verified Practice
                </span>
              </div>
              <div className="flex-1 min-h-[280px] bg-aqua/50 relative">
                <iframe
                  title="Clinic Practice Location Map"
                  src={doctor.map_embed_url}
                  className="w-full h-full min-h-[280px] border-0"
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* PATIENT FEEDBACK & FAQ */}
      <section className="py-16 sm:py-20 bg-surface-muted border-t border-slate-200/70">
        <div className="clinic-container space-y-16">
          {reviews.length > 0 && (
            <div>
              <div className="text-center max-w-2xl mx-auto mb-10">
                <p className="text-xs font-semibold uppercase tracking-widest text-teal mb-2">
                  Patient Experience
                </p>
                <h2 className="text-2xl sm:text-3xl font-bold text-navy">
                  Thoughtful Care, Effortless Online Access
                </h2>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {reviews.map((rev) => (
                  <div key={rev.id} className="card-surface p-6 flex flex-col justify-between">
                    <div>
                      <div className="flex items-center gap-1 mb-3">
                        {Array.from({ length: rev.rating }).map((_, i) => (
                          <Star key={i} className="h-4 w-4 fill-amber-400 text-amber-400" />
                        ))}
                      </div>
                      <p className="text-sm text-slate-600 leading-relaxed mb-4">
                        “{rev.comment}”
                      </p>
                    </div>
                    <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
                      <span className="font-semibold text-navy">
                        {rev.patient_initials}
                        {rev.city ? ` · ${rev.city}` : ''}
                      </span>
                      <span className="text-teal font-medium">{rev.concern_area}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Homepage FAQs */}
          <div className="max-w-3xl mx-auto">
            <div className="text-center mb-8">
              <p className="text-xs font-semibold uppercase tracking-widest text-teal mb-2">
                Patient FAQs
              </p>
              <h2 className="text-2xl sm:text-3xl font-bold text-navy">
                Frequently Asked Questions
              </h2>
            </div>
            <FaqAccordion faqs={faqs} />
            <div className="mt-6 text-center">
              <Link href="/faq" className="text-sm font-semibold text-teal hover:text-navy">
                Browse all FAQs & search topics →
              </Link>
            </div>
          </div>
        </div>
      </section>
    </PublicShell>
  );
}
