import React from 'react';
import Link from 'next/link';
import { notFound } from 'next/navigation';
import { ArrowLeft, Calendar, Clock, ShieldCheck } from 'lucide-react';
import PublicShell from '@/components/PublicShell';
import { getPublicShellContext } from '@/lib/publicData';
import { getDb } from '@/lib/db';

export const dynamic = 'force-dynamic';

export default async function BlogArticlePage({
  params,
}: {
  params: { slug: string };
}) {
  const ctx = await getPublicShellContext();
  const db = getDb();

  const article = db
    .prepare('SELECT * FROM blog_articles WHERE slug = ? AND is_published = 1')
    .get(params.slug) as
    | {
        id: string;
        title: string;
        category: string;
        excerpt: string;
        content: string;
        read_time_minutes: number;
        reviewed_by: string;
        published_at: string;
      }
    | undefined;

  if (!article) notFound();

  const blocks = article.content.split('\n\n');

  return (
    <PublicShell
      announcement={ctx.announcement}
      user={ctx.user}
      doctor={ctx.doctor}
      chatbotWelcome={ctx.chatbotWelcome}
    >
      <article className="py-12 sm:py-16 bg-white">
        <div className="clinic-container max-w-3xl space-y-6">
          <Link
            href="/blog"
            className="inline-flex items-center gap-1.5 text-xs font-semibold text-teal hover:text-navy"
          >
            <ArrowLeft className="h-3.5 w-3.5" /> Back to Health & Wellness Blog
          </Link>

          <div className="space-y-3 border-b border-slate-200 pb-6">
            <div className="flex flex-wrap items-center gap-3 text-xs">
              <span className="rounded-full bg-aqua px-3 py-1 font-semibold text-teal">
                {article.category}
              </span>
              <span className="inline-flex items-center gap-1 text-slate-500">
                <Clock className="h-3.5 w-3.5" /> {article.read_time_minutes} min read
              </span>
              <span className="inline-flex items-center gap-1 text-navy font-medium">
                <ShieldCheck className="h-3.5 w-3.5 text-teal" /> Medically reviewed by{' '}
                {article.reviewed_by}
              </span>
            </div>
            <h1 className="text-2xl sm:text-4xl font-bold text-navy leading-tight">
              {article.title}
            </h1>
            <p className="text-base text-slate-600">{article.excerpt}</p>
          </div>

          <div className="space-y-4 text-[15.5px] text-slate-700 leading-relaxed">
            {blocks.map((block, idx) => {
              if (block.startsWith('### ')) {
                return (
                  <h2 key={idx} className="text-xl font-bold text-navy pt-3">
                    {block.replace('### ', '')}
                  </h2>
                );
              }
              return (
                <p key={idx} className="whitespace-pre-line">
                  {block.replace(/\*\*/g, '')}
                </p>
              );
            })}
          </div>

          <div className="mt-10 rounded-2xl bg-aqua border border-teal/20 p-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div>
              <h3 className="font-heading text-base font-bold text-navy">
                Need Individualized Guidance for {article.category}?
              </h3>
              <p className="text-xs text-slate-600 mt-0.5">
                Consult {ctx.doctor.display_name} (BHMS) online · Mon–Sat, 3:00 PM – 8:00 PM IST.
              </p>
            </div>
            <Link
              href={`/book?concern=${encodeURIComponent(article.category)}`}
              className="btn-primary shrink-0 text-xs"
            >
              <Calendar className="h-4 w-4" /> Book Online Slot
            </Link>
          </div>
        </div>
      </article>
    </PublicShell>
  );
}
