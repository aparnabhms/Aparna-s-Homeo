import React from 'react';
import Link from 'next/link';
import { ArrowRight, BookOpen, Clock, ShieldCheck } from 'lucide-react';
import PublicShell from '@/components/PublicShell';
import { getPublicShellContext } from '@/lib/publicData';
import { getDb } from '@/lib/db';

export const dynamic = 'force-dynamic';

export default async function BlogPage({
  searchParams,
}: {
  searchParams?: { category?: string; q?: string };
}) {
  const ctx = await getPublicShellContext();
  const db = getDb();

  const allArticles = db
    .prepare('SELECT * FROM blog_articles WHERE is_published = 1 ORDER BY published_at DESC')
    .all() as Array<{
    id: string;
    slug: string;
    title: string;
    category: string;
    excerpt: string;
    read_time_minutes: number;
    reviewed_by: string;
    published_at: string;
  }>;

  const categories = ['All', ...Array.from(new Set(allArticles.map((a) => a.category)))];
  const activeCat = searchParams?.category || 'All';
  const q = (searchParams?.q || '').trim().toLowerCase();

  const filtered = allArticles.filter((a) => {
    const cOk = activeCat === 'All' || a.category === activeCat;
    const qOk =
      !q ||
      a.title.toLowerCase().includes(q) ||
      a.excerpt.toLowerCase().includes(q) ||
      a.category.toLowerCase().includes(q);
    return cOk && qOk;
  });

  return (
    <PublicShell
      announcement={ctx.announcement}
      user={ctx.user}
      doctor={ctx.doctor}
      chatbotWelcome={ctx.chatbotWelcome}
    >
      <section className="bg-aqua/65 border-b border-slate-200/70 py-12 sm:py-16">
        <div className="clinic-container max-w-4xl text-center space-y-3">
          <p className="text-xs font-semibold uppercase tracking-widest text-teal">
            Doctor-Reviewed Patient Education
          </p>
          <h1 className="text-3xl sm:text-4xl font-bold text-navy">
            Health & Wellness Blog
          </h1>
          <p className="text-sm sm:text-base text-slate-600 max-w-2xl mx-auto">
            Evidence-informed wellness guides curated and reviewed by {ctx.doctor.display_name} (BHMS) on women’s health, thyroid care, skin, digestion, and seasonal allergies.
          </p>
        </div>
      </section>

      <section className="py-12 sm:py-16 bg-white">
        <div className="clinic-container space-y-8">
          {/* Search & Category Filter */}
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="flex flex-wrap gap-2">
              {categories.map((cat) => (
                <Link
                  key={cat}
                  href={cat === 'All' ? '/blog' : `/blog?category=${encodeURIComponent(cat)}`}
                  className={`rounded-full px-3.5 py-1.5 text-xs font-semibold transition-colors ${
                    activeCat === cat
                      ? 'bg-navy text-white'
                      : 'bg-aqua text-navy hover:bg-teal hover:text-white'
                  }`}
                >
                  {cat}
                </Link>
              ))}
            </div>
            <form action="/blog" method="get" className="flex gap-2 w-full md:w-72">
              <input
                type="search"
                name="q"
                defaultValue={searchParams?.q || ''}
                placeholder="Search health articles..."
                className="input-field py-2 text-xs"
              />
              <button type="submit" className="btn-secondary py-2 px-3.5 text-xs">
                Search
              </button>
            </form>
          </div>

          {filtered.length === 0 ? (
            <div className="card-surface p-10 text-center space-y-3">
              <BookOpen className="h-8 w-8 text-slate-300 mx-auto" />
              <p className="text-sm text-slate-500">No articles matched your search.</p>
              <Link href="/blog" className="text-xs font-semibold text-teal hover:underline">
                Show all articles
              </Link>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filtered.map((art) => (
                <article
                  key={art.id}
                  className="card-surface p-6 flex flex-col justify-between hover:border-teal/40 transition-colors"
                >
                  <div>
                    <div className="flex items-center justify-between text-xs mb-3">
                      <span className="rounded-full bg-aqua px-2.5 py-1 font-semibold text-teal">
                        {art.category}
                      </span>
                      <span className="inline-flex items-center gap-1 text-slate-400 tabular">
                        <Clock className="h-3 w-3" /> {art.read_time_minutes} min read
                      </span>
                    </div>
                    <h2 className="text-lg font-bold text-navy mb-2.5 leading-snug">
                      <Link href={`/blog/${art.slug}`} className="hover:text-teal transition-colors">
                        {art.title}
                      </Link>
                    </h2>
                    <p className="text-sm text-slate-600 leading-relaxed mb-5">{art.excerpt}</p>
                  </div>
                  <div className="pt-4 border-t border-slate-100 flex items-center justify-between text-xs">
                    <span className="inline-flex items-center gap-1 text-slate-500">
                      <ShieldCheck className="h-3.5 w-3.5 text-teal" /> {art.reviewed_by}
                    </span>
                    <Link
                      href={`/blog/${art.slug}`}
                      className="inline-flex items-center gap-1 font-semibold text-teal hover:text-navy"
                    >
                      Read <ArrowRight className="h-3.5 w-3.5" />
                    </Link>
                  </div>
                </article>
              ))}
            </div>
          )}
        </div>
      </section>
    </PublicShell>
  );
}
