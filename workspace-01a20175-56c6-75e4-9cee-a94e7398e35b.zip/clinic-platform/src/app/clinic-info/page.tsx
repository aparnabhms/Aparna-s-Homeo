import React from 'react';
import Link from 'next/link';
import { Calendar, Clock, FileCheck2, Lock, Mail, MapPin, Phone, ShieldCheck } from 'lucide-react';
import PublicShell from '@/components/PublicShell';
import { getPublicShellContext } from '@/lib/publicData';
import { formatTime12h, getDb } from '@/lib/db';

export const dynamic = 'force-dynamic';

export default async function ClinicInfoPage() {
  const ctx = await getPublicShellContext();
  const db = getDb();
  const { doctor } = ctx;

  const schedule = db
    .prepare('SELECT * FROM doctor_availability ORDER BY CASE WHEN day_of_week = 0 THEN 7 ELSE day_of_week END ASC')
    .all() as Array<{
    day_of_week: number;
    day_name: string;
    is_enabled: number;
    start_time: string;
    end_time: string;
    slot_interval_minutes: number;
  }>;

  return (
    <PublicShell
      announcement={ctx.announcement}
      user={ctx.user}
      doctor={doctor}
      chatbotWelcome={ctx.chatbotWelcome}
    >
      <section className="bg-aqua/65 border-b border-slate-200/70 py-12 sm:py-16">
        <div className="clinic-container max-w-4xl text-center space-y-3">
          <p className="text-xs font-semibold uppercase tracking-widest text-teal">
            Practice Policies & Schedule
          </p>
          <h1 className="text-3xl sm:text-4xl font-bold text-navy">Clinic Information</h1>
          <p className="text-sm sm:text-base text-slate-600 max-w-2xl mx-auto">
            {doctor.clinic_name} — transparent timings, tele-consultation standards, payment policies, and patient data protection under India’s DPDP Act 2023.
          </p>
        </div>
      </section>

      <section className="py-14 bg-white">
        <div className="clinic-container grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Weekly Schedule Table */}
          <div className="lg:col-span-6 card-surface p-6 sm:p-7 space-y-4">
            <div className="flex items-center gap-2">
              <Clock className="h-5 w-5 text-teal" />
              <h2 className="text-xl font-bold text-navy">Weekly Consultation Hours (IST)</h2>
            </div>
            <div className="divide-y divide-slate-100">
              {schedule.map((d) => (
                <div key={d.day_of_week} className="py-3 flex items-center justify-between text-sm">
                  <span className="font-medium text-navy">{d.day_name}</span>
                  {d.is_enabled ? (
                    <span className="font-semibold text-teal tabular">
                      {formatTime12h(d.start_time)} – {formatTime12h(d.end_time)}
                    </span>
                  ) : (
                    <span className="text-xs font-semibold text-slate-400">Closed</span>
                  )}
                </div>
              ))}
            </div>
            <div className="pt-2">
              <Link href="/book" className="btn-primary w-full">
                <Calendar className="h-4 w-4" /> Check Live Slots & Book
              </Link>
            </div>
          </div>

          {/* Credentials, Contact & Map */}
          <div className="lg:col-span-6 space-y-6">
            <div className="card-surface p-6 space-y-3 text-sm">
              <h2 className="text-xl font-bold text-navy">Practice Summary</h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div className="rounded-xl bg-surface-muted p-3.5">
                  <span className="text-slate-500 block">Physician</span>
                  <strong className="text-navy">{doctor.display_name} (BHMS)</strong>
                </div>
                <div className="rounded-xl bg-surface-muted p-3.5">
                  <span className="text-slate-500 block">Experience</span>
                  <strong className="text-navy">{doctor.experience_years} Years</strong>
                </div>
                <div className="rounded-xl bg-surface-muted p-3.5">
                  <span className="text-slate-500 block">Appointment Mode</span>
                  <strong className="text-navy">Online · By Prior Booking</strong>
                </div>
                <div className="rounded-xl bg-surface-muted p-3.5">
                  <span className="text-slate-500 block">Official UPI ID</span>
                  <strong className="text-navy font-mono">{doctor.upi_id}</strong>
                </div>
              </div>
              <div className="pt-2 space-y-2 text-xs text-slate-600">
                <p className="flex items-center gap-2">
                  <Phone className="h-4 w-4 text-teal" /> <strong>Contact / WhatsApp:</strong>{' '}
                  {doctor.phone}
                </p>
                <p className="flex items-center gap-2">
                  <Mail className="h-4 w-4 text-teal" /> <strong>Email:</strong> {doctor.email}
                </p>
                <p className="flex items-start gap-2">
                  <MapPin className="h-4 w-4 text-teal shrink-0 mt-0.5" />{' '}
                  <span>{doctor.clinic_address}</span>
                </p>
              </div>
            </div>

            <div className="card-surface overflow-hidden h-56">
              <iframe
                title="Practice Map"
                src={doctor.map_embed_url}
                className="w-full h-full border-0"
                loading="lazy"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Privacy, Telemedicine & Refund Governance */}
      <section className="py-14 bg-surface-muted border-t border-slate-200/70">
        <div className="clinic-container grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="card-surface p-6 space-y-2.5">
            <Lock className="h-5 w-5 text-teal" />
            <h3 className="text-base font-bold text-navy">DPDP Act 2023 Data Privacy</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Personal and clinical data is collected solely with explicit, logged consent for healthcare delivery. Patients may review consents, export their data, or submit a data erasure request anytime from Patient Portal → My Profile (subject to statutory clinical retention norms).
            </p>
          </div>
          <div className="card-surface p-6 space-y-2.5">
            <ShieldCheck className="h-5 w-5 text-teal" />
            <h3 className="text-base font-bold text-navy">Telemedicine Standards</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Video consultations use private authenticated links and are never automatically recorded. Digital prescriptions are authorised exclusively by {doctor.display_name}. Minor consultations require verified parent/legal guardian consent and presence.
            </p>
          </div>
          <div className="card-surface p-6 space-y-2.5">
            <FileCheck2 className="h-5 w-5 text-teal" />
            <h3 className="text-base font-bold text-navy">Rescheduling & Refund Policy</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Patients can reschedule or cancel upcoming bookings via the Patient Portal. If a consultation cannot proceed due to doctor unavailability, a free reschedule or full server-audited refund is processed promptly.
            </p>
          </div>
        </div>
      </section>
    </PublicShell>
  );
}
