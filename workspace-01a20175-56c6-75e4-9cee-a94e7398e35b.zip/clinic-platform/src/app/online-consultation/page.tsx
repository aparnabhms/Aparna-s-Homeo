import React from 'react';
import Link from 'next/link';
import {
  AlertTriangle,
  Calendar,
  CheckCircle2,
  Lock,
  MessageCircle,
  MessageSquare,
  Phone,
  QrCode,
  ShieldCheck,
  Smartphone,
  Upload,
  Video,
} from 'lucide-react';
import PublicShell from '@/components/PublicShell';
import { getPublicShellContext } from '@/lib/publicData';

export const dynamic = 'force-dynamic';

export default async function OnlineConsultationPage() {
  const ctx = await getPublicShellContext();
  const { doctor } = ctx;

  return (
    <PublicShell
      announcement={ctx.announcement}
      user={ctx.user}
      doctor={doctor}
      chatbotWelcome={ctx.chatbotWelcome}
    >
      <section className="bg-aqua/65 border-b border-slate-200/70 py-12 sm:py-16">
        <div className="clinic-container grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          <div className="lg:col-span-7 space-y-4">
            <p className="text-xs font-semibold uppercase tracking-widest text-teal">
              Private Tele-Consultation
            </p>
            <h1 className="text-3xl sm:text-4xl font-bold text-navy">
              Consult Dr. Aparna Mishra Online from Home
            </h1>
            <p className="text-sm sm:text-base text-slate-600 leading-relaxed">
              Connect via secure <strong>Live HD Video Call</strong>, <strong>Audio Call</strong>, or <strong>Two-Way Chat</strong> — directly in your Patient Portal or on Dr. Aparna Mishra’s official consultation line <strong className="text-navy tabular">+91 8123108149</strong> (Monday to Saturday, 3:00 PM to 8:00 PM IST).
            </p>
            <div className="flex flex-wrap gap-2.5 pt-2">
              <Link href="/book" className="btn-primary">
                <Calendar className="h-4 w-4" /> Book Online Slot
              </Link>
              <Link href="/portal?tab=video&start=VIDEO" className="btn-secondary">
                <Video className="h-4 w-4 text-teal" /> Start Live Video Call
              </Link>
              <Link href="/portal?tab=video&start=AUDIO" className="btn-secondary">
                <Phone className="h-4 w-4 text-teal" /> Start Live Audio Call
              </Link>
              <Link href="/portal?tab=chat" className="btn-secondary">
                <MessageSquare className="h-4 w-4 text-teal" /> Live Doctor Chat
              </Link>
              <a
                href={`https://wa.me/${doctor.whatsapp_number}?text=${encodeURIComponent(
                  'Namaste Dr. Aparna Mishra, connecting regarding Online Video / Audio Consultation (+91 8123108149).'
                )}`}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 rounded-xl border border-emerald-200 bg-white px-4 py-2.5 text-xs sm:text-sm font-semibold text-emerald-800 hover:bg-emerald-50"
              >
                <MessageCircle className="h-4 w-4" /> WhatsApp Video / Chat
              </a>
            </div>
          </div>
          <div className="lg:col-span-5 card-surface p-6 space-y-3">
            <div className="flex items-center gap-2 text-sm font-bold text-navy">
              <Lock className="h-4 w-4 text-teal" /> Privacy & Security Guarantees
            </div>
            <ul className="space-y-2.5 text-xs sm:text-sm text-slate-600">
              <li className="flex items-start gap-2">
                <CheckCircle2 className="h-4 w-4 text-teal shrink-0 mt-0.5" />
                <span>Authenticated unique meeting room generated per appointment.</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="h-4 w-4 text-teal shrink-0 mt-0.5" />
                <span>Consultations are <strong>never automatically recorded</strong> or streamed.</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="h-4 w-4 text-teal shrink-0 mt-0.5" />
                <span>Uploaded diagnostic reports are encrypted at rest (AES-256-GCM).</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="h-4 w-4 text-teal shrink-0 mt-0.5" />
                <span>Works on Android phones, iPhones, tablets, and laptops without app installs.</span>
              </li>
            </ul>
          </div>
        </div>
      </section>

      {/* Pre-Consultation Checklist + Payment Options */}
      <section className="py-14 sm:py-16 bg-white">
        <div className="clinic-container grid grid-cols-1 lg:grid-cols-12 gap-8">
          <div className="lg:col-span-7 space-y-5">
            <h2 className="text-2xl font-bold text-navy">Before Your Scheduled Slot</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {[
                {
                  icon: Upload,
                  title: 'Upload Prior Lab Reports',
                  desc: 'Upload recent blood tests (TSH, CBC, Vitamin D/B12), scans, or earlier prescriptions in Patient Portal → Medical Reports.',
                },
                {
                  icon: Smartphone,
                  title: 'Join 5 Minutes Early',
                  desc: 'Sit in a quiet, well-lit room with a stable 4G/5G or Wi-Fi connection and allow browser microphone & camera access.',
                },
                {
                  icon: ShieldCheck,
                  title: 'Minor Patient Consultations',
                  desc: 'For patients under 18, the registered parent or legal guardian must be present during the online consultation.',
                },
                {
                  icon: AlertTriangle,
                  title: 'Not for Medical Emergencies',
                  desc: 'For chest pain, severe breathlessness, acute injury, heavy bleeding, or high fever, dial 112/108 or visit the nearest ER.',
                },
              ].map((item) => {
                const Icon = item.icon;
                return (
                  <div key={item.title} className="card-surface p-5 space-y-2">
                    <Icon className="h-5 w-5 text-teal" />
                    <h3 className="font-heading text-sm font-bold text-navy">{item.title}</h3>
                    <p className="text-xs text-slate-600 leading-relaxed">{item.desc}</p>
                  </div>
                );
              })}
            </div>
          </div>

          {/* All Accepted Payments Preview with Official PhonePe QR */}
          <div className="lg:col-span-5 card-surface p-6 space-y-4">
            <div className="flex items-center gap-2">
              <QrCode className="h-5 w-5 text-teal" />
              <h2 className="text-lg font-bold text-navy">All Payment Options Accepted</h2>
            </div>
            <p className="text-xs text-slate-600 leading-relaxed">
              During booking, choose between direct PhonePe / Google Pay / Paytm / BHIM UPI QR scan or Razorpay online checkout (UPI ID, RuPay / Visa / Mastercard Cards, NetBanking, Wallets & Pay Later).
            </p>
            <div className="flex items-center gap-4 rounded-xl bg-surface-muted p-4 border border-slate-200">
              <img
                src={doctor.upi_qr_url}
                alt="Official Clinic PhonePe UPI QR"
                className="h-24 w-24 rounded-lg border border-slate-200 bg-white object-contain shrink-0"
              />
              <div className="text-xs space-y-1">
                <p className="font-bold text-navy">{doctor.upi_payee_name}</p>
                <p className="font-mono text-teal">{doctor.upi_id}</p>
                <p className="text-slate-500">
                  Book your slot first to generate your Appointment Reference Number before paying.
                </p>
              </div>
            </div>
            <Link href="/book" className="btn-primary w-full">
              Proceed to Slot Selection & Payment
            </Link>
          </div>
        </div>
      </section>
    </PublicShell>
  );
}
