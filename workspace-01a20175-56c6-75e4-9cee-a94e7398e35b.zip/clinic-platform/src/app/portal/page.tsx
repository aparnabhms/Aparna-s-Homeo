import React from 'react';
import { redirect } from 'next/navigation';
import { getSessionWithToken } from '@/lib/auth';
import { getDb, getDoctorPublicProfile } from '@/lib/db';
import PatientPortalClient from '@/components/PatientPortalClient';
import { ConsultationTypeOption } from '@/components/BookingFlow';

export const dynamic = 'force-dynamic';

export default async function PatientPortalPage({
  searchParams,
}: {
  searchParams?: { tab?: string; start?: string; _st?: string };
}) {
  const session = await getSessionWithToken(searchParams?._st);
  if (!session) redirect('/login?next=/portal&autoresume=1');
  const { user, token } = session;

  if (['DOCTOR', 'ADMIN', 'STAFF'].includes(user.role)) {
    redirect(`/admin?_st=${encodeURIComponent(token)}`);
  }

  const db = getDb();
  const doctor = getDoctorPublicProfile();
  const consultationTypes = db
    .prepare('SELECT * FROM consultation_types WHERE is_active = 1 ORDER BY sort_order ASC')
    .all() as ConsultationTypeOption[];

  const startCall =
    searchParams?.start === 'VIDEO'
      ? 'VIDEO'
      : searchParams?.start === 'AUDIO'
      ? 'AUDIO'
      : null;

  return (
    <PatientPortalClient
      initialTab={searchParams?.tab || 'dashboard'}
      initialStartCall={startCall}
      sessionToken={token}
      sessionUser={{
        id: user.id,
        fullName: user.fullName,
        email: user.email,
        role: user.role,
        isDemo: user.isDemo,
      }}
      consultationTypes={consultationTypes}
      clinicContact={{
        doctorName: doctor.display_name,
        phone: doctor.phone,
        whatsapp: doctor.whatsapp_number,
        email: doctor.email,
        timings: doctor.timings_summary,
        upiId: doctor.upi_id,
        qrUrl: doctor.upi_qr_url,
      }}
    />
  );
}
