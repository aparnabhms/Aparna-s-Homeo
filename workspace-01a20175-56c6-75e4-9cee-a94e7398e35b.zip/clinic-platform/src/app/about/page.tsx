import React from 'react';
import Link from 'next/link';
import {
  Award,
  BookOpen,
  Calendar,
  CheckCircle2,
  Clock,
  Globe,
  HeartHandshake,
  ShieldCheck,
} from 'lucide-react';
import PublicShell from '@/components/PublicShell';
import { getPublicShellContext } from '@/lib/publicData';

export const dynamic = 'force-dynamic';

export default async function AboutPage() {
  const ctx = await getPublicShellContext();
  const { doctor } = ctx;

  return (
    <PublicShell
      announcement={ctx.announcement}
      user={ctx.user}
      doctor={doctor}
      chatbotWelcome={ctx.chatbotWelcome}
    >
      <section className="bg-aqua/65 border-b border-slate-200/70 py-12 sm:py-16">
        <div className="clinic-container grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
          <div className="lg:col-span-4">
            <div className="max-w-sm mx-auto rounded-3xl border border-slate-200 bg-white p-3.5 shadow-card">
              <img
                src={doctor.photo_url}
                alt={doctor.display_name}
                className="w-full aspect-[4/4.4] object-cover object-top rounded-2xl"
              />
            </div>
          </div>
          <div className="lg:col-span-8 space-y-5">
            <p className="text-xs font-semibold uppercase tracking-widest text-teal">
              About the Doctor
            </p>
            <h1 className="text-3xl sm:text-4xl font-bold text-navy">{doctor.display_name}</h1>
            <p className="text-base font-semibold text-teal">
              {doctor.qualification} · {doctor.specialisation}
            </p>
            <p className="text-base text-slate-600 leading-relaxed">{doctor.bio}</p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 pt-2">
              <div className="rounded-xl bg-white border border-slate-200 p-4 flex items-start gap-3">
                <Award className="h-5 w-5 text-teal shrink-0 mt-0.5" />
                <div>
                  <p className="text-xs text-slate-500">Clinical Experience</p>
                  <p className="font-heading text-sm font-bold text-navy">
                    {doctor.experience_years} Years in Practice
                  </p>
                </div>
              </div>
              <div className="rounded-xl bg-white border border-slate-200 p-4 flex items-start gap-3">
                <Clock className="h-5 w-5 text-teal shrink-0 mt-0.5" />
                <div>
                  <p className="text-xs text-slate-500">Online Consultation Timings</p>
                  <p className="font-heading text-sm font-bold text-navy">
                    Mon–Sat · 3:00 PM – 8:00 PM IST
                  </p>
                </div>
              </div>
              <div className="rounded-xl bg-white border border-slate-200 p-4 flex items-start gap-3">
                <ShieldCheck className="h-5 w-5 text-teal shrink-0 mt-0.5" />
                <div>
                  <p className="text-xs text-slate-500">Council & Registration</p>
                  <p className="font-heading text-xs font-bold text-navy">
                    {doctor.registration_number}
                  </p>
                  <p className="text-[11px] text-slate-500">{doctor.registration_council}</p>
                </div>
              </div>
              <div className="rounded-xl bg-white border border-slate-200 p-4 flex items-start gap-3">
                <Globe className="h-5 w-5 text-teal shrink-0 mt-0.5" />
                <div>
                  <p className="text-xs text-slate-500">Consultation Languages & Mode</p>
                  <p className="font-heading text-sm font-bold text-navy">
                    {doctor.languages} · Online Video/Audio
                  </p>
                </div>
              </div>
            </div>

            <div className="pt-2 flex flex-wrap gap-3">
              <Link href="/book" className="btn-primary">
                <Calendar className="h-4 w-4" />
                Book Consultation with Dr. Aparna
              </Link>
              <Link href="/contact" className="btn-secondary">
                Contact Clinic
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Clinical Philosophy & Standards */}
      <section className="py-16 bg-white">
        <div className="clinic-container grid grid-cols-1 md:grid-cols-3 gap-6">
          {[
            {
              icon: HeartHandshake,
              title: 'Compassionate, Unhurried Case-Taking',
              text: 'Every patient is heard attentively—covering presenting symptoms, onset, lifestyle triggers, sleep, nutrition, stress, family history, and diagnostic reports before formulating a care plan.',
            },
            {
              icon: BookOpen,
              title: 'Individualized Constitutional Approach',
              text: 'Rather than one-size-fits-all prescribing, homoeopathic remedies, potency, and lifestyle recommendations are tailored to each individual’s health constitution and response over follow-ups.',
            },
            {
              icon: CheckCircle2,
              title: 'Ethical Telemedicine & Timely Referral',
              text: doctor.approach_note,
            },
          ].map((card) => {
            const Icon = card.icon;
            return (
              <div key={card.title} className="card-surface p-6 space-y-3">
                <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-aqua text-teal">
                  <Icon className="h-5 w-5" />
                </div>
                <h2 className="text-lg font-bold text-navy">{card.title}</h2>
                <p className="text-sm text-slate-600 leading-relaxed">{card.text}</p>
              </div>
            );
          })}
        </div>
      </section>
    </PublicShell>
  );
}
