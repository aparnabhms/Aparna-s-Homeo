'use client';

import React, { useEffect, useState, Suspense } from 'react';
import Link from 'next/link';
import { useSearchParams } from 'next/navigation';
import {
  ArrowLeft,
  Eye,
  EyeOff,
  Lock,
  LogOut,
  Mail,
  PhoneCall,
  ShieldCheck,
  Stethoscope,
  UserCheck,
  UserPlus,
  Users,
  Video,
} from 'lucide-react';
import { BrandMark } from '@/components/MedicalIcons';
import GoogleSignInButton from '@/components/GoogleSignInButton';
import {
  authFetch,
  clearClientSession,
  getClientSessionToken,
  navigateWithSession,
  saveClientSession,
} from '@/lib/clientSession';

async function parseJsonSafe(res: Response): Promise<Record<string, unknown>> {
  const txt = await res.text();
  if (!txt) return {};
  try {
    return JSON.parse(txt) as Record<string, unknown>;
  } catch {
    return { error: `Unexpected server response (HTTP ${res.status}). Please retry.` };
  }
}

function LoginInner() {
  const searchParams = useSearchParams();
  const nextPath = searchParams.get('next') || '';
  const autoOpenGoogle = searchParams.get('google') === '1';
  const autoResume = searchParams.get('autoresume') === '1';
  const urlError = searchParams.get('error') || '';

  const isCallRedirect =
    nextPath.includes('start=VIDEO') ||
    nextPath.includes('start=AUDIO') ||
    nextPath.startsWith('/call/');
  const isAudioRedirect = nextPath.includes('start=AUDIO');

  // Clean 2-tab layout below Sign in with Google: Gmail & Password | Create Account (no OTP section)
  const [mode, setMode] = useState<'GMAIL_PASSWORD' | 'SIGNUP'>('GMAIL_PASSWORD');

  // Gmail & Password Sign In
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPass, setShowPass] = useState(false);

  // Create Account
  const [regName, setRegName] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regPhone, setRegPhone] = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [regConfirm, setRegConfirm] = useState('');

  // State & session status
  const [loading, setLoading] = useState(false);
  const [redirectingMsg, setRedirectingMsg] = useState('');
  const [resuming, setResuming] = useState(false);
  const [existingSession, setExistingSession] = useState<{
    fullName: string;
    email: string;
    role: string;
  } | null>(null);
  const [error, setError] = useState(urlError);

  function resetMessages() {
    setError('');
  }

  function resolveTargetPath(redirectTo: string, role: string): string {
    const isClinicRole = ['DOCTOR', 'ADMIN', 'STAFF'].includes(role);
    const defaultDest = isClinicRole ? '/admin' : '/portal';
    if (nextPath && nextPath.startsWith('/') && !nextPath.startsWith('//')) {
      if (nextPath.startsWith('/admin') && !isClinicRole) return '/portal';
      if (nextPath.startsWith('/portal') && isClinicRole) {
        return nextPath.includes('start=') || nextPath.includes('video') || nextPath.includes('chat')
          ? '/admin?tab=chat'
          : '/admin';
      }
      return nextPath;
    }
    return redirectTo || defaultDest;
  }

  function navigateAfterLogin(redirectTo: string, role: string, sessionToken?: string) {
    if (sessionToken) saveClientSession(sessionToken);
    const dest = resolveTargetPath(redirectTo, role);
    setRedirectingMsg('Signed in! Opening your clinic portal…');
    navigateWithSession(dest, sessionToken);
  }

  // Seamlessly restore active session when browser blocks 3rd-party cookies in preview iframe
  useEffect(() => {
    const storedTok = getClientSessionToken();
    let active = true;
    const controller = new AbortController();
    const safetyTimer = setTimeout(() => {
      controller.abort();
      if (active) setResuming(false);
    }, 3500);

    if (storedTok && autoResume) {
      setResuming(true);
    }

    authFetch('/api/auth/me', { signal: controller.signal }, storedTok)
      .then((r) => (r.ok ? r.json() : null))
      .then((data) => {
        if (!active) return;
        if (data?.user) {
          if (autoResume && storedTok) {
            const dest = resolveTargetPath('', data.user.role);
            navigateWithSession(dest, storedTok);
            return;
          }
          setExistingSession({
            fullName: data.user.fullName,
            email: data.user.email,
            role: data.user.role,
          });
          setResuming(false);
        } else {
          if (storedTok) clearClientSession();
          setResuming(false);
        }
      })
      .catch(() => {
        if (active) setResuming(false);
      })
      .finally(() => {
        clearTimeout(safetyTimer);
      });

    return () => {
      active = false;
      clearTimeout(safetyTimer);
      controller.abort();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [autoResume]);

  async function handleSwitchAccount() {
    clearClientSession();
    setExistingSession(null);
    await fetch('/api/auth/logout', { method: 'POST', credentials: 'include' }).catch(() => {});
  }

  // 1. Sign In with Gmail / Email & Password
  async function handleGmailPasswordLogin(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    resetMessages();
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        cache: 'no-store',
        body: JSON.stringify({ method: 'EMAIL', email: email.trim(), password }),
      });
      const data = await parseJsonSafe(res);
      const userObj = data.user as { role: string } | undefined;
      if (!res.ok || !userObj) {
        setError(String(data.error || 'Incorrect email or password.'));
        setLoading(false);
        return;
      }
      navigateAfterLogin(
        String(data.redirectTo || '/portal'),
        userObj.role,
        typeof data.sessionToken === 'string' ? data.sessionToken : undefined
      );
    } catch {
      setError('Connection error while signing in. Please tap Sign In again.');
      setLoading(false);
    }
  }

  // 2. Register New Account with Gmail & Password
  async function handleQuickGmailSignup(e: React.FormEvent) {
    e.preventDefault();
    resetMessages();
    const trimmedEmail = regEmail.trim().toLowerCase();
    if (!/^[a-zA-Z0-9._%+-]{2,}@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/.test(trimmedEmail)) {
      setError('Please enter a valid Gmail or email address (e.g. yourname@gmail.com).');
      return;
    }
    if (regPassword.length < 6) {
      setError('Password must be at least 6 characters long.');
      return;
    }
    if (regConfirm && regPassword !== regConfirm) {
      setError('Passwords do not match. Please re-enter the same password.');
      return;
    }

    setLoading(true);
    try {
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        cache: 'no-store',
        body: JSON.stringify({
          fullName: regName.trim(),
          email: trimmedEmail,
          phone: regPhone.trim(),
          password: regPassword,
          dpdpConsent: true,
          telemedicineConsent: true,
          whatsappConsent: true,
        }),
      });
      const data = await parseJsonSafe(res);
      if (!res.ok || !data.user) {
        setError(String(data.error || 'Could not create account.'));
        setLoading(false);
        return;
      }
      navigateAfterLogin(
        '/portal',
        'PATIENT',
        typeof data.sessionToken === 'string' ? data.sessionToken : undefined
      );
    } catch {
      setError('Connection error while creating account. Please try again.');
      setLoading(false);
    }
  }

  // 3. One-Click Demo Role Switcher
  async function quickDemoSignIn(demoAccount: 'PATIENT' | 'GUARDIAN' | 'DOCTOR' | 'STAFF') {
    setLoading(true);
    resetMessages();
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        cache: 'no-store',
        body: JSON.stringify({ method: 'DEMO_QUICK', demoAccount }),
      });
      const data = await parseJsonSafe(res);
      const userObj = data.user as { role: string } | undefined;
      if (res.ok && userObj) {
        navigateAfterLogin(
          String(data.redirectTo || '/portal'),
          userObj.role,
          typeof data.sessionToken === 'string' ? data.sessionToken : undefined
        );
      } else {
        setError(String(data.error || 'Demo sign-in unavailable.'));
        setLoading(false);
      }
    } catch {
      setError('Connection error. Please try again.');
      setLoading(false);
    }
  }

  if (resuming || redirectingMsg) {
    return (
      <div className="min-h-screen bg-surface-muted flex items-center justify-center p-6">
        <div className="card-surface p-8 text-center space-y-2.5 max-w-sm w-full">
          <div className="mx-auto h-7 w-7 rounded-full border-2 border-teal border-t-transparent animate-spin" />
          <p className="font-heading text-sm font-bold text-navy">
            {redirectingMsg || 'Opening Your Portal…'}
          </p>
          <p className="text-xs text-slate-500">Connecting your secure clinic session</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-surface-muted flex flex-col justify-center py-10 px-4 sm:px-6">
      <div className="mx-auto w-full max-w-md space-y-5">
        {/* Header */}
        <div className="text-center space-y-2">
          <Link href="/" className="inline-flex items-center gap-2.5 justify-center">
            <BrandMark className="h-10 w-10" />
            <div className="text-left">
              <span className="block font-heading text-base font-bold text-navy">
                Dr. Aparna Mishra
              </span>
              <span className="block text-[11px] text-slate-500">
                BHMS · Online Clinic · +91 8123108149
              </span>
            </div>
          </Link>
          <h1 className="text-2xl font-bold text-navy pt-1">
            {mode === 'SIGNUP' ? 'Create Your Clinic Account' : 'Sign In to Clinic Portal'}
          </h1>
          <p className="text-xs text-slate-500">
            Sign in with Google in one click (no password needed) or use your Gmail &amp; password
          </p>
        </div>

        {/* Context Banner if coming from Live Video / Audio Call button */}
        {isCallRedirect && (
          <div className="rounded-2xl bg-navy px-4 py-3.5 text-white flex items-center gap-3 text-xs shadow-sm">
            <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-teal text-white">
              {isAudioRedirect ? <PhoneCall className="h-4 w-4" /> : <Video className="h-4 w-4" />}
            </span>
            <div>
              <p className="font-semibold">
                {isAudioRedirect ? 'Live Audio Call Ready' : 'Live HD Video Call Ready'}
              </p>
              <p className="text-[11px] text-teal-200">
                Sign in below and your private call with Dr. Aparna Mishra (+91 8123108149) opens immediately.
              </p>
            </div>
          </div>
        )}

        <div className="card-surface p-6 sm:p-7 space-y-5">
          {/* Active Session Banner (if already signed in) */}
          {existingSession && (
            <div className="rounded-xl bg-aqua border border-teal/35 p-3.5 space-y-2.5 text-xs">
              <div className="flex items-center justify-between gap-3">
                <div className="min-w-0">
                  <p className="font-semibold text-navy truncate">
                    Signed in as {existingSession.fullName}
                  </p>
                  <p className="text-[11px] text-slate-600 truncate">{existingSession.email}</p>
                </div>
                <button
                  type="button"
                  onClick={() =>
                    navigateAfterLogin(
                      ['DOCTOR', 'ADMIN', 'STAFF'].includes(existingSession.role)
                        ? '/admin'
                        : '/portal',
                      existingSession.role,
                      getClientSessionToken() || undefined
                    )
                  }
                  className="btn-primary py-2 px-3.5 text-xs shrink-0"
                >
                  Continue →
                </button>
              </div>
              <button
                type="button"
                onClick={handleSwitchAccount}
                className="inline-flex items-center gap-1 text-[11px] font-medium text-slate-500 hover:text-rose-600"
              >
                <LogOut className="h-3 w-3" /> Sign out &amp; use another account
              </button>
            </div>
          )}

          {/* PRIMARY: 1-Click Passwordless Sign in with Google */}
          <GoogleSignInButton
            label="Sign in with Google"
            sublabel="Instant sign-in · No password required"
            nextPath={nextPath}
            autoOpen={autoOpenGoogle}
            onSuccess={(u, redirectTo, tok) => navigateAfterLogin(redirectTo, u.role, tok)}
            onError={(msg) => setError(msg)}
          />

          <div className="relative flex items-center py-0.5">
            <div className="flex-grow border-t border-slate-200" />
            <span className="mx-3 shrink-0 text-[11px] font-medium uppercase tracking-wider text-slate-400">
              or use email &amp; password
            </span>
            <div className="flex-grow border-t border-slate-200" />
          </div>

          {/* 2 Clean Tabs: Gmail Login | Create Account (No OTP) */}
          <div className="grid grid-cols-2 rounded-xl bg-surface-muted p-1 border border-slate-200 gap-1">
            <button
              type="button"
              onClick={() => {
                setMode('GMAIL_PASSWORD');
                resetMessages();
              }}
              className={`inline-flex items-center justify-center gap-1.5 rounded-lg py-2 text-xs font-semibold transition-colors ${
                mode === 'GMAIL_PASSWORD'
                  ? 'bg-white text-navy shadow-sm'
                  : 'text-slate-500 hover:text-navy'
              }`}
            >
              <Mail className="h-3.5 w-3.5 text-teal" /> Gmail &amp; Password
            </button>
            <button
              type="button"
              onClick={() => {
                setMode('SIGNUP');
                resetMessages();
              }}
              className={`inline-flex items-center justify-center gap-1.5 rounded-lg py-2 text-xs font-semibold transition-colors ${
                mode === 'SIGNUP'
                  ? 'bg-white text-navy shadow-sm'
                  : 'text-slate-500 hover:text-navy'
              }`}
            >
              <UserPlus className="h-3.5 w-3.5 text-teal" /> Create Account
            </button>
          </div>

          {/* Error Notice */}
          {error && (
            <div className="rounded-xl border border-rose-200 bg-rose-50 p-3.5 text-xs text-rose-700">
              <p className="font-medium">{error}</p>
            </div>
          )}

          {/* TAB 1: GMAIL & PASSWORD SIGN IN */}
          {mode === 'GMAIL_PASSWORD' && (
            <form onSubmit={handleGmailPasswordLogin} className="space-y-4">
              <div>
                <label className="label-text">Gmail / Email Address</label>
                <input
                  type="email"
                  required
                  autoComplete="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="yourname@gmail.com"
                  className="input-field"
                />
              </div>

              <div>
                <label className="label-text">Password</label>
                <div className="relative">
                  <input
                    type={showPass ? 'text' : 'password'}
                    required
                    minLength={6}
                    autoComplete="current-password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Enter your password (min. 6 chars)"
                    className="input-field pr-10"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPass((v) => !v)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-navy"
                    aria-label={showPass ? 'Hide password' : 'Show password'}
                  >
                    {showPass ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
              </div>

              <button type="submit" disabled={loading} className="btn-primary w-full py-3">
                <Lock className="h-4 w-4" />
                {loading ? 'Signing In…' : 'Sign In'}
              </button>
            </form>
          )}

          {/* TAB 2: CREATE NEW GMAIL & PASSWORD ACCOUNT */}
          {mode === 'SIGNUP' && (
            <form onSubmit={handleQuickGmailSignup} className="space-y-3.5">
              <div>
                <label className="label-text">Full Name *</label>
                <input
                  type="text"
                  required
                  value={regName}
                  onChange={(e) => setRegName(e.target.value)}
                  placeholder="Your full name"
                  className="input-field"
                />
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="label-text">Gmail Address *</label>
                  <input
                    type="email"
                    required
                    value={regEmail}
                    onChange={(e) => setRegEmail(e.target.value)}
                    placeholder="yourname@gmail.com"
                    className="input-field"
                  />
                </div>
                <div>
                  <label className="label-text">Mobile (Optional)</label>
                  <input
                    type="tel"
                    value={regPhone}
                    onChange={(e) => setRegPhone(e.target.value)}
                    placeholder="10-digit WhatsApp no."
                    className="input-field"
                  />
                </div>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="label-text">Create Password *</label>
                  <input
                    type="password"
                    required
                    minLength={6}
                    value={regPassword}
                    onChange={(e) => setRegPassword(e.target.value)}
                    placeholder="Min. 6 characters"
                    className="input-field"
                  />
                </div>
                <div>
                  <label className="label-text">Confirm Password *</label>
                  <input
                    type="password"
                    required
                    minLength={6}
                    value={regConfirm}
                    onChange={(e) => setRegConfirm(e.target.value)}
                    placeholder="Re-enter password"
                    className="input-field"
                  />
                </div>
              </div>

              <button type="submit" disabled={loading} className="btn-primary w-full py-3">
                <UserPlus className="h-4 w-4" />
                {loading ? 'Creating Account…' : 'Create Account & Sign In'}
              </button>
            </form>
          )}

          <div className="pt-1 flex items-center justify-center gap-1.5 text-[11px] text-slate-500">
            <ShieldCheck className="h-3.5 w-3.5 text-teal shrink-0" />
            <span>Encrypted Session · Role-Based Access · DPDP Protected</span>
          </div>
        </div>

        {/* One-Click Role Preview Switcher */}
        <div className="rounded-2xl border border-slate-200 bg-white p-5 space-y-3">
          <div className="flex items-center justify-between">
            <p className="text-xs font-bold text-navy uppercase tracking-wider">
              1-Click Demo Role Access
            </p>
            <span className="rounded-full bg-aqua px-2.5 py-0.5 text-[10px] font-semibold text-teal">
              Instant Open
            </span>
          </div>
          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              disabled={loading}
              onClick={() => quickDemoSignIn('DOCTOR')}
              className="flex items-center gap-2 rounded-xl border border-teal/30 bg-aqua/60 px-3 py-2.5 text-left text-xs font-semibold text-navy hover:bg-aqua transition-colors disabled:opacity-60"
            >
              <Stethoscope className="h-4 w-4 text-teal shrink-0" />
              <div className="min-w-0">
                <p className="truncate">Dr. Aparna Mishra</p>
                <p className="text-[10px] text-slate-500 font-normal">Doctor Console</p>
              </div>
            </button>
            <button
              type="button"
              disabled={loading}
              onClick={() => quickDemoSignIn('PATIENT')}
              className="flex items-center gap-2 rounded-xl border border-slate-200 px-3 py-2.5 text-left text-xs font-semibold text-navy hover:border-teal hover:bg-aqua/50 transition-colors disabled:opacity-60"
            >
              <UserCheck className="h-4 w-4 text-teal shrink-0" />
              <div className="min-w-0">
                <p className="truncate">Patient Portal</p>
                <p className="text-[10px] text-slate-500 font-normal">Ananya (Demo)</p>
              </div>
            </button>
            <button
              type="button"
              disabled={loading}
              onClick={() => quickDemoSignIn('STAFF')}
              className="flex items-center gap-2 rounded-xl border border-slate-200 px-3 py-2.5 text-left text-xs font-semibold text-navy hover:border-teal hover:bg-aqua/50 transition-colors disabled:opacity-60"
            >
              <ShieldCheck className="h-4 w-4 text-teal shrink-0" />
              <div className="min-w-0">
                <p className="truncate">Staff Console</p>
                <p className="text-[10px] text-slate-500 font-normal">Coordinator</p>
              </div>
            </button>
            <button
              type="button"
              disabled={loading}
              onClick={() => quickDemoSignIn('GUARDIAN')}
              className="flex items-center gap-2 rounded-xl border border-slate-200 px-3 py-2.5 text-left text-xs font-semibold text-navy hover:border-teal hover:bg-aqua/50 transition-colors disabled:opacity-60"
            >
              <Users className="h-4 w-4 text-teal shrink-0" />
              <div className="min-w-0">
                <p className="truncate">Parent / Guardian</p>
                <p className="text-[10px] text-slate-500 font-normal">Minor Booking</p>
              </div>
            </button>
          </div>
          <p className="text-[10.5px] text-slate-400 leading-relaxed">
            Demo passwords — Doctor (<span className="font-mono">aparnabhms@gmail.com</span>):{' '}
            <span className="font-mono text-slate-600">Doctor@2026!</span> · Patient:{' '}
            <span className="font-mono text-slate-600">Patient@2026!</span>
          </p>
        </div>

        <div className="text-center">
          <Link
            href="/"
            className="inline-flex items-center gap-1.5 text-xs font-medium text-slate-500 hover:text-navy"
          >
            <ArrowLeft className="h-3.5 w-3.5" /> Back to Clinic Homepage
          </Link>
        </div>
      </div>
    </div>
  );
}

export default function LoginPage() {
  return (
    <Suspense
      fallback={
        <div className="min-h-screen bg-surface-muted flex items-center justify-center text-sm text-slate-500">
          Loading sign-in…
        </div>
      }
    >
      <LoginInner />
    </Suspense>
  );
}
