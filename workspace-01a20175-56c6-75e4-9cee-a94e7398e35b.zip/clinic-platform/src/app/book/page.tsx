import React from 'react';
import PublicShell from '@/components/PublicShell';
import BookingFlow, { ConsultationTypeOption } from '@/components/BookingFlow';
import { getPublicShellContext } from '@/lib/publicData';
import { getDb } from '@/lib/db';

export const dynamic = 'force-dynamic';

export default async function BookPage({
  searchParams,
}: {
  searchParams?: { concern?: string; type?: string; _st?: string };
}) {
  const ctx = await getPublicShellContext(searchParams?._st);
  const db = getDb();
  const consultationTypes = db
    .prepare('SELECT * FROM consultation_types WHERE is_active = 1 ORDER BY sort_order ASC')
    .all() as ConsultationTypeOption[];

  return (
    <PublicShell
      announcement={ctx.announcement}
      user={ctx.user}
      doctor={ctx.doctor}
      chatbotWelcome={ctx.chatbotWelcome}
    >
      <section className="bg-surface-muted min-h-[calc(100vh-140px)] py-10 sm:py-14">
        <div className="clinic-container max-w-4xl">
          <div className="mb-7">
            <p className="text-xs font-semibold uppercase tracking-widest text-teal mb-1">
              Online Appointment Booking
            </p>
            <h1 className="text-2xl sm:text-3xl font-bold text-navy">
              Book Consultation with {ctx.doctor.display_name}
            </h1>
            <p className="text-sm text-slate-600 mt-1">
              BHMS · {ctx.doctor.experience_years} Years Experience · Monday to Saturday, 3:00 PM – 8:00 PM IST · Instant Reference Number
            </p>
          </div>

          <BookingFlow
            consultationTypes={consultationTypes}
            initialConcern={searchParams?.concern}
            initialTypeId={searchParams?.type}
            sessionToken={ctx.sessionToken}
            initialUser={
              ctx.user
                ? { fullName: ctx.user.fullName, email: ctx.user.email, role: ctx.user.role }
                : null
            }
          />
        </div>
      </section>
    </PublicShell>
  );
}
