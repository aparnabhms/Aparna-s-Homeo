import React from 'react';
import Link from 'next/link';
import { ArrowRight, Calendar, CheckCircle2, Clock, Info } from 'lucide-react';
import PublicShell from '@/components/PublicShell';
import { ServiceIllustration } from '@/components/MedicalIcons';
import { getPublicShellContext } from '@/lib/publicData';
import { getDb } from '@/lib/db';

export const dynamic = 'force-dynamic';

export default async function ServicesPage() {
  const ctx = await getPublicShellContext();
  const db = getDb();

  const services = db
    .prepare('SELECT * FROM medical_services WHERE is_active = 1 ORDER BY sort_order ASC')
    .all() as Array<{
    id: string;
    slug: string;
    title: string;
    short_description: string;
    full_description: string;
    conditions_json: string;
    icon_key: string;
  }>;

  const consultationTypes = db
    .prepare('SELECT * FROM consultation_types WHERE is_active = 1 ORDER BY sort_order ASC')
    .all() as Array<{
    id: string;
    name: string;
    description: string;
    mode: string;
    duration_minutes: number;
    fee_inr: number;
  }>;

  return (
    <PublicShell
      announcement={ctx.announcement}
      user={ctx.user}
      doctor={ctx.doctor}
      chatbotWelcome={ctx.chatbotWelcome}
    >
      <section className="bg-aqua/65 border-b border-slate-200/70 py-12 sm:py-16">
        <div className="clinic-container max-w-4xl text-center space-y-3">
          <p className="text-xs font-semibold uppercase tracking-widest text-teal">
            Medical Services & Areas of Consultation
          </p>
          <h1 className="text-3xl sm:text-4xl font-bold text-navy">
            Comprehensive Online Homoeopathic & Wellness Care
          </h1>
          <p className="text-sm sm:text-base text-slate-600 max-w-2xl mx-auto">
            Individualized online consultations with Dr. Aparna Mishra (BHMS, 7 years experience) — available Monday to Saturday, 3:00 PM to 8:00 PM IST.
          </p>
        </div>
      </section>

      <section className="py-14 sm:py-18 bg-white">
        <div className="clinic-container space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {services.map((svc) => {
              const items = JSON.parse(svc.conditions_json) as string[];
              return (
                <div key={svc.id} className="card-surface p-6 sm:p-7 flex flex-col justify-between">
                  <div>
                    <div className="flex items-start gap-4 mb-4">
                      <ServiceIllustration iconKey={svc.icon_key} className="h-14 w-14 shrink-0" />
                      <div>
                        <h2 className="text-xl font-bold text-navy">{svc.title}</h2>
                        <p className="text-xs font-semibold text-teal mt-0.5">
                          {svc.short_description}
                        </p>
                      </div>
                    </div>
                    <p className="text-sm text-slate-600 leading-relaxed mb-4">
                      {svc.full_description}
                    </p>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mb-6">
                      {items.map((cond) => (
                        <div key={cond} className="flex items-center gap-2 text-xs text-slate-700">
                          <CheckCircle2 className="h-3.5 w-3.5 text-teal shrink-0" />
                          <span>{cond}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                  <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
                    <span className="text-xs text-slate-500">Online Video / Audio</span>
                    <Link
                      href={`/book?concern=${encodeURIComponent(svc.title)}`}
                      className="btn-primary py-2 px-4 text-xs"
                    >
                      Book Consultation <ArrowRight className="h-3.5 w-3.5" />
                    </Link>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Scope & Referral Notice */}
          <div className="rounded-2xl bg-aqua border border-teal/20 p-5 flex items-start gap-3 text-xs sm:text-sm text-navy">
            <Info className="h-5 w-5 text-teal shrink-0 mt-0.5" />
            <p>
              <strong>Clinical Evaluation & Referral Guidance:</strong> Online consultations are meant for non-emergency health guidance and chronic follow-up care. Where physical examination, diagnostic investigation, specialist intervention, or emergency treatment is necessary, immediate medical evaluation and referral will be advised.
            </p>
          </div>
        </div>
      </section>

      {/* Consultation Fee Table */}
      <section className="py-14 bg-surface-muted border-t border-slate-200/70">
        <div className="clinic-container">
          <h2 className="text-2xl font-bold text-navy mb-6">Consultation Formats & Fees</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
            {consultationTypes.map((ct) => (
              <div key={ct.id} className="card-surface p-6 flex flex-col justify-between">
                <div>
                  <span className="inline-flex items-center gap-1 rounded-full bg-aqua px-2.5 py-1 text-[11px] font-semibold text-navy mb-3 tabular">
                    <Clock className="h-3 w-3 text-teal" /> {ct.duration_minutes} Minutes
                  </span>
                  <h3 className="text-base font-bold text-navy mb-2">{ct.name}</h3>
                  <p className="text-xs text-slate-600 leading-relaxed mb-4">{ct.description}</p>
                </div>
                <div>
                  <p className="font-heading text-2xl font-bold text-navy tabular mb-3">
                    ₹{ct.fee_inr}
                  </p>
                  <Link href={`/book?type=${ct.id}`} className="btn-navy w-full text-xs py-2.5">
                    <Calendar className="h-3.5 w-3.5" /> Book This Option
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </PublicShell>
  );
}
