import React from 'react';
import { redirect } from 'next/navigation';
import { getSessionWithToken } from '@/lib/auth';
import AdminDashboardClient from '@/components/AdminDashboardClient';

export const dynamic = 'force-dynamic';

export default async function AdminDashboardPage({
  searchParams,
}: {
  searchParams?: { tab?: string; _st?: string };
}) {
  const session = await getSessionWithToken(searchParams?._st);
  if (!session) redirect('/login?next=/admin&autoresume=1');
  const { user, token } = session;

  if (!['DOCTOR', 'ADMIN', 'STAFF'].includes(user.role)) {
    redirect(`/portal?_st=${encodeURIComponent(token)}`);
  }

  return (
    <AdminDashboardClient
      initialTab={searchParams?.tab || 'overview'}
      sessionToken={token}
      sessionUser={{
        id: user.id,
        fullName: user.fullName,
        email: user.email,
        role: user.role,
      }}
    />
  );
}
