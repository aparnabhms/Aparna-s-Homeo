import React from 'react';
import Link from 'next/link';
import PublicShell from '@/components/PublicShell';
import FaqAccordion, { FaqItem } from '@/components/FaqAccordion';
import { getPublicShellContext } from '@/lib/publicData';
import { getDb } from '@/lib/db';

export const dynamic = 'force-dynamic';

export default async function FaqPage() {
  const ctx = await getPublicShellContext();
  const db = getDb();
  const faqs = db
    .prepare('SELECT id, category, question, answer FROM faqs WHERE is_active = 1 ORDER BY sort_order ASC')
    .all() as FaqItem[];

  return (
    <PublicShell
      announcement={ctx.announcement}
      user={ctx.user}
      doctor={ctx.doctor}
      chatbotWelcome={ctx.chatbotWelcome}
    >
      <section className="bg-aqua/65 border-b border-slate-200/70 py-12 sm:py-16">
        <div className="clinic-container max-w-3xl text-center space-y-3">
          <p className="text-xs font-semibold uppercase tracking-widest text-teal">
            Patient Help Centre
          </p>
          <h1 className="text-3xl sm:text-4xl font-bold text-navy">
            Frequently Asked Questions
          </h1>
          <p className="text-sm sm:text-base text-slate-600">
            Clear answers about booking slots (3:00 PM – 8:00 PM, Mon–Sat), online consultations, payment options, prescriptions, reports, and data privacy.
          </p>
        </div>
      </section>

      <section className="py-12 sm:py-16 bg-white">
        <div className="clinic-container max-w-3xl space-y-10">
          <FaqAccordion faqs={faqs} searchable />

          <div className="rounded-2xl bg-surface-muted border border-slate-200 p-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div>
              <h2 className="font-heading text-base font-bold text-navy">Still have a question?</h2>
              <p className="text-xs text-slate-600 mt-0.5">
                Reach our clinic support team directly on {ctx.doctor.phone} or {ctx.doctor.email}.
              </p>
            </div>
            <Link href="/contact" className="btn-primary text-xs shrink-0">
              Contact Clinic Desk
            </Link>
          </div>
        </div>
      </section>
    </PublicShell>
  );
}
