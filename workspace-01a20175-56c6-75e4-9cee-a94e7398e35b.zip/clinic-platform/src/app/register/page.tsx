'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { ArrowLeft, ShieldCheck, UserPlus } from 'lucide-react';
import { BrandMark } from '@/components/MedicalIcons';
import GoogleSignInButton from '@/components/GoogleSignInButton';
import { navigateWithSession } from '@/lib/clientSession';

export default function RegisterPage() {
  const [isMinorAccount, setIsMinorAccount] = useState(false);
  const [form, setForm] = useState({
    fullName: '',
    email: '',
    phone: '',
    password: '',
    dateOfBirth: '',
    gender: 'Female',
    bloodGroup: '',
    city: '',
    state: '',
    guardianRelation: 'Mother (Legal Guardian)',
    minorPatientName: '',
    minorDateOfBirth: '',
    dpdpConsent: true,
    telemedicineConsent: true,
    whatsappConsent: true,
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError('');
    try {
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...form, isMinorAccount }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || 'Registration failed.');
        return;
      }
      navigateWithSession('/portal', data.sessionToken);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen bg-surface-muted py-10 px-4 sm:px-6">
      <div className="mx-auto max-w-2xl space-y-6">
        <div className="text-center space-y-2">
          <Link href="/" className="inline-flex items-center gap-2.5 justify-center">
            <BrandMark className="h-10 w-10" />
            <div className="text-left">
              <span className="block font-heading text-base font-bold text-navy">
                Dr. Aparna Mishra
              </span>
              <span className="block text-[11px] text-slate-500">
                BHMS · Patient Registration
              </span>
            </div>
          </Link>
          <h1 className="text-2xl sm:text-3xl font-bold text-navy pt-2">
            Create Your Secure Patient Account
          </h1>
          <p className="text-xs sm:text-sm text-slate-500">
            Sign up in one click with Google (no password needed) or register below to book online consultations (Mon–Sat, 3:00 PM – 8:00 PM), chat live, and join Audio/Video calls on +91 8123108149.
          </p>
        </div>

        <div className="card-surface p-6 sm:p-8 space-y-5">
          {/* Passwordless Sign up with Google */}
          <div className="max-w-md mx-auto">
            <GoogleSignInButton
              label="Sign up with Google"
              sublabel="Create & access your clinic account instantly — no password required"
              onSuccess={(_u, redirectTo, tok) => {
                navigateWithSession(redirectTo || '/portal', tok);
              }}
              onError={(msg) => setError(msg)}
            />
          </div>

          <div className="relative flex items-center">
            <div className="flex-grow border-t border-slate-200" />
            <span className="mx-3 shrink-0 text-[11px] font-medium uppercase tracking-wider text-slate-400">
              or register with email &amp; password
            </span>
            <div className="flex-grow border-t border-slate-200" />
          </div>

        <form onSubmit={handleSubmit} className="space-y-5">
          {/* Adult vs Parent/Guardian Toggle */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 rounded-xl bg-surface-muted p-1.5 border border-slate-200">
            <button
              type="button"
              onClick={() => setIsMinorAccount(false)}
              className={`rounded-lg py-2.5 px-3 text-xs font-semibold transition-colors ${
                !isMinorAccount ? 'bg-white text-navy shadow-sm' : 'text-slate-500'
              }`}
            >
              Adult Patient Account (18+)
            </button>
            <button
              type="button"
              onClick={() => setIsMinorAccount(true)}
              className={`rounded-lg py-2.5 px-3 text-xs font-semibold transition-colors ${
                isMinorAccount ? 'bg-white text-navy shadow-sm' : 'text-slate-500'
              }`}
            >
              Parent / Legal Guardian (for Minor)
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="label-text">
                {isMinorAccount ? 'Parent / Legal Guardian Full Name *' : 'Full Name *'}
              </label>
              <input
                type="text"
                required
                value={form.fullName}
                onChange={(e) => setForm({ ...form, fullName: e.target.value })}
                placeholder="Enter full name"
                className="input-field"
              />
            </div>
            <div>
              <label className="label-text">Mobile / WhatsApp Number *</label>
              <input
                type="tel"
                required
                value={form.phone}
                onChange={(e) => setForm({ ...form, phone: e.target.value })}
                placeholder="10-digit Indian mobile number"
                className="input-field tabular"
              />
            </div>
            <div>
              <label className="label-text">Email Address *</label>
              <input
                type="email"
                required
                value={form.email}
                onChange={(e) => setForm({ ...form, email: e.target.value })}
                placeholder="you@example.com"
                className="input-field"
              />
            </div>
            <div>
              <label className="label-text">Create Password * (min. 8 chars)</label>
              <input
                type="password"
                required
                minLength={8}
                value={form.password}
                onChange={(e) => setForm({ ...form, password: e.target.value })}
                placeholder="Strong password"
                className="input-field"
              />
            </div>
          </div>

          {/* Minor Child Section */}
          {isMinorAccount && (
            <div className="rounded-2xl bg-aqua/70 border border-teal/25 p-4 space-y-3">
              <p className="text-xs font-bold text-navy">Minor Patient Details</p>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="label-text">Minor’s Full Name *</label>
                  <input
                    type="text"
                    required
                    value={form.minorPatientName}
                    onChange={(e) => setForm({ ...form, minorPatientName: e.target.value })}
                    placeholder="Child’s name"
                    className="input-field"
                  />
                </div>
                <div>
                  <label className="label-text">Minor’s Date of Birth</label>
                  <input
                    type="date"
                    value={form.minorDateOfBirth}
                    onChange={(e) => setForm({ ...form, minorDateOfBirth: e.target.value })}
                    className="input-field"
                  />
                </div>
                <div>
                  <label className="label-text">Guardian Relationship *</label>
                  <select
                    value={form.guardianRelation}
                    onChange={(e) => setForm({ ...form, guardianRelation: e.target.value })}
                    className="input-field"
                  >
                    <option>Mother (Legal Guardian)</option>
                    <option>Father (Legal Guardian)</option>
                    <option>Court-Appointed Legal Guardian</option>
                  </select>
                </div>
              </div>
            </div>
          )}

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div>
              <label className="label-text">Date of Birth</label>
              <input
                type="date"
                value={form.dateOfBirth}
                onChange={(e) => setForm({ ...form, dateOfBirth: e.target.value })}
                className="input-field"
              />
            </div>
            <div>
              <label className="label-text">Gender</label>
              <select
                value={form.gender}
                onChange={(e) => setForm({ ...form, gender: e.target.value })}
                className="input-field"
              >
                <option>Female</option>
                <option>Male</option>
                <option>Other</option>
                <option>Prefer not to say</option>
              </select>
            </div>
            <div>
              <label className="label-text">Blood Group</label>
              <select
                value={form.bloodGroup}
                onChange={(e) => setForm({ ...form, bloodGroup: e.target.value })}
                className="input-field"
              >
                <option value="">Select</option>
                {['A+', 'A-', 'B+', 'B-', 'O+', 'O-', 'AB+', 'AB-'].map((bg) => (
                  <option key={bg} value={bg}>
                    {bg}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="label-text">City</label>
              <input
                type="text"
                value={form.city}
                onChange={(e) => setForm({ ...form, city: e.target.value })}
                placeholder="e.g. Patna"
                className="input-field"
              />
            </div>
          </div>

          {/* Mandatory DPDP & Telemedicine Consents */}
          <div className="rounded-xl bg-surface-muted p-4 space-y-2.5 text-xs text-slate-600">
            <label className="flex items-start gap-2.5 cursor-pointer">
              <input
                type="checkbox"
                required
                checked={form.dpdpConsent}
                onChange={(e) => setForm({ ...form, dpdpConsent: e.target.checked })}
                className="mt-0.5 h-4 w-4 rounded border-slate-300 text-teal"
              />
              <span>
                <strong>DPDP Act 2023 Privacy Consent *:</strong> I consent to the secure processing and storage of my health profile and consultation records strictly for clinical care.
              </span>
            </label>
            <label className="flex items-start gap-2.5 cursor-pointer">
              <input
                type="checkbox"
                required
                checked={form.telemedicineConsent}
                onChange={(e) => setForm({ ...form, telemedicineConsent: e.target.checked })}
                className="mt-0.5 h-4 w-4 rounded border-slate-300 text-teal"
              />
              <span>
                <strong>Telemedicine Consent *:</strong> I understand online consultations are for non-emergency care{isMinorAccount ? ' and confirm I am the verified legal guardian of the minor patient' : ''}.
              </span>
            </label>
            <label className="flex items-start gap-2.5 cursor-pointer">
              <input
                type="checkbox"
                checked={form.whatsappConsent}
                onChange={(e) => setForm({ ...form, whatsappConsent: e.target.checked })}
                className="mt-0.5 h-4 w-4 rounded border-slate-300 text-teal"
              />
              <span>
                Receive privacy-safe appointment & payment updates via official WhatsApp & Email.
              </span>
            </label>
          </div>

          {error && (
            <div className="rounded-xl border border-rose-200 bg-rose-50 p-3 text-xs font-medium text-rose-700">
              {error}
            </div>
          )}

          <button type="submit" disabled={loading} className="btn-primary w-full py-3.5">
            <UserPlus className="h-4 w-4" />
            {loading ? 'Creating Secure Account…' : 'Complete Patient Registration'}
          </button>

          <div className="flex flex-wrap items-center justify-between gap-2 pt-2 text-xs text-slate-500">
            <span>
              Already have an account?{' '}
              <Link href="/login" className="font-semibold text-teal hover:underline">
                Sign In with Google or Email
              </Link>
            </span>
            <span className="inline-flex items-center gap-1 text-navy font-medium">
              <ShieldCheck className="h-3.5 w-3.5 text-teal" /> Bcrypt + TLS Protected
            </span>
          </div>
        </form>
        </div>

        <div className="text-center">
          <Link
            href="/"
            className="inline-flex items-center gap-1.5 text-xs font-medium text-slate-500 hover:text-navy"
          >
            <ArrowLeft className="h-3.5 w-3.5" /> Back to Homepage
          </Link>
        </div>
      </div>
    </div>
  );
}
