import React from 'react';
import Link from 'next/link';
import { AlertTriangle, Clock, Mail, MessageCircle, MessageSquare, Phone, Video } from 'lucide-react';
import PublicShell from '@/components/PublicShell';
import { ContactForm, FeedbackForm } from '@/components/ContactFeedbackForms';
import { getPublicShellContext } from '@/lib/publicData';

export const dynamic = 'force-dynamic';

export default async function ContactPage() {
  const ctx = await getPublicShellContext();
  const { doctor, user } = ctx;

  return (
    <PublicShell
      announcement={ctx.announcement}
      user={user}
      doctor={doctor}
      chatbotWelcome={ctx.chatbotWelcome}
    >
      <section className="bg-aqua/65 border-b border-slate-200/70 py-12 sm:py-16">
        <div className="clinic-container max-w-4xl text-center space-y-3">
          <p className="text-xs font-semibold uppercase tracking-widest text-teal">
            Get in Touch
          </p>
          <h1 className="text-3xl sm:text-4xl font-bold text-navy">Contact Us</h1>
          <p className="text-sm sm:text-base text-slate-600 max-w-2xl mx-auto">
            Connect with {doctor.display_name}’s online consultation desk for appointment assistance, payment support, or portal queries.
          </p>
        </div>
      </section>

      <section className="py-14 bg-white">
        <div className="clinic-container grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Direct Contact Cards */}
          <div className="lg:col-span-5 space-y-4">
            <div className="card-surface p-6 space-y-4">
              <h2 className="text-lg font-bold text-navy">Direct Clinic Details</h2>
              <div className="space-y-3.5 text-sm">
                <div className="flex items-start gap-3">
                  <Phone className="h-4 w-4 text-teal mt-1 shrink-0" />
                  <div>
                    <p className="text-xs text-slate-500">Direct Audio Calling Line</p>
                    <a
                      href="tel:+918123108149"
                      className="font-semibold text-navy hover:text-teal tabular"
                    >
                      {doctor.phone} (Tap to Call)
                    </a>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <Video className="h-4 w-4 text-teal mt-1 shrink-0" />
                  <div>
                    <p className="text-xs text-slate-500">Video &amp; Audio Calling (+91 8123108149)</p>
                    <div className="flex flex-wrap gap-2 mt-1">
                      <Link
                        href="/portal?tab=video&start=VIDEO"
                        className="inline-flex items-center gap-1 rounded-lg bg-teal px-2.5 py-1 text-xs font-semibold text-white hover:bg-teal-600 transition-colors"
                      >
                        Start Live Video Call
                      </Link>
                      <Link
                        href="/portal?tab=video&start=AUDIO"
                        className="inline-flex items-center gap-1 rounded-lg bg-navy px-2.5 py-1 text-xs font-semibold text-white hover:bg-navy-600 transition-colors"
                      >
                        Start Live Audio Call
                      </Link>
                      <a
                        href={`https://wa.me/${doctor.whatsapp_number}?text=${encodeURIComponent(
                          'Namaste Dr. Aparna Mishra, requesting to connect for Online Video Consultation.'
                        )}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1 rounded-lg bg-emerald-50 border border-emerald-200 px-2.5 py-1 text-xs font-semibold text-emerald-800 hover:bg-emerald-100"
                      >
                        WhatsApp Call
                      </a>
                    </div>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <MessageCircle className="h-4 w-4 text-teal mt-1 shrink-0" />
                  <div>
                    <p className="text-xs text-slate-500">Live Chat &amp; WhatsApp (+91 8123108149)</p>
                    <div className="flex flex-wrap gap-2 mt-1">
                      <a
                        href={`https://wa.me/${doctor.whatsapp_number}?text=${encodeURIComponent(
                          'Namaste Dr. Aparna Mishra, I have a query regarding an online consultation.'
                        )}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="font-semibold text-xs text-teal hover:underline"
                      >
                        WhatsApp Chat (+91 8123108149)
                      </a>
                      <span className="text-slate-300">·</span>
                      <Link
                        href="/portal?tab=chat"
                        className="inline-flex items-center gap-1 font-semibold text-xs text-navy hover:text-teal"
                      >
                        <MessageSquare className="h-3 w-3 text-teal" /> Live Portal Chat
                      </Link>
                    </div>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <Mail className="h-4 w-4 text-teal mt-1 shrink-0" />
                  <div>
                    <p className="text-xs text-slate-500">Professional Email</p>
                    <a
                      href={`mailto:${doctor.email}`}
                      className="font-semibold text-navy hover:text-teal break-all"
                    >
                      {doctor.email}
                    </a>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <Clock className="h-4 w-4 text-teal mt-1 shrink-0" />
                  <div>
                    <p className="text-xs text-slate-500">Online Consultation Hours</p>
                    <p className="font-semibold text-navy">Monday – Saturday · 3:00 PM – 8:00 PM</p>
                    <p className="text-xs text-slate-500">Appointment strictly by prior booking · Sunday Closed</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="rounded-2xl border border-rose-200 bg-rose-50/70 p-5 flex items-start gap-3 text-xs text-rose-900">
              <AlertTriangle className="h-5 w-5 text-rose-600 shrink-0 mt-0.5" />
              <div>
                <p className="font-bold mb-1">Medical Emergency Helpline</p>
                <p className="leading-relaxed">
                  Do not use this form or WhatsApp for urgent medical symptoms. Visit the nearest hospital emergency department immediately or dial <strong>112</strong> / Ambulance <strong>108</strong>.
                </p>
              </div>
            </div>
          </div>

          {/* Enquiry Form + Feedback */}
          <div className="lg:col-span-7 space-y-8">
            <div className="card-surface p-6 sm:p-8">
              <h2 className="text-xl font-bold text-navy mb-1">Send an Enquiry</h2>
              <p className="text-xs text-slate-500 mb-6">
                Every enquiry generates a tracked support ticket reviewed by our clinic coordinator.
              </p>
              <ContactForm
                defaultName={user?.fullName || ''}
                defaultEmail={user?.email || ''}
                defaultPhone={user?.phone || ''}
              />
            </div>

            <div className="card-surface p-6 sm:p-8">
              <h2 className="text-lg font-bold text-navy mb-1">Share Patient Feedback</h2>
              <p className="text-xs text-slate-500 mb-5">
                Help us continually improve your online clinic experience.
              </p>
              <FeedbackForm />
            </div>
          </div>
        </div>
      </section>
    </PublicShell>
  );
}
