'use client';

import React, { useEffect, useState } from 'react';
import Link from 'next/link';
import { useParams } from 'next/navigation';
import { ArrowLeft, ShieldAlert } from 'lucide-react';
import NativeWebRTCCall, { ActiveRtcSession } from '@/components/NativeWebRTCCall';
import {
  authFetch,
  buildAuthedUrl,
  getClientSessionToken,
  navigateWithSession,
  saveClientSession,
} from '@/lib/clientSession';

export default function StandaloneCallPage() {
  const params = useParams();
  const callId = String(params?.callId || '');

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [participantInfo, setParticipantInfo] = useState<{
    fullName: string;
    mode: 'PATIENT' | 'CLINIC';
    hasClinicSession: boolean;
    sessionToken?: string;
  } | null>(null);
  const [session, setSession] = useState<ActiveRtcSession | null>(null);

  useEffect(() => {
    if (!callId) return;
    let active = true;

    (async () => {
      try {
        const sp = new URLSearchParams(window.location.search);
        const roomKey = (sp.get('rk') || sp.get('jk') || sp.get('ck') || '').trim();
        const urlSt = (sp.get('_st') || '').trim();
        if (urlSt) saveClientSession(urlSt);
        const tok = getClientSessionToken(urlSt) || undefined;

        // 1. Direct cryptographic call-key join (works in new tabs & WhatsApp join links with ZERO login screen)
        if (roomKey) {
          const rtcRes = await authFetch(
            `/api/rtc?callId=${encodeURIComponent(callId)}&rk=${encodeURIComponent(roomKey)}`,
            { headers: { 'X-Call-Key': roomKey } },
            tok
          );
          const rtcData = await rtcRes.json();
          if (rtcRes.ok && rtcData?.call) {
            const pMode: 'PATIENT' | 'CLINIC' =
              rtcData.participantMode === 'CLINIC' ? 'CLINIC' : 'PATIENT';
            if (active) {
              setParticipantInfo({
                fullName: rtcData.displayName || (pMode === 'CLINIC' ? 'Dr. Aparna Mishra' : rtcData.call.patientName),
                mode: pMode,
                hasClinicSession: Boolean(tok),
                sessionToken: tok,
              });
              setSession({
                callId: rtcData.call.id,
                callType: rtcData.call.callType,
                role: rtcData.mySide,
                peerName: pMode === 'PATIENT' ? 'Dr. Aparna Mishra' : rtcData.call.patientName,
                callerKey: rtcData.call.callerKey || null,
                peerKey: rtcData.call.peerKey || null,
                roomKey,
              });
              setLoading(false);
            }
            return;
          }
        }

        // 2. Authenticated clinic session join
        const meRes = await authFetch('/api/auth/me', undefined, tok);
        const meData = meRes.ok ? await meRes.json() : null;
        if (!meData?.user) {
          window.location.assign(`/login?next=${encodeURIComponent(`/call/${callId}`)}`);
          return;
        }

        const rtcRes = await authFetch(
          `/api/rtc?callId=${encodeURIComponent(callId)}`,
          undefined,
          tok
        );
        const rtcData = await rtcRes.json();
        if (!rtcRes.ok || !rtcData?.call) {
          if (active) {
            setError(rtcData.error || 'This call session has ended or expired.');
            setLoading(false);
          }
          return;
        }

        const isPatient = meData.user.role === 'PATIENT';
        if (active) {
          setParticipantInfo({
            fullName: meData.user.fullName,
            mode: isPatient ? 'PATIENT' : 'CLINIC',
            hasClinicSession: true,
            sessionToken: tok,
          });
          setSession({
            callId: rtcData.call.id,
            callType: rtcData.call.callType,
            role: rtcData.mySide,
            peerName: isPatient ? 'Dr. Aparna Mishra' : rtcData.call.patientName,
            callerKey: rtcData.call.callerKey || null,
            peerKey: rtcData.call.peerKey || null,
          });
          setLoading(false);
        }
      } catch {
        if (active) {
          setError('Unable to connect live call room. Please check your internet connection.');
          setLoading(false);
        }
      }
    })();

    return () => {
      active = false;
    };
  }, [callId]);

  const backHref = !participantInfo?.hasClinicSession
    ? '/'
    : participantInfo.mode === 'CLINIC'
    ? '/admin?tab=chat'
    : '/portal?tab=chat';

  if (loading) {
    return (
      <div className="min-h-screen bg-navy flex items-center justify-center p-6 text-white">
        <div className="text-center space-y-3">
          <div className="mx-auto h-8 w-8 rounded-full border-2 border-teal-300 border-t-transparent animate-spin" />
          <p className="font-heading text-sm font-bold">Connecting Live Consultation Room…</p>
          <p className="text-xs text-teal-200">Dr. Aparna Mishra Digital Clinic · +91 8123108149</p>
        </div>
      </div>
    );
  }

  if (error || !session || !participantInfo) {
    return (
      <div className="min-h-screen bg-surface-muted flex items-center justify-center p-6">
        <div className="card-surface p-8 max-w-md w-full text-center space-y-4">
          <ShieldAlert className="h-9 w-9 text-teal mx-auto" />
          <h1 className="font-heading text-lg font-bold text-navy">Call Session Ended</h1>
          <p className="text-xs text-slate-600">{error || 'This call has already ended.'}</p>
          <Link
            href={
              typeof window !== 'undefined' && participantInfo?.hasClinicSession
                ? buildAuthedUrl(backHref, participantInfo.sessionToken)
                : '/'
            }
            className="btn-primary text-xs"
          >
            <ArrowLeft className="h-4 w-4" /> Return to Clinic
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-950 p-3 sm:p-4">
      <NativeWebRTCCall
        session={session}
        mode={participantInfo.mode}
        currentUserName={participantInfo.fullName}
        sessionToken={participantInfo.sessionToken}
        fullScreen
        onClose={() => {
          if (participantInfo.hasClinicSession) {
            navigateWithSession(backHref, participantInfo.sessionToken);
          } else {
            window.location.assign('/');
          }
        }}
      />
    </div>
  );
}
