# Publish Dr. Aparna Mishra's Digital Clinic Live in 2 Minutes

This gives you a **real, permanent `https://` website link** that patients can open on any phone and where Dr. Aparna receives every appointment, payment proof, live chat, and audio/video call in her Doctor Console (`/admin`).

---

## Step 1 — Upload to GitHub (Free, 1 Minute)
1. Go to **https://github.com/new** (sign in or create a free GitHub account).
2. Repository name: **`dr-aparna-mishra-clinic`** → select **Private** → click **Create repository**.
3. Click **"uploading an existing file"**, drag all files inside the `clinic-platform` folder (`src`, `public`, `database`, `package.json`, `render.yaml`, `Dockerfile`, `next.config.mjs`, etc.), and click **Commit changes**.

---

## Step 2 — One-Click Deploy on Render (Free, 1 Minute)
1. Go to **https://dashboard.render.com** → sign in with your GitHub account.
2. Click **New +** → **Blueprint** → select your **`dr-aparna-mishra-clinic`** repository.
3. Render automatically reads `render.yaml` (sets build command, start command, and generates secure `JWT_SECRET` & `FILE_ENCRYPTION_KEY`) → click **Apply**.
4. In ~2 minutes your permanent public link is ready:
   **`https://dr-aparna-mishra-clinic.onrender.com`**

*(Alternative: Go to **https://railway.app** → **New Project** → **Deploy from GitHub repo** → select `dr-aparna-mishra-clinic` — auto-deploys using the included `Dockerfile` & `railway.json`.)*

---

## Step 3 — Lock Production Security (Optional, Recommended Before Sharing Publicly)
In your Render / Railway **Environment** tab:
- Set `NEXT_PUBLIC_DEMO_MODE` = `false` (hides preview demo shortcuts on `/login`).
- Doctor login: **`aparnabhms@gmail.com`** (log in to `/admin` and update password under Profile/Security).
- Optional Google OAuth 2.0: add `GOOGLE_CLIENT_ID` & `GOOGLE_CLIENT_SECRET`.
- Optional Automatic Payment Verification: add `RAZORPAY_KEY_ID` & `RAZORPAY_KEY_SECRET`.
- Optional Custom Domain (e.g. `draparnamishra.in`): open Render → **Settings → Custom Domains** → add your domain.
