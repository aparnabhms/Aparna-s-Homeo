import type { Config } from 'tailwindcss';

const config: Config = {
  content: [
    './src/pages/**/*.{js,ts,jsx,tsx,mdx}',
    './src/components/**/*.{js,ts,jsx,tsx,mdx}',
    './src/app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      colors: {
        navy: {
          DEFAULT: '#153B5B',
          50: '#F0F5F9',
          100: '#DCE7F1',
          200: '#B8CFE3',
          300: '#89AFCE',
          400: '#5689B4',
          500: '#2E6695',
          600: '#1E4E78',
          700: '#153B5B',
          800: '#0F2B43',
          900: '#0A1D2E',
        },
        teal: {
          DEFAULT: '#168B83',
          50: '#EAF4F5',
          100: '#CEEAE8',
          200: '#9ED6D2',
          300: '#66BBB5',
          400: '#35A19A',
          500: '#168B83',
          600: '#11706A',
          700: '#0E5954',
          800: '#0B4542',
          900: '#083331',
        },
        aqua: {
          DEFAULT: '#EAF4F5',
          dark: '#D6EBED',
        },
        surface: {
          DEFAULT: '#FFFFFF',
          muted: '#F5F7FA',
        },
      },
      fontFamily: {
        heading: ['var(--font-manrope)', 'system-ui', '-apple-system', 'sans-serif'],
        sans: ['var(--font-inter)', 'system-ui', '-apple-system', 'sans-serif'],
      },
      boxShadow: {
        card: '0 2px 12px -2px rgba(21, 59, 91, 0.06), 0 1px 3px 0 rgba(21, 59, 91, 0.04)',
        elevated: '0 12px 32px -8px rgba(21, 59, 91, 0.12), 0 4px 12px -2px rgba(21, 59, 91, 0.05)',
      },
    },
  },
  plugins: [],
};

export default config;
